"""YTmation dev API — stub endpoints for the mini dashboard."""

from __future__ import annotations

import mimetypes
import re
import shutil
import subprocess
import time
import json
from pathlib import Path
from typing import Any
from urllib.parse import quote, unquote

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from Api.models import list_agent_models

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / "Backend"
CONFIG = ROOT / "Config"
CACHE = BACKEND / "Cache"
UPLOADS = CACHE / "uploads"
AGENT_OUTPUT = CACHE / "agent"
SIDEBAR_MANIFEST = CACHE / "sidebar-artifacts.json"
SIDEBAR_MAX = 40

app = FastAPI(title="YTmation API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"http://(localhost|127\.0\.0\.1|192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}):5173",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STEPS = ["script", "voice", "render", "stitch", "upload"]

PREVIEW_KINDS: dict[str, str] = {
    ".mp4": "video",
    ".webm": "video",
    ".mov": "video",
    ".mkv": "video",
    ".png": "image",
    ".jpg": "image",
    ".jpeg": "image",
    ".gif": "image",
    ".webp": "image",
    ".svg": "image",
    ".bmp": "image",
    ".ico": "image",
    ".pdf": "pdf",
    ".doc": "document",
    ".docx": "document",
    ".odt": "document",
    ".rtf": "document",
    ".txt": "text",
    ".md": "text",
    ".json": "text",
    ".csv": "text",
    ".srt": "text",
}

_job: dict[str, Any] = {
    "id": "dev-1",
    "status": "idle",
    "progress": 0,
    "message": "Waiting for a job…",
    "steps": {s: "pending" for s in STEPS},
    "started_at": None,
    "prompt": None,
    "artifact": None,
}


class PromptRequest(BaseModel):
    message: str = Field(min_length=1)
    model: str = "qwen2.5-coder:3b"


class PromptResponse(BaseModel):
    reply: str
    tool_calls: list[str] = []


def _preview_kind(path: Path) -> str:
    return PREVIEW_KINDS.get(path.suffix.lower(), "file")


def _find_latest_preview() -> Path | None:
    if not CACHE.is_dir():
        return None
    candidates: list[Path] = []
    for ext in PREVIEW_KINDS:
        candidates.extend(CACHE.rglob(f"*{ext}"))
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


def _resolve_cache_ref(ref: str) -> Path:
    """Resolve a cache file by relative path or basename."""
    ref = unquote(ref or "").strip()
    if not ref or ".." in ref or ref.startswith(("/", "\\")):
        raise HTTPException(status_code=400, detail="Invalid path")

    normalized = ref.replace("\\", "/")
    if "/" in normalized:
        resolved = (CACHE / normalized).resolve()
        if not resolved.is_file() or not _is_under_cache(resolved):
            raise HTTPException(status_code=404, detail=ref)
        return resolved

    return _resolve_cache_file(ref)


def _artifact_url(rel: Path) -> str:
    rel_path = rel.as_posix() if isinstance(rel, Path) else str(rel)
    return f"/api/preview/file?rel={quote(rel_path, safe='/')}"


def _artifact_entry(path: Path, *, source: str = "cache") -> dict[str, Any]:
    rel = path.relative_to(CACHE)
    kind = _preview_kind(path)
    mime, _ = mimetypes.guess_type(path.name)
    return {
        "id": rel.as_posix(),
        "name": path.name,
        "kind": kind,
        "url": _artifact_url(rel),
        "updated": int(path.stat().st_mtime),
        "source": source,
    }


def _is_sidebar_rel(rel: str) -> bool:
    """Only uploads/ and agent/ preview files (not workflow cache trees)."""
    norm = rel.replace("\\", "/").lstrip("/")
    if norm.startswith("uploads/"):
        return True
    if norm.startswith("agent/"):
        return not norm.endswith("_script.md")
    return False


def _load_sidebar_ids() -> list[str]:
    if not SIDEBAR_MANIFEST.is_file():
        return []
    try:
        data = json.loads(SIDEBAR_MANIFEST.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    raw = data.get("items") if isinstance(data, dict) else data
    if not isinstance(raw, list):
        return []
    ids: list[str] = []
    for row in raw:
        rel = row.get("id") if isinstance(row, dict) else row
        if isinstance(rel, str) and _is_sidebar_rel(rel):
            ids.append(rel)
    return ids


def _save_sidebar_ids(ids: list[str]) -> None:
    SIDEBAR_MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    stamp = int(time.time())
    payload = {
        "items": [{"id": rel, "added": stamp} for rel in ids[:SIDEBAR_MAX]],
    }
    SIDEBAR_MANIFEST.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _register_sidebar(rel: str | Path) -> None:
    rel_str = (
        rel.relative_to(CACHE).as_posix()
        if isinstance(rel, Path)
        else str(rel).replace("\\", "/")
    )
    if not _is_sidebar_rel(rel_str):
        return
    ids = [i for i in _load_sidebar_ids() if i != rel_str]
    ids.insert(0, rel_str)
    _save_sidebar_ids(ids)


def _slug(text: str, limit: int = 32) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return (slug or "render")[:limit]


def _write_agent_script(job_id: str, prompt: str) -> Path | None:
    AGENT_OUTPUT.mkdir(parents=True, exist_ok=True)
    script_path = AGENT_OUTPUT / f"{job_id}_script.md"
    body = (
        f"# Agent script\n\n"
        f"Prompt: {prompt.strip()}\n\n"
        f"Line 1 (seriousB)\nHey guys, welcome back to the channel.\n\n"
        f"Line 2 (amazedB)\nWithout further ado, enjoy the video.\n"
    )
    script_path.write_text(body, encoding="utf-8")
    return script_path


def _write_agent_video(job_id: str, prompt: str) -> Path | None:
    AGENT_OUTPUT.mkdir(parents=True, exist_ok=True)
    slug = _slug(prompt)
    video_path = AGENT_OUTPUT / f"{job_id}_{slug}.mp4"

    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        try:
            subprocess.run(
                [
                    ffmpeg,
                    "-y",
                    "-f",
                    "lavfi",
                    "-i",
                    "color=c=black:s=1280x720:d=3",
                    "-f",
                    "lavfi",
                    "-i",
                    "sine=frequency=440:duration=3",
                    "-shortest",
                    "-c:v",
                    "libx264",
                    "-pix_fmt",
                    "yuv420p",
                    "-c:a",
                    "aac",
                    str(video_path),
                ],
                capture_output=True,
                timeout=120,
                check=True,
            )
            if video_path.is_file():
                return video_path
        except (subprocess.SubprocessError, OSError):
            pass

    return None


def _finalize_job_artifact() -> None:
    job_id = str(_job.get("id") or f"job-{int(time.time())}")
    prompt = str(_job.get("prompt") or "Agent render")

    _write_agent_script(job_id, prompt)
    video_path = _write_agent_video(job_id, prompt)
    if video_path:
        _job["artifact"] = _artifact_entry(video_path, source="agent")
        _register_sidebar(video_path)
        return

    script_path = AGENT_OUTPUT / f"{job_id}_script.md"
    if script_path.is_file():
        _job["artifact"] = _artifact_entry(script_path, source="agent")
        return

    _job["artifact"] = None


def _resolve_cache_file(name: str) -> Path:
    """Resolve a basename safely inside CACHE."""
    safe_name = Path(name).name
    if safe_name != name or ".." in name:
        raise HTTPException(status_code=400, detail="Invalid path")

    matches = list(CACHE.rglob(safe_name))
    for p in matches:
        if p.is_file() and _is_under_cache(p):
            return p
    raise HTTPException(status_code=404, detail=safe_name)


def _is_under_cache(path: Path) -> bool:
    try:
        path.resolve().relative_to(CACHE.resolve())
        return True
    except ValueError:
        return False


def _advance_job() -> None:
    started = _job.get("started_at")
    if not started or _job["status"] == "failed":
        return

    elapsed = time.time() - started
    phase = int(elapsed // 8)

    if phase >= len(STEPS):
        if _job["status"] != "done":
            _finalize_job_artifact()
        _job["status"] = "done"
        _job["progress"] = 100
        _job["message"] = "Pipeline complete."
        for s in STEPS:
            _job["steps"][s] = "done"
        return

    for i, step in enumerate(STEPS):
        if i < phase:
            _job["steps"][step] = "done"
        elif i == phase:
            _job["steps"][step] = "running"
            _job["message"] = f"Running {step}… ({int(elapsed % 8) + 1}/8s)"
        else:
            _job["steps"][step] = "pending"

    _job["status"] = "running"
    _job["progress"] = min(99, int((phase / len(STEPS)) * 100 + (elapsed % 8) * 3))


def _preview_payload(path: Path) -> dict[str, Any]:
    kind = _preview_kind(path)
    mime, _ = mimetypes.guess_type(path.name)
    rel = path.relative_to(CACHE)
    return {
        "ready": True,
        "id": rel.as_posix(),
        "url": _artifact_url(rel),
        "path": str(path),
        "name": path.name,
        "kind": kind,
        "mime": mime or "application/octet-stream",
    }


class SidebarRegisterRequest(BaseModel):
    id: str = Field(min_length=1)


@app.post("/api/artifacts/register")
def artifacts_register(body: SidebarRegisterRequest) -> dict[str, str]:
    """Add a cache file to the sidebar list (e.g. after agent preview)."""
    _register_sidebar(body.id)
    return {"status": "ok"}


@app.get("/api/artifacts")
def artifacts_list() -> dict[str, Any]:
    """Sidebar list: files you opened (uploads/) or agent previewed — not the whole Cache."""
    items: list[dict[str, Any]] = []
    for rel_id in _load_sidebar_ids():
        path = (CACHE / rel_id).resolve()
        if not path.is_file() or not _is_under_cache(path):
            continue
        source = "agent" if rel_id.startswith("agent/") else "cache"
        items.append(_artifact_entry(path, source=source))
    items.sort(key=lambda x: x["updated"], reverse=True)
    return {"artifacts": items}


@app.post("/api/artifacts/upload")
async def artifacts_upload(file: UploadFile = File(...)) -> dict[str, Any]:
    """Upload a file from the user's device into Cache/uploads for preview."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="Missing filename")

    UPLOADS.mkdir(parents=True, exist_ok=True)
    safe_name = Path(file.filename).name
    if safe_name != file.filename or ".." in file.filename:
        raise HTTPException(status_code=400, detail="Invalid filename")

    dest = UPLOADS / safe_name
    if dest.exists():
        stem = dest.stem
        suffix = dest.suffix
        dest = UPLOADS / f"{stem}-{int(time.time())}{suffix}"

    data = await file.read()
    dest.write_bytes(data)

    rel = dest.relative_to(CACHE)
    _register_sidebar(rel)

    payload = _preview_payload(dest)
    payload["id"] = rel.as_posix()
    payload["source"] = "cache"
    payload["updated"] = int(dest.stat().st_mtime)
    return payload


@app.get("/api/models")
def models_list() -> dict[str, Any]:
    """Local (Ollama) + provider models for the agent dropdown."""
    return list_agent_models()


@app.post("/api/agent/prompt", response_model=PromptResponse)
def agent_prompt(body: PromptRequest) -> PromptResponse:
    global _job

    _job = {
        "id": f"job-{int(time.time())}",
        "status": "running",
        "progress": 5,
        "message": "Starting pipeline…",
        "steps": {s: ("running" if s == "script" else "pending") for s in STEPS},
        "started_at": time.time(),
        "prompt": body.message.strip(),
        "artifact": None,
    }

    return PromptResponse(
        reply=f"Got it. Starting pipeline for: “{body.message.strip()}” (model: {body.model}).",
        tool_calls=["generateScript", "generateSpeech", "renderAnimation"],
    )


@app.get("/api/jobs/latest")
def jobs_latest() -> dict[str, Any]:
    if _job["status"] == "running":
        _advance_job()
    return dict(_job)


@app.get("/api/preview/latest")
def preview_latest() -> dict[str, Any]:
    if _job["status"] not in ("idle", "done", "running"):
        return {"ready": False, "url": None, "path": None, "name": None, "kind": None, "mime": None}

    artifact = _job.get("artifact")
    if _job["status"] == "done" and artifact:
        ref = artifact.get("id") or artifact.get("name")
        if ref:
            try:
                return _preview_payload(_resolve_cache_ref(ref))
            except HTTPException:
                pass

    latest = _find_latest_preview()
    if not latest:
        return {"ready": False, "url": None, "path": None, "name": None, "kind": None, "mime": None}

    return _preview_payload(latest)


@app.get("/api/preview/file")
def preview_file(
    name: str | None = None,
    path: str | None = None,
    rel: str | None = None,
) -> FileResponse:
    ref = rel or path or name
    if not ref:
        raise HTTPException(status_code=400, detail="Missing name, path, or rel")
    resolved = _resolve_cache_ref(ref)
    mime, _ = mimetypes.guess_type(resolved.name)
    kind = _preview_kind(resolved)
    # inline so PDFs/images embed in the dashboard iframe (filename= forces attachment → new tab)
    disposition = "inline" if kind in ("pdf", "image", "video", "text") else "attachment"
    safe_fn = resolved.name.replace('"', "'")
    return FileResponse(
        resolved,
        media_type=mime or "application/octet-stream",
        headers={
            "Accept-Ranges": "bytes",
            "Content-Disposition": f'{disposition}; filename="{safe_fn}"',
        },
    )


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


def _load_app_config() -> dict[str, Any]:
    path = CONFIG / "app.json"
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _resolve_config_asset(rel: str) -> Path:
    ref = unquote(rel or "").strip().replace("\\", "/")
    if not ref or ".." in ref or ref.startswith(("/", "\\")):
        raise HTTPException(status_code=400, detail="Invalid config path")
    resolved = (CONFIG / ref).resolve()
    if not resolved.is_file():
        raise HTTPException(status_code=404, detail=ref)
    try:
        resolved.relative_to(CONFIG.resolve())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid config path") from exc
    return resolved


@app.get("/api/config")
def app_config() -> dict[str, Any]:
    """App-level defaults from Config/app.json (user avatar, display name, etc.)."""
    return _load_app_config()


@app.get("/api/config/{asset_path:path}")
def config_asset(asset_path: str) -> FileResponse:
    """Serve files under Config/ (e.g. user avatar)."""
    resolved = _resolve_config_asset(asset_path)
    mime, _ = mimetypes.guess_type(resolved.name)
    return FileResponse(resolved, media_type=mime or "application/octet-stream")
