"""Discover agent models for the dashboard (Ollama local + cloud providers)."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
DEFAULT_OLLAMA_MODEL = "qwen2.5-coder:3b"

# Cloud LLMs — shown under Providers (availability = env API key)
_PROVIDER_DEFS: list[dict[str, Any]] = [
    {
        "id": "anthropic:claude-sonnet",
        "label": "Claude Sonnet",
        "env": "ANTHROPIC_API_KEY",
        "note": "Anthropic API",
    },
    {
        "id": "openai:gpt-4o",
        "label": "GPT-4o",
        "env": "OPENAI_API_KEY",
        "note": "OpenAI API",
    },
]


def _manifest_libraries() -> list[Path]:
    roots: list[Path] = []
    env_dir = os.environ.get("OLLAMA_MODELS")
    if env_dir:
        roots.append(Path(env_dir).expanduser())
    roots.append(Path.home() / ".ollama" / "models")

    libraries: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        for candidate in (
            root / "manifests" / "registry.ollama.ai" / "library",
            root / "library",
        ):
            key = str(candidate.resolve()) if candidate.exists() else str(candidate)
            if candidate.is_dir() and key not in seen:
                seen.add(key)
                libraries.append(candidate)
    return libraries


def _ollama_models_from_disk() -> list[dict[str, str]]:
    models: dict[str, dict[str, str]] = {}
    for library in _manifest_libraries():
        for model_dir in sorted(library.iterdir()):
            if not model_dir.is_dir():
                continue
            tags = [t.name for t in sorted(model_dir.iterdir()) if t.is_dir() or t.is_file()]
            if tags:
                for tag in tags:
                    model_id = f"{model_dir.name}:{tag}"
                    models[model_id] = {"id": model_id, "label": model_id}
            else:
                models[model_dir.name] = {"id": model_dir.name, "label": model_dir.name}
    return sorted(models.values(), key=lambda m: m["id"])


def _ollama_tags() -> list[dict[str, str]]:
    req = urllib.request.Request(f"{OLLAMA_URL}/api/tags", method="GET")
    with urllib.request.urlopen(req, timeout=3) as resp:
        data = json.loads(resp.read())
    models = []
    for item in data.get("models") or []:
        name = item.get("name") or item.get("model")
        if not name:
            continue
        size = item.get("size")
        label = name
        if size:
            gb = size / (1024**3)
            label = f"{name} ({gb:.1f} GB)"
        models.append({"id": name, "label": label, "provider": "ollama"})
    return sorted(models, key=lambda m: m["id"])


def _provider_available(defn: dict[str, Any]) -> bool:
    if defn.get("always_available"):
        return True
    key = defn.get("env")
    if key and os.environ.get(key):
        return True
    alt = defn.get("env_alt")
    return bool(alt and os.environ.get(alt))


def list_agent_models() -> dict[str, Any]:
    local: list[dict[str, Any]] = []
    ollama_online = False
    ollama_error: str | None = None

    try:
        for m in _ollama_tags():
            local.append({
                "id": m["id"],
                "label": m["label"],
                "available": True,
                "kind": "local",
            })
        ollama_online = bool(local)
    except urllib.error.URLError as exc:
        ollama_error = str(exc.reason if hasattr(exc, "reason") else exc)
    except (TimeoutError, json.JSONDecodeError, KeyError) as exc:
        ollama_error = str(exc)

    if not local:
        disk = _ollama_models_from_disk()
        if disk:
            for m in disk:
                local.append({
                    "id": m["id"],
                    "label": m["label"],
                    "available": False,
                    "kind": "local",
                    "source": "disk",
                })
        else:
            local.append({
                "id": DEFAULT_OLLAMA_MODEL,
                "label": DEFAULT_OLLAMA_MODEL,
                "available": False,
                "kind": "local",
            })

    providers: list[dict[str, Any]] = []
    for defn in _PROVIDER_DEFS:
        providers.append({
            "id": defn["id"],
            "label": defn["label"],
            "note": defn.get("note", ""),
            "available": _provider_available(defn),
            "kind": "provider",
        })

    default = next(
        (m["id"] for m in local if m.get("available")),
        local[0]["id"],
    )

    return {
        "local": local,
        "providers": providers,
        "default": default,
        "ollama_online": ollama_online,
        "ollama_error": ollama_error,
    }
