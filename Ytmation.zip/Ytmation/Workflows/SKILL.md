# Workflows — niche → production pipeline

Maps a niche to the exact ordered steps the agent runs. Read this **first** after picking a niche.

## Layout

```
Workflows/
├── SKILL.md
├── workflows.py
└── pipelines/
    ├── blender_physics.json
    ├── soundscape_sleep.json
    ├── manhwa_recap.json
    ├── literary_analysis.json
    ├── philosophy.json
    └── true_crime.json
```

## Pipelines

| File | Niche | Format | Duration |
|------|-------|--------|----------|
| `blender_physics` | Blender Physics | short 9:16 | 60s |
| `soundscape_sleep` | Soundscapes for Sleep | long 16:9 | 1 hr |
| `manhwa_recap` | Manhwa Recap | long 16:9 | 15 min |
| `literary_analysis` | Literary Analysis | long 16:9 | 20 min |
| `philosophy` | Philosophy | long 16:9 | 15 min |
| `true_crime` | True Crime | long 16:9 | 30 min |

Each file may also set `storyboard` and `script_template` keys for downstream modules.

## CLI

```bash
python Workflows/workflows.py --list
python Workflows/workflows.py blender_physics
python Workflows/workflows.py manhwa_recap --json
```

## Python API (agent)

```python
from Workflows.workflows import load_workflow, runWorkflow, parse_step

workflow = load_workflow("blender_physics")

for step in workflow["pipeline"]:
    parsed = parse_step(step)
    # agent.execute(parsed["module"], parsed["action"])
    print(parsed["module"], "→", parsed["action"])

runWorkflow("soundscape_sleep")
```

## Full production order

```
Niche decision
     ↓
Workflows/    → which pipeline to run
     ↓
Templates/    → format/recipe (when used)
     ↓
Storyboard/   → timeline / timestamps
     ↓
Script/       → narration
     ↓
Prompts/      → AI instructions per skill
     ↓
[production skills: Blender, Voice, Music, …]
     ↓
Stitching/    → final assembly
     ↓
Upload/       → live on YouTube
```

Add a niche by dropping a new `.json` in `pipelines/`.

## Channel workflows (code)

Per-channel Python pipelines live under `Workflows/channels/<channel>/`. Each channel may ship a local `SKILL.md`:

| Channel | Guide | Typical modules |
|---------|-------|-----------------|
| `mathmwk` | `Workflows/channels/mathmwk/SKILL.md` | Script, Storyboard, Math, Voice, Stitching |
| `bouncemwk` | `Workflows/channels/bouncemwk/SKILL.md` | Characters, Games, Transitions, Voice (intro) |

Shared production skills: `Voice/SKILL.md`, `Characters/SKILL.md`, `Games/SKILL.md`, `Math/SKILL.md`, etc.
