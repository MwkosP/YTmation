"""
Stitch all 10 sorting explainer scenes into one video.

python Workflows/channels/mathmwk/sortingExplainerShowcase.py
"""

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.utils import _renderManim
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"
EXPLAINER = Path(__file__).resolve().parent / "sortingExplainer.py"

SCENES = [
    ("01_title", "Scene01Title"),
    ("02_problem", "Scene02Problem"),
    ("03_bubble_idea", "Scene03BubbleIdea"),
    ("04_bubble_one_pass", "Scene04BubbleOnePass"),
    ("05_bubble_complete", "Scene05BubbleComplete"),
    ("06_faster_way", "Scene06FasterWay"),
    ("07_selection_idea", "Scene07SelectionIdea"),
    ("08_side_by_side", "Scene08SideBySide"),
    ("09_why_matters", "Scene09WhyMatters"),
    ("10_summary", "Scene10Summary"),
]


def runSortingExplainerShowcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    source = EXPLAINER.read_text()
    rendered: list[str] = []
    total = len(SCENES)
    print(
        f"{CHANNEL} sorting explainer — {total} scenes, quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, (slug, scene_name) in enumerate(SCENES, 1):
        print(f"  [{i}/{total}] {slug} — {scene_name}", flush=True)
        out = CACHE / "math" / f"sorting_explainer_{slug}.mp4"
        path = _renderManim(
            source=source,
            scene_name=scene_name,
            output=out,
            quality=quality,
        )
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_sorting_explainer_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.2,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} scenes): {final_path}")
    return final_path


if __name__ == "__main__":
    runSortingExplainerShowcase(quality="low", format="long")
