---
name: mathmwk-workflow
description: Use this skill when creating or editing a workflow file for the mathmwk YouTube channel. Covers the exact workflow file structure, --prepare/run pattern, how to write scene functions, channel branding, and all available module APIs for this channel. Trigger when user asks to make a math video, create a new workflow, or add scenes to mathmwk.
---

# mathmwk Workflow — Agent Guide

## Channel Info

| Key | Value |
|---|---|
| Channel | `mathmwk` |
| Niche | Math proofs and concepts |
| Format | Long 1920x1080 (default), Shorts 1080x1920 optional |
| Style | Explainers, showcases, and voiceover videos |
| bg_color | `#0a0a0a` |
| accent_color | `#FF4500` |
| text_color | `#ffffff` |
| music_vibe | `ambient/cinematic` |

---

## Workflow File Location

```
Workflows/channels/mathmwk/<topic>.py
```

One file per video. Example: `Workflows/channels/mathmwk/neural_networks.py`

Common current files:

- `spatialDimensionsELI5Voiceover.py`
- `economicsEquilibriumVoiceover.py`
- `bitcoinELI5Voiceover.py`
- `*Showcase.py` files (module demo reels)

---

## Two Step Process

```bash
# Step 1 — generate + print script and storyboard, agent reads output
python Workflows/channels/mathmwk/neural_networks.py --prepare

# Step 2 — agent has written scene functions, run full pipeline
python Workflows/channels/mathmwk/neural_networks.py
```

For direct voiceover workflows (already authored as segment lists), run once:

```bash
python Workflows/channels/mathmwk/spatialDimensionsELI5Voiceover.py
python Workflows/channels/mathmwk/bitcoinELI5Voiceover.py --voice-backend orpheus --orpheus-voice tara
```

---

## Exact Workflow File Template

```python
# Workflows/channels/mathmwk/<topic>.py

from Script.script import generateScript
from Storyboard.storyboard import generateStoryboard
from Voice import generateSpeech  # model="gtts" | "orpheus:tara"
from Math.mathAbstractions import renderSegment, renderIntro, renderOutro
from Stitching.stitching import stitch
from Music.music import prepareMusic
from Thumbnail.thumbnail import generateThumbnail
from Upload.upload import upload
from Storage.storage import logRun, logUpload, cacheScript, getCachedScript, getCachedStoryboard

# ── CONFIG ────────────────────────────────────────────────
CHANNEL  = "mathmwk"
TOPIC    = "<topic>"
DURATION = 60         # seconds
TONE     = "educational"

# ── SCENES (agent writes these after --prepare) ───────────

def scene1(scene):
    ...

def scene2(scene):
    ...

# ── PIPELINE ──────────────────────────────────────────────

def prepare():
    script     = generateScript(TOPIC, DURATION, TONE, channel=CHANNEL)
    cacheScript(script, channel=CHANNEL)
    storyboard = generateStoryboard(script, channel=CHANNEL)
    print(storyboard)  # agent reads this, then writes scenes above

def run():
    try:
        script     = getCachedScript(channel=CHANNEL)
        storyboard = getCachedStoryboard(channel=CHANNEL)

        music = prepareMusic(vibe="ambient/cinematic", duration=DURATION, channel=CHANNEL)

        scenes = [scene1, scene2]  # must match storyboard length exactly

        renderIntro(title=TOPIC, channel=CHANNEL)

        for seg, scene in zip(storyboard, scenes):
            renderSegment(seg["text"], scene, channel=CHANNEL)

        renderOutro(channel=CHANNEL)

        final     = stitch(music=music, channel=CHANNEL)
        thumbnail = generateThumbnail(TOPIC, channel=CHANNEL)
        upload(final, thumbnail, channel=CHANNEL)
        logUpload(TOPIC, channel=CHANNEL)

    except Exception as e:
        logRun(success=False, error=str(e), channel=CHANNEL)

if __name__ == "__main__":
    import sys
    prepare() if "--prepare" in sys.argv else run()
```

---

## Writing Scene Functions

Agent writes one scene function per storyboard segment after running `--prepare`.
Each scene is fully isolated — no shared state, no shared imports between scenes.

### Option 1 — Library building block (recommended)
```python
def scene1(scene):
    from Math.library.math.calculus.derivative import Derivative
    Derivative(scene, func=lambda x: x**2, color=BLUE)
```

### Option 2 — mathAbstractions convenience function
```python
def scene2(scene):
    from Math.mathAbstractions import renderLayers
    renderLayers(scene)
```

### Option 3 — Raw Manim (when no block fits)
```python
def scene3(scene):
    from manim import *
    tex = MathTex(r"\int_0^1 x^2 dx = \frac{1}{3}")
    scene.play(Write(tex))
    scene.wait(1)
```

See `Math/SKILL.md` for all available building blocks and their params.

---

## Intro / Outro

Always call `renderIntro` and `renderOutro` — they apply mathmwk branding automatically.

```python
renderIntro(title=TOPIC, channel=CHANNEL)   # branded animated intro
renderOutro(channel=CHANNEL)                # branded animated outro
```

Never build custom intros/outros — branding must stay consistent.

---

## Storyboard Format

`generateStoryboard()` returns:

```python
[
    {"id": 1, "text": "A neural network is made of layers",       "duration": 12},
    {"id": 2, "text": "Each neuron computes a weighted sum",      "duration": 10},
    {"id": 3, "text": "Training adjusts weights via backprop",    "duration": 14},
]
```

Agent writes exactly one scene function per segment. `scenes` list must match length.

---

## Available Modules

| Module | Key Functions | SKILL.md |
|---|---|---|
| Script | `generateScript(topic, duration, tone, channel)` | `Script/SKILL.md` |
| Storyboard | `generateStoryboard(script, channel)` | `Storyboard/SKILL.md` |
| Voice | `generateSpeech(text, model=...)`, `getAudioDuration` | `Voice/SKILL.md` |
| Math | `renderSegment, renderIntro, renderOutro` + all library blocks | `Math/SKILL.md` |
| Music | `prepareMusic(vibe, duration, channel)` | `Music/SKILL.md` |
| Stitching | `stitch(music, channel)` | `Stitching/SKILL.md` |
| Thumbnail | `generateThumbnail(topic, channel)` | `Thumbnail/SKILL.md` |
| Upload | `upload(final, thumbnail, channel)` | `Upload/SKILL.md` |
| Storage | `logRun, logUpload, cacheScript, getCachedScript, getCachedStoryboard` | `Storage/SKILL.md` |

---

## Rules

- For `--prepare` workflows: run `--prepare` first, then write scenes
- For segment-based voiceover workflows: keep one segment dict per beat (`name`, `beat`, `narration`, `animation`)
- `scenes` list length must exactly match storyboard length (prepare-based flows)
- Intro/outro is optional for showcases/voiceovers; many current channel videos are demos only
- Never share Manim objects across scene functions
- Never import at module level — all imports inside scene functions
- `CHANNEL` is always `"mathmwk"` — never change it
- Music is always `ambient/cinematic` for this channel
- Default format is long `1920x1080`; support shorts `1080x1920` when requested