"""
Linear Regression — long-form explainer (~3 minutes).

Segment durations are chosen so narration can breathe; each chunk is one Manim scene.
TARGET_SECONDS must equal sum(SEGMENTS[*].duration).
"""

import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia
from Thumbnail.thumbnail import generateThumbnail
from Storage.storage import logRun

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"
TARGET_SECONDS = 180  # 3:00 long-form

# Shared scatter data for continuity across segments
PTS = [(1, 2.2), (2, 2.5), (3, 3.7), (4, 4.2), (5, 5.1), (6, 5.9), (7, 6.8), (8, 7.5), (9, 8.1)]
M_GOOD, B_GOOD = 0.74, 1.35

# ── 1) Hook (12s) ─────────────────────────────────────────────────────────
HOOK = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        l1 = Text("Linear Regression", font_size=76, color="#FF4500", weight=BOLD)
        l2 = Text("The complete beginner guide", font_size=44, color=WHITE)
        l3 = Text("Find the best straight line through noisy data", font_size=32, color=GRAY)
        g = VGroup(l1, l2, l3).arrange(DOWN, buff=0.38)
        self.play(FadeIn(l1, shift=UP * 0.25), run_time=1.0)
        self.play(FadeIn(l2, shift=UP * 0.2), run_time=1.0)
        self.play(Write(l3), run_time=1.2)
        self.wait(8.5)
"""

# ── 2) Motivation (14s) ───────────────────────────────────────────────────
MOTIVATION = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Why do we need it?", font_size=42, color=WHITE).to_edge(UP, buff=0.4)
        items = VGroup(
            Text("• House size → price", font_size=34, color=GRAY),
            Text("• Study hours → exam score", font_size=34, color=GRAY),
            Text("• Ads spent → revenue", font_size=34, color=GRAY),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.45).shift(DOWN * 0.2)
        punch = Text("We want a rule: x → y", font_size=40, color="#FF4500").to_edge(DOWN, buff=0.55)
        self.play(Write(title), run_time=0.8)
        self.play(LaggedStart(*[FadeIn(i, shift=RIGHT * 0.15) for i in items], lag_ratio=0.25), run_time=2.5)
        self.play(Write(punch), run_time=1.0)
        self.wait(9.5)
"""

# ── 3) Scatter plot (16s) ─────────────────────────────────────────────────
DATA_SCATTER = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 1 — Plot your data", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        axes = Axes(
            x_range=[0, 10, 1], y_range=[0, 10, 1],
            x_length=8, y_length=4.6, axis_config={"color": GRAY}, tips=False,
        ).shift(DOWN * 0.35)
        pts = [(1,2.2),(2,2.5),(3,3.7),(4,4.2),(5,5.1),(6,5.9),(7,6.8),(8,7.5),(9,8.1)]
        dots = VGroup(*[Dot(axes.c2p(x, y), color="#FFD700", radius=0.08) for x, y in pts])
        note = Text("Each point = one observation", font_size=28, color=GRAY).to_edge(DOWN, buff=0.4)
        self.play(Write(title), run_time=0.7)
        self.play(Create(axes), run_time=1.2)
        self.play(LaggedStart(*[GrowFromCenter(d) for d in dots], lag_ratio=0.1), run_time=2.2)
        self.play(FadeIn(note), run_time=0.8)
        self.wait(11.0)
"""

# ── 4) Line model (16s) ───────────────────────────────────────────────────
LINE_MODEL = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 2 — Assume a straight line", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        axes = Axes(
            x_range=[0, 10, 1], y_range=[0, 10, 1],
            x_length=8, y_length=4.6, axis_config={"color": GRAY}, tips=False,
        ).shift(DOWN * 0.35)
        pts = [(1,2.2),(2,2.5),(3,3.7),(4,4.2),(5,5.1),(6,5.9),(7,6.8),(8,7.5),(9,8.1)]
        dots = VGroup(*[Dot(axes.c2p(x, y), color="#FFD700", radius=0.07) for x, y in pts])
        line = axes.plot(lambda x: 0.5 * x + 2.0, color="#FF4500", x_range=[0, 10], stroke_width=5)
        eq = MathTex(r"\\hat{y} = mx + b", font_size=64, color="#FF4500").to_edge(DOWN, buff=0.35)
        self.play(Write(title), run_time=0.7)
        self.add(axes, dots)
        self.play(Create(line), run_time=1.4)
        self.play(Write(eq), run_time=1.0)
        self.wait(12.5)
"""

# ── 5) m and b meaning (14s) ────────────────────────────────────────────────
SLOPE_INTERCEPT = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("What are m and b?", font_size=42, color=WHITE).to_edge(UP, buff=0.4)
        m_line = VGroup(
            MathTex("m", font_size=72, color="#FF4500"),
            Text("= slope (steepness)", font_size=32, color=GRAY),
        ).arrange(RIGHT, buff=0.35).shift(UP * 0.5)
        b_line = VGroup(
            MathTex("b", font_size=72, color="#FFD700"),
            Text("= intercept (start height)", font_size=32, color=GRAY),
        ).arrange(RIGHT, buff=0.35).shift(DOWN * 0.5)
        self.play(Write(title), run_time=0.7)
        self.play(FadeIn(m_line, shift=RIGHT * 0.2), run_time=1.0)
        self.play(FadeIn(b_line, shift=RIGHT * 0.2), run_time=1.0)
        self.wait(11.0)
"""

# ── 6) Residuals (16s) ──────────────────────────────────────────────────────
RESIDUALS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 3 — Vertical errors (residuals)", font_size=38, color=WHITE).to_edge(UP, buff=0.4)
        axes = Axes(
            x_range=[0, 10, 1], y_range=[0, 10, 1],
            x_length=8, y_length=4.6, axis_config={"color": GRAY}, tips=False,
        ).shift(DOWN * 0.35)
        pts = [(1,2.2),(2,2.5),(3,3.7),(4,4.2),(5,5.1),(6,5.9),(7,6.8),(8,7.5),(9,8.1)]
        line = axes.plot(lambda x: 0.5 * x + 2.0, color="#FF4500", x_range=[0, 10], stroke_width=5)
        dots = VGroup(*[Dot(axes.c2p(x, y), color="#FFD700", radius=0.07) for x, y in pts])
        res = VGroup()
        for x, y in pts:
            yh = 0.5 * x + 2.0
            res.add(Line(axes.c2p(x, y), axes.c2p(x, yh), color=WHITE, stroke_width=2))
        self.play(Write(title), run_time=0.7)
        self.add(axes, line, dots)
        self.play(LaggedStart(*[Create(r) for r in res], lag_ratio=0.07), run_time=2.5)
        self.wait(12.5)
"""

# ── 7) MSE loss (16s) ───────────────────────────────────────────────────────
MSE_LOSS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 4 — Squared error loss", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        loss = MathTex(
            r"L = \\frac{1}{n}\\sum_{i=1}^{n}(y_i - \\hat{y}_i)^2",
            font_size=58, color="#FFD700",
        )
        why = VGroup(
            Text("Squares punish big mistakes harder", font_size=30, color=GRAY),
            Text("Always positive — easy to minimize", font_size=30, color=GRAY),
        ).arrange(DOWN, buff=0.35).next_to(loss, DOWN, buff=0.7)
        self.play(Write(title), run_time=0.7)
        self.play(Write(loss), run_time=1.8)
        self.play(LaggedStart(*[FadeIn(w) for w in why], lag_ratio=0.3), run_time=1.5)
        self.wait(11.7)
"""

# ── 8) Optimization (16s) ───────────────────────────────────────────────────
OPTIMIZE = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 5 — Tune m and b", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        axes = Axes(
            x_range=[0, 10, 1], y_range=[0, 10, 1],
            x_length=8, y_length=4.6, axis_config={"color": GRAY}, tips=False,
        ).shift(DOWN * 0.35)
        pts = [(1,2.2),(2,2.5),(3,3.7),(4,4.2),(5,5.1),(6,5.9),(7,6.8),(8,7.5),(9,8.1)]
        dots = VGroup(*[Dot(axes.c2p(x, y), color="#FFD700", radius=0.07) for x, y in pts])
        bad = axes.plot(lambda x: 0.5 * x + 2.0, color="#666666", x_range=[0, 10], stroke_width=4)
        good = axes.plot(lambda x: 0.74 * x + 1.35, color="#FF4500", x_range=[0, 10], stroke_width=6)
        self.play(Write(title), run_time=0.7)
        self.add(axes, dots)
        self.play(Create(bad), run_time=1.0)
        self.play(Transform(bad, good), run_time=1.8)
        self.wait(12.2)
"""

# ── 9) Best fit result (14s) ────────────────────────────────────────────────
BEST_FIT = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Best-fit line found", font_size=42, color=WHITE).to_edge(UP, buff=0.4)
        eq = MathTex(r"\\hat{y} = 0.74x + 1.35", font_size=80, color="#FF4500")
        sub = Text("minimizes total squared error on training data", font_size=28, color=GRAY)
        sub.next_to(eq, DOWN, buff=0.5)
        self.play(Write(title), run_time=0.7)
        self.play(Write(eq), run_time=1.5)
        self.play(FadeIn(sub), run_time=0.9)
        self.wait(10.6)
"""

# ── 10) Prediction (16s) ────────────────────────────────────────────────────
PREDICT = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 6 — Predict new x values", font_size=38, color=WHITE).to_edge(UP, buff=0.4)
        axes = Axes(
            x_range=[0, 12, 1], y_range=[0, 12, 1],
            x_length=8, y_length=4.6, axis_config={"color": GRAY}, tips=False,
        ).shift(DOWN * 0.35)
        line = axes.plot(lambda x: 0.74 * x + 1.35, color="#FF4500", x_range=[0, 11], stroke_width=5)
        old = VGroup(*[Dot(axes.c2p(x, y), color="#FFD700", radius=0.07)
                       for x, y in [(1,2.2),(3,3.7),(5,5.1),(7,6.8),(9,8.1)]])
        x_new = 11
        y_new = 0.74 * x_new + 1.35
        new_dot = Dot(axes.c2p(x_new, y_new), color="#00ff88", radius=0.12)
        lbl = Text("prediction", font_size=26, color="#00ff88").next_to(new_dot, UR, buff=0.15)
        self.play(Write(title), run_time=0.7)
        self.add(axes, line, old)
        self.play(GrowFromCenter(new_dot), FadeIn(lbl), run_time=1.2)
        self.wait(13.8)
"""

# ── 11) Limits (14s) ────────────────────────────────────────────────────────
LIMITS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("When linear regression struggles", font_size=38, color=WHITE).to_edge(UP, buff=0.4)
        items = VGroup(
            Text("• Curved / nonlinear patterns", font_size=32, color=GRAY),
            Text("• Outliers pull the line", font_size=32, color=GRAY),
            Text("• Too many features (overfitting risk)", font_size=32, color=GRAY),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.4).shift(DOWN * 0.15)
        hint = Text("→ Random Forest handles nonlinearity", font_size=30, color="#FF4500").to_edge(DOWN, buff=0.5)
        self.play(Write(title), run_time=0.8)
        self.play(LaggedStart(*[FadeIn(i, shift=RIGHT * 0.12) for i in items], lag_ratio=0.22), run_time=2.2)
        self.play(Write(hint), run_time=0.9)
        self.wait(9.8)
"""

# ── 12) Outro (16s) ─────────────────────────────────────────────────────────
OUTRO = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        t1 = Text("Linear Regression", font_size=60, color=WHITE)
        t2 = Text("one line, one clear story", font_size=40, color="#FF4500").next_to(t1, DOWN, buff=0.3)
        t3 = Text("mathmwk  •  follow for more ML math", font_size=28, color=GRAY).next_to(t2, DOWN, buff=0.45)
        self.play(Write(t1), run_time=1.2)
        self.play(FadeIn(t2), run_time=1.0)
        self.play(FadeIn(t3), run_time=0.9)
        self.wait(12.6)
"""

# Timing map (narration beats ≈ segment duration)
SEGMENTS = [
    {"name": "hook",           "code": HOOK,           "duration": 12, "beat": "title + promise"},
    {"name": "motivation",     "code": MOTIVATION,     "duration": 14, "beat": "real-world examples"},
    {"name": "data_scatter",   "code": DATA_SCATTER,   "duration": 16, "beat": "plot points"},
    {"name": "line_model",     "code": LINE_MODEL,     "duration": 16, "beat": "introduce y_hat = mx+b"},
    {"name": "slope_intercept","code": SLOPE_INTERCEPT,"duration": 14, "beat": "explain m and b"},
    {"name": "residuals",      "code": RESIDUALS,      "duration": 16, "beat": "vertical errors"},
    {"name": "mse_loss",       "code": MSE_LOSS,       "duration": 16, "beat": "loss function"},
    {"name": "optimize",       "code": OPTIMIZE,       "duration": 16, "beat": "fit the line"},
    {"name": "best_fit",       "code": BEST_FIT,       "duration": 14, "beat": "final equation"},
    {"name": "predict",        "code": PREDICT,        "duration": 16, "beat": "extrapolate"},
    {"name": "limits",         "code": LIMITS,         "duration": 14, "beat": "assumptions / limits"},
    {"name": "outro",          "code": OUTRO,          "duration": 16, "beat": "recap + CTA"},
]


def _assertTiming():
    total = sum(s["duration"] for s in SEGMENTS)
    if total != TARGET_SECONDS:
        raise ValueError(f"SEGMENTS total {total}s != TARGET_SECONDS {TARGET_SECONDS}s")


def runMathLinearRegression(quality: str = "medium", format: str = "long"):
    _assertTiming()
    start = time.time()
    width, height = (1920, 1080) if format == "long" else (1080, 1920)
    total = sum(s["duration"] for s in SEGMENTS)
    mins = total // 60
    secs = total % 60

    try:
        print(f"Linear Regression — {len(SEGMENTS)} segments, {mins}:{secs:02d} target, {format}")

        rendered = []
        for i, seg in enumerate(SEGMENTS):
            beat = seg.get("beat", "")
            print(f"  [{i + 1}/{len(SEGMENTS)}] {seg['name']} ({seg['duration']}s) — {beat}")
            video = renderCustomScene(
                manim_code=seg["code"],
                duration=seg["duration"],
                quality=quality,
            )
            rendered.append(str(video))

        combined = CACHE / "stitched" / f"math_linear_regression_{int(time.time())}.mp4"
        combined.parent.mkdir(parents=True, exist_ok=True)

        video = combineMedia(
            media=rendered,
            output=combined,
            transition="crossfade",
            duration=0.35,
            width=width,
            height=height,
            fps=60,
        )

        thumb = generateThumbnail(
            title="Linear Regression (Full Guide)",
            style="bold_text",
            bg_color="#0a0a0a",
            text_color="#ffffff",
            accent_color="#FF4500",
        )

        logRun(
            "MathLinearRegression",
            "success",
            channel=CHANNEL,
            topic="linear_regression",
            duration=round(time.time() - start, 1),
        )

        print(f"Video:     {video}")
        print(f"Thumbnail: {thumb}")
        return video, thumb

    except Exception as e:
        logRun(
            "MathLinearRegression",
            "failed",
            channel=CHANNEL,
            topic="linear_regression",
            duration=round(time.time() - start, 1),
            error=str(e),
        )
        raise


if __name__ == "__main__":
    runMathLinearRegression(quality="medium", format="long")
