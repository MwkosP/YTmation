"""
ML Manim abstractions showcase.

python Workflows/channels/mathmwk/mlmanimShowcase.py
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"
PAD_WAIT = 1.0

# Focused on abstractions / building blocks.
DEMOS = [
    ("neural_net_forward", "demoNeuralNet"),
    ("backprop", "demoBackprop"),
    ("weight_update", "demoWeightUpdate"),
    ("cnn_convolution", "demoCnnConv"),
    ("cnn_pooling", "demoCnnPooling"),
    ("rnn_unrolled", "demoRnn"),
    ("token_embeddings", "demoEmbeddings"),
    ("attention_matrix", "demoAttentionMatrix"),
    ("self_attention_flow", "demoSelfAttention"),
    ("transformer_block", "demoTransformerBlock"),
    ("residual_connection", "demoResidual"),
    ("architecture_overview", "demoArchitectureOverview"),
    ("llm_inference", "demoLlmInference"),
    ("sampling_controls", "demoSampling"),
]


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}


def _beat(body: str) -> str:
    b = body.strip()
    if "self.wait(" not in b.split("\n")[-1]:
        b += f"\nself.wait({PAD_WAIT})"
    return b


def _demo_segment(idx: int, slug: str, fn: str) -> dict:
    return _seg(
        f"{idx:02d}_{slug}",
        fn,
        _beat(
            f"""
from Math.library.common.styling import setupScene
from Math.library.ml.recipes import {fn}
setupScene(self)
{fn}(self)
"""
        ),
    )


SEGMENTS = [_demo_segment(i + 1, slug, fn) for i, (slug, fn) in enumerate(DEMOS)]


def _scene_source(animation: str) -> str:
    body = textwrap.indent(animation.strip(), "        ")
    return f"""
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
{body}
"""


def runMlManimShowcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    rendered: list[str] = []
    total = len(SEGMENTS)
    print(f"{CHANNEL} ml manim showcase — {total} segments, quality={quality}, {width}x{height}", flush=True)

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"mlmanim_showcase_{seg['name']}.mp4"
        path = renderCustomScene(manim_code=_scene_source(seg["animation"]), output=out, quality=quality)
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_mlmanim_showcase_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.18,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runMlManimShowcase(quality="low", format="long")
