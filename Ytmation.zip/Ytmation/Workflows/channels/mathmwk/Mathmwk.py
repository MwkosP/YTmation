import time
from pathlib import Path

from Math.math import renderScene, renderCustomScene
from Stitching.stitching import resizeVideo
from Transitions.transitions import combineMedia
from Thumbnail.thumbnail import generateThumbnail
from Storage.storage import logRun, logUsed

CHANNEL = "mathmwk"
ROOT    = Path(__file__).resolve().parent.parent.parent
CACHE   = ROOT / "Cache"

# ── Segment 1: Hook text (0-3s) ───────────────────────────────────────────
HOOK = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        question = Text(
            "Why does",
            font_size=52, color=WHITE,
        ).shift(UP * 1.2)
        formula = MathTex(
            "a^2 + b^2 = c^2",
            font_size=90,
        )
        formula[0][0].set_color("#FF4500")
        formula[0][3].set_color("#ffffff")
        formula[0][6].set_color("#FFD700")
        question_mark = Text("?", font_size=90, color=WHITE).shift(DOWN * 1.2)

        self.play(FadeIn(question, shift=DOWN * 0.3), run_time=0.8)
        self.play(Write(formula), run_time=1.2)
        self.play(FadeIn(question_mark, shift=UP * 0.3), run_time=0.5)
        self.wait(0.5)
"""

# ── Segment 2: Triangle draws itself (3-12s) ──────────────────────────────
TRIANGLE = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        A = LEFT * 2.5 + DOWN * 1.5
        B = RIGHT * 2.5 + DOWN * 1.5
        C = LEFT * 2.5 + UP * 1.5

        side_a = Line(A, B, color="#FF4500", stroke_width=5)
        side_b = Line(A, C, color="#ffffff", stroke_width=5)
        side_c = Line(B, C, color="#FFD700", stroke_width=5)

        label_a = MathTex("a", color="#FF4500", font_size=56).next_to(side_a, DOWN, buff=0.3)
        label_b = MathTex("b", color="#ffffff", font_size=56).next_to(side_b, LEFT, buff=0.3)
        label_c = MathTex("c", color="#FFD700", font_size=56).next_to(side_c, RIGHT, buff=0.3)

        # right angle marker
        corner = Square(side_length=0.3, color=WHITE, stroke_width=2)
        corner.move_to(A + RIGHT * 0.15 + UP * 0.15)

        self.play(Create(side_a), run_time=1)
        self.play(Create(side_b), run_time=1)
        self.play(Create(side_c), run_time=1)
        self.play(
            Write(label_a), Write(label_b), Write(label_c),
            Create(corner),
            run_time=1.5,
        )
        self.wait(2)
"""

# ── Segment 3: Squares grow from each side (12-22s) ───────────────────────
SQUARES = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        # triangle
        A = ORIGIN
        B = RIGHT * 2
        C = UP * 2

        tri = Polygon(A, B, C, color=WHITE, stroke_width=3)

        # squares on each side
        sq_a = Square(side_length=2, color="#FF4500", fill_opacity=0.35, stroke_width=3)
        sq_a.next_to(Line(A, B), DOWN, buff=0)

        sq_b = Square(side_length=2, color="#ffffff", fill_opacity=0.2, stroke_width=3)
        sq_b.next_to(Line(A, C), LEFT, buff=0)

        sq_c = Square(side_length=2*1.414, color="#FFD700", fill_opacity=0.3, stroke_width=3)
        sq_c.move_to(tri.get_center() + RIGHT * 1.5 + UP * 1.5)

        label_a = MathTex("a^2", color="#FF4500", font_size=52).move_to(sq_a)
        label_b = MathTex("b^2", color="#ffffff", font_size=52).move_to(sq_b)
        label_c = MathTex("c^2", color="#FFD700", font_size=52).move_to(sq_c)

        self.add(tri)
        self.play(GrowFromEdge(sq_a, UP),   run_time=1.2)
        self.play(Write(label_a),            run_time=0.6)
        self.play(GrowFromEdge(sq_b, RIGHT), run_time=1.2)
        self.play(Write(label_b),            run_time=0.6)
        self.play(GrowFromEdge(sq_c, LEFT),  run_time=1.2)
        self.play(Write(label_c),            run_time=0.6)
        self.wait(2)
"""

# ── Segment 4: Rearrangement proof (22-32s) ───────────────────────────────
PROOF = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        title = Text("The Visual Proof", color=WHITE, font_size=44).to_edge(UP, buff=0.4)
        self.play(Write(title), run_time=1)

        # big square c²
        big_sq = Square(side_length=3, color="#FFD700", fill_opacity=0.2, stroke_width=4)

        # four triangles inside
        triangles = VGroup(*[
            Polygon(
                ORIGIN, RIGHT * 1.8, UP * 2.4,
                color="#FF4500", fill_opacity=0.5, stroke_width=2
            ) for _ in range(4)
        ])
        triangles[0].move_to(big_sq.get_corner(DL) + RIGHT * 0.9 + UP * 1.2)
        triangles[1].rotate(PI/2).move_to(big_sq.get_corner(DR) + LEFT * 0.9 + UP * 1.2)
        triangles[2].rotate(PI).move_to(big_sq.get_corner(UR) + LEFT * 0.9 + DOWN * 1.2)
        triangles[3].rotate(-PI/2).move_to(big_sq.get_corner(UL) + RIGHT * 0.9 + DOWN * 1.2)

        inner = Square(side_length=1.2, color="#ffffff", fill_opacity=0.3, stroke_width=3)

        formula = MathTex(
            "a^2 + b^2 = c^2",
            font_size=64,
        ).to_edge(DOWN, buff=0.5)
        formula[0][0].set_color("#FF4500")
        formula[0][3].set_color("#ffffff")
        formula[0][6].set_color("#FFD700")

        self.play(Create(big_sq),          run_time=1)
        self.play(Create(triangles),       run_time=1.5)
        self.play(Create(inner),           run_time=0.8)
        self.play(Write(formula),          run_time=1.5)
        self.wait(1.5)
"""

# ── Segment 5: 3-4-5 real example (32-40s) ───────────────────────────────
EXAMPLE = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        title = Text("Real Example", color=WHITE, font_size=44).to_edge(UP, buff=0.4)

        A = LEFT * 2 + DOWN * 1
        B = RIGHT * 1 + DOWN * 1
        C = LEFT * 2 + UP * 1.67

        tri = Polygon(A, B, C, color=WHITE, stroke_width=4)

        l3 = MathTex("3", color="#FF4500", font_size=52).next_to(Line(A, B), DOWN, buff=0.2)
        l4 = MathTex("4", color="#ffffff", font_size=52).next_to(Line(A, C), LEFT, buff=0.2)
        l5 = MathTex("5", color="#FFD700", font_size=52).next_to(Line(B, C), RIGHT, buff=0.2)

        calc = MathTex(r"3^2 + 4^2 = 5^2", font_size=56, color=WHITE).shift(RIGHT * 1.5 + UP * 0.5)
        result = MathTex(r"9 + 16 = 25", font_size=52, color="#FF4500").next_to(calc, DOWN, buff=0.4)
        check = MathTex(r"\checkmark", font_size=80, color="#00ff88").next_to(result, DOWN, buff=0.3)

        self.play(Write(title), run_time=0.8)
        self.play(Create(tri), Write(l3), Write(l4), Write(l5), run_time=1.5)
        self.play(Write(calc),   run_time=1)
        self.play(Write(result), run_time=1)
        self.play(Write(check),  run_time=0.8)
        self.wait(1.5)
"""

# ── Segment 6: Mind blow fact (40-50s) ────────────────────────────────────
MINDBLOW = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        line1 = Text("This works for", font_size=52, color=WHITE).shift(UP * 1.5)
        line2 = Text("every right triangle.", font_size=52, color="#FF4500").shift(UP * 0.5)
        line3 = Text("Forever.", font_size=72, color="#FFD700", weight=BOLD).shift(DOWN * 0.8)

        formula = MathTex("a^2 + b^2 = c^2", font_size=52, color=WHITE).shift(DOWN * 2)

        self.play(FadeIn(line1, shift=UP * 0.2), run_time=1)
        self.play(FadeIn(line2, shift=UP * 0.2), run_time=1)
        self.play(FadeIn(line3, shift=UP * 0.2), run_time=1)
        self.play(
            Write(formula),
            line3.animate.set_color(WHITE),
            run_time=1.5,
        )
        self.wait(2)
"""

# ── Segment 7: Outro (50-58s) ─────────────────────────────────────────────
OUTRO = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        name = Text("mathmwk", font_size=80, color="#FF4500", weight=BOLD)
        sub  = Text("follow for more", font_size=36, color=WHITE).next_to(name, DOWN, buff=0.5)
        formula = MathTex("a^2 + b^2 = c^2", font_size=40, color=GRAY).next_to(sub, DOWN, buff=0.5)

        self.play(Write(name),    run_time=1.5)
        self.play(FadeIn(sub),    run_time=0.8)
        self.play(FadeIn(formula), run_time=0.8)
        self.wait(2)
"""

SEGMENTS = [
    {"name": "hook",      "code": HOOK,      "duration": 3},
    {"name": "triangle",  "code": TRIANGLE,  "duration": 9},
    {"name": "squares",   "code": SQUARES,   "duration": 10},
    {"name": "proof",     "code": PROOF,     "duration": 10},
    {"name": "example",   "code": EXAMPLE,   "duration": 8},
    {"name": "mindblow",  "code": MINDBLOW,  "duration": 10},
    {"name": "outro",     "code": OUTRO,     "duration": 8},
]




def runMathmwk(quality: str = "medium", format: str = "short"):
    
    start = time.time()
    width, height = (1920, 1080) if format == "long" else (1080, 1920)

    try:
        print(f"Rendering {len(SEGMENTS)} segments...")

        # ── render each segment ───────────────────────────────────────
        rendered = []
        for i, seg in enumerate(SEGMENTS):
            print(f"  [{i+1}/{len(SEGMENTS)}] {seg['name']} ({seg['duration']}s)")
            video = renderCustomScene(
                manim_code=seg["code"],
                duration=seg["duration"],
                quality=quality,
            )
            rendered.append(str(video))

        # ── combine all segments ──────────────────────────────────────
        combined = CACHE / "stitched" / f"mathmwk_{format}_{int(time.time())}.mp4"
        combined.parent.mkdir(parents=True, exist_ok=True)

        video = combineMedia(
            media=rendered,
            output=combined,
            transition="crossfade",
            duration=0.4,
            width=1920,
            height=1080,
            fps=60,
        )

        # ── resize to shorts ──────────────────────────────────────────
        #video = resizeVideo(video, width=width, height=height)

        # ── thumbnail ─────────────────────────────────────────────────
        thumb = generateThumbnail(
            title="Why a² + b² = c²",
            style="bold_text",
            bg_color="#0a0a0a",
            text_color="#ffffff",
            accent_color="#FF4500",
        )

        logRun("Mathmwk", "success", channel=CHANNEL,
               topic="pythagorean", duration=round(time.time() - start, 1))

        print(f"Video:     {video}")
        print(f"Thumbnail: {thumb}")
        return video, thumb

    except Exception as e:
        logRun("Mathmwk", "failed", channel=CHANNEL,
               topic="pythagorean", duration=round(time.time() - start, 1), error=str(e))
        raise