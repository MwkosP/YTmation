"""
Explain Like I'm 5 — Clustering (Tom + balls edition).

Tom no know clustering. Tom has balls. Tom want know WHERE balls.
Ooga booga voice. Layout helpers + simple Manim visuals.

python Workflows/channels/mathmwk/explainLike5Showcase.py
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"

BEAT_SECONDS = 7.0
TITLE_RUN = 1.2
SHOW_RUN = 3.2
PAD_WAIT = 2.0


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}


def _beat(body: str) -> str:
    b = body.strip()
    if "self.wait(" not in b.split("\n")[-1]:
        b += f"\nself.wait({PAD_WAIT})"
    return b


SEGMENTS = [
    _seg(
        "00_intro",
        "tom_meet_clustering",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle, makeCaption
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("hero")
title = makeTitle("Ooga Booga Explain", size=50, layout=layout)
sub = makeSubtitle("Topic: CLUSTERING (Tom edition)", size=30, layout=layout, below=title)
cap = makeCaption("Tom no know clustering. Tom learn now. Unga.", size=24, layout=layout)
self.play(Write(title), FadeIn(sub), FadeIn(cap), run_time={TITLE_RUN + 0.8})
"""
        ),
    ),
    _seg(
        "01_tom_has_balls",
        "many_ball",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("standard")
self.play(Write(makeTitle("Tom has ball. Many ball.", size=40, layout=layout)), run_time={TITLE_RUN})

tom_head = Circle(radius=0.35, color=GOLD, fill_opacity=0.85)
tom_body = Line(ORIGIN, DOWN * 0.9, color=GOLD, stroke_width=8)
tom = VGroup(tom_head, tom_body).arrange(DOWN, buff=0)
tom_label = Text("TOM", font_size=28, weight=BOLD, color=GOLD).next_to(tom, DOWN, buff=0.2)

balls = VGroup(*[Circle(radius=0.18, color=RED, fill_opacity=0.9) for _ in range(8)])
for i, b in enumerate(balls):
    b.move_to(np.array([np.random.uniform(-3, 3), np.random.uniform(-1.5, 1.5), 0]))
scene = VGroup(tom, tom_label, balls)
placeInRegion(scene, "main", layout=layout, fit=True)

cap = makeCaption("Tom proud. Ball everywhere. Ooga ooga.", size=24, layout=layout)
self.play(FadeIn(tom), Write(tom_label), LaggedStart(*[FadeIn(b, scale=0.2) for b in balls], lag_ratio=0.08), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "02_balls_on_floor",
        "floor_chaos",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("sidebar_left")
self.play(Write(makeTitle("Ball on floor. Floor full ball.", size=36, layout=layout)), run_time={TITLE_RUN})

floor = Rectangle(width=9, height=0.25, color=GREY_B, fill_opacity=0.5).move_to(DOWN * 2.2)
balls = VGroup()
for x in np.linspace(-3.8, 3.8, 14):
    c = Circle(radius=0.16, color=np.random.choice([RED, BLUE, GREEN, ORANGE]), fill_opacity=0.9)
    c.move_to(np.array([x + np.random.uniform(-0.2, 0.2), -2.0 + np.random.uniform(0, 1.8), 0]))
    balls.add(c)
placeInRegion(VGroup(floor, balls), "main", layout=layout, fit=True)

thought = VGroup(
    Text("Tom: ???", font_size=30, color=YELLOW),
    Text("Which ball where?", font_size=24, color=MUTED),
).arrange(DOWN, buff=0.25)
placeInRegion(thought, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

cap = makeCaption("Tom brain hurt. Too many ball.", size=22, layout=layout)
self.play(Create(floor), LaggedStart(*[FadeIn(b) for b in balls], lag_ratio=0.05), Write(thought), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "03_where_balls",
        "tom_want_know_where",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("WHERE BALL??", size=48, layout=layout)), run_time={TITLE_RUN})

tom = Text("TOM", font_size=56, weight=BOLD, color=GOLD)
question = Text("where these ball???", font_size=36, color=YELLOW)
arrows = VGroup(*[Arrow(ORIGIN, d, color=YELLOW, buff=0.1) for d in [UL, UR, DL, DR, UP, DOWN, LEFT, RIGHT]]).scale(0.55)
group = VGroup(tom, question, arrows).arrange(DOWN, buff=0.45)
placeInRegion(group, "main", layout=layout, fit=True)

cap = makeCaption("Tom want know where ball live. Not what ball name.", size=22, layout=layout)
self.play(Write(tom), Write(question), LaggedStart(*[GrowArrow(a) for a in arrows], lag_ratio=0.1), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "04_close_balls_friends",
        "near_means_friend",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("split")
self.play(Write(makeTitle("Ball near ball = friend pile", size=34, layout=layout)), run_time={TITLE_RUN})

pile_a = VGroup(*[Circle(radius=0.2, color=RED, fill_opacity=0.9) for _ in range(5)])
pile_b = VGroup(*[Circle(radius=0.2, color=BLUE, fill_opacity=0.9) for _ in range(5)])
pile_a.arrange_in_grid(rows=2, cols=3, buff=0.15).move_to(LEFT * 2.5 + DOWN * 0.3)
pile_b.arrange_in_grid(rows=2, cols=3, buff=0.15).move_to(RIGHT * 2.5 + DOWN * 0.3)
left = VGroup(pile_a, Text("friends", font_size=24, color=RED).next_to(pile_a, UP, buff=0.25))
right = VGroup(pile_b, Text("friends", font_size=24, color=BLUE).next_to(pile_b, UP, buff=0.25))
placeInRegion(left, "left", layout=layout, fit=True)
placeInRegion(right, "right", layout=layout, fit=True)

cap = makeCaption("Tom see: close ball stick together. Ooga.", size=22, layout=layout)
self.play(FadeIn(pile_a), FadeIn(pile_b), Write(left[1]), Write(right[1]), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "05_no_names_needed",
        "tom_no_need_label",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("Tom no need name. Just pile.", size=36, layout=layout)), run_time={TITLE_RUN})

piles = VGroup()
for col, label in [(RED, "???"), (BLUE, "???"), (GREEN, "???")]:
    box = RoundedRectangle(width=2.4, height=2.0, corner_radius=0.12, color=col).set_fill(col, opacity=0.15)
    dots = VGroup(*[Dot(point=np.array([np.random.uniform(-0.7, 0.7), np.random.uniform(-0.5, 0.5), 0]), radius=0.1, color=col) for _ in range(4)])
    tag = Text(label, font_size=32, color=MUTED).next_to(box, UP, buff=0.15)
    piles.add(VGroup(box, dots.move_to(box.get_center()), tag))
piles.arrange(RIGHT, buff=0.45)
placeInRegion(piles, "main", layout=layout, fit=True)

side = VGroup(
    Text("Classification = name", font_size=24, color=GREY_B),
    Text("Clustering = pile only", font_size=24, color=YELLOW),
    Text("Tom like pile. Simple.", font_size=24, color=GOLD),
).arrange(DOWN, aligned_edge=LEFT, buff=0.28)
placeInRegion(side, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

cap = makeCaption("Nobody tell Tom 'this apple'. Tom just see piles.", size=22, layout=layout)
self.play(FadeIn(piles), Write(side), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "06_distance_ooga",
        "close_far",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("formula_focus")
self.play(Write(makeTitle("Close = small step. Far = big step.", size=34, layout=layout)), run_time={TITLE_RUN})

a = Circle(radius=0.25, color=RED, fill_opacity=0.9).move_to(LEFT * 1.2)
b = Circle(radius=0.25, color=RED, fill_opacity=0.9).move_to(LEFT * 0.5)
c = Circle(radius=0.25, color=BLUE, fill_opacity=0.9).move_to(RIGHT * 2.2)
close_line = DashedLine(a.get_center(), b.get_center(), color=GREEN)
far_line = DashedLine(b.get_center(), c.get_center(), color=RED)
diagram = VGroup(a, b, c, close_line, far_line)
placeInRegion(diagram, "main", layout=layout, fit=True)

formula = Text("near friend  |  far stranger", font_size=30, color=YELLOW)
placeInRegion(formula, "formula", layout=layout, fit=True)

cap = makeCaption("Tom walk small step = same pile. Big step = different pile.", size=22, layout=layout)
self.play(FadeIn(a), FadeIn(b), FadeIn(c), Create(close_line), Create(far_line), Write(formula), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "07_draw_circles",
        "tom_draw_pile_ring",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("standard")
self.play(Write(makeTitle("Tom draw circle round friend ball", size=34, layout=layout)), run_time={TITLE_RUN})

cluster1 = VGroup(*[Circle(radius=0.18, color=RED, fill_opacity=0.85) for _ in range(6)])
cluster2 = VGroup(*[Circle(radius=0.18, color=BLUE, fill_opacity=0.85) for _ in range(6)])
cluster1.arrange_in_grid(rows=2, cols=3, buff=0.12).move_to(LEFT * 2.2 + UP * 0.2)
cluster2.arrange_in_grid(rows=2, cols=3, buff=0.12).move_to(RIGHT * 2.2 + DOWN * 0.2)
ring1 = Circle(radius=1.1, color=RED, stroke_width=4).move_to(cluster1.get_center())
ring2 = Circle(radius=1.1, color=BLUE, stroke_width=4).move_to(cluster2.get_center())
placeInRegion(VGroup(cluster1, cluster2, ring1, ring2), "main", layout=layout, fit=True)

cap = makeCaption("Circle = cluster. Tom happy. Unga bunga.", size=24, layout=layout)
self.play(FadeIn(cluster1), FadeIn(cluster2), Create(ring1), Create(ring2), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "08_two_or_three_piles",
        "how_many_pile",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("split")
self.play(Write(makeTitle("Two pile? Three pile? Tom choose.", size=34, layout=layout)), run_time={TITLE_RUN})

balls = VGroup()
positions = [LEFT * 2.5 + UP * 0.5, ORIGIN + DOWN * 0.3, RIGHT * 2.5 + UP * 0.4]
cols = [RED, GREEN, BLUE]
for pos, col in zip(positions, cols):
    grp = VGroup(*[Circle(radius=0.16, color=col, fill_opacity=0.9) for _ in range(4)])
    grp.arrange_in_grid(rows=2, cols=2, buff=0.12).move_to(pos)
    balls.add(grp)
left = VGroup(balls[0], balls[1])
right = balls[2]
placeInRegion(VGroup(left, Text("2 pile", font_size=28, color=YELLOW).next_to(left, DOWN, buff=0.5)), "left", layout=layout, fit=True)
placeInRegion(VGroup(right, Text("or 3 pile", font_size=28, color=YELLOW).next_to(right, DOWN, buff=0.5)), "right", layout=layout, fit=True)

cap = makeCaption("More pile = smaller groups. Tom pick with nose.", size=22, layout=layout)
self.play(FadeIn(balls), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "09_lonely_ball",
        "outlier_ooga",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("inset")
self.play(Write(makeTitle("One ball far away = lonely ball", size=34, layout=layout)), run_time={TITLE_RUN})

herd = VGroup(*[Circle(radius=0.2, color=YELLOW, fill_opacity=0.9) for _ in range(7)])
herd.arrange_in_grid(rows=2, cols=4, buff=0.15).move_to(LEFT * 1.5)
lonely = Circle(radius=0.28, color=GREY_B, fill_opacity=0.9).move_to(RIGHT * 3.0 + UP * 0.8)
arrow = Arrow(herd.get_right(), lonely.get_left(), color=RED, buff=0.2)
placeInRegion(VGroup(herd, lonely, arrow), "main", layout=layout, fit=True)

inset = RoundedRectangle(width=2.8, height=1.2, corner_radius=0.1, color=RED).set_fill(RED_E, opacity=0.2)
inset_txt = Text("Tom: why you alone?", font_size=20, color=RED).move_to(inset.get_center())
placeInRegion(VGroup(inset, inset_txt), "inset", layout=layout, fit=True)

cap = makeCaption("Lonely ball maybe weird. Maybe special. Tom shrug.", size=22, layout=layout)
self.play(FadeIn(herd), FadeIn(lonely), GrowArrow(arrow), FadeIn(inset), Write(inset_txt), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "10_tom_clean_cave",
        "sort_into_corners",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("stacked")
self.play(Write(makeTitle("Tom put each pile in corner", size=38, layout=layout)), run_time={TITLE_RUN})

corners = VGroup()
labels = ["red pile", "blue pile", "green pile"]
colors = [RED, BLUE, GREEN]
for lab, col in zip(labels, colors):
    corner = RoundedRectangle(width=6.8, height=0.95, corner_radius=0.1, color=col).set_fill(col, opacity=0.18)
    txt = Text(lab, font_size=28, color=col).move_to(corner.get_left() + RIGHT * 1.3)
    dots = VGroup(*[Dot(radius=0.09, color=col) for _ in range(5)]).arrange(RIGHT, buff=0.15).move_to(corner.get_right() + LEFT * 1.0)
    corners.add(VGroup(corner, txt, dots))
corners.arrange(DOWN, buff=0.22)
placeInRegion(corners, "main", layout=layout, fit=True)

footer = Text("Cave clean. Tom find ball fast now.", font_size=26, color=GOLD)
placeInRegion(footer, "footer", layout=layout, fit=True)

cap = makeCaption("Clustering = organize without name tags", size=22, layout=layout)
self.play(LaggedStart(*[FadeIn(c, shift=RIGHT * 0.25) for c in corners], lag_ratio=0.15), Write(footer), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "11_cave_market",
        "real_world_ooga",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("lecture")
self.play(Write(makeTitle("Cave market already cluster", size=36, layout=layout)), run_time={TITLE_RUN})

aisles = VGroup()
names = ["meat rock", "berry bush", "shiny rock"]
cols = [RED, GREEN, YELLOW]
for n, c in zip(names, cols):
    shelf = Rectangle(width=2.2, height=2.6, color=c).set_fill(c, opacity=0.12)
    label = Text(n, font_size=22, color=c).next_to(shelf, UP, buff=0.12)
    items = VGroup(*[Circle(radius=0.12, color=c, fill_opacity=0.8) for _ in range(4)]).arrange_in_grid(rows=2, cols=2, buff=0.1).move_to(shelf.get_center())
    aisles.add(VGroup(shelf, label, items))
aisles.arrange(RIGHT, buff=0.35)
placeInRegion(aisles, "main", layout=layout, fit=True)

side = VGroup(
    Text("Similar thing sit together", font_size=24),
    Text("Tom no read label", font_size=24),
    Text("Tom just see piles", font_size=24),
).arrange(DOWN, aligned_edge=LEFT, buff=0.25)
placeInRegion(side, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

cap = makeCaption("Maps, photos, customers — all pile like Tom ball", size=22, layout=layout)
self.play(FadeIn(aisles), Write(side), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "12_computer_ooga",
        "machine_find_pile",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("sidebar_left")
self.play(Write(makeTitle("Big rock brain find piles too", size=34, layout=layout)), run_time={TITLE_RUN})

screen = RoundedRectangle(width=7.2, height=3.8, corner_radius=0.15, color=GREY_B).set_fill(BLACK, opacity=0.45)
dots = VGroup()
for _ in range(30):
    d = Dot(radius=0.07, color=np.random.choice([RED, BLUE, GREEN, ORANGE]))
    d.move_to(np.array([np.random.uniform(-2.8, 2.8), np.random.uniform(-1.2, 1.2), 0]))
    dots.add(d)
rings = VGroup(
    Circle(radius=1.0, color=RED, stroke_width=3).move_to(LEFT * 1.4 + UP * 0.2),
    Circle(radius=0.9, color=BLUE, stroke_width=3).move_to(RIGHT * 1.2 + DOWN * 0.3),
)
ui = VGroup(screen, dots.move_to(screen.get_center()), rings)
placeInRegion(ui, "main", layout=layout, fit=True)

side = VGroup(
    Text("Tom feed many point", font_size=24),
    Text("Rock brain draw circles", font_size=24),
    Text("No name. Just cluster.", font_size=24, color=YELLOW),
).arrange(DOWN, aligned_edge=LEFT, buff=0.28)
placeInRegion(side, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

cap = makeCaption("k-means ooga = pick centers, pull friends close", size=22, layout=layout)
self.play(FadeIn(screen), FadeIn(dots), Create(rings), Write(side), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "13_tom_learned",
        "tom_smart_now",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Tom know clustering now", size=42, layout=layout)), run_time={TITLE_RUN})

tom = Text("TOM", font_size=64, weight=BOLD, color=GOLD)
lesson = VGroup(
    Text("1) Ball near ball = pile", font_size=28),
    Text("2) No name needed", font_size=28),
    Text("3) Tom know WHERE", font_size=28, color=YELLOW),
).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
group = VGroup(tom, lesson).arrange(RIGHT, buff=0.8)
placeInRegion(group, "main", layout=layout, fit=True)

cap = makeCaption("Classification name thing. Clustering find pile. Tom get it.", size=22, layout=layout)
self.play(Write(tom), LaggedStart(*[FadeIn(l, shift=RIGHT * 0.2) for l in lesson], lag_ratio=0.2), FadeIn(cap), run_time={SHOW_RUN})
"""
        ),
    ),
    _seg(
        "14_outro",
        "tom_happy_end",
        _beat(
            f"""
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle, makeCaption
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Tom happy. Ball sorted.", size=46, layout=layout)
sub = makeSubtitle("Clustering = find groups Tom did not name", size=28, layout=layout, below=title)
cap = makeCaption("Ooga booga · Clustering complete · Tom sleep good", size=22, layout=layout)
self.play(Write(title), FadeIn(sub), FadeIn(cap), run_time={TITLE_RUN + 0.6})
"""
        ),
    ),
]


def _sceneSource(body: str) -> str:
    return f"""
from manim import *
import numpy as np
from Math.library.common.styling import MUTED, ACCENT, TEXT

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
{textwrap.indent(body, "        ")}
"""


def runExplainLike5Showcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    rendered: list[str] = []
    total = len(SEGMENTS)
    print(
        f"{CHANNEL} explain-like-5 clustering (Tom) — {total} segments × ~{BEAT_SECONDS}s, "
        f"quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"eli5_clustering_{seg['name']}.mp4"
        path = renderCustomScene(
            manim_code=_sceneSource(seg["animation"]),
            output=out,
            quality=quality,
        )
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_eli5_clustering_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.25,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runExplainLike5Showcase(quality="low", format="long")
