"""
Bitcoin — Explain Like I'm 5 (~40s voiceover).

Uses the same workflow style as spatialDimensionsELI5Voiceover.py:
- pregenerate voice per segment
- renderCustomVoiceoverScene synced to tracker.duration
- stitch final video

Examples:
python Workflows/channels/mathmwk/bitcoinELI5Voiceover.py
python Workflows/channels/mathmwk/bitcoinELI5Voiceover.py --voice-backend orpheus --orpheus-voice tara --orpheus-max-new-tokens 300
"""

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomVoiceoverScene
from Math.voiceover.helpers import pregenerateOrpheusVoice, pregenerateVoice
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"
VOICE_CACHE = CACHE / "voice" / "bitcoin_eli5"
TARGET_SECONDS = 40
VOICE_SLOW = True

SEGMENTS = [
    {
        "name": "01_hook",
        "beat": "what is bitcoin",
        "narration": (
            "Bitcoin is internet money. "
            "No single bank controls it. "
            "Lots of computers keep it running together."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle

setupScene(self)
layout = SceneLayout("hero")
title = makeTitle("Bitcoin", size=56, layout=layout)
sub = makeSubtitle("Money on the internet", size=32, layout=layout, below=title)
self.play(Write(title), run_time=tracker.duration * 0.52)
self.play(FadeIn(sub), run_time=tracker.duration * 0.38)
self.wait(tracker.duration * 0.10)
""",
    },
    {
        "name": "02_shared_notebook",
        "beat": "everyone keeps the same list",
        "narration": (
            "Imagine a giant notebook everyone can read. "
            "When someone sends coins, the notebook writes it down."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.pacing import waitForVoice

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Shared Notebook", size=44, layout=layout)
book = RoundedRectangle(corner_radius=0.18, width=7.2, height=4.2, color=TEAL_B)
line1 = Line(LEFT * 2.6, RIGHT * 2.6, color=GREY_B).shift(UP * 0.8)
line2 = Line(LEFT * 2.6, RIGHT * 2.6, color=GREY_B)
line3 = Line(LEFT * 2.6, RIGHT * 2.6, color=GREY_B).shift(DOWN * 0.8)
entry = Text("Sam → Mia : 1 coin", font_size=30, color=YELLOW)
notebook = VGroup(book, line1, line2, line3, entry)
cap = makeCaption("A public list of transactions", layout=layout)
placeInRegion(notebook, "main", layout=layout, fit=True)
self.play(Write(title), run_time=tracker.duration * 0.18)
self.play(Create(book), Create(line1), Create(line2), Create(line3), run_time=tracker.duration * 0.28)
self.play(Write(entry), run_time=tracker.duration * 0.28)
self.play(FadeIn(cap), run_time=tracker.duration * 0.12)
waitForVoice(self, tracker)
""",
    },
    {
        "name": "03_blocks",
        "beat": "transactions grouped into blocks",
        "narration": (
            "New transactions are packed into blocks, like pages. "
            "Each new block links to the one before it."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.pacing import waitForVoice

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Blocks Chain Together", size=42, layout=layout)
b1 = Rectangle(width=2.0, height=1.2, color=BLUE_B, fill_opacity=0.15)
b2 = Rectangle(width=2.0, height=1.2, color=GREEN_B, fill_opacity=0.15)
b3 = Rectangle(width=2.0, height=1.2, color=PURPLE_B, fill_opacity=0.15)
a1 = Arrow(RIGHT * 0.9, RIGHT * 1.9, buff=0.0, color=GREY_B)
a2 = Arrow(RIGHT * 0.9, RIGHT * 1.9, buff=0.0, color=GREY_B)
chain = VGroup(b1, a1, b2, a2, b3).arrange(RIGHT, buff=0.25)
cap = makeCaption("Block 1 → Block 2 → Block 3", layout=layout)
placeInRegion(chain, "main", layout=layout, fit=True)
self.play(Write(title), run_time=tracker.duration * 0.17)
self.play(FadeIn(b1), run_time=tracker.duration * 0.14)
self.play(GrowArrow(a1), FadeIn(b2), run_time=tracker.duration * 0.23)
self.play(GrowArrow(a2), FadeIn(b3), run_time=tracker.duration * 0.23)
self.play(FadeIn(cap), run_time=tracker.duration * 0.10)
waitForVoice(self, tracker)
""",
    },
    {
        "name": "04_mining",
        "beat": "computers check puzzle",
        "narration": (
            "Computers race to solve a hard puzzle to add the next block. "
            "That work helps keep cheating very hard."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.pacing import waitForVoice

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Mining = Security Work", size=40, layout=layout)
pc1 = Square(side_length=1.1, color=BLUE_B)
pc2 = Square(side_length=1.1, color=GREEN_B)
pc3 = Square(side_length=1.1, color=PURPLE_B)
cpu_row = VGroup(pc1, pc2, pc3).arrange(RIGHT, buff=0.45)
puzzle = Text("Puzzle: 0000 ?", font_size=34, color=YELLOW)
check = Text("Solved ✓", font_size=34, color=TEAL_B)
scene_group = VGroup(cpu_row, puzzle, check).arrange(DOWN, buff=0.45)
cap = makeCaption("Many computers verify the same rules", layout=layout)
placeInRegion(scene_group, "main", layout=layout, fit=True)
self.play(Write(title), run_time=tracker.duration * 0.17)
self.play(FadeIn(cpu_row), run_time=tracker.duration * 0.25)
self.play(Write(puzzle), run_time=tracker.duration * 0.22)
self.play(Transform(puzzle, check), run_time=tracker.duration * 0.18)
self.play(FadeIn(cap), run_time=tracker.duration * 0.10)
waitForVoice(self, tracker)
""",
    },
    {
        "name": "05_recap",
        "beat": "simple summary",
        "narration": (
            "So Bitcoin is shared internet money, written in public blocks, "
            "and protected by computer work. That is Bitcoin, simply."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle

setupScene(self)
layout = SceneLayout("hero")
title = makeTitle("Bitcoin in Simple Words", size=44, layout=layout)
sub = makeSubtitle("Shared money + public blocks + security work", size=27, layout=layout, below=title)
self.play(Write(title), run_time=tracker.duration * 0.55)
self.play(FadeIn(sub), run_time=tracker.duration * 0.45)
""",
    },
]


def runBitcoinELI5Voiceover(
    quality: str = "low",
    format: str = "long",
    transcription_model: str | None = None,
    voice_slow: bool = VOICE_SLOW,
    voice_backend: str = "gtts",
    orpheus_voice: str = "tara",
    orpheus_max_new_tokens: int = 400,
) -> Path:
    start = time.time()
    width, height = (1920, 1080) if format == "long" else (1080, 1920)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    use_orpheus = voice_backend.lower() in ("orpheus", "hf", "hf_orpheus")
    voice_cache = (
        CACHE / "voice" / f"bitcoin_eli5_orpheus_{orpheus_voice}"
        if use_orpheus
        else VOICE_CACHE
    )
    voice_cache.mkdir(parents=True, exist_ok=True)

    print(
        f"{CHANNEL} bitcoin ELI5 voiceover — {len(SEGMENTS)} segments, "
        f"target ~{TARGET_SECONDS}s, voice={voice_backend}, quality={quality}",
        flush=True,
    )

    rendered: list[str] = []
    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{len(SEGMENTS)}] {seg['name']} — {seg['beat']}", flush=True)
        voice_path = voice_cache / f"{seg['name']}.mp3"
        out_path = CACHE / "math" / f"bitcoin_eli5_{seg['name']}.mp4"

        if not voice_path.is_file():
            if use_orpheus:
                print(f"    generating voice (Orpheus / {orpheus_voice})...", flush=True)
                pregenerateOrpheusVoice(
                    seg["narration"],
                    output=voice_path,
                    voice=orpheus_voice,
                    max_new_tokens=orpheus_max_new_tokens,
                )
            else:
                print(
                    "    generating voice (slow)..." if voice_slow else "    generating voice...",
                    flush=True,
                )
                pregenerateVoice(seg["narration"], output=voice_path, slow=voice_slow)

        video = renderCustomVoiceoverScene(
            narration=seg["narration"],
            animation_body=seg["animation"],
            voice_path=voice_path,
            output=out_path,
            quality=quality,
            pregenerate=False,
            transcription_model=transcription_model,
        )
        rendered.append(str(video))

    final_path = CACHE / "stitched" / f"mathmwk_bitcoin_eli5_{int(time.time())}.mp4"
    combined = combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.3,
        width=width,
        height=height,
        fps=30,
    )

    print(f"Stitched video: {combined}")
    print(f"Wall time: {time.time() - start:.1f}s (check playback length vs ~{TARGET_SECONDS}s target)")
    return combined


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--quality", default="low")
    parser.add_argument("--format", default="long", choices=("long", "short"))
    parser.add_argument(
        "--voice-backend",
        default="gtts",
        choices=("gtts", "orpheus"),
        help="gtts (default) or orpheus (HF Space MohamedRashad/Orpheus-TTS)",
    )
    parser.add_argument("--orpheus-voice", default="tara")
    parser.add_argument(
        "--orpheus-max-new-tokens",
        type=int,
        default=300,
        help="Orpheus max_new_tokens per segment (lower = shorter, cheaper).",
    )
    args = parser.parse_args()
    runBitcoinELI5Voiceover(
        quality=args.quality,
        format=args.format,
        voice_backend=args.voice_backend,
        orpheus_voice=args.orpheus_voice,
        orpheus_max_new_tokens=args.orpheus_max_new_tokens,
    )
