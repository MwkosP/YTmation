"""
Full Algebra library showcase — every demo + key primitives.

~3 seconds per segment. No voice. Long-form 1920x1080 default.
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"

# Target duration per stitched segment (animation + wait)
BEAT_SECONDS = 3.0
SHOW_RUN = 1.75
PAD_WAIT = 1.0


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}


def _beat(body: str) -> str:
    """Append padding wait so each clip ≈ BEAT_SECONDS."""
    b = body.strip()
    if "self.wait(" not in b.split("\n")[-1]:
        b += f"\nself.wait({PAD_WAIT})"
    return b


SEGMENTS = [
    _seg(
        "00_intro",
        "catalog",
        _beat("""
from Math.library.common.layout import makeTitle, makeSubtitle
from Math.library.common.styling import setupScene

setupScene(self)
title = makeTitle("Algebra Library", size=50)
sub = makeSubtitle("Math.library.math.algebra · 3s beats", size=28).next_to(title, DOWN, buff=0.35)
self.play(Write(title), FadeIn(sub), run_time=1.0)
"""),
    ),
    # ── RECIPES (23) ──────────────────────────────────────────────────────
    _seg("01_demo_combine_like_terms", "demoCombineLikeTerms", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.expressions import showCombineLikeTerms
setupScene(self)
showCombineLikeTerms(self, run_time={SHOW_RUN})
""")),
    _seg("02_demo_distribute", "demoDistribute", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.expressions import showDistribute
setupScene(self)
showDistribute(self, run_time={SHOW_RUN})
""")),
    _seg("03_demo_solve_linear", "demoSolveLinear", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.linear import showSolveLinear
setupScene(self)
showSolveLinear(self, run_time={SHOW_RUN})
""")),
    _seg("04_demo_balance", "demoBalanceEquation", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.linear import showBalanceEquation
setupScene(self)
showBalanceEquation(self, run_time={SHOW_RUN})
""")),
    _seg("05_demo_system", "demoSystem", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.systems import showSystemIntersection
setupScene(self)
showSystemIntersection(self, run_time={SHOW_RUN})
""")),
    _seg("06_demo_elimination", "demoElimination", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.systems import showEliminationSteps
setupScene(self)
showEliminationSteps(self, run_time={SHOW_RUN})
""")),
    _seg("07_demo_factor_trinomial", "demoFactorTrinomial", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.factoring import showFactorTrinomial
setupScene(self)
showFactorTrinomial(self, run_time={SHOW_RUN})
""")),
    _seg("08_demo_factor_dots", "demoFactorDots", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.factoring import showFactorDifferenceOfSquares
setupScene(self)
showFactorDifferenceOfSquares(self, run_time={SHOW_RUN})
""")),
    _seg("09_demo_quadratic", "demoQuadratic", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.quadratic import showQuadratic
setupScene(self)
showQuadratic(self, a=1, b=-1, c=-1, run_time={SHOW_RUN})
""")),
    _seg("10_demo_completing_square", "demoCompletingSquare", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.quadratic import showCompletingSquare
setupScene(self)
showCompletingSquare(self, run_time={SHOW_RUN})
""")),
    _seg("11_demo_vertex_form", "demoVertexForm", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.quadratic import showVertexForm
setupScene(self)
showVertexForm(self, h=2, k=-1, run_time={SHOW_RUN})
""")),
    _seg("12_demo_polynomial", "demoPolynomial", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.polynomial import showPolynomial
setupScene(self)
showPolynomial(self, coeffs=[1, 0, -2, 0.5], run_time={SHOW_RUN})
""")),
    _seg("13_demo_function_machine", "demoFunctionMachine", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.functions import showFunctionMachine
setupScene(self)
showFunctionMachine(self, run_time={SHOW_RUN})
""")),
    _seg("14_demo_composition", "demoComposition", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.composition import showComposition
setupScene(self)
showComposition(self, run_time={SHOW_RUN})
""")),
    _seg("15_demo_graph_transform", "demoGraphTransform", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.transformations import showGraphTransformation
setupScene(self)
showGraphTransformation(self, run_time={SHOW_RUN})
""")),
    _seg("16_demo_exponential", "demoExponential", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.exponential import showExponentialGrowth
setupScene(self)
showExponentialGrowth(self, run_time={SHOW_RUN})
""")),
    _seg("17_demo_exp_log", "demoExpLogInverse", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.logarithmic import showExpLogInverse
setupScene(self)
showExpLogInverse(self, run_time={SHOW_RUN})
""")),
    _seg("18_demo_arithmetic_sequence", "demoArithmeticSequence", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.sequences import showArithmeticSequence
setupScene(self)
showArithmeticSequence(self, run_time={SHOW_RUN})
""")),
    _seg("19_demo_binomial", "demoBinomialTheorem", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.binomial import showBinomialTheorem
setupScene(self)
showBinomialTheorem(self, run_time={SHOW_RUN})
""")),
    _seg("20_demo_complex", "demoComplexMultiply", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.complex import showComplexMultiply
setupScene(self)
showComplexMultiply(self, run_time={SHOW_RUN})
""")),
    _seg("21_demo_square_identity", "demoSquareIdentity", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.laws import showSquareIdentity
setupScene(self)
showSquareIdentity(self, run_time={SHOW_RUN})
""")),
    _seg("22_demo_induction", "demoInduction", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.induction import showInduction
setupScene(self)
showInduction(self, run_time={SHOW_RUN})
""")),
    _seg("23_demo_cayley", "demoCayleyTable", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.groups import showCayleyTable
setupScene(self)
showCayleyTable(self, run_time={SHOW_RUN})
""")),
    # ── EXTRA PRIMITIVES (not separate demos) ─────────────────────────────
    _seg("24_inequality_numberline", "showInequalityOnNumberLine", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.inequalities import showInequalityOnNumberLine
setupScene(self)
showInequalityOnNumberLine(self, run_time={SHOW_RUN})
""")),
    _seg("25_inequality_halfplane", "showLinearInequality", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.inequalities import showLinearInequality
setupScene(self)
showLinearInequality(self, run_time={SHOW_RUN})
""")),
    _seg("26_absolute_value", "showAbsoluteValue", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.absolute_value import showAbsoluteValue
setupScene(self)
showAbsoluteValue(self, run_time={SHOW_RUN})
""")),
    _seg("27_rational", "showRationalFunction", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.rational import showRationalFunction
setupScene(self)
showRationalFunction(self, run_time={SHOW_RUN})
""")),
    _seg("28_roots_on_graph", "showRootsOnGraph", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.roots import showRootsOnGraph
setupScene(self)
showRootsOnGraph(self, coeffs=[1, -5, 6, 0], run_time={SHOW_RUN})
""")),
    _seg("29_piecewise", "showPiecewise", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.functions import showPiecewise
setupScene(self)
showPiecewise(self, run_time={SHOW_RUN})
""")),
    _seg("30_inverse", "showInverseReflection", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.inverse import showInverseReflection
setupScene(self)
showInverseReflection(self, run_time={SHOW_RUN})
""")),
    _seg("31_geometric_sequence", "showGeometricSequence", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.sequences import showGeometricSequence
setupScene(self)
showGeometricSequence(self, run_time={SHOW_RUN})
""")),
    _seg("32_radical", "showSimplifyRadical", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.radical import showSimplifyRadical
setupScene(self)
showSimplifyRadical(self, run_time={SHOW_RUN})
""")),
    _seg("33_substitution", "showSubstitution", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.substitution import showSubstitution
setupScene(self)
showSubstitution(self, run_time={SHOW_RUN})
""")),
    _seg("34_factor_gcf", "showFactorGcf", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.factoring import showFactorGcf
setupScene(self)
showFactorGcf(self, run_time={SHOW_RUN})
""")),
    _seg("35_conic_parabola", "showParabola", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.conics import showParabola
setupScene(self)
showParabola(self, run_time={SHOW_RUN})
""")),
    _seg("36_conic_ellipse", "showEllipse", _beat(f"""
from Math.library.common.styling import setupScene
from Math.library.math.algebra.conics import showEllipse
setupScene(self)
showEllipse(self, run_time={SHOW_RUN})
""")),
    _seg(
        "37_outro",
        "end",
        _beat("""
from Math.library.common.layout import makeTitle, makeSubtitle
from Math.library.common.styling import setupScene

setupScene(self)
title = makeTitle("Algebra library complete", size=46)
sub = makeSubtitle("algebra/AGENT.md", size=26).next_to(title, DOWN, buff=0.35)
self.play(Write(title), FadeIn(sub), run_time=1.0)
"""),
    ),
]


def _sceneSource(animation: str) -> str:
    body = textwrap.indent(animation.strip(), "        ")
    return f"""
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
{body}
"""


def runAlgebraShowcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    rendered: list[str] = []
    total = len(SEGMENTS)
    print(
        f"{CHANNEL} algebra showcase — {total} segments × ~{BEAT_SECONDS}s, "
        f"quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"algebra_showcase_{seg['name']}.mp4"
        path = renderCustomScene(
            manim_code=_sceneSource(seg["animation"]),
            output=out,
            quality=quality,
        )
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_algebra_showcase_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        transition="crossfade",
        duration=0.15,
        output=final_path,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runAlgebraShowcase(quality="low", format="long")
