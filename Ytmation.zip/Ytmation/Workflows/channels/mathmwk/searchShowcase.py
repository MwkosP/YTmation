"""
Workflows/channels/mathmwk/searchExplainerShowcase.py

20-scene explainer: Search Algorithms
Target duration: ~5 minutes (300s)
Each scene targets ~15-30s of wait time plus animation
Covers: linear, binary, jump, interpolation, hash search + Big O
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia
from Math.library.common.layout import (
    SceneLayout, placeInRegion, makeTitle, makeSubtitle, makeCaption
)
from Math.library.common.styling import setupScene


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}

def _beat(body: str) -> str:
    return body.strip()

def _sceneSource(body: str) -> str:
    indented = textwrap.indent(textwrap.dedent(body).strip(), "        ")
    return f"""from manim import *
from Math.library.common.layout import SceneLayout, placeInRegion, makeTitle, makeSubtitle, makeCaption
from Math.library.common.styling import setupScene

class CustomScene(Scene):
    def construct(self):
{indented}
"""


SEGMENTS = [

    # 1 ── title (~20s) ───────────────────────────────────────────────────────
    _seg(
        name="title",
        beat=_beat("Title card"),
        animation=_sceneSource("""
        setupScene(self)
        title = Text("How Does a Computer Search?", font_size=48, color=WHITE)
        sub   = Text("Search Algorithms", font_size=28, color=GRAY)
        group = VGroup(title, sub).arrange(DOWN, buff=0.4)
        group.move_to(ORIGIN + UP * 0.5)
        self.play(FadeIn(title), run_time=0.8)
        self.play(FadeIn(sub),   run_time=0.6)
        self.wait(15)
        self.play(FadeOut(group))
        """),
    ),

    # 2 ── what is search (~30s) ──────────────────────────────────────────────
    _seg(
        name="what_is_search",
        beat=_beat("Phonebook analogy"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("What Is Search?", size=38, layout=layout)
        cap   = makeCaption("Finding one item inside a list of many.", size=22, layout=layout)

        names = ["Alice", "Bob", "Carol", "Dave", "Eve", "Frank", "Grace", "Henry"]
        boxes = VGroup(*[
            VGroup(
                Rectangle(width=1.3, height=0.55, fill_color=BLUE_E,
                          fill_opacity=0.8, stroke_width=0.5),
                Text(n, font_size=20, color=WHITE),
            ).arrange(ORIGIN)
            for n in names
        ]).arrange(RIGHT, buff=0.12)
        boxes.move_to(ORIGIN)

        question = Text('Where is "Eve"?', font_size=30, color=YELLOW)
        question.next_to(boxes, UP, buff=0.6)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(b) for b in boxes], lag_ratio=0.08))
        self.wait(3)
        self.play(FadeIn(question))
        self.wait(3)
        self.play(boxes[4][0].animate.set_fill(GREEN), run_time=0.5)
        self.wait(8)
        self.play(FadeOut(VGroup(title, cap, boxes, question)))
        """),
    ),

    # 3 ── linear search idea (~30s) ──────────────────────────────────────────
    _seg(
        name="linear_search_idea",
        beat=_beat("Linear search steps"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Linear Search", size=38, layout=layout)
        sub   = makeSubtitle("Check each item one by one from the start.", size=24, layout=layout, below=title)
        cap   = makeCaption("Simple. Works on any list. Slow on large data.", size=22, layout=layout)

        steps = VGroup(
            Text("1. Start at the first item",        font_size=26, color=WHITE),
            Text("2. Is this the one we want?",       font_size=26, color=WHITE),
            Text("3. Yes -> done.  No -> move right", font_size=26, color=WHITE),
            Text("4. Repeat until found or end",      font_size=26, color=WHITE),
        ).arrange(DOWN, buff=0.45, aligned_edge=LEFT)
        steps.move_to(ORIGIN + UP * 0.3)

        self.play(FadeIn(title), FadeIn(sub), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(s) for s in steps], lag_ratio=0.3))
        self.wait(12)
        self.play(FadeOut(VGroup(title, sub, cap, steps)))
        """),
    ),

    # 4 ── linear search animated (~35s) ──────────────────────────────────────
    _seg(
        name="linear_search_animated",
        beat=_beat("Animate linear search"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Linear Search in Action", size=38, layout=layout)
        cap   = makeCaption("Checking each box until we find 7.", size=22, layout=layout)

        values = [3, 1, 5, 8, 7, 2, 9, 4]
        target = 7
        bar_w, gap = 0.7, 0.15

        boxes = VGroup(*[
            VGroup(
                Rectangle(width=bar_w, height=0.7, fill_color=BLUE_E,
                          fill_opacity=0.85, stroke_width=0.5),
                Text(str(v), font_size=24, color=WHITE),
            ).arrange(ORIGIN)
            for v in values
        ]).arrange(RIGHT, buff=gap)
        boxes.move_to(ORIGIN)

        step_label = Text("Checking...", font_size=26, color=YELLOW)
        step_label.next_to(boxes, UP, buff=0.5)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(b) for b in boxes], lag_ratio=0.08))
        self.play(FadeIn(step_label))
        self.wait(2)

        for i, v in enumerate(values):
            new_lbl = Text(f"Is {v} == {target}?", font_size=26, color=YELLOW)
            new_lbl.move_to(step_label)
            self.play(
                Transform(step_label, new_lbl),
                boxes[i][0].animate.set_fill(YELLOW),
                run_time=0.4,
            )
            self.wait(1.2)
            if v == target:
                found_lbl = Text(f"Found {target}!", font_size=28, color=GREEN)
                found_lbl.move_to(step_label)
                self.play(
                    Transform(step_label, found_lbl),
                    boxes[i][0].animate.set_fill(GREEN),
                    run_time=0.4,
                )
                self.wait(6)
                break
            else:
                self.play(boxes[i][0].animate.set_fill(RED_E), run_time=0.25)

        self.play(FadeOut(VGroup(title, cap, boxes, step_label)))
        """),
    ),

    # 5 ── problem with linear (~25s) ─────────────────────────────────────────
    _seg(
        name="linear_problem",
        beat=_beat("Linear is slow on big data"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("The Problem With Linear", size=38, layout=layout)
        cap   = makeCaption("The bigger the list, the more checks needed.", size=22, layout=layout)

        lines = VGroup(
            Text("100 items    ->  100 checks worst case",       font_size=26, color=YELLOW),
            Text("10,000 items ->  10,000 checks worst case",    font_size=26, color=ORANGE),
            Text("1,000,000    ->  1,000,000 checks worst case", font_size=26, color=RED),
        ).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        lines.move_to(ORIGIN)

        self.play(FadeIn(title), FadeIn(cap))
        for line in lines:
            self.play(FadeIn(line), run_time=0.5)
            self.wait(4)
        self.wait(5)
        self.play(FadeOut(VGroup(title, cap, lines)))
        """),
    ),

    # 6 ── binary search idea (~30s) ──────────────────────────────────────────
    _seg(
        name="binary_search_idea",
        beat=_beat("Binary search: sorted list, split in half"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Binary Search", size=38, layout=layout)
        sub   = makeSubtitle("List must be sorted. Split in half each time.", size=24, layout=layout, below=title)
        cap   = makeCaption("Each step cuts the remaining items in half.", size=22, layout=layout)

        steps = VGroup(
            Text("1. Look at the middle item",          font_size=26, color=WHITE),
            Text("2. Too high? Search the left half",   font_size=26, color=WHITE),
            Text("3. Too low?  Search the right half",  font_size=26, color=WHITE),
            Text("4. Repeat until found",               font_size=26, color=WHITE),
        ).arrange(DOWN, buff=0.45, aligned_edge=LEFT)
        steps.move_to(ORIGIN + UP * 0.3)

        self.play(FadeIn(title), FadeIn(sub), FadeIn(cap))
        for s in steps:
            self.play(FadeIn(s), run_time=0.5)
            self.wait(3)
        self.wait(5)
        self.play(FadeOut(VGroup(title, sub, cap, steps)))
        """),
    ),

    # 7 ── binary search animated (~35s) ──────────────────────────────────────
    _seg(
        name="binary_search_animated",
        beat=_beat("Animate binary search with mid pointer"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Binary Search in Action", size=38, layout=layout)
        cap   = makeCaption("Looking for 14 in a sorted list.", size=22, layout=layout)

        values = [2, 5, 7, 9, 11, 14, 17, 20]
        target = 14
        bar_w, gap = 0.75, 0.25

        boxes = VGroup(*[
            VGroup(
                Rectangle(width=bar_w, height=0.7, fill_color=BLUE_E,
                          fill_opacity=0.85, stroke_width=0.5),
                Text(str(v), font_size=24, color=WHITE),
            ).arrange(ORIGIN)
            for v in values
        ]).arrange(RIGHT, buff=gap)
        boxes.move_to(ORIGIN)

        step_label = Text("", font_size=26, color=YELLOW)
        step_label.next_to(boxes, UP, buff=0.5)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(b) for b in boxes], lag_ratio=0.08))
        self.play(FadeIn(step_label))
        self.wait(2)

        lo, hi = 0, len(values) - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            new_lbl = Text(f"mid = {values[mid]}", font_size=26, color=YELLOW)
            new_lbl.move_to(step_label)
            self.play(
                Transform(step_label, new_lbl),
                boxes[mid][0].animate.set_fill(YELLOW),
                run_time=0.4,
            )
            self.wait(1.5)
            if values[mid] == target:
                found_lbl = Text(f"Found {target}!", font_size=28, color=GREEN)
                found_lbl.move_to(step_label)
                self.play(
                    Transform(step_label, found_lbl),
                    boxes[mid][0].animate.set_fill(GREEN),
                    run_time=0.4,
                )
                self.wait(6)
                break
            elif values[mid] < target:
                for i in range(lo, mid + 1):
                    self.play(boxes[i][0].animate.set_fill(GRAY, opacity=0.3), run_time=0.08)
                lo = mid + 1
            else:
                for i in range(mid, hi + 1):
                    self.play(boxes[i][0].animate.set_fill(GRAY, opacity=0.3), run_time=0.08)
                hi = mid - 1

        self.play(FadeOut(VGroup(title, cap, boxes, step_label)))
        """),
    ),

    # 8 ── linear vs binary comparison (~30s) ─────────────────────────────────
    _seg(
        name="linear_vs_binary",
        beat=_beat("Comparison table linear vs binary"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Linear vs Binary", size=38, layout=layout)
        cap   = makeCaption("Same list. Very different number of steps.", size=22, layout=layout)

        rows = VGroup(
            Text("List size     Linear (worst)   Binary (worst)", font_size=22, color=GRAY),
            Text("8 items       8 checks          3 checks",       font_size=24, color=WHITE),
            Text("1,000         1,000 checks      10 checks",      font_size=24, color=WHITE),
            Text("1,000,000     1,000,000 checks  20 checks",      font_size=24, color=WHITE),
        ).arrange(DOWN, buff=0.45, aligned_edge=LEFT)
        rows.move_to(ORIGIN)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(FadeIn(rows[0]), run_time=0.4)
        for row in rows[1:]:
            self.play(FadeIn(row), run_time=0.5)
            self.wait(3)
        highlight = SurroundingRectangle(rows[3], color=GREEN, buff=0.1)
        self.play(Create(highlight))
        self.wait(8)
        self.play(FadeOut(VGroup(title, cap, rows, highlight)))
        """),
    ),

    # 9 ── jump search idea (~25s) ─────────────────────────────────────────────
    _seg(
        name="jump_search_idea",
        beat=_beat("Jump search: skip blocks then linear"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Jump Search", size=38, layout=layout)
        sub   = makeSubtitle("Jump ahead in fixed steps. Then search backwards.", size=24, layout=layout, below=title)
        cap   = makeCaption("Faster than linear. Simpler than binary.", size=22, layout=layout)

        steps = VGroup(
            Text("1. List must be sorted",                    font_size=26, color=WHITE),
            Text("2. Jump forward by sqrt(n) steps",          font_size=26, color=WHITE),
            Text("3. Overshot? Step backwards one by one",    font_size=26, color=WHITE),
            Text("4. Found or not found",                     font_size=26, color=WHITE),
        ).arrange(DOWN, buff=0.45, aligned_edge=LEFT)
        steps.move_to(ORIGIN + UP * 0.3)

        self.play(FadeIn(title), FadeIn(sub), FadeIn(cap))
        for s in steps:
            self.play(FadeIn(s), run_time=0.5)
            self.wait(3)
        self.wait(4)
        self.play(FadeOut(VGroup(title, sub, cap, steps)))
        """),
    ),

    # 10 ── jump search animated (~35s) ───────────────────────────────────────
    _seg(
        name="jump_search_animated",
        beat=_beat("Animate jump search with block jumps"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Jump Search in Action", size=38, layout=layout)
        cap   = makeCaption("Looking for 14. Jump step = 3.", size=22, layout=layout)

        values = [1, 3, 5, 7, 9, 11, 14, 17, 19, 22, 25, 28]
        target = 14
        step   = 3
        bar_w, gap = 0.52, 0.1

        boxes = VGroup(*[
            VGroup(
                Rectangle(width=bar_w, height=0.65, fill_color=BLUE_E,
                          fill_opacity=0.85, stroke_width=0.5),
                Text(str(v), font_size=20, color=WHITE),
            ).arrange(ORIGIN)
            for v in values
        ]).arrange(RIGHT, buff=gap)
        boxes.move_to(ORIGIN)

        step_label = Text("Jumping...", font_size=26, color=YELLOW)
        step_label.next_to(boxes, UP, buff=0.5)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(b) for b in boxes], lag_ratio=0.05))
        self.play(FadeIn(step_label))
        self.wait(1)

        prev, curr = 0, 0
        while curr < len(values) and values[curr] <= target:
            lbl = Text(f"Jump to index {curr} -> {values[curr]}", font_size=24, color=YELLOW)
            lbl.move_to(step_label)
            self.play(Transform(step_label, lbl), boxes[curr][0].animate.set_fill(YELLOW), run_time=0.4)
            self.wait(1.2)
            if values[curr] == target:
                break
            self.play(boxes[curr][0].animate.set_fill(BLUE_E), run_time=0.2)
            prev = curr
            curr = min(curr + step, len(values) - 1)

        # linear scan back
        for i in range(prev, min(curr + 1, len(values))):
            lbl = Text(f"Check {values[i]}", font_size=24, color=ORANGE)
            lbl.move_to(step_label)
            self.play(Transform(step_label, lbl), boxes[i][0].animate.set_fill(ORANGE), run_time=0.35)
            self.wait(0.8)
            if values[i] == target:
                found_lbl = Text(f"Found {target}!", font_size=28, color=GREEN)
                found_lbl.move_to(step_label)
                self.play(Transform(step_label, found_lbl), boxes[i][0].animate.set_fill(GREEN), run_time=0.4)
                self.wait(5)
                break
            else:
                self.play(boxes[i][0].animate.set_fill(RED_E), run_time=0.2)

        self.play(FadeOut(VGroup(title, cap, boxes, step_label)))
        """),
    ),

    # 11 ── interpolation search idea (~25s) ──────────────────────────────────
    _seg(
        name="interpolation_search_idea",
        beat=_beat("Interpolation search: guess where target is"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Interpolation Search", size=38, layout=layout)
        sub   = Text("Guess where the target is based on its value.", font_size=24, color=WHITE).next_to(title, DOWN, buff=0.2)
        cap   = makeCaption("Like how you open a dictionary near the right letter.", size=22, layout=layout)

        steps = VGroup(
            Text("1. List must be sorted and evenly spread",   font_size=26, color=WHITE),
            Text("2. Estimate position using a formula",       font_size=26, color=WHITE),
            Text("3. Check that position",                     font_size=26, color=WHITE),
            Text("4. Adjust and repeat if not found",          font_size=26, color=WHITE),
        ).arrange(DOWN, buff=0.45, aligned_edge=LEFT)
        steps.move_to(ORIGIN + UP * 0.3)

        self.play(FadeIn(title), FadeIn(sub), FadeIn(cap))
        for s in steps:
            self.play(FadeIn(s), run_time=0.5)
            self.wait(3)
        self.wait(4)
        self.play(FadeOut(VGroup(title, sub, cap, steps)))
        """),
    ),

    # 12 ── interpolation search animated (~35s) ───────────────────────────────
    _seg(
        name="interpolation_search_animated",
        beat=_beat("Animate interpolation search with position formula"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Interpolation Search in Action", size=36, layout=layout)
        cap   = makeCaption("Looking for 70. Formula guesses the position.", size=22, layout=layout)

        values = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
        target = 70
        bar_w, gap = 0.62, 0.12

        boxes = VGroup(*[
            VGroup(
                Rectangle(width=bar_w, height=0.65, fill_color=BLUE_E,
                          fill_opacity=0.85, stroke_width=0.5),
                Text(str(v), font_size=20, color=WHITE),
            ).arrange(ORIGIN)
            for v in values
        ]).arrange(RIGHT, buff=gap)
        boxes.move_to(ORIGIN)

        step_label = Text("", font_size=24, color=YELLOW)
        step_label.next_to(boxes, UP, buff=0.5)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(b) for b in boxes], lag_ratio=0.06))
        self.play(FadeIn(step_label))
        self.wait(2)

        lo, hi = 0, len(values) - 1
        while lo <= hi and values[lo] <= target <= values[hi]:
            pos = lo + ((target - values[lo]) * (hi - lo) // (values[hi] - values[lo]))
            lbl = Text(f"Guess index {pos} -> {values[pos]}", font_size=24, color=YELLOW)
            lbl.move_to(step_label)
            self.play(Transform(step_label, lbl), boxes[pos][0].animate.set_fill(YELLOW), run_time=0.45)
            self.wait(1.5)
            if values[pos] == target:
                found_lbl = Text(f"Found {target}!", font_size=28, color=GREEN)
                found_lbl.move_to(step_label)
                self.play(Transform(step_label, found_lbl), boxes[pos][0].animate.set_fill(GREEN), run_time=0.4)
                self.wait(6)
                break
            elif values[pos] < target:
                self.play(boxes[pos][0].animate.set_fill(RED_E), run_time=0.2)
                lo = pos + 1
            else:
                self.play(boxes[pos][0].animate.set_fill(RED_E), run_time=0.2)
                hi = pos - 1

        self.play(FadeOut(VGroup(title, cap, boxes, step_label)))
        """),
    ),

    # 13 ── hash search idea (~25s) ────────────────────────────────────────────
    _seg(
        name="hash_search_idea",
        beat=_beat("Hash search: direct lookup via key"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Hash Search", size=38, layout=layout)
        sub   = makeSubtitle("Convert the key into a position directly.", size=24, layout=layout, below=title)
        cap   = makeCaption("No scanning. No splitting. Almost instant.", size=22, layout=layout)

        steps = VGroup(
            Text("1. Run the key through a hash function",    font_size=26, color=WHITE),
            Text("2. Hash gives you an index",                font_size=26, color=WHITE),
            Text("3. Go directly to that index",              font_size=26, color=WHITE),
            Text("4. Found in 1 step (usually)",              font_size=26, color=GREEN),
        ).arrange(DOWN, buff=0.45, aligned_edge=LEFT)
        steps.move_to(ORIGIN + UP * 0.3)

        self.play(FadeIn(title), FadeIn(sub), FadeIn(cap))
        for s in steps:
            self.play(FadeIn(s), run_time=0.5)
            self.wait(3)
        self.wait(4)
        self.play(FadeOut(VGroup(title, sub, cap, steps)))
        """),
    ),

    # 14 ── hash search animated (~30s) ────────────────────────────────────────
    _seg(
        name="hash_search_animated",
        beat=_beat("Animate hash function mapping key to bucket"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Hash Search in Action", size=38, layout=layout)
        cap   = makeCaption('key "Eve" -> hash -> index 4 -> found instantly.', size=22, layout=layout)

        buckets = VGroup(*[
            VGroup(
                Rectangle(width=1.0, height=0.65, fill_color=BLUE_E,
                          fill_opacity=0.7, stroke_width=0.5),
                Text(f"[{i}]", font_size=20, color=GRAY),
            ).arrange(ORIGIN)
            for i in range(8)
        ]).arrange(RIGHT, buff=0.15)
        buckets.move_to(ORIGIN)

        # fill some buckets
        names_at = {0: "Alice", 2: "Bob", 4: "Eve", 6: "Frank"}
        for idx, name in names_at.items():
            lbl = Text(name, font_size=18, color=WHITE)
            lbl.move_to(buckets[idx])
            buckets[idx].add(lbl)

        key_text = Text('"Eve"', font_size=32, color=YELLOW).move_to(UP * 2.2)
        arrow1   = Arrow(key_text.get_bottom(), key_text.get_bottom() + DOWN * 0.6, color=YELLOW)
        hash_box = VGroup(
            Rectangle(width=2.0, height=0.6, fill_color=PURPLE_E, fill_opacity=0.8, stroke_width=0.5),
            Text("hash(Eve) = 4", font_size=22, color=WHITE),
        ).arrange(ORIGIN)
        hash_box.next_to(key_text, DOWN, buff=0.7)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(b) for b in buckets], lag_ratio=0.08))
        self.wait(2)
        self.play(FadeIn(key_text))
        self.wait(1)
        self.play(GrowArrow(arrow1), FadeIn(hash_box))
        self.wait(2)
        self.play(
            buckets[4][0].animate.set_fill(GREEN),
            run_time=0.5,
        )
        result = Text("Found in 1 step!", font_size=28, color=GREEN)
        result.next_to(buckets, DOWN, buff=0.5)
        self.play(FadeIn(result))
        self.wait(6)
        self.play(FadeOut(VGroup(title, cap, buckets, key_text, arrow1, hash_box, result)))
        """),
    ),

    # 15 ── all 4 compared (~30s) ──────────────────────────────────────────────
    _seg(
        name="all_compared",
        beat=_beat("Table comparing all 4 algorithms"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("All Four Compared", size=38, layout=layout)
        cap   = makeCaption("Sorted = list must be sorted before searching.", size=22, layout=layout)

        rows = VGroup(
            Text("Algorithm      Sorted?   Speed (big list)", font_size=22, color=GRAY),
            Text("Linear          No        Slow   O(n)",     font_size=23, color=WHITE),
            Text("Binary          Yes       Fast   O(log n)", font_size=23, color=WHITE),
            Text("Jump            Yes       Medium O(sqrt n)",font_size=23, color=WHITE),
            Text("Hash            No        Instant O(1)",    font_size=23, color=GREEN),
        ).arrange(DOWN, buff=0.38, aligned_edge=LEFT)
        rows.move_to(ORIGIN)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(r) for r in rows], lag_ratio=0.2))
        self.wait(12)
        self.play(FadeOut(VGroup(title, cap, rows)))
        """),
    ),

    # 16 ── when to use which (~25s) ───────────────────────────────────────────
    _seg(
        name="when_to_use",
        beat=_beat("Decision guide for which algorithm to pick"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Which One Do I Use?", size=38, layout=layout)
        cap   = makeCaption("It depends on your data.", size=22, layout=layout)

        rules = VGroup(
            Text("Small list or unsorted  ->  Linear",    font_size=25, color=BLUE_B),
            Text("Large sorted list       ->  Binary",    font_size=25, color=TEAL_B),
            Text("Large sorted, uniform   ->  Interpolation", font_size=25, color=YELLOW),
            Text("Need instant lookup     ->  Hash",      font_size=25, color=GREEN),
        ).arrange(DOWN, buff=0.5, aligned_edge=LEFT)
        rules.move_to(ORIGIN)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(r) for r in rules], lag_ratio=0.2))
        self.wait(12)
        self.play(FadeOut(VGroup(title, cap, rules)))
        """),
    ),

    # 17 ── real world examples (~30s) ─────────────────────────────────────────
    _seg(
        name="real_world",
        beat=_beat("Real world uses"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Search Is Everywhere", size=38, layout=layout)
        cap   = makeCaption("Every time you search, an algorithm runs.", size=22, layout=layout)

        examples = VGroup(
            Text("[google]   Billions of pages searched in ms",   font_size=24, color=WHITE),
            Text("[phone]    Finding a contact by name",           font_size=24, color=WHITE),
            Text("[database] Looking up a user by ID via hash",    font_size=24, color=WHITE),
            Text("[store]    Finding a product in inventory",      font_size=24, color=WHITE),
        ).arrange(DOWN, buff=0.4, aligned_edge=LEFT)
        examples.move_to(ORIGIN + UP * 0.5)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(ex) for ex in examples], lag_ratio=0.3))
        self.wait(10)
        self.play(FadeOut(VGroup(title, cap, examples)))
        """),
    ),

    # 18 ── big O intro (~25s) ─────────────────────────────────────────────────
    _seg(
        name="big_o_intro",
        beat=_beat("Big O notation explained simply"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("What Is Big O?", size=38, layout=layout)
        cap   = makeCaption("Big O describes how steps grow as the list gets bigger.", size=22, layout=layout)

        lines = VGroup(
            Text("O(1)      ->  always 1 step, no matter how big",  font_size=25, color=GREEN),
            Text("O(log n)  ->  steps grow slowly (doubling list = +1 step)", font_size=25, color=TEAL_B),
            Text("O(sqrt n) ->  steps grow moderately",             font_size=25, color=YELLOW),
            Text("O(n)      ->  steps grow with list size",         font_size=25, color=RED),
        ).arrange(DOWN, buff=0.45, aligned_edge=LEFT)
        lines.move_to(ORIGIN)

        self.play(FadeIn(title), FadeIn(cap))
        for line in lines:
            self.play(FadeIn(line), run_time=0.5)
            self.wait(4)
        self.wait(4)
        self.play(FadeOut(VGroup(title, cap, lines)))
        """),
    ),

    # 19 ── big O visual (~30s) ────────────────────────────────────────────────
    _seg(
        name="big_o_visual",
        beat=_beat("Visual bar chart comparing steps for each algorithm at N=1000"),
        animation=_sceneSource("""
        setupScene(self)
        layout = SceneLayout("standard")
        title = makeTitle("Steps at N = 1,000", size=38, layout=layout)
        cap   = makeCaption("How many steps each algorithm needs for 1,000 items.", size=22, layout=layout)

        import math
        entries = [
            ("Linear O(n)",       1000, RED,    3.5),
            ("Jump O(sqrt n)",    32,   YELLOW, 1.1),
            ("Binary O(log n)",   10,   TEAL_B, 0.7),
            ("Hash O(1)",          1,   GREEN,  0.15),
        ]

        bars = VGroup()
        for lbl, val, col, bar_h in entries:
            bar      = Rectangle(width=1.3, height=bar_h,
                                 fill_color=col, fill_opacity=0.85, stroke_width=0.5)
            val_lbl  = Text(str(val), font_size=20, color=WHITE)
            name_lbl = Text(lbl, font_size=18, color=col, line_spacing=0.8)
            bar_grp  = VGroup(val_lbl, bar, name_lbl).arrange(DOWN, buff=0.15)
            bars.add(bar_grp)

        bars.arrange(RIGHT, buff=0.6)
        # align all bar bottoms
        for grp in bars:
            grp[1].align_to(bars, DOWN)
        bars.move_to(ORIGIN + DOWN * 0.2)

        self.play(FadeIn(title), FadeIn(cap))
        self.play(LaggedStart(*[FadeIn(b) for b in bars], lag_ratio=0.25))
        self.wait(10)
        self.play(FadeOut(VGroup(title, cap, bars)))
        """),
    ),

    # 20 ── summary (~25s) ─────────────────────────────────────────────────────
    _seg(
        name="summary",
        beat=_beat("Final summary"),
        animation=_sceneSource("""
        setupScene(self)
        title = Text("That Is Search.", font_size=52, color=WHITE)
        lines = VGroup(
            Text("Linear      ->  simple, any list",          font_size=24, color=BLUE_B),
            Text("Binary      ->  fast, sorted list",         font_size=24, color=TEAL_B),
            Text("Jump        ->  middle ground",             font_size=24, color=YELLOW),
            Text("Interpolation -> smarter binary",           font_size=24, color=ORANGE),
            Text("Hash        ->  instant, best when possible", font_size=24, color=GREEN),
        ).arrange(DOWN, buff=0.38, aligned_edge=LEFT)
        cap = Text("The right algorithm saves millions of steps.", font_size=24, color=GRAY)

        group = VGroup(title, lines, cap).arrange(DOWN, buff=0.45)
        group.move_to(ORIGIN + UP * 0.2)

        self.play(FadeIn(title))
        self.play(LaggedStart(*[FadeIn(l) for l in lines], lag_ratio=0.15))
        self.play(FadeIn(cap))
        self.wait(8)
        self.play(FadeOut(group))
        """),
    ),

]


def runTopicShowcase(quality: str = "low", format: str = "long") -> Path:
    rendered_paths = []
    topic = "search"

    for seg in SEGMENTS:
        out_path = f"Cache/math/{topic}_{seg['name']}.mp4"
        print(f"  rendering: {seg['name']} ...")
        path = renderCustomScene(
            manim_code=seg["animation"],
            output=out_path,
            quality=quality,
        )
        rendered_paths.append(path)

    timestamp = int(time.time())
    final_path = f"Cache/stitched/mathmwk_{topic}_{timestamp}.mp4"

    print(f"  stitching {len(rendered_paths)} segments ...")
    combineMedia(
        media=rendered_paths,
        output=final_path,
        transition="crossfade",
        duration=0.15,
        width=1920,
        height=1080,
        fps=30,
    )

    print(f"  done -> {final_path}")
    return Path(final_path)


if __name__ == "__main__":
    result = runTopicShowcase(quality="low", format="long")
    print(f"\nFinal video: {result}")