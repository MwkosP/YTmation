"""
Layout manager showcase — every preset + catalog intro.

python Workflows/channels/mathmwk/layoutShowcase.py
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"

BEAT_SECONDS = 3.0
PAD_WAIT = 1.0

# Keep in sync with Math/library/common/layout/presets.py PRESETS keys
DEMOS = [
    ("standard", "demoLayoutStandard"),
    ("sidebar", "demoLayoutSidebar"),
    ("sidebar_left", "demoLayoutSidebarLeft"),
    ("split", "demoLayoutSplit"),
    ("stacked", "demoLayoutStacked"),
    ("formula_focus", "demoLayoutFormulaFocus"),
    ("inset", "demoLayoutInset"),
    ("minimal", "demoLayoutMinimal"),
    ("short", "demoLayoutShort"),
    ("lecture", "demoLayoutLecture"),
    ("hero", "demoLayoutHero"),
]


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}


def _beat(body: str) -> str:
    b = body.strip()
    if "self.wait(" not in b.split("\n")[-1]:
        b += f"\nself.wait({PAD_WAIT})"
    return b


def _demo_segment(idx: int, slug: str, fn: str) -> dict:
    num = f"{idx:02d}"
    return _seg(
        f"{num}_{slug}",
        fn,
        _beat(
            f"""
from Math.library.common.layout.recipes import {fn}
{fn}(self)
"""
        ),
    )


SEGMENTS = [
    _seg(
        "00_catalog",
        "demoLayoutCatalog",
        _beat(
            """
from Math.library.common.layout.recipes import demoLayoutCatalog
demoLayoutCatalog(self)
"""
        ),
    ),
    *[_demo_segment(i + 1, slug, fn) for i, (slug, fn) in enumerate(DEMOS)],
]


def _sceneSource(body: str) -> str:
    return f"""
from manim import *

class LayoutShowcaseSegment(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
{textwrap.indent(body, "        ")}
"""


def runLayoutShowcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    rendered: list[str] = []
    total = len(SEGMENTS)
    print(
        f"{CHANNEL} layout showcase — {total} segments × ~{BEAT_SECONDS}s, "
        f"quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"layout_showcase_{seg['name']}.mp4"
        path = renderCustomScene(
            manim_code=_sceneSource(seg["animation"]),
            output=out,
            quality=quality,
        )
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_layout_showcase_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.15,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runLayoutShowcase(quality="low", format="long")
