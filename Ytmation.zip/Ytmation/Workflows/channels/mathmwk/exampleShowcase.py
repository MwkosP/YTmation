"""
Non-math layout showcase example.

python Workflows/channels/mathmwk/exampleShowcase.py
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"

BEAT_SECONDS = 3.0
PAD_WAIT = 1.0


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}


def _beat(body: str) -> str:
    b = body.strip()
    if "self.wait(" not in b.split("\n")[-1]:
        b += f"\nself.wait({PAD_WAIT})"
    return b


SEGMENTS = [
    _seg(
        "00_intro",
        "studio_intro",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle, makeCaption
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("hero")
title = makeTitle("Creator Studio Showcase", size=48, layout=layout)
sub = makeSubtitle("Using layout + helper functions beyond pure math", size=24, layout=layout, below=title)
cap = makeCaption("8 scene mini story: idea -> publish", size=22, layout=layout)
self.play(Write(title), FadeIn(sub), FadeIn(cap), run_time=1.2)
"""
        ),
    ),
    _seg(
        "01_storyboard",
        "storyboard_wall",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("sidebar_left")
self.play(Write(makeTitle("Scene 1: Storyboard Wall", size=34, layout=layout)), run_time=0.4)

cards = VGroup()
for r in range(2):
    for c in range(3):
        card = RoundedRectangle(width=2.1, height=1.2, corner_radius=0.12, stroke_width=2, color=GREY_B)
        card.set_fill(BLUE_E, opacity=0.25)
        icon = Dot(radius=0.06, color=YELLOW).move_to(card.get_corner(UL) + DOWN * 0.18 + RIGHT * 0.18)
        cards.add(VGroup(card, icon))
cards.arrange_in_grid(rows=2, cols=3, buff=0.25)
placeInRegion(cards, "main", layout=layout, fit=True)

notes = VGroup(
    Text("Hook", font_size=24, color=WHITE),
    Text("Conflict", font_size=24, color=WHITE),
    Text("Resolution", font_size=24, color=WHITE),
).arrange(DOWN, aligned_edge=LEFT, buff=0.22)
placeInRegion(notes, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

cap = makeCaption("Block scenes before filming", size=20, layout=layout)
self.play(FadeIn(cards, shift=UP * 0.2), Write(notes), FadeIn(cap), run_time=1.2)
"""
        ),
    ),
    _seg(
        "02_script",
        "script_revision",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("split")
self.play(Write(makeTitle("Scene 2: Script Revisions", size=34, layout=layout)), run_time=0.4)

draft = VGroup(
    Text("Draft v1", font_size=26, weight=BOLD),
    Text("- rough intro", font_size=22),
    Text("- long pacing", font_size=22),
    Text("- no CTA", font_size=22),
).arrange(DOWN, aligned_edge=LEFT, buff=0.18)
draft_bg = RoundedRectangle(width=4.8, height=3.8, corner_radius=0.15, color=GREY_B).set_fill(BLUE_E, opacity=0.2)
left = VGroup(draft_bg, draft.move_to(draft_bg.get_center()))
placeInRegion(left, "left", layout=layout, fit=True)

final = VGroup(
    Text("Draft v3", font_size=26, weight=BOLD, color=GREEN),
    Text("+ strong hook", font_size=22),
    Text("+ tighter beats", font_size=22),
    Text("+ clear CTA", font_size=22),
).arrange(DOWN, aligned_edge=LEFT, buff=0.18)
final_bg = RoundedRectangle(width=4.8, height=3.8, corner_radius=0.15, color=GREEN).set_fill(GREEN_E, opacity=0.15)
right = VGroup(final_bg, final.move_to(final_bg.get_center()))
placeInRegion(right, "right", layout=layout, fit=True)

arrow = Arrow(left.get_right(), right.get_left(), buff=0.25, color=YELLOW)
cap = makeCaption("Iterate quickly, then lock script", size=20, layout=layout)
self.play(FadeIn(left), GrowArrow(arrow), FadeIn(right), FadeIn(cap), run_time=1.2)
"""
        ),
    ),
    _seg(
        "03_recording",
        "recording_booth",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("standard")
self.play(Write(makeTitle("Scene 3: Recording Booth", size=34, layout=layout)), run_time=0.4)

frame = RoundedRectangle(width=8.0, height=3.0, corner_radius=0.2, color=GREY_B).set_fill(BLACK, opacity=0.35)
bars = VGroup()
for i, h in enumerate([0.4, 1.2, 0.7, 1.5, 0.9, 1.3, 0.6, 1.0, 0.5, 0.8]):
    bar = Rectangle(width=0.45, height=h, stroke_width=0, fill_color=BLUE_B, fill_opacity=0.9)
    bars.add(bar)
bars.arrange(RIGHT, buff=0.15)
wave = VGroup(frame, bars.move_to(frame.get_center()))
placeInRegion(wave, "main", layout=layout, fit=True)

mic = VGroup(
    Circle(radius=0.28, color=YELLOW).set_fill(YELLOW_E, opacity=0.4),
    Line(ORIGIN, DOWN * 0.8, color=YELLOW, stroke_width=6),
).arrange(DOWN, buff=0.0).scale(0.9)
placeInRegion(mic, "formula", layout=layout, fit=False)

cap = makeCaption("Capture clean voice and energy", size=20, layout=layout)
self.play(FadeIn(frame), LaggedStart(*[GrowFromEdge(b, DOWN) for b in bars], lag_ratio=0.06), FadeIn(mic), FadeIn(cap), run_time=1.25)
"""
        ),
    ),
    _seg(
        "04_timeline",
        "timeline_edit",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("Scene 4: Timeline Edit", size=34, layout=layout)), run_time=0.4)

tracks = VGroup()
colors = [BLUE_B, GREEN_B, PURPLE_B]
for i, col in enumerate(colors):
    lane = RoundedRectangle(width=7.2, height=0.7, corner_radius=0.08, color=GREY_B).set_fill(GREY_E, opacity=0.35)
    clip_a = RoundedRectangle(width=2.0, height=0.48, corner_radius=0.06, color=col).set_fill(col, opacity=0.8)
    clip_b = RoundedRectangle(width=1.4, height=0.48, corner_radius=0.06, color=col).set_fill(col, opacity=0.65)
    clip_a.move_to(lane.get_left() + RIGHT * 1.6)
    clip_b.move_to(lane.get_left() + RIGHT * 4.2)
    tracks.add(VGroup(lane, clip_a, clip_b))
tracks.arrange(DOWN, buff=0.3)
playhead = Line(UP * 1.6, DOWN * 1.6, color=YELLOW, stroke_width=5)
timeline = VGroup(tracks, playhead.move_to(tracks.get_left() + RIGHT * 2.2))
placeInRegion(timeline, "main", layout=layout, fit=True)

tips = VGroup(
    Text("Trim dead space", font_size=24),
    Text("Align beats to cuts", font_size=24),
    Text("Layer SFX lightly", font_size=24),
).arrange(DOWN, aligned_edge=LEFT, buff=0.22)
placeInRegion(tips, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

cap = makeCaption("Editing shapes the story rhythm", size=20, layout=layout)
self.play(FadeIn(tracks), Create(playhead), Write(tips), FadeIn(cap), run_time=1.2)
"""
        ),
    ),
    _seg(
        "05_color_grade",
        "color_grade_pass",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("split")
self.play(Write(makeTitle("Scene 5: Color Grade", size=34, layout=layout)), run_time=0.4)

before = RoundedRectangle(width=4.9, height=3.3, corner_radius=0.15, color=GREY_B).set_fill(GREY_D, opacity=0.85)
after = RoundedRectangle(width=4.9, height=3.3, corner_radius=0.15, color=YELLOW).set_fill(ORANGE, opacity=0.5)
sun_before = Circle(radius=0.36, color=GREY_B).set_fill(GREY_B, opacity=0.8)
sun_after = Circle(radius=0.36, color=YELLOW).set_fill(YELLOW, opacity=0.9)
left = VGroup(before, sun_before.move_to(before.get_center() + UP * 0.5))
right = VGroup(after, sun_after.move_to(after.get_center() + UP * 0.5))
placeInRegion(left, "left", layout=layout, fit=True)
placeInRegion(right, "right", layout=layout, fit=True)

lbl_left = Text("Before", font_size=24, color=GREY_B).next_to(left, DOWN, buff=0.2)
lbl_right = Text("After", font_size=24, color=YELLOW).next_to(right, DOWN, buff=0.2)
cap = makeCaption("Consistency beats random filters", size=20, layout=layout)
self.play(FadeIn(left), FadeIn(right), Write(lbl_left), Write(lbl_right), FadeIn(cap), run_time=1.2)
"""
        ),
    ),
    _seg(
        "06_thumbnail",
        "thumbnail_design",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("inset")
self.play(Write(makeTitle("Scene 6: Thumbnail Design", size=34, layout=layout)), run_time=0.4)

canvas = RoundedRectangle(width=8.4, height=4.6, corner_radius=0.2, color=GREY_B).set_fill(BLUE_E, opacity=0.22)
headline = Text("STOP SCROLLING", font_size=48, weight=BOLD, color=YELLOW).move_to(canvas.get_center() + UP * 0.75)
face = Circle(radius=0.7, color=WHITE).set_fill(GREY_C, opacity=0.5).move_to(canvas.get_center() + LEFT * 2.3 + DOWN * 0.7)
arrow = Arrow(face.get_right(), headline.get_left(), buff=0.1, color=RED)
thumb = VGroup(canvas, headline, face, arrow)
placeInRegion(thumb, "main", layout=layout, fit=True)

inset_box = RoundedRectangle(width=2.8, height=1.4, corner_radius=0.1, color=GREEN).set_fill(GREEN_E, opacity=0.2)
inset_text = Text("A/B test 3 variants", font_size=20, color=GREEN).move_to(inset_box.get_center())
placeInRegion(VGroup(inset_box, inset_text), "inset", layout=layout, fit=True)

cap = makeCaption("Thumbnail and title are one system", size=20, layout=layout)
self.play(FadeIn(canvas), Write(headline), FadeIn(face), GrowArrow(arrow), FadeIn(inset_box), Write(inset_text), FadeIn(cap), run_time=1.3)
"""
        ),
    ),
    _seg(
        "07_publish",
        "publish_queue",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("stacked")
self.play(Write(makeTitle("Scene 7: Publish Queue", size=34, layout=layout)), run_time=0.4)

queue = VGroup()
for i, label in enumerate(["YouTube", "Shorts", "Instagram"]):
    card = RoundedRectangle(width=7.5, height=0.9, corner_radius=0.1, color=GREY_B).set_fill(GREY_E, opacity=0.3)
    t = Text(label, font_size=26).move_to(card.get_left() + RIGHT * 1.2)
    dot = Dot(radius=0.11, color=[GREEN, YELLOW, BLUE][i]).move_to(card.get_right() + LEFT * 0.55)
    queue.add(VGroup(card, t, dot))
queue.arrange(DOWN, buff=0.22)
placeInRegion(queue, "main", layout=layout, fit=True)

status = VGroup(
    Text("Upload: complete", font_size=26, color=GREEN),
    Text("Metadata: scheduled", font_size=26, color=YELLOW),
).arrange(DOWN, buff=0.2)
placeInRegion(status, "footer", layout=layout, fit=True)

cap = makeCaption("One publish pass, many destinations", size=20, layout=layout)
self.play(LaggedStart(*[FadeIn(item, shift=RIGHT * 0.2) for item in queue], lag_ratio=0.12), Write(status), FadeIn(cap), run_time=1.3)
"""
        ),
    ),
    _seg(
        "08_analytics",
        "analytics_feedback",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, placeInRegion
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("lecture")
self.play(Write(makeTitle("Scene 8: Analytics Feedback", size=34, layout=layout)), run_time=0.4)

grid = NumberPlane(
    x_range=[0, 10, 1],
    y_range=[0, 10, 1],
    background_line_style={"stroke_opacity": 0.25, "stroke_width": 1},
).scale(0.48)
line = VMobject(color=GREEN, stroke_width=5)
pts = [LEFT * 3.2 + DOWN * 1.1, LEFT * 2.0 + DOWN * 0.9, LEFT * 0.8 + DOWN * 0.5, RIGHT * 0.4 + UP * 0.1, RIGHT * 1.8 + UP * 0.9, RIGHT * 3.0 + UP * 1.25]
line.set_points_as_corners(pts)
chart = VGroup(grid, line)
placeInRegion(chart, "main", layout=layout, fit=True)

stats = VGroup(
    Text("CTR 7.8%", font_size=24, color=YELLOW),
    Text("Retention 43%", font_size=24, color=BLUE),
    Text("Rewatch 1.3x", font_size=24, color=GREEN),
).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
placeInRegion(stats, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

cap = makeCaption("Use data to choose next experiment", size=20, layout=layout)
self.play(FadeIn(grid), Create(line), Write(stats), FadeIn(cap), run_time=1.3)
"""
        ),
    ),
    _seg(
        "09_outro",
        "studio_outro",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle, makeCaption
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("End-to-End Creative Pipeline", size=44, layout=layout)
sub = makeSubtitle("Storyboard -> Script -> Record -> Edit -> Publish", size=22, layout=layout, below=title)
cap = makeCaption("Template: Workflows/channels/mathmwk/exampleShowcase.py", size=18, layout=layout)
self.play(Write(title), FadeIn(sub), FadeIn(cap), run_time=1.1)
"""
        ),
    ),
]


def _sceneSource(body: str) -> str:
    return f"""
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
{textwrap.indent(body, "        ")}
"""


def runExampleShowcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    rendered: list[str] = []
    total = len(SEGMENTS)
    print(
        f"{CHANNEL} example showcase — {total} segments × ~{BEAT_SECONDS}s, "
        f"quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"example_showcase_{seg['name']}.mp4"
        path = renderCustomScene(
            manim_code=_sceneSource(seg["animation"]),
            output=out,
            quality=quality,
        )
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_example_showcase_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.15,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runExampleShowcase(quality="low", format="long")
