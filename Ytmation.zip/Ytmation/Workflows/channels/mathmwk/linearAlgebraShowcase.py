"""
Full Linear Algebra library showcase — every recipe + key primitives.

~3 seconds per segment. No voice. Long-form 1920x1080 default.
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"

BEAT_SECONDS = 3.0
SHOW_RUN = 1.7
PAD_WAIT = 1.0


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}


def _beat(body: str) -> str:
    b = body.strip()
    if "self.wait(" not in b.split("\n")[-1]:
        b += f"\nself.wait({PAD_WAIT})"
    return b


SEGMENTS = [
    _seg(
        "00_intro",
        "catalog",
        _beat("""
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Linear Algebra Library", size=48, layout=layout)
sub = makeSubtitle("Math.library.math.linear_algebra · layout-aware beats", size=24, layout=layout, below=title)
self.play(Write(title), FadeIn(sub), run_time=1.0)
"""),
    ),
    # ── RECIPES (23) ────────────────────────────────────────────────────
    _seg("01_matrix_transform", "applyMatrixToSquare", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.transformations import applyMatrixToSquare
import numpy as np
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Matrix Transform", size=36, layout=layout)), run_time=0.35)
applyMatrixToSquare(self, np.array([[1.2, 0.5], [0.3, 1.1]]), run_time={SHOW_RUN})
""")),
    _seg("02_linear_transform_grid", "showLinearTransform", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.transformations import showLinearTransform
import numpy as np
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Linear Transform", size=36, layout=layout)), run_time=0.35)
showLinearTransform(self, np.array([[1.0, 0.6], [-0.4, 1.0]]), show_grid=True, run_time={SHOW_RUN})
""")),
    _seg("03_matrix_vector", "showMatrixVectorProduct", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.matrix_vector import showMatrixVectorProduct
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Matrix × Vector", size=36, layout=layout)), run_time=0.35)
showMatrixVectorProduct(self, run_time={SHOW_RUN})
""")),
    _seg("04_matrix_multiply_order", "showMatrixMultiplyOrder", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.matrix_multiply import showMatrixMultiplyOrder
setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("AB vs BA", size=36, layout=layout)), run_time=0.35)
showMatrixMultiplyOrder(self, run_time={SHOW_RUN}, layout=layout)
""")),
    _seg("05_rref", "showRrefAnimation", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.rref import showRrefAnimation
setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("RREF", size=36, layout=layout)), run_time=0.35)
showRrefAnimation(self, run_time={SHOW_RUN})
""")),
    _seg("06_inverse", "showMatrixInverse", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.inverse import showMatrixInverse
setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("Matrix Inverse", size=36, layout=layout)), run_time=0.35)
showMatrixInverse(self, run_time={SHOW_RUN})
""")),
    _seg("07_eigenvectors", "showEigenDirections", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.eigenvectors import showEigenDirections
import numpy as np
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Eigenvectors", size=36, layout=layout)), run_time=0.35)
showEigenDirections(self, np.array([[2.0, 1.0], [1.0, 2.0]]), run_time={SHOW_RUN})
""")),
    _seg("08_eigen_stretch", "showEigenvalueStretch", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.eigenvectors import showEigenvalueStretch
import numpy as np
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Eigenvalue Stretch", size=34, layout=layout)), run_time=0.35)
showEigenvalueStretch(self, np.array([[2.0, 0.0], [0.0, 0.5]]), run_time={SHOW_RUN})
""")),
    _seg("09_rotation", "showRotation", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.rotation import showRotation
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Rotation", size=36, layout=layout)), run_time=0.35)
showRotation(self, angle_deg=35, run_time={SHOW_RUN})
""")),
    _seg("10_complex_eigen_rotation", "showComplexEigenRotation", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.rotation import showComplexEigenRotation
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Complex Eigen Rotation", size=32, layout=layout)), run_time=0.35)
showComplexEigenRotation(self, angle_deg=50, run_time={SHOW_RUN})
""")),
    _seg("11_determinant", "showDeterminantArea", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.determinant import showDeterminantArea
import numpy as np
setupScene(self)
layout = SceneLayout("formula_focus")
self.play(Write(makeTitle("Determinant", size=36, layout=layout)), run_time=0.35)
showDeterminantArea(self, np.array([[2.0, 0.5], [0.0, 1.5]]), run_time={SHOW_RUN})
""")),
    _seg("12_dot_product", "showDotProduct", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.dot_product import showDotProduct
setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("Dot Product", size=36, layout=layout)), run_time=0.35)
showDotProduct(self, run_time={SHOW_RUN}, layout=layout)
""")),
    _seg("13_projection", "showProjection", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.projection import showProjection
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Projection", size=36, layout=layout)), run_time=0.35)
showProjection(self, run_time={SHOW_RUN})
""")),
    _seg("14_span", "showSpan", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.span import showSpan
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Span", size=36, layout=layout)), run_time=0.35)
showSpan(self, run_time={SHOW_RUN})
""")),
    _seg("15_col_null_space", "showColumnSpaceNullSpace", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.subspaces import showColumnSpaceNullSpace
setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("Column / Null Space", size=32, layout=layout)), run_time=0.35)
showColumnSpaceNullSpace(self, run_time={SHOW_RUN})
""")),
    _seg("16_gram_schmidt", "showGramSchmidt", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.gram_schmidt import showGramSchmidt
setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("Gram-Schmidt", size=34, layout=layout)), run_time=0.35)
showGramSchmidt(self, run_time={SHOW_RUN})
""")),
    _seg("17_norm_angle", "showNormAndAngle", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.norms import showNormAndAngle
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Norm & Angle", size=34, layout=layout)), run_time=0.35)
showNormAndAngle(self, run_time={SHOW_RUN})
""")),
    _seg("18_cross_2d", "showCrossProduct2d", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.cross_product import showCrossProduct2d
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Cross Product 2D", size=32, layout=layout)), run_time=0.35)
showCrossProduct2d(self, run_time={SHOW_RUN})
""")),
    _seg("19_cross_3d", "showCrossProduct3d", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.cross_product import showCrossProduct3d
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Cross Product 3D", size=32, layout=layout)), run_time=0.35)
showCrossProduct3d(self, run_time={SHOW_RUN})
""")),
    _seg("20_vector_addition", "showVectorAddition", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.vectors import showVectorAddition
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Vector Addition", size=34, layout=layout)), run_time=0.35)
showVectorAddition(self, run_time={SHOW_RUN})
""")),
    _seg("21_vector_decompose", "decomposeVector", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.vectors import decomposeVector
import numpy as np
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Vector Components", size=34, layout=layout)), run_time=0.35)
vg = decomposeVector(ORIGIN, np.array([2.2, 1.4, 0.0]))
self.play(Create(vg), run_time={SHOW_RUN})
""")),
    _seg("22_gaussian_elimination", "showGaussianElimination", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.systems import showGaussianElimination
setupScene(self)
layout = SceneLayout("sidebar")
self.play(Write(makeTitle("Gaussian Elimination", size=32, layout=layout)), run_time=0.35)
showGaussianElimination(self, run_time={SHOW_RUN})
""")),
    _seg("23_vector_field", "showVectorField", _beat(f"""
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.vector_field import showVectorField
setupScene(self)
layout = SceneLayout("hero")
self.play(Write(makeTitle("Vector Field", size=34, layout=layout)), run_time=0.35)
showVectorField(self, lambda x, y: (-y, x), run_time={SHOW_RUN})
""")),
    _seg(
        "24_outro",
        "end",
        _beat("""
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Linear algebra complete", size=46, layout=layout)
sub = makeSubtitle("linear_algebra/AGENT.md", size=26, layout=layout, below=title)
self.play(Write(title), FadeIn(sub), run_time=1.0)
"""),
    ),
]


def _sceneSource(animation: str) -> str:
    body = textwrap.indent(animation.strip(), "        ")
    return f"""
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
{body}
"""


def runLinearAlgebraShowcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    rendered: list[str] = []
    total = len(SEGMENTS)
    print(
        f"{CHANNEL} linear algebra showcase — {total} segments × ~{BEAT_SECONDS}s, "
        f"quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"linear_algebra_showcase_{seg['name']}.mp4"
        path = renderCustomScene(
            manim_code=_sceneSource(seg["animation"]),
            output=out,
            quality=quality,
        )
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_linear_algebra_showcase_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.15,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runLinearAlgebraShowcase(quality="low", format="long")
