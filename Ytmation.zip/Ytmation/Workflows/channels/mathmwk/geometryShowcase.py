"""
Full Geometry library showcase — every demo (~90% intro geometry).

~3 seconds per segment. No voice. Long-form 1920x1080 default.
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"

BEAT_SECONDS = 3.0
PAD_WAIT = 1.0

DEMOS = [
    ("pythagorean", "demoPythagorean"),
    ("circle_pi", "demoCirclePi"),
    ("unit_circle_sine", "demoUnitCircleSine"),
    ("triangle_angle_sum", "demoTriangleAngleSum"),
    ("exterior_angle", "demoExteriorAngle"),
    ("triangle_345", "demoSpecialRightTriangle"),
    ("triangle_454590", "demo454590Triangle"),
    ("vertical_angles", "demoVerticalAngles"),
    ("complementary", "demoComplementaryAngles"),
    ("supplementary", "demoSupplementaryAngles"),
    ("angle_bisector", "demoAngleBisector"),
    ("parallel_transversal", "demoParallelTransversal"),
    ("alternate_interior", "demoAlternateInterior"),
    ("same_side_interior", "demoSameSideInterior"),
    ("congruence_sss", "demoCongruenceSSS"),
    ("congruence_sas", "demoCongruenceSAS"),
    ("congruence_asa", "demoCongruenceASA"),
    ("congruence_hl", "demoCongruenceHL"),
    ("triangle_inequality", "demoTriangleInequality"),
    ("midsegment", "demoMidsegment"),
    ("isosceles", "demoIsoscelesTriangle"),
    ("classify_triangles", "demoClassifyTriangles"),
    ("law_of_sines", "demoLawOfSines"),
    ("law_of_cosines", "demoLawOfCosines"),
    ("similar_triangles", "demoSimilarTriangles"),
    ("aa_similarity", "demoAASimilarity"),
    ("regular_polygon", "demoRegularPolygon"),
    ("interior_angle_sum", "demoInteriorAngleSum"),
    ("central_angle", "demoCentralAngle"),
    ("inscribed_angle", "demoInscribedAngle"),
    ("tangent_radius", "demoTangentRadius"),
    ("chord", "demoChordAndArc"),
    ("thales", "demoThalesTheorem"),
    ("perimeter", "demoPerimeter"),
    ("circumference", "demoCircumference"),
    ("rectangle_area", "demoRectangleArea"),
    ("parallelogram_area", "demoParallelogramArea"),
    ("sector_area", "demoSectorArea"),
    ("arc_length", "demoArcLength"),
    ("triangle_area", "demoTriangleArea"),
    ("circle_area", "demoCircleArea"),
    ("trapezoid_area", "demoTrapezoidArea"),
    ("prism_volume", "demoPrismVolume"),
    ("cylinder_volume", "demoCylinderVolume"),
    ("cone_volume", "demoConeVolume"),
    ("sphere_volume", "demoSphereVolume"),
    ("box_surface_area", "demoBoxSurfaceArea"),
    ("cross_section", "demoCrossSection"),
    ("distance", "demoDistanceFormula"),
    ("parallel_slopes", "demoParallelSlopes"),
    ("perpendicular_slopes", "demoPerpendicularSlopes"),
    ("line_symmetry", "demoLineSymmetry"),
    ("midpoint", "demoMidpoint"),
    ("slope", "demoSlope"),
    ("translation", "demoTranslation"),
    ("reflection", "demoReflection"),
    ("rotation", "demoRotation"),
    ("dilation", "demoDilation"),
]


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}


def _beat(body: str) -> str:
    b = body.strip()
    if "self.wait(" not in b.split("\n")[-1]:
        b += f"\nself.wait({PAD_WAIT})"
    return b


def _demo_segment(idx: int, slug: str, fn: str) -> dict:
    num = f"{idx:02d}"
    return _seg(
        f"{num}_{slug}",
        fn,
        _beat(f"""
from Math.library.math.geometry.recipes import {fn}
{fn}(self)
"""),
    )


SEGMENTS = [
    _seg(
        "00_intro",
        "catalog",
        _beat("""
from Math.library.common.layout import makeTitle, makeSubtitle
from Math.library.common.styling import setupScene

setupScene(self)
title = makeTitle("Geometry Library", size=48)
sub = makeSubtitle("Math.library.math.geometry · 3s beats", size=26).next_to(title, DOWN, buff=0.35)
self.play(Write(title), FadeIn(sub), run_time=1.0)
"""),
    ),
    *[_demo_segment(i + 1, slug, fn) for i, (slug, fn) in enumerate(DEMOS)],
]


def _sceneSource(body: str) -> str:
    return f"""
from manim import *

class GeometryShowcaseSegment(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
{textwrap.indent(body, "        ")}
"""


def runGeometryShowcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    rendered: list[str] = []
    total = len(SEGMENTS)
    print(
        f"{CHANNEL} geometry showcase — {total} segments × ~{BEAT_SECONDS}s, "
        f"quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"geometry_showcase_{seg['name']}.mp4"
        path = renderCustomScene(
            manim_code=_sceneSource(seg["animation"]),
            output=out,
            quality=quality,
        )
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_geometry_showcase_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.15,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runGeometryShowcase(quality="low", format="long")
