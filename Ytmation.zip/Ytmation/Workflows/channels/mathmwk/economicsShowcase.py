"""
Full Economics library showcase.

python Workflows/channels/mathmwk/economicsShowcase.py

Pacing: edit PACING_PROFILE below or pass pacing= to runEconomicsShowcase().
"""

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Math.library.common.pacing import PacingProfile, PACING_NORMAL, PACING_SLOW, setDefaultPacing
from Math.library.common.showcase_runner import demoSegment, sceneSource, stitchCrossfadeDuration
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"
RECIPES = "Math.library.economics.recipes"

# Switch profile for whole render: PACING_NORMAL, PACING_SLOW, PACING_FAST, PACING_EXPLAINER
PACING_PROFILE = PACING_NORMAL

DEMOS = [
    ("supply_demand", "demoSupplyDemand"),
    ("equilibrium", "demoEquilibrium"),
    ("demand_shift", "demoDemandShift"),
    ("supply_shift", "demoSupplyShift"),
    ("elasticity", "demoElasticity"),
    ("surplus", "demoSurplus"),
    ("opportunity_cost", "demoOpportunityCost"),
    ("gdp", "demoGDP"),
    ("inflation", "demoInflation"),
    ("unemployment", "demoUnemployment"),
    ("fiscal_policy", "demoFiscalPolicy"),
    ("monetary_policy", "demoMonetaryPolicy"),
    ("phillips_curve", "demoPhillipsCurve"),
    ("business_cycle", "demoBusinessCycle"),
    ("comparative_advantage", "demoComparativeAdvantage"),
    ("market_structures", "demoMarketStructures"),
]


def runEconomicsShowcase(
    quality: str = "low",
    format: str = "long",
    pacing: PacingProfile | None = None,
) -> Path:
    profile = pacing or PACING_PROFILE
    setDefaultPacing(profile)
    pad = profile.pad_after_segment

    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    segments = [demoSegment(i + 1, slug, fn, RECIPES, pad=pad) for i, (slug, fn) in enumerate(DEMOS)]
    rendered: list[str] = []
    total = len(segments)
    print(
        f"{CHANNEL} economics showcase — {total} segments, "
        f"beat={profile.beat_default}s pad={pad}s, quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, seg in enumerate(segments, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"economics_showcase_{seg['name']}.mp4"
        path = renderCustomScene(manim_code=sceneSource(seg["animation"]), output=out, quality=quality)
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_economics_showcase_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=stitchCrossfadeDuration(profile),
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runEconomicsShowcase(quality="low", format="long")
