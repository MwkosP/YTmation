"""
Alias workflow for ML Manim abstractions showcase.

python Workflows/channels/mathmwk/manimmlShowcase.py
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Workflows.channels.mathmwk.mlmanimShowcase import runMlManimShowcase


def runManimMlShowcase(quality: str = "low", format: str = "long"):
    return runMlManimShowcase(quality=quality, format=format)


if __name__ == "__main__":
    runManimMlShowcase(quality="low", format="long")
