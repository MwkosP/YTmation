import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia
from Thumbnail.thumbnail import generateThumbnail
from Storage.storage import logRun

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"

# Segment 1: Hook (6s)
HOOK = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        l1 = Text("Neural Networks", font_size=72, color="#FF4500", weight=BOLD)
        l2 = Text("in 60 seconds", font_size=54, color=WHITE)
        l3 = Text("How does AI actually learn?", font_size=36, color=GRAY)
        group = VGroup(l1, l2, l3).arrange(DOWN, buff=0.35)
        self.play(FadeIn(l1, shift=UP * 0.2), run_time=0.8)
        self.play(FadeIn(l2, shift=UP * 0.2), run_time=0.8)
        self.play(Write(l3), run_time=0.9)
        self.wait(3.2)
"""

# Segment 2: Layers and connections (10s)
LAYERS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("1) Layers of neurons", font_size=40, color=WHITE).to_edge(UP, buff=0.4)

        x_positions = [-3.0, -1.0, 1.0, 3.0]
        counts = [4, 5, 5, 3]
        columns = VGroup()
        for x, n in zip(x_positions, counts):
            col = VGroup(*[
                Dot(point=[x, 1.8 - i * (3.6 / (n - 1)), 0], radius=0.09, color="#FFD700")
                for i in range(n)
            ])
            columns.add(col)

        edges = VGroup()
        for left, right in zip(columns[:-1], columns[1:]):
            for a in left:
                for b in right:
                    edges.add(Line(a.get_center(), b.get_center(), stroke_width=1.2, color="#444444"))

        labels = VGroup(
            Text("Input", font_size=24, color=GRAY).next_to(columns[0], DOWN, buff=0.35),
            Text("Hidden", font_size=24, color=GRAY).next_to(columns[1], DOWN, buff=0.35),
            Text("Hidden", font_size=24, color=GRAY).next_to(columns[2], DOWN, buff=0.35),
            Text("Output", font_size=24, color=GRAY).next_to(columns[3], DOWN, buff=0.35),
        )

        self.play(Write(title), run_time=0.6)
        self.play(LaggedStart(*[Create(e) for e in edges], lag_ratio=0.01), run_time=2.2)
        self.play(LaggedStart(*[FadeIn(c) for c in columns], lag_ratio=0.12), run_time=1.3)
        self.play(FadeIn(labels), run_time=0.7)
        self.wait(4.5)
"""

# Segment 3: Forward pass animation (10s)
FORWARD_PASS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("2) Forward pass", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        self.play(Write(title), run_time=0.6)

        layers = [[-3, -1, 1, 3], [2, 1.2, 0.4, -0.4, -1.2], [2, 1.2, 0.4, -0.4, -1.2], [1.2, 0, -1.2]]
        colors = ["#FFD700", "#FFD700", "#FFD700", "#FF4500"]
        cols = VGroup()
        for i, ys in enumerate(layers):
            x = -3 + i * 2
            col = VGroup(*[Dot([x, y, 0], radius=0.09, color=colors[i]) for y in ys])
            cols.add(col)

        edges = VGroup()
        for left, right in zip(cols[:-1], cols[1:]):
            for a in left:
                for b in right:
                    edges.add(Line(a.get_center(), b.get_center(), color="#333333", stroke_width=1))
        self.add(edges, cols)

        pulse = Dot(cols[0][1].get_center(), radius=0.12, color=WHITE)
        self.add(pulse)
        for right in cols[1:]:
            targets = [n.get_center() for n in right]
            anims = [pulse.animate.move_to(t) for t in targets]
            self.play(LaggedStart(*anims, lag_ratio=0.12), run_time=1.2)
            self.play(*[n.animate.set_color("#FF4500") for n in right], run_time=0.4)
        self.wait(3.8)
"""

# Segment 4: Error and loss (10s)
LOSS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("3) Compare prediction vs truth", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        pred = MathTex(r"\\hat{y} = 0.72", font_size=72, color="#FF4500").shift(UP * 0.8)
        truth = MathTex(r"y = 1.00", font_size=72, color=WHITE).next_to(pred, DOWN, buff=0.6)
        loss = MathTex(r"\\text{loss} = (y-\\hat y)^2", font_size=58, color="#FFD700").shift(DOWN * 1.6)
        brace = Brace(VGroup(pred, truth), LEFT, color=GRAY)

        self.play(Write(title), run_time=0.7)
        self.play(Write(pred), run_time=0.8)
        self.play(Write(truth), run_time=0.8)
        self.play(Create(brace), run_time=0.5)
        self.play(Write(loss), run_time=1.0)
        self.play(pred.animate.shift(LEFT * 0.2), run_time=0.4)
        self.play(pred.animate.shift(RIGHT * 0.2), run_time=0.4)
        self.wait(4.4)
"""

# Segment 5: Backprop update (10s)
BACKPROP = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("4) Backpropagation", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        eq = MathTex(r"w_{new} = w - \\eta \\nabla L", font_size=74, color="#FF4500")
        note = Text("small updates to reduce loss", font_size=30, color=GRAY).next_to(eq, DOWN, buff=0.45)
        arrow = Arrow(RIGHT * 3, LEFT * 3, color="#FFD700", stroke_width=6).shift(DOWN * 1.4)
        lbl = Text("error signal flows backward", font_size=28, color="#FFD700").next_to(arrow, DOWN, buff=0.2)

        self.play(Write(title), run_time=0.7)
        self.play(Write(eq), run_time=1.0)
        self.play(FadeIn(note), run_time=0.6)
        self.play(Create(arrow), run_time=0.9)
        self.play(FadeIn(lbl), run_time=0.6)
        self.wait(6.2)
"""

# Segment 6: Iterative learning (8s)
LEARNING = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("5) Repeat many times", font_size=42, color=WHITE).to_edge(UP, buff=0.4)
        axes = Axes(
            x_range=[0, 10, 1],
            y_range=[0, 1.1, 0.2],
            x_length=7,
            y_length=3.5,
            axis_config={"color": GRAY},
            tips=False,
        ).shift(DOWN * 0.4)
        curve = axes.plot(lambda x: 0.85 * (0.72 ** (x / 1.5)) + 0.06, color="#FF4500", x_range=[0, 10])
        xlab = Text("training step", font_size=24, color=GRAY).next_to(axes.x_axis, DOWN, buff=0.3)
        ylab = Text("loss", font_size=24, color=GRAY).next_to(axes.y_axis, LEFT, buff=0.2)
        dot = Dot(axes.c2p(0, 0.91), color="#FFD700")

        self.play(Write(title), run_time=0.5)
        self.play(Create(axes), FadeIn(xlab), FadeIn(ylab), run_time=1.0)
        self.play(Create(curve), run_time=1.3)
        self.play(MoveAlongPath(dot, curve), run_time=2.2, rate_func=linear)
        self.wait(2.5)
"""

# Segment 7: Outro (6s)
OUTRO = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        line1 = Text("Neural nets = layers + weights + updates", font_size=42, color=WHITE)
        line2 = Text("mathmwk", font_size=70, color="#FF4500", weight=BOLD).shift(DOWN * 1.1)
        line3 = Text("follow for more AI math", font_size=30, color=GRAY).next_to(line2, DOWN, buff=0.25)

        self.play(Write(line1), run_time=1.2)
        self.play(FadeIn(line2), run_time=0.9)
        self.play(FadeIn(line3), run_time=0.7)
        self.wait(2.8)
"""

SEGMENTS = [
    {"name": "hook", "code": HOOK, "duration": 6},
    {"name": "layers", "code": LAYERS, "duration": 10},
    {"name": "forward_pass", "code": FORWARD_PASS, "duration": 10},
    {"name": "loss", "code": LOSS, "duration": 10},
    {"name": "backprop", "code": BACKPROP, "duration": 10},
    {"name": "learning", "code": LEARNING, "duration": 8},
    {"name": "outro", "code": OUTRO, "duration": 6},
]


def runMathExample(quality: str = "medium", format: str = "long"):
    start = time.time()
    width, height = (1920, 1080) if format == "long" else (1080, 1920)
    total = sum(s["duration"] for s in SEGMENTS)

    try:
        print(f"Neural Network explainer - {len(SEGMENTS)} segments, {total}s target, {format} format")

        rendered = []
        for i, seg in enumerate(SEGMENTS):
            print(f"  [{i + 1}/{len(SEGMENTS)}] {seg['name']} ({seg['duration']}s)")
            video = renderCustomScene(
                manim_code=seg["code"],
                duration=seg["duration"],
                quality=quality,
            )
            rendered.append(str(video))

        combined = CACHE / "stitched" / f"mathexample_neural_{int(time.time())}.mp4"
        combined.parent.mkdir(parents=True, exist_ok=True)

        video = combineMedia(
            media=rendered,
            output=combined,
            transition="crossfade",
            duration=0.35,
            width=width,
            height=height,
            fps=60,
        )

        thumb = generateThumbnail(
            title="How Neural Nets Learn",
            style="bold_text",
            bg_color="#0a0a0a",
            text_color="#ffffff",
            accent_color="#FF4500",
        )

        logRun(
            "MathExampleNeural",
            "success",
            channel=CHANNEL,
            topic="neural_networks",
            duration=round(time.time() - start, 1),
        )

        print(f"Video:     {video}")
        print(f"Thumbnail: {thumb}")
        return video, thumb

    except Exception as e:
        logRun(
            "MathExampleNeural",
            "failed",
            channel=CHANNEL,
            topic="neural_networks",
            duration=round(time.time() - start, 1),
            error=str(e),
        )
        raise


if __name__ == "__main__":
    runMathExample(quality="medium", format="long")

