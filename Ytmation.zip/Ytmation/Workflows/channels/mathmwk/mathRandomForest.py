"""
Random Forest — long-form explainer (~3 minutes).

12 segments × tuned durations = 180s. Each segment is one narrated visual chunk.
"""

import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia
from Thumbnail.thumbnail import generateThumbnail
from Storage.storage import logRun

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"
TARGET_SECONDS = 180

# ── 1) Hook (12s) ─────────────────────────────────────────────────────────
HOOK = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        l1 = Text("Random Forest", font_size=76, color="#FF4500", weight=BOLD)
        l2 = Text("Many trees, one strong prediction", font_size=42, color=WHITE)
        l3 = Text("Ensemble learning in 3 minutes", font_size=32, color=GRAY)
        g = VGroup(l1, l2, l3).arrange(DOWN, buff=0.38)
        self.play(FadeIn(l1, shift=UP * 0.25), run_time=1.0)
        self.play(FadeIn(l2, shift=UP * 0.2), run_time=1.0)
        self.play(Write(l3), run_time=1.2)
        self.wait(8.5)
"""

# ── 2) Nonlinear data (14s) ─────────────────────────────────────────────────
NONLINEAR = """
from manim import *
import numpy as np

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Some data is not a straight line", font_size=38, color=WHITE).to_edge(UP, buff=0.4)
        axes = Axes(
            x_range=[0, 10, 1], y_range=[0, 10, 1],
            x_length=8, y_length=4.6, axis_config={"color": GRAY}, tips=False,
        ).shift(DOWN * 0.35)
        curve = axes.plot(lambda x: 2 + 0.35 * (x - 5) ** 2, color="#FFD700", x_range=[1, 9])
        bad_line = axes.plot(lambda x: 0.9 * x + 1.0, color="#666666", x_range=[0, 10], stroke_width=4)
        note = Text("Linear model can miss the pattern", font_size=28, color="#FF4500").to_edge(DOWN, buff=0.4)
        self.play(Write(title), run_time=0.8)
        self.play(Create(axes), run_time=1.0)
        self.play(Create(curve), run_time=1.4)
        self.play(Create(bad_line), run_time=1.0)
        self.play(FadeIn(note), run_time=0.8)
        self.wait(9.7)
"""

# ── 3) One decision tree (16s) ──────────────────────────────────────────────
ONE_TREE = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 1 — One decision tree", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        root = Text("Age < 30?", font_size=30, color="#FF4500")
        left = Text("Income > 50k?", font_size=26, color=WHITE).shift(LEFT * 2.8 + DOWN * 1.2)
        right = Text("Student?", font_size=26, color=WHITE).shift(RIGHT * 2.8 + DOWN * 1.2)
        leaf_l = Text("Approve", font_size=24, color="#00ff88").shift(LEFT * 4.2 + DOWN * 2.4)
        leaf_r = Text("Review", font_size=24, color="#FFD700").shift(RIGHT * 4.2 + DOWN * 2.4)
        e1 = Arrow(root.get_bottom(), left.get_top(), buff=0.1, color=GRAY)
        e2 = Arrow(root.get_bottom(), right.get_top(), buff=0.1, color=GRAY)
        self.play(Write(title), run_time=0.7)
        self.play(Write(root), run_time=0.9)
        self.play(Create(e1), Create(e2), run_time=0.8)
        self.play(FadeIn(left), FadeIn(right), run_time=0.9)
        self.play(FadeIn(leaf_l), FadeIn(leaf_r), run_time=0.9)
        self.wait(11.5)
"""

# ── 4) Splits (16s) ─────────────────────────────────────────────────────────
SPLITS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 2 — Split to reduce impurity", font_size=36, color=WHITE).to_edge(UP, buff=0.4)
        axes = Axes(
            x_range=[0, 10, 1], y_range=[0, 6, 1],
            x_length=7.5, y_length=4.2, axis_config={"color": GRAY}, tips=False,
        ).shift(DOWN * 0.4)
        dots = VGroup(
            *[Dot(axes.c2p(x, 1.2), color="#FF4500", radius=0.07) for x in [1, 2, 3, 4]],
            *[Dot(axes.c2p(x, 4.5), color="#FFD700", radius=0.07) for x in [6, 7, 8, 9]],
        )
        split = DashedLine(axes.c2p(5, 0), axes.c2p(5, 6), color=WHITE, stroke_width=3)
        lbl = Text("best split on feature x", font_size=28, color=GRAY).next_to(split, UP, buff=0.2)
        self.play(Write(title), run_time=0.7)
        self.play(Create(axes), FadeIn(dots), run_time=1.5)
        self.play(Create(split), Write(lbl), run_time=1.2)
        self.wait(12.3)
"""

# ── 5) Overfitting one tree (14s) ─────────────────────────────────────────────
OVERFIT = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("One deep tree overfits", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        warn = Text("Memorizes noise in training data", font_size=34, color="#FF4500")
        fix = Text("Solution: average many trees", font_size=34, color="#FFD700").next_to(warn, DOWN, buff=0.5)
        self.play(Write(title), run_time=0.8)
        self.play(FadeIn(warn, shift=UP * 0.15), run_time=1.0)
        self.play(FadeIn(fix, shift=UP * 0.15), run_time=1.0)
        self.wait(10.9)
"""

# ── 6) Forest idea (16s) ────────────────────────────────────────────────────
FOREST_IDEA = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 3 — Build a forest", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        trees = VGroup(*[
            Triangle(color="#FF4500", fill_opacity=0.35).scale(0.55).shift(RIGHT * (i - 2) * 1.4 + DOWN * 0.2)
            for i in range(5)
        ])
        label = Text("Tree 1   Tree 2   Tree 3   ...   Tree N", font_size=26, color=GRAY).next_to(trees, DOWN, buff=0.5)
        self.play(Write(title), run_time=0.7)
        self.play(LaggedStart(*[GrowFromCenter(t) for t in trees], lag_ratio=0.15), run_time=2.5)
        self.play(FadeIn(label), run_time=0.9)
        self.wait(11.6)
"""

# ── 7) Bagging (16s) ────────────────────────────────────────────────────────
BAGGING = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Bootstrap aggregating (bagging)", font_size=38, color=WHITE).to_edge(UP, buff=0.4)
        full = VGroup(*[Dot(LEFT * 3 + RIGHT * i * 0.35 + DOWN * 0.5, radius=0.06, color="#FFD700") for i in range(15)])
        sample = VGroup(*[full[i] for i in [0, 2, 2, 5, 7, 7, 9, 11, 14]])
        arr = Arrow(LEFT * 1.5, RIGHT * 1.5, color=GRAY)
        t1 = Text("random sample with replacement", font_size=28, color=GRAY).next_to(arr, UP, buff=0.2)
        self.play(Write(title), run_time=0.7)
        self.play(FadeIn(full), run_time=1.0)
        self.play(Create(arr), FadeIn(t1), run_time=1.0)
        self.play(Transform(full.copy(), sample.move_to(RIGHT * 2.5)), run_time=1.5)
        self.wait(11.5)
"""

# ── 8) Random features (14s) ────────────────────────────────────────────────
RANDOM_FEATURES = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Random feature subsets", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        feats = VGroup(
            Text("age", font_size=30, color="#FF4500"),
            Text("income", font_size=30, color=GRAY),
            Text("city", font_size=30, color=GRAY),
            Text("clicks", font_size=30, color="#FF4500"),
            Text("tenure", font_size=30, color=GRAY),
        ).arrange(RIGHT, buff=0.45).shift(DOWN * 0.2)
        note = Text("Each tree sees a different random subset", font_size=28, color=GRAY).to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.8)
        self.play(FadeIn(feats), run_time=1.2)
        self.play(Write(note), run_time=0.9)
        self.wait(10.8)
"""

# ── 9) Voting (16s) ──────────────────────────────────────────────────────────
VOTING = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 4 — Vote or average", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        votes = VGroup(
            Text("Tree A: Cat", font_size=30, color=GRAY),
            Text("Tree B: Dog", font_size=30, color=GRAY),
            Text("Tree C: Cat", font_size=30, color=GRAY),
            Text("Tree D: Cat", font_size=30, color=GRAY),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3).shift(LEFT * 1.5)
        final = Text("Final: Cat", font_size=48, color="#FF4500").shift(RIGHT * 2.2)
        self.play(Write(title), run_time=0.7)
        self.play(LaggedStart(*[FadeIn(v) for v in votes], lag_ratio=0.2), run_time=2.0)
        self.play(Write(final), run_time=1.0)
        self.wait(12.0)
"""

# ── 10) Feature importance (14s) ────────────────────────────────────────────
IMPORTANCE = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Feature importance", font_size=42, color=WHITE).to_edge(UP, buff=0.4)
        bars = VGroup(
            Rectangle(width=4.0, height=0.35, color="#FF4500", fill_opacity=0.8),
            Rectangle(width=2.8, height=0.35, color="#FFD700", fill_opacity=0.8),
            Rectangle(width=1.6, height=0.35, color=GRAY, fill_opacity=0.8),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.35).shift(DOWN * 0.1)
        labels = VGroup(
            Text("income", font_size=26, color=WHITE).next_to(bars[0], LEFT, buff=0.2),
            Text("age", font_size=26, color=WHITE).next_to(bars[1], LEFT, buff=0.2),
            Text("city", font_size=26, color=WHITE).next_to(bars[2], LEFT, buff=0.2),
        )
        self.play(Write(title), run_time=0.8)
        self.play(LaggedStart(*[GrowFromEdge(b, LEFT) for b in bars], lag_ratio=0.2), run_time=2.0)
        self.play(FadeIn(labels), run_time=0.8)
        self.wait(10.1)
"""

# ── 11) When to use (16s) ───────────────────────────────────────────────────
WHEN_TO_USE = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("When Random Forest shines", font_size=38, color=WHITE).to_edge(UP, buff=0.4)
        pros = VGroup(
            Text("✓ tabular data", font_size=32, color="#00ff88"),
            Text("✓ nonlinear interactions", font_size=32, color="#00ff88"),
            Text("✓ robust baseline model", font_size=32, color="#00ff88"),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.35).shift(LEFT * 0.5)
        cons = Text("Slower + less interpretable than one line", font_size=28, color=GRAY).to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.7)
        self.play(LaggedStart(*[FadeIn(p) for p in pros], lag_ratio=0.25), run_time=2.2)
        self.play(FadeIn(cons), run_time=0.8)
        self.wait(12.0)
"""

# ── 12) Outro (16s) ─────────────────────────────────────────────────────────
OUTRO = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        t1 = Text("Random Forest", font_size=60, color=WHITE)
        t2 = Text("wisdom of many trees", font_size=40, color="#FF4500").next_to(t1, DOWN, buff=0.3)
        t3 = Text("mathmwk  •  follow for more ML math", font_size=28, color=GRAY).next_to(t2, DOWN, buff=0.45)
        self.play(Write(t1), run_time=1.2)
        self.play(FadeIn(t2), run_time=1.0)
        self.play(FadeIn(t3), run_time=0.9)
        self.wait(12.6)
"""

SEGMENTS = [
    {"name": "hook",             "code": HOOK,             "duration": 12, "beat": "title + ensemble idea"},
    {"name": "nonlinear",        "code": NONLINEAR,        "duration": 14, "beat": "why lines fail"},
    {"name": "one_tree",         "code": ONE_TREE,         "duration": 16, "beat": "decision tree basics"},
    {"name": "splits",           "code": SPLITS,           "duration": 16, "beat": "feature splits"},
    {"name": "overfit",          "code": OVERFIT,          "duration": 14, "beat": "single tree risk"},
    {"name": "forest_idea",      "code": FOREST_IDEA,      "duration": 16, "beat": "many trees"},
    {"name": "bagging",          "code": BAGGING,          "duration": 16, "beat": "bootstrap samples"},
    {"name": "random_features",  "code": RANDOM_FEATURES,  "duration": 14, "beat": "feature subsampling"},
    {"name": "voting",           "code": VOTING,           "duration": 16, "beat": "aggregate predictions"},
    {"name": "importance",       "code": IMPORTANCE,       "duration": 14, "beat": "interpretability"},
    {"name": "when_to_use",      "code": WHEN_TO_USE,      "duration": 16, "beat": "practical guidance"},
    {"name": "outro",            "code": OUTRO,            "duration": 16, "beat": "recap + CTA"},
]


def _assertTiming():
    total = sum(s["duration"] for s in SEGMENTS)
    if total != TARGET_SECONDS:
        raise ValueError(f"SEGMENTS total {total}s != TARGET_SECONDS {TARGET_SECONDS}s")


def runMathRandomForest(quality: str = "medium", format: str = "long"):
    _assertTiming()
    start = time.time()
    width, height = (1920, 1080) if format == "long" else (1080, 1920)
    total = sum(s["duration"] for s in SEGMENTS)

    try:
        print(f"Random Forest — {len(SEGMENTS)} segments, {total // 60}:{total % 60:02d} target, {format}")

        rendered = []
        for i, seg in enumerate(SEGMENTS):
            print(f"  [{i + 1}/{len(SEGMENTS)}] {seg['name']} ({seg['duration']}s) — {seg.get('beat', '')}")
            video = renderCustomScene(
                manim_code=seg["code"],
                duration=seg["duration"],
                quality=quality,
            )
            rendered.append(str(video))

        combined = CACHE / "stitched" / f"math_random_forest_{int(time.time())}.mp4"
        combined.parent.mkdir(parents=True, exist_ok=True)

        video = combineMedia(
            media=rendered,
            output=combined,
            transition="crossfade",
            duration=0.35,
            width=width,
            height=height,
            fps=60,
        )

        thumb = generateThumbnail(
            title="Random Forest Explained",
            style="bold_text",
            bg_color="#0a0a0a",
            text_color="#ffffff",
            accent_color="#FF4500",
        )

        logRun(
            "MathRandomForest",
            "success",
            channel=CHANNEL,
            topic="random_forest",
            duration=round(time.time() - start, 1),
        )

        print(f"Video:     {video}")
        print(f"Thumbnail: {thumb}")
        return video, thumb

    except Exception as e:
        logRun(
            "MathRandomForest",
            "failed",
            channel=CHANNEL,
            topic="random_forest",
            duration=round(time.time() - start, 1),
            error=str(e),
        )
        raise


if __name__ == "__main__":
    runMathRandomForest(quality="medium", format="long")
