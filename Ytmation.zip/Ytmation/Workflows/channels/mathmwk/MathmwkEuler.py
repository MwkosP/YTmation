import time
from pathlib import Path

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia
from Thumbnail.thumbnail import generateThumbnail
from Storage.storage import logRun

CHANNEL = "mathmwk"
ROOT    = Path(__file__).resolve().parent.parent.parent
CACHE   = ROOT / "Cache"

# ── Segment 1: Hook (6s) ─────────────────────────────────────────────────
HOOK = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        line1 = Text("Five numbers.", font_size=60, color=WHITE, weight=BOLD)
        line2 = Text("One equation.", font_size=60, color="#FF4500", weight=BOLD)
        line3 = Text("The most beautiful in math.", font_size=44, color=GRAY)
        group = VGroup(line1, line2, line3).arrange(DOWN, buff=0.4)

        self.play(FadeIn(line1, shift=DOWN * 0.2), run_time=0.8)
        self.play(FadeIn(line2, shift=DOWN * 0.2), run_time=0.8)
        self.play(FadeIn(line3, shift=DOWN * 0.2), run_time=0.8)
        self.wait(3.5)
"""

# ── Segment 2: The Five Constants (14s) ──────────────────────────────────
CONSTANTS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        title = Text("Five fundamental constants", font_size=38, color=WHITE).to_edge(UP, buff=0.4)

        constants = VGroup(
            VGroup(MathTex("e",      font_size=64, color="#FF4500"),
                   Text("Euler's number  2.718...", font_size=26, color=GRAY)).arrange(RIGHT, buff=0.4),
            VGroup(MathTex("i",      font_size=64, color="#FFD700"),
                   Text("Imaginary unit  sqrt(-1)", font_size=26, color=GRAY)).arrange(RIGHT, buff=0.4),
            VGroup(MathTex(r"\\pi",  font_size=64, color="#FF4500"),
                   Text("Pi  3.14159...", font_size=26, color=GRAY)).arrange(RIGHT, buff=0.4),
            VGroup(MathTex("1",      font_size=64, color=WHITE),
                   Text("The multiplicative identity", font_size=26, color=GRAY)).arrange(RIGHT, buff=0.4),
            VGroup(MathTex("0",      font_size=64, color=WHITE),
                   Text("The additive identity", font_size=26, color=GRAY)).arrange(RIGHT, buff=0.4),
        ).arrange(DOWN, buff=0.3).shift(DOWN * 0.2)

        self.play(Write(title), run_time=0.8)
        self.play(
            LaggedStart(*[FadeIn(c, shift=RIGHT * 0.2) for c in constants], lag_ratio=0.3),
            run_time=3,
        )
        self.wait(7)
"""

# ── Segment 3: Unit Circle (14s) ─────────────────────────────────────────
CIRCLE = """
from manim import *
import numpy as np

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        title = Text("The Complex Plane", font_size=38, color=WHITE).to_edge(UP, buff=0.3)

        axes = Axes(
            x_range=[-1.5, 1.5, 0.5],
            y_range=[-1.5, 1.5, 0.5],
            x_length=5, y_length=5,
            axis_config={"color": GRAY, "stroke_width": 1.5},
            x_axis_config={"include_numbers": False},
            y_axis_config={"include_numbers": False},
        ).shift(DOWN * 0.3)

        x_label = Text("Real", font_size=24, color=GRAY).next_to(axes.x_axis, RIGHT)
        y_label = Text("Imaginary", font_size=24, color=GRAY).next_to(axes.y_axis, UP)

        circle = Circle(radius=axes.x_length/3, color="#FF4500",
                       stroke_width=3).move_to(axes.get_origin())

        formula = MathTex(r"e^{i\\theta}", font_size=52,
                         color="#FFD700").to_edge(DOWN, buff=0.5)

        dot = Dot(axes.get_origin() + RIGHT * axes.x_length/3,
                 color="#FFD700", radius=0.1)

        self.play(Write(title), run_time=0.8)
        self.play(Create(axes), Write(x_label), Write(y_label), run_time=1.2)
        self.play(Create(circle), run_time=1.5)
        self.play(FadeIn(dot), Write(formula), run_time=0.8)
        self.play(
            MoveAlongPath(dot, circle),
            run_time=3, rate_func=linear,
        )
        self.wait(4)
"""

# ── Segment 4: The Proof Moment (14s) ────────────────────────────────────
PROOF = """
from manim import *
import numpy as np

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        axes = Axes(
            x_range=[-1.5, 1.5, 0.5],
            y_range=[-1.5, 1.5, 0.5],
            x_length=5, y_length=5,
            axis_config={"color": GRAY, "stroke_width": 1.5},
        ).shift(UP * 0.5)

        circle = Circle(radius=axes.x_length/3, color="#FF4500",
                       stroke_width=3).move_to(axes.get_origin())

        origin = axes.get_origin()
        r = axes.x_length / 3

        start_dot = Dot(origin + RIGHT * r, color="#FFD700", radius=0.1)
        end_point = origin + LEFT * r
        end_dot   = Dot(end_point, color="#FFD700", radius=0.12)

        theta_label = MathTex(r"\\theta = \\pi", font_size=44,
                             color=WHITE).to_edge(UP, buff=0.3)

        arc = Arc(radius=r, angle=PI, start_angle=0,
                 color="#FFD700", stroke_width=3).move_to(origin)

        result = MathTex(r"e^{i\\pi} = -1", font_size=60,
                        color="#FFD700").to_edge(DOWN, buff=0.5)

        self.add(axes, circle)
        self.play(Write(theta_label), FadeIn(start_dot), run_time=0.8)
        self.play(Create(arc), run_time=2)
        self.play(ReplacementTransform(start_dot, end_dot), run_time=0.5)
        self.play(Write(result), run_time=1.2)
        self.wait(6)
"""

# ── Segment 5: The Equation (12s) ────────────────────────────────────────
EQUATION = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        parts = VGroup(
            MathTex("e^{i\\\\pi}", font_size=100, color="#FF4500"),
            MathTex("+",           font_size=100, color=WHITE),
            MathTex("1",           font_size=100, color=WHITE),
            MathTex("=",           font_size=100, color=WHITE),
            MathTex("0",           font_size=100, color="#FFD700"),
        ).arrange(RIGHT, buff=0.3)

        box = SurroundingRectangle(parts, color="#FF4500",
                                  stroke_width=2, buff=0.3)

        label = Text("Euler's Identity", font_size=36,
                    color=GRAY).next_to(box, DOWN, buff=0.4)

        self.play(
            LaggedStart(*[Write(p) for p in parts], lag_ratio=0.3),
            run_time=3,
        )
        self.play(Create(box), run_time=0.8)
        self.play(FadeIn(label), run_time=0.8)
        self.play(
            parts.animate.set_color(WHITE),
            box.animate.set_color("#FFD700"),
            run_time=1,
        )
        self.wait(4)
"""

# ── Segment 6: Mind Blow (10s) ───────────────────────────────────────────
MINDBLOW = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        line1 = Text("This wasn't discovered.", font_size=52, color=WHITE)
        line2 = Text("It was always true.", font_size=52, color="#FF4500", weight=BOLD)
        line3 = Text("We just finally understood it.", font_size=40, color=GRAY)

        group = VGroup(line1, line2, line3).arrange(DOWN, buff=0.5)

        self.play(FadeIn(line1, shift=DOWN * 0.2), run_time=1)
        self.play(FadeIn(line2, shift=DOWN * 0.2), run_time=1)
        self.play(FadeIn(line3, shift=DOWN * 0.2), run_time=1)
        self.wait(5)
"""

# ── Segment 7: Outro (8s) ────────────────────────────────────────────────
OUTRO = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"

        eq   = MathTex(r"e^{i\\pi} + 1 = 0", font_size=90, color="#FF4500")
        name = Text("mathmwk", font_size=60,
                   color=WHITE, weight=BOLD).next_to(eq, DOWN, buff=0.5)
        sub  = Text("follow for more math",
                   font_size=30, color=GRAY).next_to(name, DOWN, buff=0.3)

        self.play(Write(eq),   run_time=1.5)
        self.play(FadeIn(name), run_time=0.8)
        self.play(FadeIn(sub),  run_time=0.8)
        self.wait(4)
"""

SEGMENTS = [
    {"name": "hook",       "code": HOOK,       "duration": 6},
    {"name": "constants",  "code": CONSTANTS,  "duration": 14},
    {"name": "circle",     "code": CIRCLE,     "duration": 14},
    {"name": "proof",      "code": PROOF,      "duration": 14},
    {"name": "equation",   "code": EQUATION,   "duration": 12},
    {"name": "mindblow",   "code": MINDBLOW,   "duration": 10},
    {"name": "outro",      "code": OUTRO,      "duration": 8},
]


def runMathmwkEuler(quality: str = "medium", format: str = "long"):
    start = time.time()
    width, height = (1920, 1080) if format == "long" else (1080, 1920)

    try:
        total = sum(s["duration"] for s in SEGMENTS)
        print(f"Euler's Identity — {len(SEGMENTS)} segments, {total}s target, {format} format")

        # ── render each segment ───────────────────────────────────────
        rendered = []
        for i, seg in enumerate(SEGMENTS):
            print(f"  [{i+1}/{len(SEGMENTS)}] {seg['name']} ({seg['duration']}s)")
            video = renderCustomScene(
                manim_code=seg["code"],
                duration=seg["duration"],
                quality=quality,
            )
            rendered.append(str(video))

        # ── combine ───────────────────────────────────────────────────
        combined = CACHE / "stitched" / f"mathmwk_euler_{int(time.time())}.mp4"
        combined.parent.mkdir(parents=True, exist_ok=True)

        video = combineMedia(
            media=rendered,
            output=combined,
            transition="crossfade",
            duration=0.4,
            width=width,
            height=height,
            fps=60,
        )

        # ── thumbnail ─────────────────────────────────────────────────
        thumb = generateThumbnail(
            title="The Most Beautiful Equation",
            style="bold_text",
            bg_color="#0a0a0a",
            text_color="#ffffff",
            accent_color="#FF4500",
        )

        logRun("MathmwkEuler", "success", channel=CHANNEL,
               topic="euler_identity", duration=round(time.time() - start, 1))

        print(f"Video:     {video}")
        print(f"Thumbnail: {thumb}")
        return video, thumb

    except Exception as e:
        logRun("MathmwkEuler", "failed", channel=CHANNEL,
               topic="euler_identity", duration=round(time.time() - start, 1), error=str(e))
        raise