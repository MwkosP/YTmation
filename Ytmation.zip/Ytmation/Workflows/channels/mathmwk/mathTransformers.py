"""
Transformers — long-form explainer (5 minutes / 300s).

20 segments × 15s each. Each chunk = one narrated Manim scene.
Logic: problem → tokens → attention → architecture → training → models → impact.
"""

import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia
from Thumbnail.thumbnail import generateThumbnail
from Storage.storage import logRun

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"
TARGET_SECONDS = 300  # 5:00 long-form

# ── 1) Hook ─────────────────────────────────────────────────────────────────
HOOK = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        l1 = Text("Transformers", font_size=78, color="#FF4500", weight=BOLD)
        l2 = Text("The architecture behind modern AI", font_size=42, color=WHITE)
        l3 = Text("ChatGPT, Claude, Gemini — same core idea", font_size=30, color=GRAY)
        g = VGroup(l1, l2, l3).arrange(DOWN, buff=0.35)
        self.play(FadeIn(l1, shift=UP * 0.25), run_time=1.0)
        self.play(FadeIn(l2, shift=UP * 0.2), run_time=1.0)
        self.play(Write(l3), run_time=1.1)
        self.wait(11.5)
"""

# ── 2) Sequence problem ───────────────────────────────────────────────────
SEQ_PROBLEM = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("The problem: language is sequential", font_size=38, color=WHITE).to_edge(UP, buff=0.4)
        words = VGroup(*[
            Text(w, font_size=40, color=WHITE if i < 4 else GRAY)
            for i, w in enumerate(["The", "cat", "sat", "on", "the", "mat"])
        ]).arrange(RIGHT, buff=0.25).shift(DOWN * 0.2)
        arrow = Arrow(words[3].get_right(), words[5].get_left(), color="#FF4500", buff=0.15)
        note = Text("Meaning depends on context far away", font_size=28, color=GRAY).to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.8)
        self.play(LaggedStart(*[FadeIn(w) for w in words], lag_ratio=0.15), run_time=2.0)
        self.play(Create(arrow), FadeIn(note), run_time=1.2)
        self.wait(10.5)
"""

# ── 3) Old approach limits ──────────────────────────────────────────────────
OLD_LIMITS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Before Transformers: RNNs", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        boxes = VGroup(*[
            Rectangle(width=1.2, height=0.7, color=GRAY, stroke_width=2)
            for _ in range(6)
        ]).arrange(RIGHT, buff=0.2).shift(DOWN * 0.2)
        arrows = VGroup(*[
            Arrow(boxes[i].get_right(), boxes[i+1].get_left(), buff=0.05, color="#666666")
            for i in range(5)
        ])
        issues = VGroup(
            Text("• slow (one step at a time)", font_size=28, color=GRAY),
            Text("• hard to remember long context", font_size=28, color="#FF4500"),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.3).to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.8)
        self.play(Create(boxes), LaggedStart(*[Create(a) for a in arrows], lag_ratio=0.1), run_time=2.0)
        self.play(FadeIn(issues), run_time=1.0)
        self.wait(10.7)
"""

# ── 4) Tokenization ─────────────────────────────────────────────────────────
TOKENIZE = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 1 — Tokenize text", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        sentence = Text("Hello world!", font_size=44, color=WHITE).shift(UP * 0.5)
        tokens = VGroup(
            Text("[Hello]", font_size=32, color="#FF4500"),
            Text("[world]", font_size=32, color="#FFD700"),
            Text("[!]", font_size=32, color=GRAY),
        ).arrange(RIGHT, buff=0.35).shift(DOWN * 0.5)
        ids = Text("→ token IDs: 15496, 995, 0", font_size=28, color=GRAY).to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.7)
        self.play(Write(sentence), run_time=0.9)
        self.play(Transform(sentence.copy(), tokens), run_time=1.5)
        self.play(FadeIn(ids), run_time=0.8)
        self.wait(10.6)
"""

# ── 5) Embeddings ───────────────────────────────────────────────────────────
EMBEDDINGS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Step 2 — Embeddings", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        toks = VGroup(
            Text("Hello", font_size=30, color=WHITE),
            Text("world", font_size=30, color=WHITE),
        ).arrange(RIGHT, buff=1.5).shift(UP * 0.8)
        vecs = VGroup(
            Rectangle(width=0.5, height=2.2, color="#FF4500", fill_opacity=0.5),
            Rectangle(width=0.5, height=1.6, color="#FFD700", fill_opacity=0.5),
        ).arrange(RIGHT, buff=1.5).shift(DOWN * 0.5)
        lbl = Text("each token → vector in high-dimensional space", font_size=26, color=GRAY).to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.7)
        self.play(FadeIn(toks), run_time=0.8)
        self.play(LaggedStart(*[GrowFromCenter(v) for v in vecs], lag_ratio=0.2), run_time=1.8)
        self.play(FadeIn(lbl), run_time=0.8)
        self.wait(10.4)
"""

# ── 6) Attention idea ───────────────────────────────────────────────────────
ATTENTION_IDEA = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Core idea: Attention", font_size=42, color=WHITE).to_edge(UP, buff=0.4)
        line = Text("Every token can look at every other token", font_size=34, color="#FF4500")
        sub = Text("in parallel — not one-by-one", font_size=30, color=GRAY).next_to(line, DOWN, buff=0.35)
        grid_hint = VGroup(*[
            Square(side_length=0.35, color="#333333", stroke_width=1, fill_opacity=0.2)
            for _ in range(25)
        ]).arrange_in_grid(5, 5, buff=0.05).scale(0.9).shift(DOWN * 0.8)
        self.play(Write(title), run_time=0.8)
        self.play(Write(line), FadeIn(sub), run_time=1.2)
        self.play(FadeIn(grid_hint), run_time=1.2)
        self.wait(11.3)
"""

# ── 7) Q K V ────────────────────────────────────────────────────────────────
QKV = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Query, Key, Value", font_size=42, color=WHITE).to_edge(UP, buff=0.4)
        q = VGroup(MathTex("Q", font_size=64, color="#FF4500"), Text("Query\\n(what am I looking for?)", font_size=22, color=GRAY)).arrange(DOWN, buff=0.2).shift(LEFT * 3)
        k = VGroup(MathTex("K", font_size=64, color="#FFD700"), Text("Key\\n(what do I offer?)", font_size=22, color=GRAY)).arrange(DOWN, buff=0.2)
        v = VGroup(MathTex("V", font_size=64, color=WHITE), Text("Value\\n(what info do I pass?)", font_size=22, color=GRAY)).arrange(DOWN, buff=0.2).shift(RIGHT * 3)
        self.play(Write(title), run_time=0.8)
        self.play(FadeIn(q), FadeIn(k), FadeIn(v), run_time=1.8)
        self.wait(12.1)
"""

# ── 8) Attention scores ─────────────────────────────────────────────────────
ATTENTION_SCORES = """
from manim import *
import numpy as np

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Attention weights", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        labels = VGroup(*[Text(t, font_size=22, color=GRAY) for t in ["The", "cat", "sat"]]).arrange(RIGHT, buff=0.55).shift(UP * 1.2)
        mat = VGroup()
        vals = [[0.1,0.7,0.2],[0.2,0.6,0.2],[0.15,0.25,0.6]]
        for i in range(3):
            for j in range(3):
                c = "#FF4500" if vals[i][j] > 0.5 else "#333333"
                mat.add(Square(side_length=0.7, color=c, fill_opacity=vals[i][j], stroke_width=1))
        mat.arrange_in_grid(3, 3, buff=0.08).shift(DOWN * 0.3)
        formula = MathTex(r"\\text{softmax}\\left(\\frac{QK^T}{\\sqrt{d_k}}\\right)", font_size=44, color="#FFD700").to_edge(DOWN, buff=0.4)
        self.play(Write(title), FadeIn(labels), run_time=1.0)
        self.play(FadeIn(mat), run_time=1.5)
        self.play(Write(formula), run_time=1.2)
        self.wait(10.8)
"""

# ── 9) Multi-head ───────────────────────────────────────────────────────────
MULTI_HEAD = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Multi-Head Attention", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        heads = VGroup(*[
            Rectangle(width=1.4, height=1.8, color=c, fill_opacity=0.25, stroke_width=2)
            for c in ["#FF4500", "#FFD700", "#ffffff", "#FF4500"]
        ]).arrange(RIGHT, buff=0.25).shift(DOWN * 0.2)
        labels = VGroup(*[Text(f"Head {i+1}", font_size=22, color=GRAY) for i in range(4)]).arrange(RIGHT, buff=0.55).next_to(heads, DOWN, buff=0.35)
        note = Text("Different heads learn different relationships", font_size=28, color=GRAY).to_edge(DOWN, buff=0.4)
        self.play(Write(title), run_time=0.8)
        self.play(LaggedStart(*[GrowFromCenter(h) for h in heads], lag_ratio=0.15), run_time=2.0)
        self.play(FadeIn(labels), FadeIn(note), run_time=1.0)
        self.wait(10.7)
"""

# ── 10) Positional encoding ─────────────────────────────────────────────────
POSITIONAL = """
from manim import *
import numpy as np

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Positional encoding", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        line = Text("Attention alone has no word order", font_size=32, color=GRAY)
        fix = Text("Add position info to each embedding", font_size=32, color="#FF4500").next_to(line, DOWN, buff=0.4)
        axes = Axes(
            x_range=[0, 6, 1], y_range=[-1, 1, 0.5],
            x_length=6, y_length=2, axis_config={"color": GRAY},
        ).shift(DOWN * 0.8)
        graph = axes.plot(lambda x: np.sin(x), color="#FFD700")
        self.play(Write(title), run_time=0.8)
        self.play(Write(line), Write(fix), run_time=1.4)
        self.play(Create(axes), Create(graph), run_time=1.5)
        self.wait(10.8)
"""

# ── 11) Feed-forward ──────────────────────────────────────────────────────────
FEED_FORWARD = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Feed-Forward Network", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        layers = VGroup(
            Rectangle(width=0.5, height=2, color=GRAY, fill_opacity=0.3),
            Rectangle(width=1.2, height=2, color="#FF4500", fill_opacity=0.35),
            Rectangle(width=0.5, height=2, color=GRAY, fill_opacity=0.3),
        ).arrange(RIGHT, buff=0.5).shift(DOWN * 0.2)
        lbl = VGroup(Text("expand", font_size=24, color=GRAY), Text("contract", font_size=24, color=GRAY)).arrange(RIGHT, buff=2.8).next_to(layers, DOWN, buff=0.4)
        note = Text("Applied to each token position", font_size=28, color=GRAY).to_edge(DOWN, buff=0.4)
        self.play(Write(title), run_time=0.8)
        self.play(LaggedStart(*[GrowFromCenter(l) for l in layers], lag_ratio=0.2), run_time=1.8)
        self.play(FadeIn(lbl), FadeIn(note), run_time=1.0)
        self.wait(10.9)
"""

# ── 12) Encoder block ─────────────────────────────────────────────────────────
ENCODER_BLOCK = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("One Transformer block", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        blocks = VGroup(
            Rectangle(width=5, height=0.9, color="#FF4500", fill_opacity=0.2),
            Rectangle(width=5, height=0.9, color="#FFD700", fill_opacity=0.2),
        ).arrange(DOWN, buff=0.25).shift(DOWN * 0.1)
        t1 = Text("Multi-Head Self-Attention", font_size=26, color=WHITE).move_to(blocks[0])
        t2 = Text("Feed-Forward Network", font_size=26, color=WHITE).move_to(blocks[1])
        stack = Text("× N layers", font_size=32, color=GRAY).next_to(blocks, DOWN, buff=0.45)
        self.play(Write(title), run_time=0.8)
        self.play(FadeIn(blocks), Write(t1), Write(t2), run_time=1.8)
        self.play(FadeIn(stack), run_time=0.8)
        self.wait(11.1)
"""

# ── 13) Residual + norm ───────────────────────────────────────────────────────
RESIDUAL = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Residual + Layer Norm", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        eq = MathTex(r"x + \\text{Attention}(x)", font_size=56, color="#FF4500")
        eq2 = MathTex(r"x + \\text{FFN}(x)", font_size=56, color="#FFD700").next_to(eq, DOWN, buff=0.5)
        why = Text("Helps deep networks train stably", font_size=28, color=GRAY).to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.8)
        self.play(Write(eq), run_time=1.2)
        self.play(Write(eq2), run_time=1.2)
        self.play(FadeIn(why), run_time=0.8)
        self.wait(10.5)
"""

# ── 14) Encoder-decoder ───────────────────────────────────────────────────────
ENCODER_DECODER = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Encoder–Decoder (original Transformer)", font_size=36, color=WHITE).to_edge(UP, buff=0.4)
        enc = Rectangle(width=2.8, height=3.2, color="#FF4500", fill_opacity=0.15).shift(LEFT * 2.2)
        dec = Rectangle(width=2.8, height=3.2, color="#FFD700", fill_opacity=0.15).shift(RIGHT * 2.2)
        enc_t = Text("Encoder\\n(reads input)", font_size=24, color=WHITE).move_to(enc)
        dec_t = Text("Decoder\\n(generates output)", font_size=24, color=WHITE).move_to(dec)
        arrow = Arrow(enc.get_right(), dec.get_left(), color=GRAY, buff=0.15)
        ex = Text("Translation: English → French", font_size=26, color=GRAY).to_edge(DOWN, buff=0.4)
        self.play(Write(title), run_time=0.8)
        self.play(Create(enc), Create(dec), Write(enc_t), Write(dec_t), run_time=1.8)
        self.play(Create(arrow), FadeIn(ex), run_time=1.0)
        self.wait(10.9)
"""

# ── 15) Training ──────────────────────────────────────────────────────────────
TRAINING = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Training objective", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        line = Text("Predict the next token", font_size=38, color="#FF4500")
        seq = VGroup(*[
            Text(t, font_size=32, color=c)
            for t, c in [("The", WHITE), ("cat", WHITE), ("sat", WHITE), ("?", GRAY)]
        ]).arrange(RIGHT, buff=0.3).shift(DOWN * 0.3)
        loss = Text("Minimize cross-entropy loss over billions of tokens", font_size=26, color=GRAY).to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.8)
        self.play(Write(line), run_time=1.0)
        self.play(FadeIn(seq), run_time=1.2)
        self.play(FadeIn(loss), run_time=0.8)
        self.wait(10.7)
"""

# ── 16) GPT ───────────────────────────────────────────────────────────────────
GPT = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("GPT: Decoder-only", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        box = Rectangle(width=4, height=3, color="#FF4500", fill_opacity=0.15)
        lbl = Text("Autoregressive\\none token at a time →", font_size=28, color=WHITE).move_to(box)
        out = Text('The cat sat on the ___', font_size=30, color="#FFD700").next_to(box, DOWN, buff=0.5)
        self.play(Write(title), run_time=0.8)
        self.play(Create(box), Write(lbl), run_time=1.5)
        self.play(Write(out), run_time=1.0)
        self.wait(11.2)
"""

# ── 17) BERT / encoders ───────────────────────────────────────────────────────
BERT = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("BERT: Encoder-only", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        sent = Text("The [MASK] sat on the mat", font_size=34, color=WHITE)
        task = Text("Fill in masked words — bidirectional context", font_size=28, color=GRAY).next_to(sent, DOWN, buff=0.5)
        use = Text("Great for classification & search", font_size=26, color="#FF4500").to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.8)
        self.play(Write(sent), run_time=1.0)
        self.play(FadeIn(task), FadeIn(use), run_time=1.2)
        self.wait(11.5)
"""

# ── 18) Scale ─────────────────────────────────────────────────────────────────
SCALE = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Scale changes everything", font_size=40, color=WHITE).to_edge(UP, buff=0.4)
        items = VGroup(
            Text("More parameters", font_size=32, color=GRAY),
            Text("More data", font_size=32, color=GRAY),
            Text("More compute", font_size=32, color=GRAY),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.35).shift(LEFT * 0.5)
        arrow = Text("→ emergent abilities", font_size=36, color="#FF4500").shift(RIGHT * 1.8)
        self.play(Write(title), run_time=0.8)
        self.play(LaggedStart(*[FadeIn(i, shift=RIGHT*0.1) for i in items], lag_ratio=0.2), run_time=2.0)
        self.play(Write(arrow), run_time=1.0)
        self.wait(10.7)
"""

# ── 19) Applications + limits ─────────────────────────────────────────────────
APPLICATIONS = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        title = Text("Where Transformers are used", font_size=36, color=WHITE).to_edge(UP, buff=0.4)
        apps = VGroup(
            Text("• Chat & coding assistants", font_size=30, color="#00ff88"),
            Text("• Translation & summarization", font_size=30, color="#00ff88"),
            Text("• Vision (ViT), audio, multimodal", font_size=30, color="#00ff88"),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.32).shift(UP * 0.1)
        lim = Text("Limits: cost, hallucinations, bias", font_size=28, color="#FF4500").to_edge(DOWN, buff=0.45)
        self.play(Write(title), run_time=0.8)
        self.play(LaggedStart(*[FadeIn(a) for a in apps], lag_ratio=0.2), run_time=2.2)
        self.play(FadeIn(lim), run_time=0.8)
        self.wait(10.7)
"""

# ── 20) Outro ─────────────────────────────────────────────────────────────────
OUTRO = """
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
        t1 = Text("Transformers", font_size=62, color=WHITE)
        t2 = Text("Attention is all you need", font_size=38, color="#FF4500").next_to(t1, DOWN, buff=0.3)
        t3 = Text("mathmwk  •  follow for more AI math", font_size=28, color=GRAY).next_to(t2, DOWN, buff=0.45)
        self.play(Write(t1), run_time=1.2)
        self.play(FadeIn(t2), run_time=1.0)
        self.play(FadeIn(t3), run_time=0.9)
        self.wait(11.4)
"""

# 20 × 15s = 300s
SEGMENTS = [
    {"name": "hook",             "code": HOOK,             "duration": 15, "beat": "what Transformers are"},
    {"name": "seq_problem",      "code": SEQ_PROBLEM,      "duration": 15, "beat": "sequential language"},
    {"name": "old_limits",       "code": OLD_LIMITS,       "duration": 15, "beat": "RNN limitations"},
    {"name": "tokenize",         "code": TOKENIZE,         "duration": 15, "beat": "text → tokens"},
    {"name": "embeddings",       "code": EMBEDDINGS,       "duration": 15, "beat": "token vectors"},
    {"name": "attention_idea",   "code": ATTENTION_IDEA,   "duration": 15, "beat": "parallel context"},
    {"name": "qkv",              "code": QKV,              "duration": 15, "beat": "Query Key Value"},
    {"name": "attention_scores", "code": ATTENTION_SCORES, "duration": 15, "beat": "softmax weights"},
    {"name": "multi_head",       "code": MULTI_HEAD,       "duration": 15, "beat": "multiple heads"},
    {"name": "positional",       "code": POSITIONAL,       "duration": 15, "beat": "word order"},
    {"name": "feed_forward",     "code": FEED_FORWARD,     "duration": 15, "beat": "FFN per token"},
    {"name": "encoder_block",    "code": ENCODER_BLOCK,    "duration": 15, "beat": "one layer"},
    {"name": "residual",         "code": RESIDUAL,         "duration": 15, "beat": "skip connections"},
    {"name": "encoder_decoder",  "code": ENCODER_DECODER,  "duration": 15, "beat": "original architecture"},
    {"name": "training",         "code": TRAINING,         "duration": 15, "beat": "next-token prediction"},
    {"name": "gpt",              "code": GPT,              "duration": 15, "beat": "decoder-only LLMs"},
    {"name": "bert",             "code": BERT,             "duration": 15, "beat": "encoder-only"},
    {"name": "scale",            "code": SCALE,            "duration": 15, "beat": "parameters & data"},
    {"name": "applications",     "code": APPLICATIONS,     "duration": 15, "beat": "uses & limits"},
    {"name": "outro",            "code": OUTRO,            "duration": 15, "beat": "recap + CTA"},
]


def _assertTiming():
    total = sum(s["duration"] for s in SEGMENTS)
    if total != TARGET_SECONDS:
        raise ValueError(f"SEGMENTS total {total}s != TARGET_SECONDS {TARGET_SECONDS}s")


def runMathTransformers(quality: str = "medium", format: str = "long"):
    _assertTiming()
    start = time.time()
    width, height = (1920, 1080) if format == "long" else (1080, 1920)
    total = sum(s["duration"] for s in SEGMENTS)

    try:
        print(f"Transformers — {len(SEGMENTS)} segments, {total // 60}:{total % 60:02d} target, {format}")

        rendered = []
        for i, seg in enumerate(SEGMENTS):
            print(f"  [{i + 1}/{len(SEGMENTS)}] {seg['name']} ({seg['duration']}s) — {seg.get('beat', '')}")
            video = renderCustomScene(
                manim_code=seg["code"],
                duration=seg["duration"],
                quality=quality,
            )
            rendered.append(str(video))

        combined = CACHE / "stitched" / f"math_transformers_{int(time.time())}.mp4"
        combined.parent.mkdir(parents=True, exist_ok=True)

        video = combineMedia(
            media=rendered,
            output=combined,
            transition="crossfade",
            duration=0.35,
            width=width,
            height=height,
            fps=60,
        )

        thumb = generateThumbnail(
            title="Transformers Explained",
            style="bold_text",
            bg_color="#0a0a0a",
            text_color="#ffffff",
            accent_color="#FF4500",
        )

        logRun(
            "MathTransformers",
            "success",
            channel=CHANNEL,
            topic="transformers",
            duration=round(time.time() - start, 1),
        )

        print(f"Video:     {video}")
        print(f"Thumbnail: {thumb}")
        return video, thumb

    except Exception as e:
        logRun(
            "MathTransformers",
            "failed",
            channel=CHANNEL,
            topic="transformers",
            duration=round(time.time() - start, 1),
            error=str(e),
        )
        raise


if __name__ == "__main__":
    runMathTransformers(quality="medium", format="long")
