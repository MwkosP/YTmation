"""
Full Physics library showcase — all demo recipes + intro.

python Workflows/channels/mathmwk/physicsShowcase.py
"""

import sys
import time
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomScene
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"

BEAT_SECONDS = 4.0
PAD_WAIT = 1.0

DEMOS = [
    ("projectile", "demoProjectile"),
    ("pendulum", "demoPendulum"),
    ("kinematics", "demoKinematicsGraph"),
    ("energy", "demoEnergyBars"),
    ("waves", "demoWaveInterference"),
    ("collision", "demoCollision"),
    ("spring", "demoSpring"),
    ("free_fall", "demoFreeFall"),
    ("bounce", "demoBounce"),
    ("fbd", "demoFreeBodyDiagram"),
    ("optics", "demoOptics"),
    ("electromagnetism", "demoElectromagnetism"),
]


def _seg(name: str, beat: str, animation: str) -> dict:
    return {"name": name, "beat": beat, "animation": animation}


def _beat(body: str) -> str:
    b = body.strip()
    if "self.wait(" not in b.split("\n")[-1]:
        b += f"\nself.wait({PAD_WAIT})"
    return b


def _demo_segment(idx: int, slug: str, fn: str) -> dict:
    num = f"{idx:02d}"
    return _seg(
        f"{num}_{slug}",
        fn,
        _beat(
            f"""
from Math.library.physics.recipes import {fn}
from Math.library.common.styling import setupScene
setupScene(self)
{fn}(self)
"""
        ),
    )


SEGMENTS = [
    _seg(
        "00_intro",
        "catalog",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("hero")
title = makeTitle("Physics Library", size=48, layout=layout)
sub = makeSubtitle("Math.library.physics · mechanics, waves, optics, E&M", size=26, layout=layout, below=title)
self.play(Write(title), FadeIn(sub), run_time=1.2)
"""
        ),
    ),
    *[_demo_segment(i + 1, slug, fn) for i, (slug, fn) in enumerate(DEMOS)],
    _seg(
        "13_outro",
        "end",
        _beat(
            """
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle
from Math.library.common.styling import setupScene

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Physics primitives ready", size=44, layout=layout)
sub = makeSubtitle("make* · show* · demo* · compose with math/", size=24, layout=layout, below=title)
self.play(Write(title), FadeIn(sub), run_time=1.0)
"""
        ),
    ),
]


def _scene_source(animation: str) -> str:
    body = textwrap.indent(animation.strip(), "        ")
    return f"""
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "#0a0a0a"
{body}
"""


def runPhysicsShowcase(quality: str = "low", format: str = "long") -> Path:
    width, height = (1080, 1920) if format == "short" else (1920, 1080)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    rendered: list[str] = []
    total = len(SEGMENTS)
    print(
        f"{CHANNEL} physics showcase — {total} segments × ~{BEAT_SECONDS}s, "
        f"quality={quality}, {width}x{height}",
        flush=True,
    )

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{total}] {seg['name']} — {seg['beat']}", flush=True)
        out = CACHE / "math" / f"physics_showcase_{seg['name']}.mp4"
        path = renderCustomScene(
            manim_code=_scene_source(seg["animation"]),
            output=out,
            quality=quality,
        )
        rendered.append(str(path))

    final_path = CACHE / "stitched" / f"mathmwk_physics_showcase_{int(time.time())}.mp4"
    combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.2,
        width=width,
        height=height,
        fps=30,
    )
    print(f"Showcase video ({total} segments): {final_path}")
    return final_path


if __name__ == "__main__":
    runPhysicsShowcase(quality="low", format="long")
