"""
Market Equilibrium — ~30s voiceover explainer.

Per segment: pregenerate voice → renderCustomVoiceoverScene (tracker.duration sync).

python Workflows/channels/mathmwk/economicsEquilibriumVoiceover.py
"""

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.math import renderCustomVoiceoverScene
from Math.voiceover.helpers import pregenerateVoice
from Transitions.transitions import combineMedia

CHANNEL = "mathmwk"
CACHE = ROOT / "Cache"
VOICE_CACHE = CACHE / "voice" / "economics_equilibrium"
TARGET_SECONDS = 30

SEGMENTS = [
    {
        "name": "01_intro",
        "beat": "what is equilibrium",
        "narration": (
            "Market equilibrium is the price and quantity where supply and demand meet."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle

setupScene(self)
layout = SceneLayout("hero")
title = makeTitle("Market Equilibrium", size=52, layout=layout)
sub = makeSubtitle("Where supply meets demand", size=32, layout=layout, below=title)
self.play(Write(title), run_time=tracker.duration * 0.55)
self.play(FadeIn(sub), run_time=tracker.duration * 0.45)
""",
    },
    {
        "name": "02_supply_demand",
        "beat": "two curves",
        "narration": (
            "Demand slopes down: buyers want more at lower prices. "
            "Supply slopes up: sellers offer more at higher prices."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.economics.shows import showSupplyDemand
from Math.library.common.pacing import waitForVoice

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Supply & Demand", size=40, layout=layout)
self.play(Write(title), run_time=tracker.duration * 0.18)
showSupplyDemand(self, layout=layout, run_time=tracker.duration * 0.72)
waitForVoice(self, tracker)
""",
    },
    {
        "name": "03_equilibrium_point",
        "beat": "intersection",
        "narration": (
            "Where the curves cross, we get equilibrium price and quantity. "
            "At that point the market clears: no shortage, no surplus."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle, makeCaption
from Math.library.economics.shows import showEquilibrium
from Math.library.common.pacing import waitForVoice

setupScene(self)
layout = SceneLayout("standard")
title = makeTitle("Equilibrium Point", size=40, layout=layout)
cap = makeCaption("P* and Q* at the intersection", layout=layout)
self.play(Write(title), run_time=tracker.duration * 0.14)
showEquilibrium(self, layout=layout, run_time=tracker.duration * 0.68)
self.play(FadeIn(cap), run_time=tracker.duration * 0.10)
waitForVoice(self, tracker)
""",
    },
    {
        "name": "04_recap",
        "beat": "summary",
        "narration": (
            "Quantity demanded equals quantity supplied. "
            "That balance is market equilibrium."
        ),
        "animation": """
from Math.library.common.styling import setupScene
from Math.library.common.layout import SceneLayout, makeTitle, makeSubtitle

setupScene(self)
layout = SceneLayout("hero")
title = makeTitle("Market clears", size=48, layout=layout)
sub = makeSubtitle("Supply = Demand at P* , Q*", size=30, layout=layout, below=title)
self.play(Write(title), run_time=tracker.duration * 0.5)
self.play(FadeIn(sub), run_time=tracker.duration * 0.5)
""",
    },
]


def runEquilibriumVoiceover(
    quality: str = "low",
    format: str = "long",
    transcription_model: str | None = None,
) -> Path:
    start = time.time()
    width, height = (1920, 1080) if format == "long" else (1080, 1920)
    VOICE_CACHE.mkdir(parents=True, exist_ok=True)
    (CACHE / "math").mkdir(parents=True, exist_ok=True)
    (CACHE / "stitched").mkdir(parents=True, exist_ok=True)

    print(
        f"{CHANNEL} market equilibrium voiceover — {len(SEGMENTS)} segments, "
        f"target ~{TARGET_SECONDS}s total, quality={quality}",
        flush=True,
    )

    rendered: list[str] = []
    voice_durations: list[float] = []

    for i, seg in enumerate(SEGMENTS, 1):
        print(f"  [{i}/{len(SEGMENTS)}] {seg['name']} — {seg['beat']}", flush=True)
        voice_path = VOICE_CACHE / f"{seg['name']}.mp3"
        out_path = CACHE / "math" / f"equilibrium_vo_{seg['name']}.mp4"

        if not voice_path.is_file():
            print("    generating voice...", flush=True)
            pregenerateVoice(seg["narration"], output=voice_path)

        # Rough duration from file size isn't reliable; measure after render via scene time
        video = renderCustomVoiceoverScene(
            narration=seg["narration"],
            animation_body=seg["animation"],
            voice_path=voice_path,
            output=out_path,
            quality=quality,
            pregenerate=False,
            transcription_model=transcription_model,
        )
        rendered.append(str(video))
        print(f"    done: {video.name}", flush=True)

    final_path = CACHE / "stitched" / f"mathmwk_equilibrium_voiceover_{int(time.time())}.mp4"
    combined = combineMedia(
        media=rendered,
        output=final_path,
        transition="crossfade",
        duration=0.25,
        width=width,
        height=height,
        fps=30,
    )

    elapsed = time.time() - start
    print(f"Stitched video: {combined}")
    print(f"Wall time: {elapsed:.1f}s (target narration ~{TARGET_SECONDS}s — check playback length)")
    return combined


if __name__ == "__main__":
    runEquilibriumVoiceover(quality="low", format="long")
