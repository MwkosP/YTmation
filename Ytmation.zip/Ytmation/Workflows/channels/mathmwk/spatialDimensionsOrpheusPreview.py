"""
Preview spatial-dimensions ELI5 narrations with Orpheus TTS (HF Space).

Generates audio only — no Manim render. Listen before swapping voice in the full workflow.

Requires: pip install gradio_client  (optional extra: voice-orpheus in pyproject)

export HF_TOKEN=hf_...   # recommended — better rate limits on the free Space

python Workflows/channels/mathmwk/spatialDimensionsOrpheusPreview.py
python Workflows/channels/mathmwk/spatialDimensionsOrpheusPreview.py --voice leah
python Workflows/channels/mathmwk/spatialDimensionsOrpheusPreview.py --segment 01_hook
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Math.voiceover.helpers import pregenerateOrpheusVoice
from Voice.orpheus import VOICES, hfToken
from Workflows.channels.mathmwk.spatialDimensionsELI5Voiceover import SEGMENTS

CACHE = ROOT / "Cache"
OUT_DIR = CACHE / "voice" / "spatial_dimensions_eli5_orpheus"


def stitchWavs(paths: list[Path], output: Path) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    list_file = output.with_suffix(".txt")
    lines = [f"file '{p.resolve()}'" for p in paths]
    list_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(list_file),
            "-c",
            "copy",
            str(output),
        ],
        check=True,
        capture_output=True,
    )
    list_file.unlink(missing_ok=True)
    return output


def runPreview(
    voice: str = "tara",
    segment: str | None = None,
    max_new_tokens: int = 1200,
    stitch: bool = True,
) -> Path | list[Path]:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    token = hfToken()
    print(
        f"Orpheus preview — voice={voice}, HF token={'set' if token else 'not set (public queue)'}",
        flush=True,
    )
    print(f"Space: MohamedRashad/Orpheus-TTS", flush=True)
    print(f"Output: {OUT_DIR}", flush=True)

    segments = SEGMENTS
    if segment:
        segments = [s for s in SEGMENTS if s["name"] == segment or s["name"].endswith(segment)]
        if not segments:
            names = ", ".join(s["name"] for s in SEGMENTS)
            raise SystemExit(f"No segment matching {segment!r}. Available: {names}")

    wavs: list[Path] = []
    start = time.time()

    for i, seg in enumerate(segments, 1):
        wav_path = OUT_DIR / f"{seg['name']}.wav"
        mp3_path = OUT_DIR / f"{seg['name']}.mp3"
        print(f"  [{i}/{len(segments)}] {seg['name']} — {seg['beat']}", flush=True)
        t0 = time.time()
        pregenerateOrpheusVoice(
            seg["narration"],
            output=wav_path,
            voice=voice,
            max_new_tokens=max_new_tokens,
        )
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(wav_path), "-codec:a", "libmp3lame", "-qscale:a", "2", str(mp3_path)],
            check=True,
            capture_output=True,
        )
        wavs.append(wav_path)
        print(f"    done in {time.time() - t0:.1f}s → {wav_path} (+ {mp3_path.name})", flush=True)

    combined: Path | None = None
    if stitch and len(wavs) > 1:
        combined = OUT_DIR / f"full_preview_{voice}.wav"
        stitchWavs(wavs, combined)
        combined_mp3 = combined.with_suffix(".mp3")
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(combined), "-codec:a", "libmp3lame", "-qscale:a", "2", str(combined_mp3)],
            check=True,
            capture_output=True,
        )
        print(f"\nFull preview: {combined_mp3}", flush=True)

    print(f"Wall time: {time.time() - start:.1f}s", flush=True)
    return combined or wavs[0]


def main() -> None:
    parser = argparse.ArgumentParser(description="Orpheus TTS preview for spatial ELI5 script")
    parser.add_argument("--voice", default="tara", choices=VOICES, help="Orpheus speaker")
    parser.add_argument("--segment", default=None, help="Only one segment, e.g. 01_hook")
    parser.add_argument("--max-new-tokens", type=int, default=1200)
    parser.add_argument("--no-stitch", action="store_true", help="Skip full concatenated preview")
    args = parser.parse_args()
    runPreview(
        voice=args.voice,
        segment=args.segment,
        max_new_tokens=args.max_new_tokens,
        stitch=not args.no_stitch,
    )


if __name__ == "__main__":
    main()
