"""
Physics Fundamentals — 5-scene Manim explainer.

Standard Manim only.
Run one scene:
  manim -ql Workflows/channels/mathmwk/physicsExplainer.py Scene01Title
"""

from manim import *


class Scene01Title(Scene):
  def construct(self):
    self.camera.background_color = "#0a0a0a"
    title = Text("What Is Physics?", font_size=62, weight=BOLD)
    sub = Text("The rules behind motion, forces, and energy", font_size=30, color=GREY_B)
    sub.next_to(title, DOWN, buff=0.45)
    self.play(FadeIn(title, shift=UP * 0.2), run_time=1.0)
    self.play(FadeIn(sub, shift=UP * 0.1), run_time=0.8)
    self.wait(2)
    self.play(FadeOut(title), FadeOut(sub), run_time=0.7)


class Scene02Motion(Scene):
  def construct(self):
    self.camera.background_color = "#0a0a0a"
    ground = Line(LEFT * 6, RIGHT * 6, color=GREY_B).shift(DOWN * 2.3)
    dot = Dot(LEFT * 4 + DOWN * 1.9, radius=0.14, color=BLUE_B)
    path = DashedLine(dot.get_center(), RIGHT * 4 + DOWN * 1.9, color=BLUE_E)
    text = Text("Motion = change in position over time", font_size=34).to_edge(UP, buff=0.6)
    self.play(Write(text), Create(ground), run_time=0.9)
    self.play(Create(path), run_time=0.6)
    self.play(dot.animate.move_to(RIGHT * 4 + DOWN * 1.9), run_time=1.8, rate_func=linear)
    self.wait(1.2)


class Scene03Velocity(Scene):
  def construct(self):
    self.camera.background_color = "#0a0a0a"
    car = RoundedRectangle(width=1.5, height=0.7, corner_radius=0.2, color=BLUE, fill_opacity=0.85).shift(LEFT * 3 + DOWN * 0.7)
    fast_arrow = Arrow(car.get_right(), car.get_right() + RIGHT * 3.2, color=YELLOW, buff=0.05, stroke_width=7)
    vel_label = Text("Velocity: speed + direction", font_size=32).to_edge(UP, buff=0.6)
    self.play(FadeIn(car), Write(vel_label), run_time=0.9)
    self.play(GrowArrow(fast_arrow), run_time=0.8)
    self.play(car.animate.shift(RIGHT * 4.0), run_time=1.4, rate_func=linear)
    self.wait(1.2)


class Scene04Acceleration(Scene):
  def construct(self):
    self.camera.background_color = "#0a0a0a"
    axes = Axes(
      x_range=[0, 6, 1],
      y_range=[0, 8, 1],
      x_length=7,
      y_length=4.5,
      axis_config={"color": GREY_B},
      tips=False,
    ).shift(DOWN * 0.3)
    graph = axes.plot(lambda t: 0.9 * t + 0.4, x_range=[0, 6], color=ORANGE)
    dot = Dot(axes.c2p(0, 0.4), color=ORANGE, radius=0.1)
    title = Text("Acceleration = change in velocity", font_size=34).to_edge(UP, buff=0.55)
    self.play(Write(title), Create(axes), run_time=1.0)
    self.play(Create(graph), run_time=0.8)
    self.play(MoveAlongPath(dot, graph), run_time=1.8, rate_func=smooth)
    self.wait(1.1)


class Scene05Force(Scene):
  def construct(self):
    self.camera.background_color = "#0a0a0a"
    block = Square(side_length=1.0, color=WHITE, fill_opacity=0.2).shift(DOWN * 1.1)
    f_push = Arrow(block.get_left() + LEFT * 1.2, block.get_left(), color=GREEN, buff=0.05, stroke_width=7)
    f_fric = Arrow(block.get_right() + RIGHT * 0.9, block.get_right(), color=RED, buff=0.05, stroke_width=7)
    caption = Text("Forces push or pull objects", font_size=34).to_edge(UP, buff=0.6)
    net = Text("Net force -> motion changes", font_size=28, color=YELLOW).next_to(block, DOWN, buff=0.8)
    self.play(Write(caption), FadeIn(block), run_time=0.9)
    self.play(GrowArrow(f_push), GrowArrow(f_fric), run_time=0.9)
    self.play(Write(net), run_time=0.7)
    self.wait(1.2)
