"""
BounceMWK — spoken character segment (~10s welcome clip).

Uses renderSpokenCharacterTimeline with photo background + seriousB / amazedB poses.
Duration follows TTS length (not a fixed 10s timer).

python Workflows/channels/bouncemwk/characterSpokenDemo.py
python Workflows/channels/bouncemwk/characterSpokenDemo.py --model orpheus:tara
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Characters import renderSpokenCharacterTimeline
from Characters.templates.photo_bg_demo import TEMPLATE as PHOTO_BG_TEMPLATE

CHANNEL = "bouncemwk"
CACHE = ROOT / "Cache" / "characters"

SCRIPT = [
    {
        "text": "Hey guys, welcome back to the channel.",
        "pose": "seriousB",
        "x": 0.5,
        "y": 0.72,
        "scale": 0.38,
        "fade_in": 0.35,
        "fade_out": 0.25,
        "anchor": "bottom_center",
    },
    {
        "text": "Without further ado, enjoy the video.",
        "pose": "amazedB",
        "x": 0.5,
        "y": 0.68,
        "scale": 0.4,
        "fade_in": 0.25,
        "fade_out": 0.35,
        "anchor": "bottom_center",
    },
]


def runCharacterSpokenDemo(*, model: str = "gtts", line_gap: float = 0.15) -> Path:
    layout = dict(PHOTO_BG_TEMPLATE)
    layout.pop("cues", None)
    layout.pop("duration", None)
    layout.pop("name", None)

    bg_image = layout.pop("bg_image", None)
    width = layout.pop("width", 1920)
    height = layout.pop("height", 1080)
    fps = layout.pop("fps", 60)

    ts = int(time.time())
    output = CACHE / f"{CHANNEL}_character_spoken_{ts}.mp4"

    print(
        f"{CHANNEL} spoken character demo — {width}x{height} @ {fps}fps, model={model!r}",
        flush=True,
    )

    return renderSpokenCharacterTimeline(
        SCRIPT,
        model=model,
        output=output,
        width=width,
        height=height,
        fps=fps,
        bg_image=bg_image,
        line_gap=line_gap,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Render bouncemwk spoken character welcome clip.")
    parser.add_argument("--model", default="gtts", help='TTS model, e.g. gtts or "orpheus:tara"')
    parser.add_argument(
        "--line-gap",
        type=float,
        default=0.15,
        help="Seconds of pause between script lines (default 0.15)",
    )
    args = parser.parse_args()
    path = runCharacterSpokenDemo(model=args.model, line_gap=args.line_gap)
    print(f"Done → {path}", flush=True)


if __name__ == "__main__":
    main()
