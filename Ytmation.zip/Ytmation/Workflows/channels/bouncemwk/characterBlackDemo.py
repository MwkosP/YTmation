"""
Character timeline on generated black screen.

python Workflows/channels/bouncemwk/characterBlackDemo.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Characters.characters import renderCharacterTimeline
from Characters.templates.black_demo import TEMPLATE

CHANNEL = "bouncemwk"
CACHE = ROOT / "Cache" / "characters"


def runCharacterBlackDemo(preset: str = "black_demo") -> Path:
    t = dict(TEMPLATE)
    cues = t.pop("cues", [])
    duration = t.pop("duration", 10.0)
    t.pop("name", None)
    output = CACHE / f"{CHANNEL}_character_black_demo.mp4"

    print(f"{CHANNEL} character black demo — {len(cues)} cues, {duration}s", flush=True)
    return renderCharacterTimeline(cues=cues, duration=duration, output=output, **t)


if __name__ == "__main__":
    runCharacterBlackDemo()
