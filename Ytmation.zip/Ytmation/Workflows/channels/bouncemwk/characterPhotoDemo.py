"""
Character timeline on a photo background.

python Workflows/channels/bouncemwk/characterPhotoDemo.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Characters.characters import renderCharacterTimeline
from Characters.templates.photo_bg_demo import TEMPLATE

CHANNEL = "bouncemwk"
CACHE = ROOT / "Cache" / "characters"


def runCharacterPhotoDemo() -> Path:
    t = dict(TEMPLATE)
    cues = t.pop("cues", [])
    duration = t.pop("duration", 10.0)
    t.pop("name", None)
    output = CACHE / f"{CHANNEL}_character_photo_demo.mp4"

    print(f"{CHANNEL} character photo demo — {len(cues)} cues, {duration}s", flush=True)
    return renderCharacterTimeline(cues=cues, duration=duration, output=output, **t)


if __name__ == "__main__":
    runCharacterPhotoDemo()
