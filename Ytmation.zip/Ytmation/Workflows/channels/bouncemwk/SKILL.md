---
name: bouncemwk-workflow
description: Use when creating or editing bouncemwk channel workflows — character intro segments, pygame game animations, title transitions, and stitched showcases. Trigger on bouncemwk, workflow showcase, character photo intro, escapeBall, predatorPrey.
---

# bouncemwk Workflow — Agent Guide

## Channel Info

| Key | Value |
|---|---|
| Channel | `bouncemwk` |
| Niche | Bouncing-ball physics animations + mascot host |
| Format | Long 1920×1080 (default), Shorts 1080×1920 optional |
| Style | Neon / satisfying physics, character-led intros |
| bg_color | `#0d0d0d` (game presets vary) |
| Character poses | `Templates/characters/*B.png` (manual cutouts) |

---

## Workflow File Location

```
Workflows/channels/bouncemwk/<name>.py
```

Current files:

| File | Purpose |
|------|---------|
| `workflowShowcase.py` | Full reel: character → transitions → 2 games |
| `characterPhotoDemo.py` | Character timeline on photo background only |
| `characterSpokenDemo.py` | Spoken welcome clip (`renderSpokenCharacterTimeline`) |

Run:

```bash
python Workflows/channels/bouncemwk/workflowShowcase.py
python Workflows/channels/bouncemwk/characterPhotoDemo.py
```

---

## Showcase pipeline order

```
[1] Character segment (photo bg, silent today)
[2] transition19 — "First Animation"
[3] Game animation 1 (e.g. escapeBall)
[4] transition20 — "Second Animation"
[5] Game animation 2 (e.g. predatorPrey)
     ↓
combineMedia(..., transition="cleanCut")
```

Output: `Cache/stitched/bouncemwk_workflow_showcase_<timestamp>.mp4`

---

## Character intro (segment 1)

**Today:** silent `renderCharacterTimeline` + `Characters/templates/photo_bg_demo.py`.

```python
from Characters.characters import renderCharacterTimeline
from Characters.templates.photo_bg_demo import TEMPLATE as PHOTO_BG_TEMPLATE

photo_t = dict(PHOTO_BG_TEMPLATE)
cues = photo_t.pop("cues")
duration = photo_t.pop("duration")
photo_t.pop("name", None)

character = renderCharacterTimeline(
    cues=cues,
    duration=duration,
    output=CHARACTERS_CACHE / f"showcase_character_{ts}.mp4",
    width=1920,
    height=1080,
    fps=60,
    **photo_t,
)
```

**Planned:** spoken intro template in `Characters/templates/bouncemwk_intro.py`.

---

## Game animations

```python
from Games.games import renderAnimation

renderAnimation(
    "escapeBall",
    duration=10.0,
    width=1920,
    height=1080,
    fps=60,
    output=...,
    collision_audio={
        "mode": "sfx",
        "wall": "marioCoin",
        "ball": "marioCoin",
        "volume": 0.9,
    },
)
```

Presets: `Games/templates/bb/`. See `Games/SKILL.md`.

---

## Stitching

```python
from Transitions.transitions import combineMedia

final = combineMedia(
    [character, t1, anim1, t2, anim2],
    output=STITCHED_CACHE / f"bouncemwk_workflow_showcase_{ts}.mp4",
    transition="cleanCut",
)
```

Title cards: `renderAnimation("transition19", ...)` / `transition20` with `title_text`.

---

## Available modules

| Module | Key functions | SKILL.md |
|---|---|---|
| Characters | `renderCharacterTimeline`, `listPoses` | `Characters/SKILL.md` |
| Voice | `generateSpeech(text, model=...)` | `Voice/SKILL.md` |
| Games | `renderAnimation`, `previewAnimation` | `Games/SKILL.md` |
| Transitions | `combineMedia`, transition animations | `Transitions/SKILL.md` |
| SFX | `getSFX` (collision_audio) | `SFX/SKILL.md` |
| Stitching | `overlayAudio` (spoken intro, planned) | — |

---

## Rules

- Character PNGs: prefer manual `*B.png` cutouts over rembg for this channel
- Photo background renders are slow (~full PNG sequence @ 60fps); black bg is faster
- Pass `collision_audio` dict into `renderAnimation`, not as top-level SFX args
- `CHANNEL = "bouncemwk"` — keep cache paths under `Cache/games/bouncemwk/`
- No lip sync — pose swaps + voice timing = “speaking” mascot
