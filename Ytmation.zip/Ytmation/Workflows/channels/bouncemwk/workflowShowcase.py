"""
BounceMWK workflow showcase — character intro + two game animations with title transitions.

Order:
  character (photo bg) → transition19 ("First Animation") → animation 1
  → transition20 ("Second Animation") → animation 2

python Workflows/channels/bouncemwk/workflowShowcase.py
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Characters.characters import renderCharacterTimeline
from Games.games import renderAnimation
from Transitions.transitions import combineMedia
from Characters.templates.photo_bg_demo import TEMPLATE as PHOTO_BG_TEMPLATE

CHANNEL = "bouncemwk"
CACHE = ROOT / "Cache"
CHARACTERS_CACHE = CACHE / "characters"
GAMES_CACHE = CACHE / "games" / CHANNEL
STITCHED_CACHE = CACHE / "stitched"

WIDTH = 1920
HEIGHT = 1080
FPS = 60

# Hit sounds: pass via renderAnimation(..., collision_audio={...})
# wall/ball are SFX names (SFX.getSFX), not separate renderAnimation args.
COLLISION_AUDIO = {
    "mode": "sfx",
    "wall": "marioCoin",
    "ball": "marioCoin",
    "volume": 0.9,
    "cooldown_ms": 45,
    "clip_s": 0.12,
}


def runWorkflowShowcase(
    *,
    anim_duration: float = 10.0,
    transition_duration: float = 4.5,
    format: str = "long",
) -> Path:
    if format == "short":
        width, height = 1080, 1920
    else:
        width, height = WIDTH, HEIGHT

    GAMES_CACHE.mkdir(parents=True, exist_ok=True)
    CHARACTERS_CACHE.mkdir(parents=True, exist_ok=True)
    STITCHED_CACHE.mkdir(parents=True, exist_ok=True)

    common = {"width": width, "height": height, "fps": FPS}
    ts = int(time.time())

    print(f"{CHANNEL} workflow showcase — {width}x{height} @ {FPS}fps", flush=True)

    photo_t = dict(PHOTO_BG_TEMPLATE)
    photo_cues = photo_t.pop("cues", [])
    photo_duration = photo_t.pop("duration", 10.0)
    photo_t.pop("name", None)
    photo_t.update({"width": width, "height": height, "fps": FPS})

    print("  [1/5] character — photo background", flush=True)
    character = renderCharacterTimeline(
        cues=photo_cues,
        duration=photo_duration,
        output=CHARACTERS_CACHE / f"showcase_character_{ts}.mp4",
        **photo_t,
    )

    print("  [2/5] transition19 — First Animation", flush=True)
    intro = renderAnimation(
        "transition19",
        output=GAMES_CACHE / f"showcase_intro_{ts}.mp4",
        text="First Animation",
        subtitle="",
        duration=transition_duration,
        **common,
    )

    print("  [3/5] escapeBall — fire", flush=True)
    anim_a = renderAnimation(
        "escapeBall",
        template="fire",
        output=GAMES_CACHE / f"showcase_anim_a_{ts}.mp4",
        shape="triangle",
        duration=anim_duration,
        collision_audio=COLLISION_AUDIO,
        **common,
    )

    print("  [4/5] transition20 — Second Animation", flush=True)
    mid = renderAnimation(
        "transition20",
        output=GAMES_CACHE / f"showcase_mid_{ts}.mp4",
        text="Second Animation",
        subtitle="",
        duration=transition_duration,
        **common,
    )

    print("  [5/5] predatorPrey — ocean", flush=True)
    anim_b = renderAnimation(
        "predatorPrey",
        template="ocean",
        output=GAMES_CACHE / f"showcase_anim_b_{ts}.mp4",
        shape="circle",
        duration=anim_duration,
        collision_audio=COLLISION_AUDIO,
        **common,
    )

    final_path = STITCHED_CACHE / f"{CHANNEL}_workflow_showcase_{ts}.mp4"
    print("  Stitching (clean cut)…", flush=True)
    combineMedia(
        media=[str(character), str(intro), str(anim_a), str(mid), str(anim_b)],
        output=final_path,
        transition="cleanCut",
        duration=0,
        width=width,
        height=height,
        fps=FPS,
    )
    print(f"Showcase video: {final_path}")
    return final_path


if __name__ == "__main__":
    runWorkflowShowcase()
