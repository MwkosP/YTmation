#!/usr/bin/env python3
"""Map niches to production pipelines for the YT agent."""

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PIPELINES_DIR = Path(__file__).resolve().parent / "pipelines"

STEP_RE = re.compile(r"^(.+?)\s*→\s*(.+)$")


def load_workflow(name: str) -> dict:
    path = PIPELINES_DIR / f"{name}.json"
    if not path.exists():
        available = ", ".join(list_workflows()) or "(none)"
        raise FileNotFoundError(f"Workflow '{name}' not found. Available: {available}")
    return json.loads(path.read_text(encoding="utf-8"))


def list_workflows() -> list[str]:
    return sorted(p.stem for p in PIPELINES_DIR.glob("*.json"))


def parse_step(step: str) -> dict:
    """Split 'Module/ → action' into module and action."""
    m = STEP_RE.match(step.strip())
    if m:
        module = m.group(1).strip().rstrip("/")
        action = m.group(2).strip()
    else:
        module, action = step.strip(), ""
    return {"module": module, "action": action, "raw": step}


def runWorkflow(name: str, *, verbose: bool = True) -> dict:
    """Load a workflow and walk its pipeline steps (for agent or CLI)."""
    workflow = load_workflow(name)
    if verbose:
        print(f"Niche: {workflow.get('niche')}")
        print(f"Format: {workflow.get('format')} | {workflow.get('ratio')} | {workflow.get('duration')}s\n")
    for i, step in enumerate(workflow.get("pipeline", []), 1):
        parsed = parse_step(step)
        if verbose:
            print(f"{i:02d}. [{parsed['module']}] {parsed['action']}")
    return workflow


def main() -> int:
    parser = argparse.ArgumentParser(description="YT production workflows by niche")
    parser.add_argument("workflow", nargs="?", help="Pipeline name (e.g. blender_physics)")
    parser.add_argument("--list", action="store_true", help="List available workflows")
    parser.add_argument("--json", action="store_true", help="Print full workflow JSON")
    args = parser.parse_args()

    if args.list:
        for name in list_workflows():
            w = load_workflow(name)
            print(f"{name:22} {w.get('niche', '')}")
        return 0

    if not args.workflow:
        parser.error("Provide a workflow name or use --list")

    if args.json:
        print(json.dumps(load_workflow(args.workflow), indent=2))
    else:
        runWorkflow(args.workflow)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
