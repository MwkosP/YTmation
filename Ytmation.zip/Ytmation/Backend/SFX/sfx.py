from datetime import datetime
from pathlib import Path
import json
import shutil
import urllib.request
 
ROOT        = Path(__file__).resolve().parent.parent
LIBRARY_DIR = Path(__file__).resolve().parent / "library"
SOUNDS_DIR  = Path(__file__).resolve().parent / "sounds"
OUTPUT_DIR  = ROOT / "Cache" / "sfx"
_AUDIO_EXTS = (".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac")


def getSFX(name: str) -> Path:
    """Get path to an SFX by name. e.g. getSFX('whoosh') or getSFX('marioCoin') from sounds/."""
    spec = Path(name)
    if spec.is_file():
        return spec.resolve()

    stem = spec.stem if spec.suffix else name
    rel_parent = spec.parent if spec.parent != Path(".") else None

    search_dirs: list[Path] = []
    if rel_parent:
        search_dirs.append(Path(__file__).resolve().parent / rel_parent)
    search_dirs.extend([LIBRARY_DIR, SOUNDS_DIR])

    manifest_path = LIBRARY_DIR / "manifest.json"
    if manifest_path.is_file():
        try:
            tags = json.loads(manifest_path.read_text(encoding="utf-8")).get("tags", {})
            entry = tags.get(stem)
            if entry and entry.get("file"):
                manifest_file = LIBRARY_DIR / entry["file"]
                if manifest_file.is_file():
                    return manifest_file.resolve()
        except (json.JSONDecodeError, OSError):
            pass

    for base in search_dirs:
        for ext in _AUDIO_EXTS:
            path = base / f"{stem}{ext}"
            if path.is_file():
                return path.resolve()
        for path in base.rglob(f"{stem}.*"):
            if path.is_file() and path.suffix.lower() in _AUDIO_EXTS:
                return path.resolve()
        if "/" in name or "\\" in name:
            nested = LIBRARY_DIR / name
            if nested.is_file():
                return nested.resolve()
            nested = Path(__file__).resolve().parent / name
            if nested.is_file():
                return nested.resolve()

    raise FileNotFoundError(
        f"SFX '{name}' not found under {LIBRARY_DIR} or {SOUNDS_DIR}. "
        f"Use listSFX() to see available sounds."
    )
 
 
def listSFX() -> list[str]:
    """List available SFX names (library root + sounds/)."""
    LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
    SOUNDS_DIR.mkdir(parents=True, exist_ok=True)
    names: set[str] = set()
    for base in (LIBRARY_DIR, SOUNDS_DIR):
        for f in base.rglob("*"):
            if f.is_file() and f.suffix.lower() in _AUDIO_EXTS:
                names.add(f.stem)
    return sorted(names)
 
 
def downloadSFX(url: str, name: str) -> Path:
    """Download an SFX from a URL and save it to the library."""
    LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
    suffix = Path(url).suffix or ".mp3"
    dest   = LIBRARY_DIR / f"{name}{suffix}"
    print(f"Downloading '{name}' → {dest}")
    urllib.request.urlretrieve(url, dest)
    return dest