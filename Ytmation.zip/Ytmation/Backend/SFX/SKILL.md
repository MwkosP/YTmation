# SFX Module

## Purpose
Sound effects library management. Handles lookup, listing, and downloading of SFX files.
All actual audio mixing is done in Stitching/stitching.py.

## Location
`SFX/sfx.py`

## Library
SFX files live in `SFX/library/`. Supported formats: .mp3 .wav .ogg .m4a

## Functions

### getSFX(name) -> Path
Returns path to an SFX by name. Raises FileNotFoundError if not found.
```python
from SFX.sfx import getSFX
whoosh = getSFX("quickWoosh")
```

### listSFX() -> list[str]
Lists all available SFX names in the library.
```python
from SFX.sfx import listSFX
print(listSFX())  # ['marioCoin', 'quickWoosh', 'screamAAh']
```

### downloadSFX(url, name) -> Path
Downloads an SFX from a URL and saves to library.
```python
from SFX.sfx import downloadSFX
downloadSFX("https://example.com/sound.mp3", "explosion")
```

## Typical Workflow
```python
from SFX.sfx import getSFX, listSFX
from Stitching.stitching import overlaySFX, overlayMultipleSFX

# single sfx
whoosh = getSFX("quickWoosh")
video  = overlaySFX(video, sfx=whoosh, start=0.0, volume=0.8)

# multiple sfx
video = overlayMultipleSFX(video, [
    {"path": getSFX("quickWoosh"), "start": 0.0,  "volume": 0.8},
    {"path": getSFX("marioCoin"),  "start": 7.0,  "volume": 1.0},
])
```