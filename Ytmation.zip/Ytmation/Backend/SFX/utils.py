import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LIBRARY_DIR = Path(__file__).resolve().parent / "library"
SOUNDS_DIR = Path(__file__).resolve().parent / "sounds"
MANIFEST_PATH = LIBRARY_DIR / "manifest.json"
OUTPUT_DIR = ROOT / "Cache" / "sfx"
AUDIO_EXTENSIONS = (".wav", ".mp3", ".m4a", ".aac", ".ogg", ".flac")

GENERATORS: list[tuple[str, str, list[str]]] = [
    ("whoosh", "motion", ["-f", "lavfi", "-i", "anoisesrc=d=0.35:c=pink", "-af", "afade=t=in:st=0:d=0.03,afade=t=out:st=0.15:d=0.2,highpass=f=400,volume=2"]),
    ("whoosh_fast", "motion", ["-f", "lavfi", "-i", "anoisesrc=d=0.25:c=white", "-af", "afade=t=in:st=0:d=0.02,afade=t=out:st=0.1:d=0.15,highpass=f=800,volume=2.5"]),
    ("whoosh_slow", "motion", ["-f", "lavfi", "-i", "anoisesrc=d=0.55:c=pink", "-af", "afade=t=in:st=0:d=0.08,afade=t=out:st=0.35:d=0.2,lowpass=f=2000,volume=1.8"]),
    ("swipe", "motion", ["-f", "lavfi", "-i", "anoisesrc=d=0.15:c=white", "-af", "highpass=f=2000,volume=3,afade=t=out:st=0.05:d=0.1"]),
    ("swoosh", "motion", ["-f", "lavfi", "-i", "sine=f=200:d=0.2", "-af", "asetrate=44100*1.5,aresample=44100,afade=t=out:st=0.1:d=0.1,volume=0.4"]),
    ("impact_hit", "impact", ["-f", "lavfi", "-i", "sine=f=55:d=0.25", "-af", "afade=t=out:st=0.05:d=0.2,volume=2"]),
    ("impact_heavy", "impact", ["-f", "lavfi", "-i", "sine=f=40:d=0.4", "-af", "afade=t=out:st=0.08:d=0.32,volume=2.5"]),
    ("impact_light", "impact", ["-f", "lavfi", "-i", "sine=f=120:d=0.12", "-af", "afade=t=out:st=0.03:d=0.09,volume=1.5"]),
    ("boom", "impact", ["-f", "lavfi", "-i", "sine=f=35:d=0.6", "-af", "afade=t=out:st=0.1:d=0.5,volume=2"]),
    ("thud", "impact", ["-f", "lavfi", "-i", "sine=f=70:d=0.18", "-af", "afade=t=out:st=0.04:d=0.14,volume=1.8"]),
    ("punch", "impact", ["-f", "lavfi", "-i", "sine=f=90:d=0.1", "-af", "afade=t=out:st=0.02:d=0.08,volume=2.2"]),
    ("glass_break", "impact", ["-f", "lavfi", "-i", "anoisesrc=d=0.5:c=white", "-af", "highpass=f=3000,volume=2,afade=t=out:st=0.2:d=0.3"]),
    ("crash", "impact", ["-f", "lavfi", "-i", "anoisesrc=d=0.45:c=white", "-af", "lowpass=f=4000,volume=2.5,afade=t=out:st=0.15:d=0.3"]),
    ("splash", "nature", ["-f", "lavfi", "-i", "anoisesrc=d=0.35:c=pink", "-af", "lowpass=f=1200,volume=1.5,afade=t=out:st=0.1:d=0.25"]),
    ("water_drop", "nature", ["-f", "lavfi", "-i", "sine=f=800:d=0.08", "-af", "afade=t=out:st=0.02:d=0.06,volume=0.8"]),
    ("rain_ambient", "ambient", ["-f", "lavfi", "-i", "anoisesrc=d=8:c=pink", "-af", "lowpass=f=1800,volume=0.35"]),
    ("fire_crackle", "ambient", ["-f", "lavfi", "-i", "anoisesrc=d=3:c=brown", "-af", "highpass=f=500,volume=0.5"]),
    ("wind_soft", "ambient", ["-f", "lavfi", "-i", "anoisesrc=d=5:c=pink", "-af", "lowpass=f=800,volume=0.4"]),
    ("room_tone", "ambient", ["-f", "lavfi", "-i", "anoisesrc=d=4:c=pink", "-af", "lowpass=f=500,volume=0.2"]),
    ("sting", "drama", ["-f", "lavfi", "-i", "sine=f=440:d=0.35", "-af", "afade=t=in:st=0:d=0.02,afade=t=out:st=0.15:d=0.2,volume=0.7"]),
    ("sting_dark", "drama", ["-f", "lavfi", "-i", "sine=f=110:d=0.5", "-af", "afade=t=in:st=0:d=0.05,afade=t=out:st=0.2:d=0.3,volume=0.9"]),
    ("riser", "drama", ["-f", "lavfi", "-i", "sine=f=200:d=1.2", "-af", "asetrate=44100*0.6,aresample=44100,afade=t=in:st=0:d=0.1,afade=t=out:st=1:d=0.2,volume=0.5"]),
    ("tension", "drama", ["-f", "lavfi", "-i", "sine=f=60:d=1.5", "-af", "tremolo=f=8:d=0.4,volume=0.4"]),
    ("beat_sync", "ui", ["-f", "lavfi", "-i", "sine=f=1000:d=0.04", "-af", "volume=1.2"]),
    ("click", "ui", ["-f", "lavfi", "-i", "sine=f=1500:d=0.02", "-af", "volume=0.9"]),
    ("pop", "ui", ["-f", "lavfi", "-i", "sine=f=600:d=0.05", "-af", "afade=t=out:st=0.02:d=0.03,volume=1"]),
    ("ding", "ui", ["-f", "lavfi", "-i", "sine=f=880:d=0.25", "-af", "afade=t=out:st=0.1:d=0.15,volume=0.6"]),
    ("notification", "ui", ["-f", "lavfi", "-i", "sine=f=523:d=0.15", "-af", "afade=t=out:st=0.05:d=0.1,volume=0.7"]),
    ("typing", "ui", ["-f", "lavfi", "-i", "sine=f=2000:d=0.03", "-af", "volume=0.5"]),
    ("typing_double", "ui", ["-f", "lavfi", "-i", "sine=f=1800:d=0.02", "-af", "volume=0.5,apad=pad_dur=0.04", "-f", "lavfi", "-i", "sine=f=1800:d=0.02", "-filter_complex", "[0][1]concat=n=2:v=0:a=1"]),
    ("clock_tick", "ui", ["-f", "lavfi", "-i", "sine=f=1200:d=0.03", "-af", "volume=0.8,highpass=f=800"]),
    ("door", "foley", ["-f", "lavfi", "-i", "sine=f=80:d=0.2", "-af", "lowpass=f=400,volume=1.5,afade=t=out:st=0.05:d=0.15"]),
    ("door_creak", "foley", ["-f", "lavfi", "-i", "anoisesrc=d=0.8:c=brown", "-af", "lowpass=f=600,volume=0.8"]),
    ("footstep", "foley", ["-f", "lavfi", "-i", "sine=f=100:d=0.08", "-af", "lowpass=f=300,volume=1.2,afade=t=out:st=0.03:d=0.05"]),
    ("zap", "foley", ["-f", "lavfi", "-i", "anoisesrc=d=0.12:c=white", "-af", "highpass=f=4000,volume=2"]),
    ("electric", "foley", ["-f", "lavfi", "-i", "sine=f=2000:d=0.1", "-af", "tremolo=f=50:d=0.8,volume=0.4"]),
    ("fade_out", "transition", ["-f", "lavfi", "-i", "sine=f=300:d=1.5", "-af", "afade=t=out:st=0:d=1.5,volume=0.3"]),
    ("fade_in", "transition", ["-f", "lavfi", "-i", "sine=f=300:d=1.0", "-af", "afade=t=in:st=0:d=1.0,volume=0.3"]),
    ("record_scratch", "transition", ["-f", "lavfi", "-i", "anoisesrc=d=0.2:c=white", "-af", "highpass=f=1000,volume=1.5"]),
    ("none", "ui", ["-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono:d=0.01", "-af", "volume=0"]),
]

SUGGEST_RULES: list[tuple[str, str]] = [
    (r"hook|cold", "impact_hit"),
    (r"montage|rapid", "beat_sync"),
    (r"shatter|glass", "glass_break"),
    (r"fluid|water|splash", "splash"),
    (r"domino|ball|physics|impact", "impact_heavy"),
    (r"reveal|twist|climax", "sting"),
    (r"outro|cta|end", "fade_out"),
    (r"ambient|sleep|rain", "rain_ambient"),
    (r"fire|cozy", "fire_crackle"),
    (r"crime|mystery|door", "door"),
    (r"typing|document", "typing"),
    (r"clock|time", "clock_tick"),
]


def run_ffmpeg(args: list[str]) -> None:
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *args]
    subprocess.run(cmd, check=True)


def write_manifest() -> None:
    tags = {}
    for name, folder, _ in GENERATORS:
        if name == "typing_double":
            continue
        path = LIBRARY_DIR / folder / f"{name}.wav"
        if path.exists():
            vol = 0.5
            if folder == "impact":
                vol = 0.85
            elif folder == "motion":
                vol = 0.65
            elif folder == "ambient":
                vol = 0.4
            elif folder == "ui":
                vol = 0.55
            tags[name] = {"file": f"{folder}/{name}.wav", "volume": vol}
    MANIFEST_PATH.write_text(json.dumps({"tags": tags}, indent=2) + "\n", encoding="utf-8")


def build_library(force: bool = False) -> int:
    LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
    made = 0
    for name, folder, ff_args in GENERATORS:
        if name == "typing_double":
            continue
        out_dir = LIBRARY_DIR / folder
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"{name}.wav"
        if path.exists() and not force:
            continue
        try:
            run_ffmpeg([*ff_args, "-ar", "44100", "-ac", "1", str(path)])
            made += 1
        except subprocess.CalledProcessError as e:
            print(f"Warning: failed {name}: {e}", file=sys.stderr)
    write_manifest()
    return made


def load_manifest() -> dict:
    if not MANIFEST_PATH.exists():
        build_library()
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def resolve_sound_file(sound_file_name: str | Path) -> Path:
    requested = Path(sound_file_name)
    candidates = []

    if requested.is_absolute() or requested.parent != Path("."):
        candidates.append(requested)
    else:
        candidates.append(SOUNDS_DIR / requested)
        if requested.suffix == "":
            candidates.extend(SOUNDS_DIR / f"{requested.name}{ext}" for ext in AUDIO_EXTENSIONS)

    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate.resolve()

    wanted = requested.name.lower()
    wanted_stem = requested.stem.lower()
    for path in SOUNDS_DIR.glob("*"):
        if not path.is_file() or path.suffix.lower() not in AUDIO_EXTENSIONS:
            continue
        if path.name.lower() == wanted or path.stem.lower() == wanted_stem:
            return path.resolve()

    available = ", ".join(sorted(path.name for path in SOUNDS_DIR.glob("*") if path.is_file()))
    raise FileNotFoundError(
        f"Sound file '{sound_file_name}' not found in {SOUNDS_DIR}. "
        f"Available: {available or '(none)'}"
    )


def suggest_sfx(scene: dict) -> str | None:
    text = " ".join(
        str(scene.get(key, "")) for key in ("type", "visual", "sfx", "narration")
    ).lower()
    existing = (scene.get("sfx") or "").strip().lower()
    if existing and existing != "none":
        return existing.replace(" ", "_")
    for pattern, tag in SUGGEST_RULES:
        if re.search(pattern, text):
            return tag
    return None


def load_storyboard(source: str | Path) -> dict:
    path = Path(source)
    if path.is_file():
        return json.loads(path.read_text(encoding="utf-8"))
    for base in [ROOT / "Storyboard" / "boards", OUTPUT_DIR.parent / "storyboards", OUTPUT_DIR]:
        candidate = base / f"{source}.json"
        if candidate.exists():
            return json.loads(candidate.read_text(encoding="utf-8"))
    raise FileNotFoundError(f"Storyboard not found: {source}")


def save_cue_sheet(sheet: dict, slug: str | None = None) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    name = slug or sheet.get("board_id", "cues")
    slug_clean = re.sub(r"[^\w]+", "_", str(name))[:40].strip("_")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = OUTPUT_DIR / f"cues_{slug_clean}_{stamp}.json"
    sheet["saved_at"] = datetime.now(timezone.utc).isoformat()
    path.write_text(json.dumps(sheet, indent=2) + "\n", encoding="utf-8")
    return path
