from Script.script import generateScript
from Trends.trends import getTrends, pickTopic
from Hooks.hooks import generateHooks, pickHook, loadHooks
from Storyboard.storyboard import generateStoryboard
from SFX.sfx import useSfx, generateSfx, listSfx, resolveSfx, placeSfx
from Transitions.transitions import combineMedia, listTransitions
from Branding.branding import applyBranding
from Revenue.revenue import calculateUserRevenue



## --------------------------------
## Trends,Script,hooks,Storyboard
## --------------------------------
#trends = getTrends(niche="Bittensor",sources="google", limit=5)
#generateScript(trends[0]["title"],template="shorts_hook")
#hooks = generateHooks("AI Agents", limit=5)
#generateStoryboard("solo leveling ep 12", board="manhwa_recap_15min")




## --------------------------------
## SFX
## --------------------------------

#listSfx()
#generateSfx("physics_short_60s")   # saves Cache/sfx/cues_*.json
# mix onto a render when you have one:
# placeSfx("render.mp4", sheet, "Cache/sfx/preview.mp4")

#useSfx("marioCoin")
#useSfx("quickWoosh", volume=0.5)


'''


listTransitions()

combineMedia(
    [
        "Cache/transitions/test_assets/clip_a.mp4",
        "Cache/transitions/test_assets/card.png",
        "Cache/transitions/test_assets/clip_b.mp4",
    ],
    "Cache/transitions/quick.mp4",
    transition="squeezeV",
    duration=0.1,
    imageDuration=0.3,
)

'''




## --------------------------------
## Branding
## --------------------------------

'''


applyBranding(
    video="Cache/renders/balls.mp4",
    output="Cache/branded/balls_final.mp4",
    preset="neon_physics",
    title="Satisfying Physics"
)


from Branding.branding import load_preset

cfg = load_preset("neon_physics")

# knows everything from one file
niche    = cfg["channel"]["niche"]
ratio    = cfg["video"]["ratio"]
duration = cfg["video"]["duration_max"]
workflow = cfg["video"]["workflow"]
title    = cfg["upload"]["title_template"].replace("{topic}", "Bouncing Balls")
tags     = cfg["upload"]["tags"]
'''


## --------------------------------
## Revenue
## --------------------------------

#calculateUserRevenue(100_000, country="us", niche="satisfying", video_duration=30, avg_watch=10)
#calculateUserRevenue(9_000_000, is_short=True, num_videos=5)
#calculateUserRevenue(1_000_000, country="global", niche="finance", video_duration=30, num_videos=1,avg_watch=10)



#++++
from gtts import gTTS
import os
from Hooks.hooks import generateHooks

os.makedirs("Voice", exist_ok=True)

hooks = generateHooks("making fun of Onlyfans models.", limit=5)

hook_text = hooks[0]["spoken"]

tts = gTTS(hook_text, lang='en')
tts.save("Voice/narration.mp3")
print(f"Saved! Text: {hook_text}")
#++++