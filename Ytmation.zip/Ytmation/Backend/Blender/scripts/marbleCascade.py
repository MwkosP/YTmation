import math
import random
import subprocess
import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from utils import *

OUTPUTS_DIR = ROOT / "outputs"
FRAMES_DIR = OUTPUTS_DIR / "frames"
OUTPUT_VIDEO = OUTPUTS_DIR / "output_marble_cascade.mp4"

cleanScene()
random.seed(7)

frames = 220
fps = 60

# Materials
floor_mat = makeMaterial("CharcoalFloor", color=(0.015, 0.014, 0.018, 1), metallic=0.0, roughness=0.35)
ramp_mat = makeGlossyMaterial("MirrorRamps", color=(0.70, 0.78, 0.86, 1))
rail_mat = makeMaterial("DarkRails", color=(0.03, 0.035, 0.045, 1), metallic=0.6, roughness=0.18)
pin_mat = makeEmissiveMaterial("HotPins", color=(1.0, 0.36, 0.08, 1), strength=1.8)
marble_mats = [
    makeEmissiveMaterial("CyanMarble", color=(0.0, 0.95, 1.0, 1), strength=1.7),
    makeEmissiveMaterial("PinkMarble", color=(1.0, 0.05, 0.45, 1), strength=1.7),
    makeEmissiveMaterial("GoldMarble", color=(1.0, 0.72, 0.08, 1), strength=1.4),
    makeEmissiveMaterial("GreenMarble", color=(0.20, 1.0, 0.30, 1), strength=1.4),
]

# Floor and back wall
floor = addPlane(location=(0, 0, 0), size=18)
applyMaterial(floor, floor_mat)
addRigidBody(floor, body_type="PASSIVE", friction=0.85, restitution=0.18)

back_wall = addCube(location=(0, 3.3, 3.4), size=1)
back_wall.name = "BackWall"
back_wall.scale = (8.5, 0.12, 3.4)
applyMaterial(back_wall, makeMaterial("BackWallMat", color=(0.025, 0.025, 0.035, 1), metallic=0.0, roughness=0.6))
addRigidBody(back_wall, body_type="PASSIVE", friction=0.8, restitution=0.15)

# Zig-zag ramps
ramp_specs = [
    ((-2.4, 0, 5.4), -14),
    ((2.1, 0, 4.5), 14),
    ((-2.1, 0, 3.6), -14),
    ((2.1, 0, 2.7), 14),
    ((-2.1, 0, 1.8), -14),
]

for i, (location, slope_deg) in enumerate(ramp_specs):
    ramp = addCube(location=location, size=1)
    ramp.name = f"Ramp_{i}"
    ramp.scale = (3.1, 0.18, 0.07)
    ramp.rotation_euler = (0, math.radians(slope_deg), 0)
    applyMaterial(ramp, ramp_mat)
    addRigidBody(ramp, body_type="PASSIVE", friction=0.55, restitution=0.25)

    # low side rails keep marbles visible and on track
    for side_y in (-0.34, 0.34):
        rail = addCube(location=(location[0], side_y, location[2] + 0.18), size=1)
        rail.name = f"Rail_{i}_{side_y}"
        rail.scale = (3.15, 0.04, 0.12)
        rail.rotation_euler = ramp.rotation_euler
        applyMaterial(rail, rail_mat)
        addRigidBody(rail, body_type="PASSIVE", friction=0.7, restitution=0.15)

# Peg field for secondary impacts near the bottom.
for row in range(4):
    for col in range(7):
        x = -2.4 + col * 0.8 + (0.4 if row % 2 else 0)
        z = 0.55 + row * 0.33
        bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=0.055, depth=0.65, location=(x, 0, z), rotation=(math.radians(90), 0, 0))
        pin = bpy.context.active_object
        pin.name = f"Peg_{row}_{col}"
        applyMaterial(pin, pin_mat)
        addRigidBody(pin, body_type="PASSIVE", friction=0.45, restitution=0.8)

# Catch tray
tray_base = addCube(location=(0, -0.02, 0.24), size=1)
tray_base.name = "CatchTray"
tray_base.scale = (3.5, 0.45, 0.08)
applyMaterial(tray_base, rail_mat)
addRigidBody(tray_base, body_type="PASSIVE", friction=0.75, restitution=0.25)

for x in (-3.55, 3.55):
    wall = addCube(location=(x, -0.02, 0.55), size=1)
    wall.name = f"TrayWall_{x}"
    wall.scale = (0.08, 0.50, 0.38)
    applyMaterial(wall, rail_mat)
    addRigidBody(wall, body_type="PASSIVE", friction=0.75, restitution=0.2)

# Marbles start above the first ramp with slight offsets.
for i in range(8):
    x = -4.25 + (i % 4) * 0.24
    y = -0.18 + (i // 4) * 0.36
    z = 6.45 + i * 0.10
    marble = addSphere(location=(x, y, z), radius=0.16)
    marble.name = f"Marble_{i}"
    applyMaterial(marble, marble_mats[i % len(marble_mats)])
    addRigidBody(marble, body_type="ACTIVE", mass=0.35, restitution=0.62, friction=0.32)
    marble.rigid_body.linear_damping = 0.02
    marble.rigid_body.angular_damping = 0.03

bakePhysics(frame_start=1, frame_end=frames)

# Camera and lighting
addCamera(location=(0, -8.2, 3.55), rotation=(math.radians(66), 0, 0), fov=36)
addAreaLight(location=(-4.5, -3.5, 6.5), energy=850, color=(0.0, 0.65, 1.0), size=3.5)
addAreaLight(location=(4.5, -3.5, 5.5), energy=850, color=(1.0, 0.1, 0.45), size=3.5)
addAreaLight(location=(0, 2.5, 6.5), energy=350, color=(1.0, 0.88, 0.60), size=5)
addAreaLight(location=(0, -4.5, 1.0), energy=180, color=(0.35, 1.0, 0.75), size=4)

setBackground(color=(0.0, 0.0, 0.0, 1))
setBackgroundStrength(0.8)

setupRender(frames=frames, fps=fps, resolution=(1920, 1080), engine="BLENDER_EEVEE")
renderFrames(str(FRAMES_DIR))

subprocess.run([
    "ffmpeg", "-y",
    "-framerate", str(fps),
    "-i", str(FRAMES_DIR / "frame_%04d.png"),
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    "-vf", "setpts=1.8*PTS",
    str(OUTPUT_VIDEO),
], check=True)

print(f"Done! Marble cascade video saved to {OUTPUT_VIDEO}")
