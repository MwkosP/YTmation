import bpy
import math
import subprocess
import os

# clean scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()

# import mesh
bpy.ops.wm.obj_import(filepath='/home/zolo/Desktop/YT/3d/TripoSR/output/0/mesh.obj')
obj = bpy.context.active_object

# center object
bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
obj.location = (0, 0, 0)

# add rotation keyframes
frames = 120
for i in range(frames + 1):
    angle = (i / frames) * 2 * math.pi
    obj.rotation_euler = (0, 0, angle)
    obj.keyframe_insert(data_path='rotation_euler', frame=i)

# add camera
bpy.ops.object.camera_add(location=(3, -3, 2))
cam = bpy.context.active_object
cam.rotation_euler = (1.1, 0, 0.785)
bpy.context.scene.camera = cam

# add light
bpy.ops.object.light_add(type='SUN', location=(5, 5, 10))
bpy.context.active_object.data.energy = 3

# black background
bpy.context.scene.world.node_tree.nodes['Background'].inputs[0].default_value = (0, 0, 0, 1)

# render settings - PNG frames
frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
os.makedirs(frames_dir, exist_ok=True)

scene = bpy.context.scene
scene.frame_start = 0
scene.frame_end = frames
scene.render.fps = 24
scene.render.resolution_x = 1920
scene.render.resolution_y = 1080
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = frames_dir + 'frame_'

# render frames
bpy.ops.render.render(animation=True)

# combine frames into mp4 with ffmpeg
subprocess.run([
    'ffmpeg', '-framerate', '24',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '/home/zolo/Desktop/YT/3d/output_video.mp4'
])