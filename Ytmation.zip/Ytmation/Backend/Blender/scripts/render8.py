import bpy
import sys
import math
import subprocess
import os

sys.path.insert(0, '/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()

frames = 300

# ─── CONE ────────────────────────────────────────────────
bpy.ops.mesh.primitive_cone_add(
    vertices=64,
    radius1=2.5,
    radius2=0,
    depth=3,
    location=(0, 0, 0)
)
cone = bpy.context.active_object
cone.name = 'Cone'

# smooth cone
bpy.ops.object.shade_smooth()

# cone material - soft white matte
mat_cone = makeMaterial('ConeMat', color=(0.08, 0.08, 0.1, 1), metallic=0.5, roughness=0.3)
applyMaterial(cone, mat_cone)

# collision for cloth
bpy.context.view_layer.objects.active = cone
bpy.ops.object.modifier_add(type='COLLISION')
cone.collision.thickness_outer = 0.002

# ─── FLOOR ───────────────────────────────────────────────
platform = addPlane(location=(0, 0, -1.55), size=20)
bpy.ops.object.modifier_add(type='COLLISION')
platform.collision.thickness_outer = 0.002
mat_floor = makeMaterial('FloorMat', color=(0.05, 0.05, 0.07, 1), metallic=0.3, roughness=0.3)
applyMaterial(platform, mat_floor)

# ─── CLOTH ───────────────────────────────────────────────
bpy.ops.mesh.primitive_plane_add(size=7, location=(0, 0, 4.5))
cloth = bpy.context.active_object
cloth.name = 'Cloth'

# subdivide for detailed simulation
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.subdivide(number_cuts=40)
bpy.ops.object.mode_set(mode='OBJECT')
bpy.ops.object.shade_smooth()

# cloth material - white silk
mat_cloth = bpy.data.materials.new('SilkMat')
mat_cloth.use_nodes = True
bsdf = mat_cloth.node_tree.nodes['Principled BSDF']
bsdf.inputs['Base Color'].default_value = (1.0, 0.97, 0.88, 1.0)
bsdf.inputs['Metallic'].default_value       = 0.0
bsdf.inputs['Roughness'].default_value      = 0.1
bsdf.inputs['Sheen Weight'].default_value   = 1.0
bsdf.inputs['Sheen Roughness'].default_value = 0.3
applyMaterial(cloth, mat_cloth)

# cloth physics
bpy.context.view_layer.objects.active = cloth
bpy.ops.object.modifier_add(type='CLOTH')
cloth_mod = cloth.modifiers['Cloth']

# silk preset settings
cloth_mod.settings.quality                   = 10
cloth_mod.settings.mass                      = 0.15        # light like silk
cloth_mod.settings.tension_stiffness         = 5
cloth_mod.settings.compression_stiffness     = 5
cloth_mod.settings.shear_stiffness           = 2
cloth_mod.settings.bending_stiffness         = 0.05        # very floppy
cloth_mod.settings.tension_damping           = 0
cloth_mod.settings.compression_damping       = 0
cloth_mod.settings.shear_damping             = 0
cloth_mod.settings.bending_damping           = 0.5
cloth_mod.settings.air_damping               = 1.0
cloth_mod.collision_settings.use_collision   = True
cloth_mod.collision_settings.use_self_collision = True
cloth_mod.collision_settings.distance_min    = 0.003

# bake cloth simulation
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end   = frames
bpy.ops.ptcache.bake_all(bake=True)

# ─── CAMERA ──────────────────────────────────────────────
bpy.ops.object.camera_add(location=(6, -6, 4))
cam = bpy.context.active_object
cam.rotation_euler = (math.radians(65), 0, math.radians(45))
cam.data.lens = 50
bpy.context.scene.camera = cam

# ─── LIGHTING - soft studio white ────────────────────────
# key light top
addAreaLight(location=(0, 0, 10),   energy=600,  color=(1.0, 1.0, 1.0), size=6)
# soft fill from sides
addAreaLight(location=(-6, -4, 5),  energy=300,  color=(0.95, 0.97, 1.0), size=4)
addAreaLight(location=(6,   4, 5),  energy=300,  color=(1.0, 0.97, 0.95), size=4)
# subtle back rim
addAreaLight(location=(0,   6, 3),  energy=150,  color=(1.0, 1.0, 1.0),  size=3)

# ─── BACKGROUND - pure white ─────────────────────────────
setBackground(color=(0.03, 0.03, 0.05, 1.0))
setBackgroundStrength(1.0)

# ─── RENDER ──────────────────────────────────────────────
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
renderFrames(frames_dir)

# slow motion 3x
subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=3.0*PTS',
    '/home/zolo/Desktop/YT/3d/outputs/output_cloth.mp4'
])

print("Done! Cloth video saved to output_cloth.mp4")