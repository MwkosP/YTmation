"""
Cloth Simulation
-----------------
A cloth falls and drapes over a sphere.

Params (via YT_PARAMS env):
    cloth_color   : list  = [0.8, 0.2, 0.2, 1.0]
    sphere_color  : list  = [0.1, 0.1, 0.1, 1.0]
    cloth_size    : float = 4.0
    subdivisions  : int   = 12
    gravity       : float = -9.8
"""

import sys
import json
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from blenderAbstractions import (
    cleanScene, setupRenderFromEnv, setBackground,
    addCamera, addThreePointLighting,
    addPlane, addSphere,
    makeMaterial, applyMaterial,
    addClothModifier, addCollision, addSubdivision,
    renderFrames,
)


def main():
    cfg    = setupRenderFromEnv()
    params = cfg["params"]

    cloth_color  = params.get("cloth_color",  [0.8, 0.2, 0.2, 1.0])
    sphere_color = params.get("sphere_color", [0.1, 0.1, 0.1, 1.0])
    cloth_size   = params.get("cloth_size",   4.0)
    subdivisions = params.get("subdivisions", 12)
    gravity      = params.get("gravity",      -9.8)

    cleanScene()
    setBackground((0.02, 0.02, 0.02, 1))

    import bpy
    bpy.context.scene.gravity = (0, 0, gravity)

    # sphere (collision object)
    sphere = addSphere(location=(0, 0, 0), radius=1.2)
    sphere_mat = makeMaterial("SphereMat", color=sphere_color, metallic=0.8, roughness=0.1)
    applyMaterial(sphere, sphere_mat)
    addCollision(sphere)

    # cloth plane
    cloth = addPlane(location=(0, 0, 3), size=cloth_size)
    bpy.context.view_layer.objects.active = cloth
    bpy.ops.object.modifier_add(type='SUBSURF')
    cloth.modifiers['Subdivision'].levels = subdivisions
    bpy.ops.object.modifier_apply(modifier='Subdivision')

    cloth_mat = makeMaterial("ClothMat", color=cloth_color, roughness=0.8)
    applyMaterial(cloth, cloth_mat)
    addClothModifier(cloth, quality=8, mass=0.3)

    # camera + lights
    addCamera(location=(5, -5, 4), rotation=(1.0, 0, 0.785))
    addThreePointLighting()

    renderFrames(cfg["output_dir"])


main()