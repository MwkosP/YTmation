import math
import random
import subprocess
import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from utils import *

OUTPUTS_DIR = ROOT / "outputs"
FRAMES_DIR = OUTPUTS_DIR / "frames"
OUTPUT_VIDEO = OUTPUTS_DIR / "output_satisfying_block_drop.mp4"

cleanScene()
random.seed(12)

frames = 180
fps = 60


def apply_scale(obj):
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.select_set(False)


def add_box_body(obj, *, body_type="ACTIVE", mass=1.0, friction=0.8, restitution=0.15):
    apply_scale(obj)
    addRigidBody(obj, body_type=body_type, mass=mass, friction=friction, restitution=restitution)
    obj.rigid_body.collision_shape = "BOX"
    return obj


def add_sphere_body(obj, *, mass=0.5, friction=0.55, restitution=0.35):
    apply_scale(obj)
    addRigidBody(obj, body_type="ACTIVE", mass=mass, friction=friction, restitution=restitution)
    obj.rigid_body.collision_shape = "SPHERE"
    return obj


# Materials
floor_mat = makeMaterial("MatteBlack", color=(0.015, 0.016, 0.020, 1), metallic=0.0, roughness=0.7)
wall_mat = makeMaterial("SoftGraphite", color=(0.045, 0.048, 0.060, 1), metallic=0.0, roughness=0.55)
glass_mat = makeMaterial("BlueGlass", color=(0.12, 0.45, 0.85, 0.35), metallic=0.0, roughness=0.08)
block_mats = [
    makeGlossyMaterial("CoralBlock", color=(1.0, 0.28, 0.20, 1)),
    makeGlossyMaterial("MintBlock", color=(0.15, 0.95, 0.60, 1)),
    makeGlossyMaterial("SkyBlock", color=(0.15, 0.55, 1.0, 1)),
    makeGlossyMaterial("LemonBlock", color=(1.0, 0.82, 0.12, 1)),
]

# Floor
floor = addCube(location=(0, 0, -0.06), size=1)
floor.name = "Floor"
floor.scale = (5.5, 5.5, 0.06)
applyMaterial(floor, floor_mat)
add_box_body(floor, body_type="PASSIVE", friction=0.9, restitution=0.05)

# Simple square catch tray with real rigid body walls.
tray_parts = [
    ("BackWall", (0, 1.7, 0.45), (2.3, 0.09, 0.5)),
    ("FrontWall", (0, -1.7, 0.45), (2.3, 0.09, 0.5)),
    ("LeftWall", (-2.3, 0, 0.45), (0.09, 1.75, 0.5)),
    ("RightWall", (2.3, 0, 0.45), (0.09, 1.75, 0.5)),
]

for name, location, scale in tray_parts:
    wall = addCube(location=location, size=1)
    wall.name = name
    wall.scale = scale
    applyMaterial(wall, wall_mat)
    add_box_body(wall, body_type="PASSIVE", friction=0.85, restitution=0.08)

# A row of small deflector pegs for extra satisfying impacts.
peg_mat = makeEmissiveMaterial("PegGlow", color=(0.0, 0.85, 1.0, 1), strength=1.2)
for row in range(3):
    for col in range(5):
        x = -1.6 + col * 0.8 + (0.4 if row % 2 else 0)
        y = 0.75 - row * 0.65
        peg = addSphere(location=(x, y, 0.42), radius=0.12)
        peg.name = f"Peg_{row}_{col}"
        applyMaterial(peg, peg_mat)
        apply_scale(peg)
        addRigidBody(peg, body_type="PASSIVE", friction=0.4, restitution=0.7)
        peg.rigid_body.collision_shape = "SPHERE"

# Drop blocks one after another. These are actual boxes with matching BOX hitboxes.
for i in range(16):
    x = random.uniform(-1.35, 1.35)
    y = random.uniform(-0.8, 0.8)
    z = 4.2 + i * 0.23

    block = addCube(location=(x, y, z), size=0.46)
    block.name = f"DropBlock_{i}"
    block.rotation_euler = (
        random.uniform(-0.4, 0.4),
        random.uniform(-0.4, 0.4),
        random.uniform(0, math.pi),
    )
    applyMaterial(block, block_mats[i % len(block_mats)])
    add_box_body(block, mass=0.7, friction=0.65, restitution=0.12)
    block.rigid_body.linear_damping = 0.04
    block.rigid_body.angular_damping = 0.08

# Add a few glassy balls so the scene has mixed rigid-body shapes.
for i in range(6):
    ball = addSphere(
        location=(random.uniform(-1.1, 1.1), random.uniform(-0.7, 0.7), 6.0 + i * 0.22),
        radius=0.18,
    )
    ball.name = f"GlassBall_{i}"
    applyMaterial(ball, glass_mat)
    add_sphere_body(ball, mass=0.35, friction=0.45, restitution=0.45)

bakePhysics(frame_start=1, frame_end=frames)

# Camera and lighting
addCamera(location=(0, -6.2, 3.2), rotation=(math.radians(64), 0, 0), fov=42)
addAreaLight(location=(-3.5, -3.5, 5.2), energy=650, color=(0.25, 0.75, 1.0), size=3.0)
addAreaLight(location=(3.5, -2.5, 4.5), energy=550, color=(1.0, 0.42, 0.24), size=3.0)
addAreaLight(location=(0, 2.5, 5.5), energy=260, color=(1.0, 0.92, 0.75), size=5.0)

setBackground(color=(0, 0, 0, 1))
setBackgroundStrength(0.7)

setupRender(frames=frames, fps=fps, resolution=(1920, 1080), engine="BLENDER_EEVEE")
renderFrames(str(FRAMES_DIR))

subprocess.run([
    "ffmpeg", "-y",
    "-framerate", str(fps),
    "-i", str(FRAMES_DIR / "frame_%04d.png"),
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    "-vf", "setpts=1.6*PTS",
    str(OUTPUT_VIDEO),
], check=True)

print(f"Done! Satisfying block drop saved to {OUTPUT_VIDEO}")
