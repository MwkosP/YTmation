#Frist time using ym clean funcs from util


import bpy
import sys
sys.path.append('/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()
obj = importObj('/home/zolo/Desktop/YT/3d/TripoSR/output/0/mesh.obj')
addThreePointLighting()
addOrbitCamera()
applyMaterial(obj, makeGlossyMaterial('shine', color=(0.2, 0.8, 1, 1)))
addRotationSpin(obj)
setupRender(120)
renderFrames('/home/zolo/Desktop/YT/3d/frames/')
renderToVideo('/home/zolo/Desktop/YT/3d/frames/', '/home/zolo/Desktop/YT/3d/output.mp4')