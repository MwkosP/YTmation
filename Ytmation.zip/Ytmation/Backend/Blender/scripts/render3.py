import bpy
import math
import subprocess
import os

# clean scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()

# import mesh
bpy.ops.wm.obj_import(filepath='/home/zolo/Desktop/YT/3d/TripoSR/output/0/mesh.obj')
obj = bpy.context.active_object

# center object
bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
obj.location = (0, 0, 0)

# hologram material
mat = bpy.data.materials.new(name="Hologram")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
nodes.clear()

output = nodes.new('ShaderNodeOutputMaterial')
emission = nodes.new('ShaderNodeEmission')
transparent = nodes.new('ShaderNodeBsdfTransparent')
mix = nodes.new('ShaderNodeMixShader')
fresnel = nodes.new('ShaderNodeFresnel')

emission.inputs['Color'].default_value = (0.0, 1.0, 0.8, 1.0)  # teal glow
emission.inputs['Strength'].default_value = 3.0
fresnel.inputs['IOR'].default_value = 2.5

links.new(fresnel.outputs['Fac'], mix.inputs['Fac'])
links.new(transparent.outputs['BSDF'], mix.inputs[1])
links.new(emission.outputs['Emission'], mix.inputs[2])
links.new(mix.outputs['Shader'], output.inputs['Surface'])

mat.blend_method = 'BLEND'
obj.data.materials.clear()
obj.data.materials.append(mat)

# wireframe overlay
bpy.ops.object.modifier_add(type='WIREFRAME')
obj.modifiers['Wireframe'].thickness = 0.005
obj.modifiers['Wireframe'].use_replace = False

# rotation animation
frames = 120
for i in range(frames + 1):
    angle = (i / frames) * 2 * math.pi
    obj.rotation_euler = (0, 0, angle)
    obj.keyframe_insert(data_path='rotation_euler', frame=i)

# spiral camera movement
cam_data = bpy.data.cameras.new('Camera')
cam_obj = bpy.data.objects.new('Camera', cam_data)
bpy.context.scene.collection.objects.link(cam_obj)
bpy.context.scene.camera = cam_obj

for i in range(frames + 1):
    t = i / frames
    angle = t * 2 * math.pi
    radius = 4
    height = 0.5 + t * 2.5  # spiral up
    cam_obj.location = (
        math.sin(angle) * radius,
        -math.cos(angle) * radius,
        height
    )
    # always look at object
    direction = cam_obj.location.copy()
    direction.negate()
    rot_quat = direction.to_track_quat('-Z', 'Y')
    cam_obj.rotation_euler = rot_quat.to_euler()
    cam_obj.keyframe_insert(data_path='location', frame=i)
    cam_obj.keyframe_insert(data_path='rotation_euler', frame=i)

# dim blue light
bpy.ops.object.light_add(type='AREA', location=(0, 0, 6))
light = bpy.context.active_object
light.data.energy = 100
light.data.color = (0.0, 0.8, 1.0)

# side accent
bpy.ops.object.light_add(type='AREA', location=(4, 0, 2))
light2 = bpy.context.active_object
light2.data.energy = 200
light2.data.color = (0.0, 1.0, 0.6)

# dark background
world = bpy.context.scene.world
world.use_nodes = True
world.node_tree.nodes['Background'].inputs[0].default_value = (0.0, 0.02, 0.05, 1)

# EEVEE render settings
frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
os.makedirs(frames_dir, exist_ok=True)

scene = bpy.context.scene
scene.frame_start = 0
scene.frame_end = frames
scene.render.fps = 24
scene.render.resolution_x = 1920
scene.render.resolution_y = 1080
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = frames_dir + 'frame_'
scene.render.engine = 'BLENDER_EEVEE'

# render
bpy.ops.render.render(animation=True)

# combine to mp4
subprocess.run([
    'ffmpeg', '-y', '-framerate', '24',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '/home/zolo/Desktop/YT/3d/output_video3.mp4'
])

print("Done! Video saved to ~/Desktop/YT/3d/output_video3.mp4")