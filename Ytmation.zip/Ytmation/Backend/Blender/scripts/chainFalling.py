import bpy
import sys
import math
import subprocess
import os
import random
sys.path.insert(0, '/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()

frames = 250

# ─── FLOOR ───────────────────────────────────────────────
floor = addPlane(location=(0, 0, 0), size=14)
addRigidBody(floor, body_type='PASSIVE', friction=0.9, restitution=0.0)
mat_floor = makeMaterial('Floor', color=(0.15, 0.12, 0.10, 1), metallic=0.0, roughness=0.95)
applyMaterial(floor, mat_floor)

# ─── RUSTY METAL MATERIAL ────────────────────────────────
def makeRustyMaterial(name, rust_amount=0.6):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out        = nodes.new('ShaderNodeOutputMaterial')
    principled = nodes.new('ShaderNodeBsdfPrincipled')
    noise      = nodes.new('ShaderNodeTexNoise')
    colorramp  = nodes.new('ShaderNodeValToRGB')
    mix_rgb    = nodes.new('ShaderNodeMixRGB')

    # base metal color
    principled.inputs['Metallic'].default_value   = 0.85
    principled.inputs['Roughness'].default_value  = 0.7

    # noise for rust patches
    noise.inputs['Scale'].default_value    = 8.0
    noise.inputs['Detail'].default_value   = 6.0
    noise.inputs['Roughness'].default_value = 0.7

    # rust color ramp - dark metal to rust orange
    colorramp.color_ramp.elements[0].position = 0.4
    colorramp.color_ramp.elements[0].color    = (0.25, 0.15, 0.08, 1)  # rust orange
    colorramp.color_ramp.elements[1].position = 0.7
    colorramp.color_ramp.elements[1].color    = (0.12, 0.10, 0.09, 1)  # dark metal

    # mix rust with base
    mix_rgb.blend_type = 'MIX'
    mix_rgb.inputs['Fac'].default_value = rust_amount

    links.new(noise.outputs['Fac'],              colorramp.inputs['Fac'])
    links.new(colorramp.outputs['Color'],         mix_rgb.inputs['Color1'])
    links.new(mix_rgb.outputs['Color'],           principled.inputs['Base Color'])
    links.new(colorramp.outputs['Color'],         principled.inputs['Roughness'])
    links.new(principled.outputs['BSDF'],         out.inputs['Surface'])

    return mat

rusty_mat = makeRustyMaterial('RustyChain', rust_amount=0.65)

# ─── CHAIN LINKS ─────────────────────────────────────────
num_links  = 40
link_w     = 0.12
link_h     = 0.22
link_thick = 0.04
gap        = 0.02

links_list = []

for i in range(num_links):
    z = 0.5 + i * (link_h * 2 + gap) + 2.0  # stack vertically
    
    # alternate links rotated 90 degrees like real chain
    rot_z = math.radians(90) if i % 2 == 0 else 0.0

    # create torus for each link
    bpy.ops.mesh.primitive_torus_add(
        major_radius=link_h,
        minor_radius=link_thick,
        major_segments=24,
        minor_segments=10,
        location=(0, 0, z)
    )
    link = bpy.context.active_object
    link.name  = f'Link_{i}'
    link.scale = (link_w / link_h, 1.0, 1.0)
    link.rotation_euler = (math.radians(90), 0, rot_z)
    bpy.ops.object.shade_smooth()
    applyMaterial(link, rusty_mat)

    # rigid body
    addRigidBody(link, body_type='ACTIVE', mass=0.8, restitution=0.1, friction=0.9)
    link.rigid_body.linear_damping  = 0.2
    link.rigid_body.angular_damping = 0.3

    # top links stay kinematic briefly then drop sequentially
    hold_until = max(1, num_links - i) * 2
    link.rigid_body.kinematic = True
    link.keyframe_insert(data_path='rigid_body.kinematic', frame=1)
    link.rigid_body.kinematic = False
    link.keyframe_insert(data_path='rigid_body.kinematic', frame=hold_until)

    links_list.append(link)

# ─── BAKE PHYSICS ────────────────────────────────────────
bakePhysics(frame_start=1, frame_end=frames)

# ─── CAMERA ──────────────────────────────────────────────
addCamera(
    location=(5, -7, 5),
    rotation=(math.radians(65), 0, math.radians(30)),
    fov=40
)

# ─── REALISTIC LIGHTING ──────────────────────────────────
# main overhead warm industrial light
addAreaLight(location=(0, 0, 10),   energy=600,  color=(1.0, 0.92, 0.80), size=5)
# side fill - cool shadow side
addAreaLight(location=(-5, -3, 5),  energy=150,  color=(0.7, 0.80, 1.00), size=4)
# subtle rim from behind
addAreaLight(location=(3,  5,  4),  energy=200,  color=(1.0, 0.88, 0.75), size=3)
# floor bounce
addAreaLight(location=(0,  0,  0.3),energy=80,   color=(0.6, 0.50, 0.40), size=4)

# ─── BACKGROUND - dark industrial ────────────────────────
setBackground(color=(0.06, 0.05, 0.04, 1))
setBackgroundStrength(1.0)

# ─── RENDER ──────────────────────────────────────────────
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/outputs/frames/'
renderFrames(frames_dir)

subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=2.5*PTS',
    '/home/zolo/Desktop/YT/3d/outputs/output_chain.mp4'
])

print("Done! Chain video saved to output_chain.mp4")