import bpy
import sys
import math
import subprocess
import os
sys.path.insert(0, '/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()

frames = 200

# ─── MATERIALS ───────────────────────────────────────────
def makeWaterMaterial(name):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out   = nodes.new('ShaderNodeOutputMaterial')
    glass = nodes.new('ShaderNodeBsdfGlass')
    glass.inputs['Color'].default_value     = (0.85, 0.95, 1.0, 1.0)
    glass.inputs['IOR'].default_value       = 1.333
    glass.inputs['Roughness'].default_value = 0.0
    links.new(glass.outputs['BSDF'], out.inputs['Surface'])
    mat.blend_method = 'BLEND'
    return mat

def makeGlassMaterial(name):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out   = nodes.new('ShaderNodeOutputMaterial')
    glass = nodes.new('ShaderNodeBsdfGlass')
    glass.inputs['Color'].default_value     = (0.90, 0.97, 1.0, 1.0)
    glass.inputs['IOR'].default_value       = 1.52
    glass.inputs['Roughness'].default_value = 0.0
    links.new(glass.outputs['BSDF'], out.inputs['Surface'])
    mat.blend_method = 'BLEND'
    return mat

# ─── TABLE ───────────────────────────────────────────────
table = addPlane(location=(0, 0, 0), size=12)
applyMaterial(table, makeMaterial('Table',
    color=(0.55, 0.40, 0.28, 1),
    metallic=0.0,
    roughness=0.6
))

# ─── DRINKING GLASS ──────────────────────────────────────
# outer glass
bpy.ops.mesh.primitive_cylinder_add(
    vertices=64,
    radius=0.55,
    depth=2.2,
    location=(0, 0, 1.1)
)
glass_outer = bpy.context.active_object
glass_outer.name = 'GlassOuter'
bpy.ops.object.shade_smooth()
applyMaterial(glass_outer, makeGlassMaterial('GlassOuter'))

# inner hollow - boolean to hollow the glass
bpy.ops.mesh.primitive_cylinder_add(
    vertices=64,
    radius=0.48,
    depth=2.1,
    location=(0, 0, 1.2)
)
glass_inner = bpy.context.active_object
glass_inner.name = 'GlassInner'

# boolean difference
bool_mod = glass_outer.modifiers.new('Boolean', 'BOOLEAN')
bool_mod.operation = 'DIFFERENCE'
bool_mod.object    = glass_inner
bpy.context.view_layer.objects.active = glass_outer
bpy.ops.object.modifier_apply(modifier='Boolean')
bpy.data.objects.remove(glass_inner)

# glass is fluid obstacle
bpy.context.view_layer.objects.active = glass_outer
bpy.ops.object.modifier_add(type='FLUID')
glass_outer.modifiers['Fluid'].fluid_type = 'EFFECTOR'
glass_outer.modifiers['Fluid'].effector_settings.effector_type = 'COLLISION'

# ─── FLUID DOMAIN ────────────────────────────────────────
bpy.ops.mesh.primitive_cube_add(size=3, location=(0, 0, 2.5))
domain = bpy.context.active_object
domain.name = 'FluidDomain'
domain.display_type = 'WIRE'

bpy.ops.object.modifier_add(type='FLUID')
domain.modifiers['Fluid'].fluid_type = 'DOMAIN'
domain_settings = domain.modifiers['Fluid'].domain_settings

# domain settings
domain_settings.domain_type        = 'LIQUID'
domain_settings.resolution_max     = 64   # balance quality vs speed
domain_settings.use_adaptive_domain = True
domain_settings.cache_frame_start  = 1
domain_settings.cache_frame_end    = frames
domain_settings.cache_type         = 'MODULAR'

# fluid surface detail
domain_settings.mesh_scale         = 2
domain_settings.mesh_particle_radius = 1.5

# apply water material to domain
applyMaterial(domain, makeWaterMaterial('Water'))

# ─── FLUID INFLOW (pouring source) ───────────────────────
bpy.ops.mesh.primitive_cylinder_add(
    vertices=16,
    radius=0.12,
    depth=0.2,
    location=(0, 0, 4.2)
)
inflow = bpy.context.active_object
inflow.name = 'Inflow'
inflow.hide_render = True

bpy.ops.object.modifier_add(type='FLUID')
inflow.modifiers['Fluid'].fluid_type = 'FLOW'
flow_settings = inflow.modifiers['Fluid'].flow_settings
flow_settings.flow_type          = 'LIQUID'
flow_settings.flow_behavior      = 'INFLOW'
flow_settings.use_initial_velocity = True
flow_settings.velocity_coord[2]  = -3.0  # downward velocity


# inflow starts at frame 1 stops at frame 120
inflow.modifiers['Fluid'].flow_settings.use_inflow = True
inflow.keyframe_insert(data_path='modifiers["Fluid"].flow_settings.use_inflow', frame=1)
inflow.modifiers['Fluid'].flow_settings.use_inflow = False
inflow.keyframe_insert(data_path='modifiers["Fluid"].flow_settings.use_inflow', frame=120)

# ─── BAKE FLUID ──────────────────────────────────────────
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end   = frames
bpy.context.view_layer.objects.active = domain
bpy.ops.fluid.bake_all()

# ─── CAMERA ──────────────────────────────────────────────
addCamera(
    location=(4, -5, 2.5),
    rotation=(math.radians(78), 0, math.radians(35)),
    fov=45
)

# ─── DAYLIGHT LIGHTING ───────────────────────────────────
addSunLight(location=(8, -6, 12),   energy=5,   color=(1.00, 0.97, 0.90))
addAreaLight(location=(0,  0,  10), energy=300, color=(0.65, 0.78, 1.00), size=6)
addAreaLight(location=(-5, -3,  5), energy=150, color=(1.00, 0.95, 0.85), size=4)
addAreaLight(location=(0,   0,  0.3), energy=80, color=(0.90, 0.85, 0.75), size=5)

# ─── BACKGROUND ──────────────────────────────────────────
setBackground(color=(0.65, 0.75, 0.90, 1))
setBackgroundStrength(1.5)

# ─── RENDER ──────────────────────────────────────────────
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/outputs/frames/'
renderFrames(frames_dir)

subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=3.0*PTS',
    '/home/zolo/Desktop/YT/3d/outputs/output_fluid.mp4'
])

print("Done! Fluid video saved to output_fluid.mp4")