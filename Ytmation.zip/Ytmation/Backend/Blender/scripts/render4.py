import bpy
import math
import subprocess
import os

# clean scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()

# use EEVEE
bpy.context.scene.render.engine = 'BLENDER_EEVEE'

# enable physics
def add_rigid_body(obj, body_type='ACTIVE'):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.rigidbody.object_add()
    obj.rigid_body.type = body_type
    obj.rigid_body.restitution = 0.3  # bounciness
    obj.rigid_body.friction = 0.8

# platform
bpy.ops.mesh.primitive_plane_add(size=10, location=(0, 0, 0))
platform = bpy.context.active_object
platform.name = 'Platform'
add_rigid_body(platform, 'PASSIVE')

# platform material - dark glossy
mat_floor = bpy.data.materials.new('Floor')
mat_floor.use_nodes = True
mat_floor.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (0.05, 0.05, 0.1, 1)
mat_floor.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = 0.9
mat_floor.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 0.1
platform.data.materials.append(mat_floor)

# box colors
colors = [
    (1.0, 0.2, 0.2, 1),  # red
    (0.2, 0.6, 1.0, 1),  # blue
    (0.2, 1.0, 0.4, 1),  # green
    (1.0, 0.8, 0.0, 1),  # yellow
]

# create 4 boxes dropping from different heights and positions
boxes = []
positions = [(-2, -2, 8), (2, -2, 12), (-2, 2, 10), (2, 2, 6)]

for i, (pos, color) in enumerate(zip(positions, colors)):
    bpy.ops.mesh.primitive_cube_add(size=0.8, location=pos)
    box = bpy.context.active_object
    box.name = f'Box_{i}'

    # random rotation
    box.rotation_euler = (i * 0.5, i * 0.3, i * 0.7)

    # material
    mat = bpy.data.materials.new(f'BoxMat_{i}')
    mat.use_nodes = True
    mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = color
    mat.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = 0.5
    mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 0.3
    box.data.materials.append(mat)

    add_rigid_body(box, 'ACTIVE')
    box.rigid_body.mass = 2.0
    boxes.append(box)

# camera - dramatic low angle
bpy.ops.object.camera_add(location=(8, -8, 4))
cam = bpy.context.active_object
cam.rotation_euler = (1.1, 0, 0.785)
bpy.context.scene.camera = cam

# lights
bpy.ops.object.light_add(type='AREA', location=(5, 5, 10))
key_light = bpy.context.active_object
key_light.data.energy = 1000
key_light.data.color = (1.0, 0.9, 0.8)
key_light.data.size = 3

bpy.ops.object.light_add(type='AREA', location=(-5, -3, 6))
fill_light = bpy.context.active_object
fill_light.data.energy = 300
fill_light.data.color = (0.3, 0.5, 1.0)

bpy.ops.object.light_add(type='SPOT', location=(0, 0, 12))
spot = bpy.context.active_object
spot.data.energy = 2000
spot.data.spot_size = 0.8
spot.data.color = (1.0, 1.0, 1.0)
spot.rotation_euler = (0, 0, 0)

# dark background
world = bpy.context.scene.world
world.use_nodes = True
world.node_tree.nodes['Background'].inputs[0].default_value = (0.01, 0.01, 0.02, 1)

# scene settings
scene = bpy.context.scene
scene.frame_start = 1
scene.frame_end = 120
scene.render.fps = 24

# bake physics simulation
bpy.context.scene.rigidbody_world.point_cache.frame_start = 1
bpy.context.scene.rigidbody_world.point_cache.frame_end = 120
bpy.ops.ptcache.bake_all(bake=True)

# render settings
frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
os.makedirs(frames_dir, exist_ok=True)

# clear old frames
for f in os.listdir(frames_dir):
    os.remove(os.path.join(frames_dir, f))

scene.render.resolution_x = 1920
scene.render.resolution_y = 1080
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = frames_dir + 'frame_'

bpy.ops.render.render(animation=True)

# combine to mp4
subprocess.run([
    'ffmpeg', '-y', '-framerate', '24',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '/home/zolo/Desktop/YT/3d/output_video4.mp4'
])

print("Done! Video saved to ~/Desktop/YT/3d/output_video4.mp4")