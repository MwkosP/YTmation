import bpy
import sys
import math
import subprocess
import os
import random
sys.path.insert(0, '/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()
random.seed(42)

frames = 250

# ─── MATERIALS ───────────────────────────────────────────
def makeConcreteMaterial(name):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out   = nodes.new('ShaderNodeOutputMaterial')
    princ = nodes.new('ShaderNodeBsdfPrincipled')
    noise = nodes.new('ShaderNodeTexNoise')
    ramp  = nodes.new('ShaderNodeValToRGB')

    noise.inputs['Scale'].default_value     = 12.0
    noise.inputs['Detail'].default_value    = 8.0
    noise.inputs['Roughness'].default_value = 0.8

    ramp.color_ramp.elements[0].position = 0.3
    ramp.color_ramp.elements[0].color    = (0.35, 0.33, 0.30, 1)
    ramp.color_ramp.elements[1].position = 0.8
    ramp.color_ramp.elements[1].color    = (0.55, 0.52, 0.48, 1)

    princ.inputs['Metallic'].default_value  = 0.0
    princ.inputs['Roughness'].default_value = 0.95

    links.new(noise.outputs['Fac'],       ramp.inputs['Fac'])
    links.new(ramp.outputs['Color'],      princ.inputs['Base Color'])
    links.new(princ.outputs['BSDF'],      out.inputs['Surface'])
    return mat

def makeSteelMaterial(name):
    return makeMaterial(name,
        color=(0.45, 0.45, 0.48, 1),
        metallic=0.95,
        roughness=0.25
    )

concrete_mat = makeConcreteMaterial('Concrete')
steel_mat    = makeSteelMaterial('Steel')

# ─── FLOOR ───────────────────────────────────────────────
floor = addPlane(location=(0, 0, 0), size=20)
addRigidBody(floor, body_type='PASSIVE', friction=0.9, restitution=0.0)
applyMaterial(floor, makeConcreteMaterial('FloorConcrete'))

# ─── BLOCK TOWER ─────────────────────────────────────────
block_w = 0.9
block_h = 0.45
block_d = 0.9
rows    = 12
cols    = 4
depth   = 4

blocks = []
for row in range(rows):
    for col in range(cols):
        for d in range(depth):
            x = (col - cols / 2 + 0.5) * block_w + random.uniform(-0.01, 0.01)
            y = (d - depth / 2 + 0.5)  * block_d + random.uniform(-0.01, 0.01)
            z = row * block_h + block_h / 2

            bpy.ops.mesh.primitive_cube_add(size=1, location=(x, y, z))
            block = bpy.context.active_object
            block.scale = (block_w * 0.98, block_d * 0.98, block_h * 0.98)
            block.name  = f'Block_{row}_{col}_{d}'

            applyMaterial(block, concrete_mat)
            addRigidBody(block, body_type='ACTIVE', mass=3.0, restitution=0.1, friction=0.9)
            blocks.append(block)

# ─── CRANE ARM ───────────────────────────────────────────
# vertical pole
bpy.ops.mesh.primitive_cylinder_add(radius=0.12, depth=10, location=(-7, 0, 5))
pole = bpy.context.active_object
applyMaterial(pole, steel_mat)

# horizontal arm
bpy.ops.mesh.primitive_cylinder_add(radius=0.08, depth=8, location=(-3, 0, 10))
arm = bpy.context.active_object
arm.rotation_euler = (0, math.radians(90), 0)
applyMaterial(arm, steel_mat)

# ─── WRECKING BALL CHAIN ─────────────────────────────────
num_chain = 8
for i in range(num_chain):
    z = 10 - i * 0.4
    bpy.ops.mesh.primitive_torus_add(
        major_radius=0.12,
        minor_radius=0.03,
        location=(1, 0, z)
    )
    chain_link = bpy.context.active_object
    chain_link.rotation_euler = (math.radians(90) if i % 2 == 0 else 0, 0, 0)
    applyMaterial(chain_link, steel_mat)

# ─── WRECKING BALL ───────────────────────────────────────
bpy.ops.mesh.primitive_uv_sphere_add(radius=0.9, location=(1, 0, 6.8))
ball = bpy.context.active_object
ball.name = 'WreckingBall'
bpy.ops.object.shade_smooth()
applyMaterial(ball, makeSteelMaterial('BallSteel'))

addRigidBody(ball, body_type='ACTIVE', mass=800.0, restitution=0.1, friction=0.8)
ball.rigid_body.linear_damping  = 0.0
ball.rigid_body.angular_damping = 0.9

# ─── ANIMATE BALL SWING ───────────────────────────────────
# start pulled back, swing forward and smash tower
swing_radius = 8.0
pivot = (-7, 0, 10)

ball.rigid_body.kinematic = True

for frame in range(frames + 1):
    t = frame / 45.0  # swing speed

    if frame <= 60:
        # swing from left to right - gaining speed
        angle = math.radians(-60) + (math.radians(60) * frame / 60)
    else:
        # after impact just keep moving slightly
        angle = math.radians(60) + math.radians(5) * (frame - 60) / frames

    bx = pivot[0] + swing_radius * math.sin(angle)
    bz = pivot[2] - swing_radius * math.cos(angle)

    ball.location = (bx, 0, bz)
    ball.keyframe_insert(data_path='location', frame=frame)

    # release kinematic at impact (frame 60) so physics takes over
    if frame == 59:
        ball.rigid_body.kinematic = True
        ball.keyframe_insert(data_path='rigid_body.kinematic', frame=frame)
    if frame == 60:
        ball.rigid_body.kinematic = False
        ball.keyframe_insert(data_path='rigid_body.kinematic', frame=frame)

# ─── BAKE PHYSICS ────────────────────────────────────────
bakePhysics(frame_start=1, frame_end=frames)

# ─── CAMERA - dramatic side angle ────────────────────────
addCamera(
    location=(8, -10, 6),
    rotation=(math.radians(72), 0, math.radians(35)),
    fov=42
)

# ─── LIGHTING ────────────────────────────────────────────
# overcast sky - soft diffuse
addAreaLight(location=(0,  0,  15), energy=800,  color=(0.90, 0.92, 1.00), size=10)
# sun from side
addSunLight(location=(10, -8, 12),  energy=4,    color=(1.00, 0.95, 0.85))
# shadow fill
addAreaLight(location=(-6, -4, 5),  energy=150,  color=(0.70, 0.80, 1.00), size=5)
# ground bounce
addAreaLight(location=(0,   0, 0.3),energy=100,  color=(0.80, 0.75, 0.65), size=6)

# ─── BACKGROUND ──────────────────────────────────────────
setBackground(color=(0.55, 0.62, 0.75, 1))
setBackgroundStrength(1.2)

# ─── RENDER ──────────────────────────────────────────────
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/outputs/frames/'
renderFrames(frames_dir)

subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=2.5*PTS',
    '/home/zolo/Desktop/YT/3d/outputs/output_wrecking.mp4'
])

print("Done! Wrecking ball video saved to output_wrecking.mp4")