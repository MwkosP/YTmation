import math
import subprocess
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from utils import *

OUTPUTS_DIR = ROOT / "outputs"
FRAMES_DIR = OUTPUTS_DIR / "frames"
OUTPUT_VIDEO = OUTPUTS_DIR / "output_earth_orbit.mp4"

cleanScene()

frames = 240
fps = 60


def set_linear_animation(obj):
    animation_data = getattr(obj, "animation_data", None)
    action = getattr(animation_data, "action", None)
    fcurves = getattr(action, "fcurves", None)
    if not fcurves:
        return

    for curve in fcurves:
        for keyframe in curve.keyframe_points:
            keyframe.interpolation = "LINEAR"


def make_earth_material():
    mat = bpy.data.materials.new("ProceduralEarth")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    bsdf = nodes.get("Principled BSDF")

    noise = nodes.new("ShaderNodeTexNoise")
    ramp = nodes.new("ShaderNodeValToRGB")

    noise.inputs["Scale"].default_value = 5.2
    noise.inputs["Detail"].default_value = 13.0
    noise.inputs["Roughness"].default_value = 0.58

    ramp.color_ramp.elements[0].position = 0.42
    ramp.color_ramp.elements[0].color = (0.02, 0.14, 0.48, 1)  # ocean
    ramp.color_ramp.elements[1].position = 0.56
    ramp.color_ramp.elements[1].color = (0.10, 0.46, 0.13, 1)  # land

    mid = ramp.color_ramp.elements.new(0.74)
    mid.color = (0.62, 0.48, 0.24, 1)  # mountains/desert

    links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = 0.42
    return mat


def make_cloud_material():
    mat = bpy.data.materials.new("ThinClouds")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    transparent = nodes.new("ShaderNodeBsdfTransparent")
    diffuse = nodes.new("ShaderNodeBsdfDiffuse")
    noise = nodes.new("ShaderNodeTexNoise")
    ramp = nodes.new("ShaderNodeValToRGB")
    mix = nodes.new("ShaderNodeMixShader")

    diffuse.inputs["Color"].default_value = (1, 1, 1, 1)
    noise.inputs["Scale"].default_value = 9.0
    noise.inputs["Detail"].default_value = 9.0
    ramp.color_ramp.elements[0].position = 0.54
    ramp.color_ramp.elements[0].color = (0, 0, 0, 1)
    ramp.color_ramp.elements[1].position = 0.78
    ramp.color_ramp.elements[1].color = (1, 1, 1, 1)

    links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], mix.inputs["Fac"])
    links.new(transparent.outputs["BSDF"], mix.inputs[1])
    links.new(diffuse.outputs["BSDF"], mix.inputs[2])
    links.new(mix.outputs["Shader"], out.inputs["Surface"])

    mat.blend_method = "BLEND"
    mat.use_screen_refraction = True
    return mat


def make_emission(name, color, strength):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    emission = nodes.new("ShaderNodeEmission")
    emission.inputs["Color"].default_value = color
    emission.inputs["Strength"].default_value = strength
    links.new(emission.outputs["Emission"], out.inputs["Surface"])
    return mat


# Sun
sun_mat = make_emission("SunGlow", (1.0, 0.58, 0.16, 1), 5.0)
sun = addSphere(location=(0, 0, 0), radius=0.75)
sun.name = "Sun"
applyMaterial(sun, sun_mat)

# Orbit ring
bpy.ops.mesh.primitive_torus_add(
    major_radius=3.6,
    minor_radius=0.008,
    major_segments=160,
    minor_segments=6,
    location=(0, 0, 0),
)
orbit_ring = bpy.context.active_object
orbit_ring.name = "EarthOrbitRing"
applyMaterial(orbit_ring, make_emission("OrbitRingBlue", (0.12, 0.55, 1.0, 1), 0.6))

# Earth and clouds
earth = addSphere(location=(3.6, 0, 0), radius=0.42)
earth.name = "Earth"
earth.rotation_euler = (math.radians(23.5), 0, 0)
applyMaterial(earth, make_earth_material())

clouds = addSphere(location=earth.location, radius=0.435)
clouds.name = "CloudLayer"
clouds.rotation_euler = earth.rotation_euler
applyMaterial(clouds, make_cloud_material())

# Moon
moon = addSphere(location=(4.2, 0, 0), radius=0.12)
moon.name = "Moon"
applyMaterial(moon, makeMaterial("MoonDust", color=(0.62, 0.62, 0.58, 1), metallic=0.0, roughness=0.85))

# Animate orbit, Earth spin, cloud drift, and moon orbit.
for frame in range(1, frames + 1):
    t = (frame - 1) / (frames - 1)
    earth_angle = t * math.tau
    earth_pos = (
        math.cos(earth_angle) * 3.6,
        math.sin(earth_angle) * 3.6,
        0.18 * math.sin(earth_angle * 2),
    )

    earth.location = earth_pos
    earth.rotation_euler = (
        math.radians(23.5),
        0,
        t * math.tau * 4,
    )
    earth.keyframe_insert(data_path="location", frame=frame)
    earth.keyframe_insert(data_path="rotation_euler", frame=frame)

    clouds.location = earth_pos
    clouds.rotation_euler = (
        math.radians(23.5),
        0,
        t * math.tau * 4.6,
    )
    clouds.keyframe_insert(data_path="location", frame=frame)
    clouds.keyframe_insert(data_path="rotation_euler", frame=frame)

    moon_angle = t * math.tau * 5
    moon.location = (
        earth_pos[0] + math.cos(moon_angle) * 0.72,
        earth_pos[1] + math.sin(moon_angle) * 0.72,
        earth_pos[2] + math.sin(moon_angle + 0.7) * 0.10,
    )
    moon.keyframe_insert(data_path="location", frame=frame)

set_linear_animation(earth)
set_linear_animation(clouds)
set_linear_animation(moon)

# Star field
star_mat = make_emission("StarWhite", (1, 1, 1, 1), 1.8)
for i in range(120):
    angle = i * 2.399963
    radius = 7.5 + (i % 19) * 0.18
    z = -2.5 + (i % 31) * 0.16
    star = addSphere(
        location=(math.cos(angle) * radius, math.sin(angle) * radius, z),
        radius=0.012 + (i % 4) * 0.004,
    )
    star.name = f"Star_{i}"
    applyMaterial(star, star_mat)

# Camera and lighting
add_look_target = (0, 0, 0.15)
bpy.ops.object.camera_add(location=(0, -7.7, 3.0))
cam = bpy.context.active_object
direction = Vector(add_look_target) - cam.location
cam.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
cam.data.lens = 42
bpy.context.scene.camera = cam

addPointLight(location=(0, 0, 0), energy=900, color=(1.0, 0.67, 0.28))
addAreaLight(location=(0, -4, 4), energy=120, color=(0.35, 0.55, 1.0), size=5)
setBackground(color=(0.005, 0.006, 0.014, 1))
setBackgroundStrength(0.7)

setupRender(frames=frames, fps=fps, resolution=(1920, 1080), engine="BLENDER_EEVEE")
renderFrames(str(FRAMES_DIR))

subprocess.run([
    "ffmpeg", "-y",
    "-framerate", str(fps),
    "-i", str(FRAMES_DIR / "frame_%04d.png"),
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    "-vf", "setpts=1.4*PTS",
    str(OUTPUT_VIDEO),
], check=True)

print(f"Done! Earth orbit video saved to {OUTPUT_VIDEO}")
