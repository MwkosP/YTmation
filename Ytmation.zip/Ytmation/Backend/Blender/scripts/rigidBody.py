"""
Rigid Body Simulation
----------------------
Stack of boxes falls and collapses.

Params (via YT_PARAMS env):
    box_count     : int   = 20
    box_color     : list  = [0.2, 0.5, 1.0, 1.0]
    floor_color   : list  = [0.1, 0.1, 0.1, 1.0]
    restitution   : float = 0.4
    friction      : float = 0.6
    stack_height  : int   = 5
"""

import sys
import os
import random

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from blenderAbstractions import (
    cleanScene, setupRenderFromEnv, setBackground,
    addCamera, addNeonLighting,
    addCube, addPlane,
    makeMaterial, makeMetallicMaterial, applyMaterial,
    addRigidBody, bakePhysics,
    renderFrames,
)


def main():
    cfg    = setupRenderFromEnv()
    params = cfg["params"]
    frames = cfg["frames"]

    box_count    = params.get("box_count",    20)
    box_color    = params.get("box_color",    [0.2, 0.5, 1.0, 1.0])
    floor_color  = params.get("floor_color",  [0.1, 0.1, 0.1, 1.0])
    restitution  = params.get("restitution",  0.4)
    friction     = params.get("friction",     0.6)
    stack_height = params.get("stack_height", 5)

    cleanScene()
    setBackground((0.02, 0.02, 0.02, 1))

    import bpy

    # floor
    floor = addPlane(location=(0, 0, 0), size=20)
    floor_mat = makeMetallicMaterial("FloorMat", color=floor_color)
    applyMaterial(floor, floor_mat)
    addRigidBody(floor, body_type='PASSIVE', friction=friction)

    # stack of boxes
    box_mat = makeMaterial("BoxMat", color=box_color, metallic=0.3, roughness=0.4)
    cols = box_count // stack_height

    for col in range(cols):
        for row in range(stack_height):
            x = (col - cols // 2) * 1.1 + random.uniform(-0.05, 0.05)
            z = row * 1.05 + 0.5
            box = addCube(location=(x, 0, z), size=1.0)
            applyMaterial(box, box_mat)
            addRigidBody(box, body_type='ACTIVE', mass=1.0,
                        restitution=restitution, friction=friction)

    bakePhysics(frame_start=1, frame_end=frames)

    addCamera(location=(8, -8, 5), rotation=(1.0, 0, 0.785))
    addNeonLighting(color_left=(0.2, 0.5, 1.0), color_right=(1.0, 0.2, 0.5), energy=800)

    renderFrames(cfg["output_dir"])


main()