import bpy
import sys
import math
import subprocess
import os
import random
sys.path.insert(0, '/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()
random.seed(7)

frames = 180

# ─── FLOOR ───────────────────────────────────────────────
floor = addPlane(location=(0, 0, 0), size=16)
addRigidBody(floor, body_type='PASSIVE', friction=0.9, restitution=0.0)
mat_floor = makeMaterial('Floor', color=(0.8, 0.78, 0.75, 1), metallic=0.0, roughness=0.9)
applyMaterial(floor, mat_floor)

# ─── GLASS SHARDS (pre-broken glass) ─────────────────────
# simulate broken glass by creating many thin flat pieces
# that start assembled and fall apart on impact

num_shards = 40
shards = []

for i in range(num_shards):
    # random shard shape using thin flat cubes
    w = random.uniform(0.05, 0.35)
    h = random.uniform(0.05, 0.35)
    thickness = random.uniform(0.005, 0.015)

    # start position - assembled into a glass shape (cylinder-ish)
    angle  = random.uniform(0, math.pi * 2)
    radius = random.uniform(0, 0.5)
    sx = math.cos(angle) * radius
    sy = math.sin(angle) * radius
    sz = random.uniform(0.1, 1.8) + 4.0  # glass starts at height 4

    bpy.ops.mesh.primitive_cube_add(size=1, location=(sx, sy, sz))
    shard = bpy.context.active_object
    shard.scale = (w, thickness, h)
    shard.name  = f'Shard_{i}'

    # random slight rotation to look like glass pieces
    shard.rotation_euler = (
        random.uniform(-0.1, 0.1),
        random.uniform(-0.1, 0.1),
        random.uniform(0, math.pi * 2)
    )

    bpy.ops.object.shade_smooth()

    # glass material - transparent with IOR
    mat = bpy.data.materials.new(f'GlassMat_{i}')
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out   = nodes.new('ShaderNodeOutputMaterial')
    glass = nodes.new('ShaderNodeBsdfGlass')
    mix   = nodes.new('ShaderNodeMixShader')
    fresnel = nodes.new('ShaderNodeFresnel')
    glossy  = nodes.new('ShaderNodeBsdfGlossy')

    glass.inputs['Color'].default_value    = (0.85, 0.95, 1.0, 1.0)
    glass.inputs['IOR'].default_value      = 1.52
    glossy.inputs['Color'].default_value   = (1.0, 1.0, 1.0, 1.0)
    glossy.inputs['Roughness'].default_value = 0.0
    fresnel.inputs['IOR'].default_value    = 1.52

    links.new(fresnel.outputs['Fac'],        mix.inputs['Fac'])
    links.new(glass.outputs['BSDF'],         mix.inputs[1])
    links.new(glossy.outputs['BSDF'],        mix.inputs[2])
    links.new(mix.outputs['Shader'],         out.inputs['Surface'])

    mat.blend_method     = 'BLEND'
    shard.data.materials.append(mat)

    # rigid body - starts kinematic then goes dynamic on impact
    addRigidBody(shard, body_type='ACTIVE', mass=0.05, restitution=0.2, friction=0.4)
    shard.rigid_body.linear_damping  = 0.1
    shard.rigid_body.angular_damping = 0.1

    # keep kinematic until impact frame
    shard.rigid_body.kinematic = True
    shard.keyframe_insert(data_path='rigid_body.kinematic', frame=1)
    shard.keyframe_insert(data_path='location',             frame=1)

    # drop at frame 15 - all shards become dynamic
    shard.rigid_body.kinematic = False
    shard.keyframe_insert(data_path='rigid_body.kinematic', frame=15)

    shards.append(shard)

# ─── WHOLE GLASS BODY (visible before shattering) ────────
bpy.ops.mesh.primitive_cylinder_add(
    vertices=32,
    radius=0.5,
    depth=1.8,
    location=(0, 0, 4.9)
)
glass_body = bpy.context.active_object
glass_body.name = 'GlassBody'
bpy.ops.object.shade_smooth()

mat_glass = bpy.data.materials.new('WholeGlass')
mat_glass.use_nodes = True
nodes = mat_glass.node_tree.nodes
links = mat_glass.node_tree.links
nodes.clear()
out   = nodes.new('ShaderNodeOutputMaterial')
glass = nodes.new('ShaderNodeBsdfGlass')
glass.inputs['Color'].default_value = (0.85, 0.95, 1.0, 1.0)
glass.inputs['IOR'].default_value   = 1.52
links.new(glass.outputs['BSDF'], out.inputs['Surface'])
mat_glass.blend_method  = 'BLEND'
glass_body.data.materials.append(mat_glass)

# glass body falls and hides at impact
glass_body.keyframe_insert(data_path='location', frame=1)
glass_body.location.z = 0.9
glass_body.keyframe_insert(data_path='location', frame=14)
# hide at impact
glass_body.hide_render   = False
glass_body.keyframe_insert(data_path='hide_render', frame=14)
glass_body.hide_render   = True
glass_body.keyframe_insert(data_path='hide_render', frame=15)

# ─── BAKE PHYSICS ────────────────────────────────────────
bakePhysics(frame_start=1, frame_end=frames)

# ─── CAMERA - close low angle ────────────────────────────
addCamera(
    location=(4, -6, 2),
    rotation=(math.radians(80), 0, math.radians(30)),
    fov=45
)

# ─── DAYLIGHT LIGHTING ───────────────────────────────────
# sun
addSunLight(location=(8, -5, 12), energy=5, color=(1.0, 0.98, 0.92))

# sky fill
addAreaLight(location=(0, 0, 10),  energy=400, color=(0.6, 0.75, 1.0), size=8)

# soft fill from side
addAreaLight(location=(-5, -3, 4), energy=200, color=(1.0, 0.95, 0.85), size=4)

# subtle bounce from floor
addAreaLight(location=(0, 0, 0.3), energy=100, color=(0.9, 0.88, 0.85), size=5)

# ─── BACKGROUND - soft sky ───────────────────────────────
setBackground(color=(0.6, 0.75, 1.0, 1.0))
setBackgroundStrength(1.5)

# ─── RENDER ──────────────────────────────────────────────
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/outputs/frames/'
renderFrames(frames_dir)

subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=3.0*PTS',
    '/home/zolo/Desktop/YT/3d/outputs/output_glass.mp4'
])

print("Done! Glass shattering saved to output_glass.mp4")