import bpy
import math
import subprocess
import os

# clean scene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()

# import mesh
bpy.ops.wm.obj_import(filepath='/home/zolo/Desktop/YT/3d/TripoSR/output/0/mesh.obj')
obj = bpy.context.active_object

# center object
bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
obj.location = (0, 0, 0)

# add glossy material
mat = bpy.data.materials.new(name="NeonMat")
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links
nodes.clear()

output = nodes.new('ShaderNodeOutputMaterial')
principled = nodes.new('ShaderNodeBsdfPrincipled')
principled.inputs['Metallic'].default_value = 0.8
principled.inputs['Roughness'].default_value = 0.2
principled.inputs['Base Color'].default_value = (0.0, 0.8, 1.0, 1.0)  # cyan
links.new(principled.outputs['BSDF'], output.inputs['Surface'])
obj.data.materials.clear()
obj.data.materials.append(mat)

# rotation + slight tilt animation
frames = 10
for i in range(frames + 1):
    angle = (i / frames) * 2 * math.pi
    obj.rotation_euler = (0.2, 0, angle)  # slight tilt
    obj.keyframe_insert(data_path='rotation_euler', frame=i)

# camera
bpy.ops.object.camera_add(location=(0, -4, 1.5))
cam = bpy.context.active_object
cam.rotation_euler = (1.3, 0, 0)
bpy.context.scene.camera = cam

# neon lights
# blue light left
bpy.ops.object.light_add(type='AREA', location=(-3, -1, 2))
light1 = bpy.context.active_object
light1.data.energy = 500
light1.data.color = (0.0, 0.5, 1.0)  # blue

# pink light right
bpy.ops.object.light_add(type='AREA', location=(3, -1, 2))
light2 = bpy.context.active_object
light2.data.energy = 500
light2.data.color = (1.0, 0.0, 0.8)  # pink

# soft top light
bpy.ops.object.light_add(type='AREA', location=(0, 0, 5))
light3 = bpy.context.active_object
light3.data.energy = 200
light3.data.color = (1.0, 1.0, 1.0)  # white

# dark background
world = bpy.context.scene.world
world.use_nodes = True
world.node_tree.nodes['Background'].inputs[0].default_value = (0.02, 0.02, 0.05, 1)

# render settings
frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
os.makedirs(frames_dir, exist_ok=True)

scene = bpy.context.scene
scene.frame_start = 0
scene.frame_end = frames
scene.render.fps = 24
scene.render.resolution_x = 1920
scene.render.resolution_y = 1080
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = frames_dir + 'frame_'

# use cycles for better lighting
scene.render.engine = 'CYCLES'
scene.cycles.samples = 64

# render
bpy.ops.render.render(animation=True)

# combine to mp4
subprocess.run([
    'ffmpeg', '-y', '-framerate', '24',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '/home/zolo/Desktop/YT/3d/output_video.mp4'
])

print("Done! Video saved to ~/Desktop/YT/3d/output_video.mp4")