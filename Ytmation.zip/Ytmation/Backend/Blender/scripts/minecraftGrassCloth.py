import math
import random
import subprocess
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from utils import *

OUTPUTS_DIR = ROOT / "outputs"
FRAMES_DIR = OUTPUTS_DIR / "frames"
OUTPUT_VIDEO = OUTPUTS_DIR / "output_minecraft_grass_cloth.mp4"

cleanScene()
random.seed(33)

frames = 260
fps = 60


def apply_transform(obj):
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.select_set(False)


def set_principled_input(mat, name, value):
    node = mat.node_tree.nodes.get("Principled BSDF")
    if node and name in node.inputs:
        node.inputs[name].default_value = value


def add_look_at_camera(location, target, fov=45):
    bpy.ops.object.camera_add(location=location)
    cam = bpy.context.active_object
    direction = Vector(target) - cam.location
    cam.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = fov
    bpy.context.scene.camera = cam
    return cam


def make_noise_material(name, base, dark, roughness=0.8):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    bsdf = nodes.get("Principled BSDF")
    noise = nodes.new("ShaderNodeTexNoise")
    ramp = nodes.new("ShaderNodeValToRGB")

    noise.inputs["Scale"].default_value = 18.0
    noise.inputs["Detail"].default_value = 10.0
    noise.inputs["Roughness"].default_value = 0.62
    ramp.color_ramp.elements[0].position = 0.28
    ramp.color_ramp.elements[0].color = dark
    ramp.color_ramp.elements[1].position = 1.0
    ramp.color_ramp.elements[1].color = base

    links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = roughness
    return mat


grass_top = make_noise_material(
    "RealisticGrassTop",
    base=(0.22, 0.64, 0.12, 1),
    dark=(0.030, 0.16, 0.025, 1),
    roughness=0.92,
)
grass_side = make_noise_material(
    "GrassSide",
    base=(0.26, 0.54, 0.13, 1),
    dark=(0.10, 0.24, 0.055, 1),
    roughness=0.9,
)
dirt_side = make_noise_material(
    "LayeredDirt",
    base=(0.39, 0.23, 0.12, 1),
    dark=(0.16, 0.09, 0.045, 1),
    roughness=0.95,
)
bottom_dirt = make_noise_material(
    "PackedDirtBottom",
    base=(0.28, 0.17, 0.09, 1),
    dark=(0.11, 0.065, 0.035, 1),
    roughness=0.98,
)

# Minecraft grass block: visible cube, passive rigid body box, and cloth collision surface.
bpy.ops.mesh.primitive_cube_add(size=2.0, location=(0, 0, 1.0))
block = bpy.context.active_object
block.name = "RealisticMinecraftGrassBlock"
block.data.materials.append(grass_top)
block.data.materials.append(grass_side)
block.data.materials.append(dirt_side)
block.data.materials.append(bottom_dirt)

for poly in block.data.polygons:
    normal = poly.normal
    if normal.z > 0.8:
        poly.material_index = 0
    elif normal.z < -0.8:
        poly.material_index = 3
    else:
        poly.material_index = 2

apply_transform(block)
addRigidBody(block, body_type="PASSIVE", friction=0.92, restitution=0.04)
block.rigid_body.collision_shape = "BOX"

bpy.context.view_layer.objects.active = block
bpy.ops.object.modifier_add(type="COLLISION")
block.collision.thickness_outer = 0.018
block.collision.damping = 0.75


# Grass side cap: thin green band around the upper sides, like a Minecraft grass block.
for name, location, scale in [
    ("GrassBandFront", (0, -1.011, 1.72), (1.01, 0.012, 0.18)),
    ("GrassBandBack", (0, 1.011, 1.72), (1.01, 0.012, 0.18)),
    ("GrassBandLeft", (-1.011, 0, 1.72), (0.012, 1.01, 0.18)),
    ("GrassBandRight", (1.011, 0, 1.72), (0.012, 1.01, 0.18)),
]:
    band = addCube(location=location, size=2.0)
    band.name = name
    band.scale = scale
    applyMaterial(band, grass_side)

# Patchy top color plates add blocky Minecraft detail without changing collision.
grass_patch_mats = [
    makeMaterial("GrassPatchBright", color=(0.30, 0.72, 0.13, 1), metallic=0.0, roughness=0.92),
    makeMaterial("GrassPatchMoss", color=(0.12, 0.38, 0.07, 1), metallic=0.0, roughness=0.95),
    makeMaterial("GrassPatchDry", color=(0.42, 0.50, 0.18, 1), metallic=0.0, roughness=0.96),
]
for i in range(42):
    x = random.uniform(-0.88, 0.88)
    y = random.uniform(-0.88, 0.88)
    patch = addCube(location=(x, y, 2.006), size=1)
    patch.name = f"GrassPatch_{i}"
    patch.scale = (
        random.uniform(0.045, 0.16),
        random.uniform(0.045, 0.18),
        0.002,
    )
    patch.rotation_euler = (0, 0, random.uniform(0, math.pi))
    applyMaterial(patch, grass_patch_mats[i % len(grass_patch_mats)])

# Small grass tufts on top for realism. They are visual only, not collision geometry.
tuft_mats = [
    makeMaterial("GrassTuftsDark", color=(0.06, 0.32, 0.045, 1), metallic=0.0, roughness=0.88),
    makeMaterial("GrassTuftsFresh", color=(0.18, 0.58, 0.08, 1), metallic=0.0, roughness=0.86),
    makeMaterial("GrassTuftsYellow", color=(0.34, 0.46, 0.10, 1), metallic=0.0, roughness=0.9),
]
for i in range(155):
    x = random.uniform(-0.92, 0.92)
    y = random.uniform(-0.92, 0.92)
    h = random.uniform(0.035, 0.18)
    bpy.ops.mesh.primitive_cube_add(size=1, location=(x, y, 2.02 + h / 2))
    blade = bpy.context.active_object
    blade.name = f"GrassTuft_{i}"
    blade.scale = (
        random.uniform(0.004, 0.010),
        random.uniform(0.006, 0.018),
        h,
    )
    blade.rotation_euler = (
        random.uniform(-0.34, 0.34),
        random.uniform(-0.34, 0.34),
        random.uniform(0, math.pi),
    )
    applyMaterial(blade, tuft_mats[i % len(tuft_mats)])

# A few hanging side roots/grass pixels make the sides less flat.
root_mat = makeMaterial("TinyRoots", color=(0.20, 0.12, 0.055, 1), metallic=0.0, roughness=0.98)
for i in range(36):
    side = random.choice(["front", "back", "left", "right"])
    if side in ("front", "back"):
        x = random.uniform(-0.9, 0.9)
        y = -1.018 if side == "front" else 1.018
        scale = (random.uniform(0.006, 0.014), 0.004, random.uniform(0.04, 0.16))
    else:
        x = -1.018 if side == "left" else 1.018
        y = random.uniform(-0.9, 0.9)
        scale = (0.004, random.uniform(0.006, 0.014), random.uniform(0.04, 0.16))
    z = random.uniform(1.36, 1.82)
    root = addCube(location=(x, y, z), size=1)
    root.name = f"SideRoot_{i}"
    root.scale = scale
    applyMaterial(root, root_mat)

# Floor catches the cloth after it drapes off the block.
floor = addPlane(location=(0, 0, -0.02), size=8)
applyMaterial(floor, makeMaterial("StudioFloor", color=(0.035, 0.035, 0.04, 1), metallic=0.0, roughness=0.7))
bpy.context.view_layer.objects.active = floor
bpy.ops.object.modifier_add(type="COLLISION")
floor.collision.thickness_outer = 0.01


# Cloth sheet falling onto the block.
bpy.ops.mesh.primitive_plane_add(size=3.7, location=(0.05, -0.08, 4.65), rotation=(math.radians(7), math.radians(-4), math.radians(12)))
cloth = bpy.context.active_object
cloth.name = "FallingCloth"

bpy.ops.object.mode_set(mode="EDIT")
bpy.ops.mesh.subdivide(number_cuts=55)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.shade_smooth()

cloth_mat = bpy.data.materials.new("SoftCottonCloth")
cloth_mat.use_nodes = True
set_principled_input(cloth_mat, "Base Color", (0.88, 0.92, 0.86, 1))
set_principled_input(cloth_mat, "Roughness", 0.62)
set_principled_input(cloth_mat, "Sheen Weight", 0.55)
set_principled_input(cloth_mat, "Sheen Roughness", 0.75)
applyMaterial(cloth, cloth_mat)

bpy.context.view_layer.objects.active = cloth
bpy.ops.object.modifier_add(type="CLOTH")
cloth_mod = cloth.modifiers["Cloth"]
cloth_mod.settings.quality = 10
cloth_mod.settings.mass = 0.20
cloth_mod.settings.tension_stiffness = 8
cloth_mod.settings.compression_stiffness = 8
cloth_mod.settings.shear_stiffness = 4
cloth_mod.settings.bending_stiffness = 0.08
cloth_mod.settings.tension_damping = 2
cloth_mod.settings.compression_damping = 2
cloth_mod.settings.shear_damping = 2
cloth_mod.settings.bending_damping = 0.7
cloth_mod.settings.air_damping = 1.0
cloth_mod.collision_settings.use_collision = True
cloth_mod.collision_settings.use_self_collision = True
cloth_mod.collision_settings.distance_min = 0.012
cloth_mod.collision_settings.self_distance_min = 0.012

bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = frames
bpy.ops.ptcache.bake_all(bake=True)

# Camera and natural studio lighting.
add_look_at_camera(location=(4.8, -6.4, 3.2), target=(0, 0, 2.35), fov=45)
addSunLight(location=(-5, -4, 8), energy=2.2, color=(1.0, 0.96, 0.86))
addAreaLight(location=(-3.5, -4.5, 5.5), energy=420, color=(0.65, 0.78, 1.0), size=4.0)
addAreaLight(location=(3.5, 3.0, 4.5), energy=260, color=(1.0, 0.80, 0.58), size=3.5)
addAreaLight(location=(0, -2.0, 2.3), energy=100, color=(0.35, 0.80, 0.45), size=4.5)

setBackground(color=(0.50, 0.70, 0.88, 1))
setBackgroundStrength(0.85)

setupRender(frames=frames, fps=fps, resolution=(1920, 1080), engine="BLENDER_EEVEE")
renderFrames(str(FRAMES_DIR))

subprocess.run([
    "ffmpeg", "-y",
    "-framerate", str(fps),
    "-i", str(FRAMES_DIR / "frame_%04d.png"),
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    "-vf", "setpts=1.8*PTS",
    str(OUTPUT_VIDEO),
], check=True)

print(f"Done! Minecraft grass cloth video saved to {OUTPUT_VIDEO}")
