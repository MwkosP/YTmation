import math
import random
import subprocess
import sys
from pathlib import Path

import bpy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from utils import *

OUTPUTS_DIR = ROOT / "outputs"
FRAMES_DIR = OUTPUTS_DIR / "frames"
OUTPUT_VIDEO = OUTPUTS_DIR / "output_minecraft_voxel_collapse.mp4"

cleanScene()
random.seed(21)

frames = 190
fps = 60


def apply_box_collision(obj, *, body_type="ACTIVE", mass=1.0, friction=0.85, restitution=0.08):
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.select_set(False)
    addRigidBody(obj, body_type=body_type, mass=mass, friction=friction, restitution=restitution)
    obj.rigid_body.collision_shape = "BOX"
    return obj


def block_material(name, color, roughness=0.85):
    return makeMaterial(name, color=color, metallic=0.0, roughness=roughness)


grass_top = block_material("GrassTop", (0.20, 0.62, 0.16, 1))
dirt = block_material("Dirt", (0.38, 0.22, 0.11, 1))
stone = block_material("Stone", (0.42, 0.42, 0.42, 1))
wood = block_material("Wood", (0.45, 0.25, 0.10, 1))
leaf = block_material("Leaves", (0.10, 0.45, 0.13, 1))
diamond = makeEmissiveMaterial("DiamondOreGlow", color=(0.0, 0.85, 1.0, 1), strength=1.0)
tnt_red = block_material("TntRed", (0.82, 0.08, 0.06, 1))
tnt_white = block_material("TntWhite", (0.92, 0.86, 0.70, 1))
lava = makeEmissiveMaterial("Lava", color=(1.0, 0.30, 0.02, 1), strength=2.4)


def add_voxel(name, location, mat, *, scale=(0.5, 0.5, 0.5), active=True, mass=1.0):
    block = addCube(location=location, size=1)
    block.name = name
    block.scale = scale
    applyMaterial(block, mat)
    apply_box_collision(
        block,
        body_type="ACTIVE" if active else "PASSIVE",
        mass=mass,
        friction=0.88,
        restitution=0.05,
    )
    if active:
        block.rigid_body.linear_damping = 0.04
        block.rigid_body.angular_damping = 0.10
    return block


# Ground platform made from passive voxel blocks.
for x in range(-5, 6):
    for y in range(-4, 5):
        top_mat = grass_top if random.random() > 0.18 else stone
        add_voxel(f"Ground_{x}_{y}", (x * 0.52, y * 0.52, 0), top_mat, active=False)
        if (x + y) % 4 == 0:
            add_voxel(f"DirtUnder_{x}_{y}", (x * 0.52, y * 0.52, -0.52), dirt, active=False)

# Lava trench for color and contrast.
for y in range(-4, 5):
    add_voxel(f"Lava_{y}", (0, y * 0.52, 0.035), lava, scale=(0.42, 0.42, 0.04), active=False)

# A simple block tower that collapses into the trench.
tower_blocks = []
for z in range(1, 9):
    radius = max(1, 4 - z // 2)
    for x in range(-radius, radius + 1):
        for y in range(-radius, radius + 1):
            if abs(x) == radius or abs(y) == radius or random.random() > 0.42:
                mat = [stone, dirt, grass_top, wood][(x + y + z) % 4]
                block = add_voxel(
                    f"Tower_{x}_{y}_{z}",
                    (x * 0.52 - 1.15, y * 0.52, z * 0.52 + 0.25),
                    mat,
                    active=True,
                    mass=0.55,
                )
                block.rotation_euler = (
                    random.uniform(-0.04, 0.04),
                    random.uniform(-0.04, 0.04),
                    random.uniform(-0.10, 0.10),
                )
                tower_blocks.append(block)

# Falling diamond ore cubes add readable Minecraft-style rewards.
for i in range(8):
    block = add_voxel(
        f"DiamondOre_{i}",
        (random.uniform(-2.2, 2.2), random.uniform(-1.8, 1.8), 5.6 + i * 0.25),
        diamond,
        active=True,
        mass=0.45,
    )
    block.rotation_euler = (random.random(), random.random(), random.random())

# TNT cube drops from above and knocks the tower apart.
tnt = add_voxel("TNT_Core", (-1.85, -0.10, 6.2), tnt_red, scale=(0.62, 0.62, 0.62), active=True, mass=4.0)
tnt.rigid_body.restitution = 0.2
tnt.rigid_body.friction = 0.45

# White band around TNT.
for offset in (-0.33, 0.33):
    add_voxel(f"TNT_Band_{offset}", (-1.85, -0.10 + offset, 6.2), tnt_white, scale=(0.64, 0.035, 0.64), active=True, mass=0.08)

# Small blocky tree in the background.
for z in range(1, 5):
    add_voxel(f"TreeTrunk_{z}", (2.75, 1.75, z * 0.52), wood, active=False)

for x in range(-1, 2):
    for y in range(-1, 2):
        for z in range(5, 8):
            if abs(x) + abs(y) + abs(z - 6) <= 3:
                add_voxel(f"Leaf_{x}_{y}_{z}", (2.75 + x * 0.48, 1.75 + y * 0.48, z * 0.48), leaf, active=False)

bakePhysics(frame_start=1, frame_end=frames)

# Camera and lighting: bright, toy-like, readable blocks.
addCamera(location=(3.8, -7.6, 4.4), rotation=(math.radians(60), 0, math.radians(28)), fov=38)
addSunLight(location=(-3, -4, 8), energy=2.6, color=(1.0, 0.96, 0.86))
addAreaLight(location=(0, -4, 6), energy=420, color=(0.55, 0.72, 1.0), size=5.0)
addAreaLight(location=(3.5, 2.5, 4), energy=240, color=(1.0, 0.55, 0.30), size=3.0)

setBackground(color=(0.45, 0.72, 1.0, 1))
setBackgroundStrength(0.9)

setupRender(frames=frames, fps=fps, resolution=(1920, 1080), engine="BLENDER_EEVEE")
renderFrames(str(FRAMES_DIR))

subprocess.run([
    "ffmpeg", "-y",
    "-framerate", str(fps),
    "-i", str(FRAMES_DIR / "frame_%04d.png"),
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    "-vf", "setpts=1.5*PTS",
    str(OUTPUT_VIDEO),
], check=True)

print(f"Done! Minecraft voxel collapse saved to {OUTPUT_VIDEO}")
