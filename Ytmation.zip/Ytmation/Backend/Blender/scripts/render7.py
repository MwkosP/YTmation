import bpy
import sys
import math
import subprocess
import os
sys.path.append('/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()

frames = 350

# ─── PLATFORM ────────────────────────────────────────────
platform = addPlane(location=(0, 0, 0), size=30)
addRigidBody(platform, body_type='PASSIVE', friction=0.8, restitution=0.1)
applyMaterial(platform, makeGlossyMaterial('Floor', color=(0.02, 0.02, 0.02, 1)))

# ─── DOMINOES IN SPIRAL PATTERN ──────────────────────────
neon_colors = [
    (1.0, 0.0, 0.5, 1),   # hot pink
    (0.0, 1.0, 0.8, 1),   # cyan
    (1.0, 0.5, 0.0, 1),   # orange
    (0.5, 0.0, 1.0, 1),   # purple
    (0.0, 0.8, 1.0, 1),   # blue
    (1.0, 1.0, 0.0, 1),   # yellow
]

num_dominoes = 60
domino_width  = 0.15
domino_height = 0.8
domino_depth  = 0.35
spacing = 0.9

dominoes = []

for i in range(num_dominoes):
    t = i / num_dominoes
    # spiral layout
    angle = t * 4 * math.pi          # 2 full loops
    radius = 1.5 + t * 5.5           # expands outward

    x = math.cos(angle) * radius
    y = math.sin(angle) * radius
    z = domino_height / 2

    # rotate domino to face along spiral tangent
    tangent_angle = angle + math.pi / 2
    rotation = (0, 0, tangent_angle)

    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(x, y, z)
    )
    domino = bpy.context.active_object
    domino.scale = (domino_width, domino_depth, domino_height / 2)
    domino.rotation_euler = rotation
    domino.name = f'Domino_{i}'

    # cycle through neon colors
    color = neon_colors[i % len(neon_colors)]
    mat = makeEmissiveMaterial(f'NeonDomino_{i}', color=color, strength=2.0)
    applyMaterial(domino, mat)

    addRigidBody(domino, body_type='ACTIVE', mass=0.5, restitution=0.1, friction=0.9)
    dominoes.append(domino)

# ─── INVISIBLE PUSHER HITS FIRST DOMINO ──────────────────
bpy.ops.mesh.primitive_cube_add(size=0.3, location=(
    dominoes[0].location.x - 0.5,
    dominoes[0].location.y,
    domino_height / 2
))
pusher = bpy.context.active_object
pusher.name = 'Pusher'

# make it invisible
pusher.hide_render = True
pusher.display_type = 'WIRE'

addRigidBody(pusher, body_type='ACTIVE', mass=5.0, restitution=0.0, friction=0.9)

# push along the domino's facing direction (tangent of spiral)
first_angle = 0  # angle of first domino in spiral
push_dir_x = math.cos(first_angle)
push_dir_y = math.sin(first_angle)

pusher.location.x = dominoes[0].location.x - push_dir_x * 3
pusher.location.y = dominoes[0].location.y - push_dir_y * 3
pusher.keyframe_insert(data_path='location', frame=1)

pusher.location.x = dominoes[0].location.x + push_dir_x * 0.3
pusher.location.y = dominoes[0].location.y + push_dir_y * 0.3
pusher.keyframe_insert(data_path='location', frame=15)
pusher.rigid_body.kinematic = True

# switch to dynamic after hitting
pusher.keyframe_insert(data_path='rigid_body.kinematic', frame=1)
pusher.rigid_body.kinematic = False
pusher.keyframe_insert(data_path='rigid_body.kinematic', frame=15)

# ─── BAKE PHYSICS ────────────────────────────────────────
bakePhysics(frame_start=1, frame_end=frames)

# ─── CAMERA - wide overhead + slight angle ───────────────
bpy.ops.object.camera_add(location=(0, -18, 22))
cam = bpy.context.active_object
cam.rotation_euler = (math.radians(50), 0, 0)
cam.data.lens = 18   # wide angle to see entire field
bpy.context.scene.camera = cam

# ─── NEON LIGHTING ───────────────────────────────────────
addAreaLight(location=(0, 0, 15),   energy=200,  color=(1, 1, 1),       size=8)
addAreaLight(location=(-8, -8, 6),  energy=800,  color=(0.0, 0.5, 1.0), size=3)
addAreaLight(location=(8,  8,  6),  energy=800,  color=(1.0, 0.0, 0.5), size=3)
addAreaLight(location=(8,  -8, 6),  energy=600,  color=(0.5, 0.0, 1.0), size=3)
addAreaLight(location=(-8,  8, 6),  energy=600,  color=(1.0, 0.8, 0.0), size=3)

# ─── BACKGROUND ──────────────────────────────────────────
setBackground(color=(0.0, 0.0, 0.0, 1))

# ─── RENDER ──────────────────────────────────────────────
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
renderFrames(frames_dir)

subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=1.8*PTS',
    '/home/zolo/Desktop/YT/3d/output_dominoes.mp4'
])

print("Done! Neon dominoes video saved to output_dominoes.mp4")