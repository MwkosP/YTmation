import bpy
import sys
sys.path.append('/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()

# slow motion - render at high fps, export at low fps
frames = 250

# platform
platform = addPlane(location=(0, 0, 0), size=14)
addRigidBody(platform, body_type='PASSIVE', friction=0.3, restitution=0.8)
applyMaterial(platform, makeGlossyMaterial('Floor', color=(0.05, 0.05, 0.08, 1)))

# balls config: (location, color, size, mass)
balls_config = [
    ((0,    0,  12), (1.0, 0.2, 0.2, 1), 0.6, 1.0),   # red
    ((-2,   1,  16), (0.2, 0.6, 1.0, 1), 0.5, 0.8),   # blue
    ((2,   -1,  14), (0.2, 1.0, 0.4, 1), 0.7, 1.2),   # green
    ((-1,  -2,  18), (1.0, 0.8, 0.0, 1), 0.4, 0.6),   # yellow
    ((1.5,  2,  10), (1.0, 0.3, 0.8, 1), 0.55, 0.9),  # pink
    ((-2.5, 0,  20), (0.4, 1.0, 1.0, 1), 0.65, 1.1),  # cyan
]

for pos, color, size, mass in balls_config:
    ball = addSphere(location=pos, radius=size)
    addRigidBody(ball, body_type='ACTIVE', mass=mass, restitution=0.85, friction=0.2)
    mat = makeGlossyMaterial(f'BallMat_{color}', color=color)
    applyMaterial(ball, mat)

# bake physics
bakePhysics(frame_start=1, frame_end=frames)

# dramatic low angle camera
addCamera(location=(9, -9, 3), rotation=(1.2, 0, 0.785), fov=35)

# lighting
addThreePointLighting(energy_key=1200, energy_fill=400, energy_back=600)
addSpotLight(location=(0, 0, 15), energy=3000, color=(1, 1, 1), spot_size=1.2)

# dark glossy background
setBackground(color=(0.01, 0.01, 0.02, 1))

# render - high fps for slow motion feel
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
renderFrames(frames_dir)

# export at 24fps = slow motion effect
import subprocess
subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=2.5*PTS',  # slow it down 2.5x
    '/home/zolo/Desktop/YT/3d/output_balls.mp4'
])

print("Done! Slow motion balls video saved!")