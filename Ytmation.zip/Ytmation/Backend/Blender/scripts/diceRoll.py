import bpy
import sys
import math
import subprocess
import os
import random
sys.path.insert(0, '/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()
random.seed(42)

frames = 200

# ─── FLOOR ───────────────────────────────────────────────
floor = addPlane(location=(0, 0, 0), size=20)
addRigidBody(floor, body_type='PASSIVE', friction=0.8, restitution=0.3)
applyMaterial(floor, makeGlossyMaterial('Floor', color=(0.02, 0.02, 0.03, 1)))

# ─── DICE COLORS ─────────────────────────────────────────
neon_colors = [
    (1.0, 0.0, 0.5, 1),   # pink
    (0.0, 1.0, 0.8, 1),   # cyan
    (1.0, 0.5, 0.0, 1),   # orange
    (0.5, 0.0, 1.0, 1),   # purple
    (0.0, 0.8, 1.0, 1),   # blue
    (1.0, 1.0, 0.0, 1),   # yellow
]

# ─── CREATE DICE ─────────────────────────────────────────
num_dice = 6
dice = []

for i in range(num_dice):
    # random start position high up and spread out
    x = random.uniform(-3, 3)
    y = random.uniform(-2, 2)
    z = random.uniform(5, 12)

    bpy.ops.mesh.primitive_cube_add(size=0.7, location=(x, y, z))
    die = bpy.context.active_object
    die.name = f'Die_{i}'

    # round the corners with subdivision + bevel
    bpy.ops.object.modifier_add(type='BEVEL')
    die.modifiers['Bevel'].width    = 0.08
    die.modifiers['Bevel'].segments = 4
    bpy.ops.object.modifier_add(type='SUBSURF')
    die.modifiers['Subdivision'].levels = 2
    bpy.ops.object.shade_smooth()

    # random initial rotation
    die.rotation_euler = (
        random.uniform(0, math.pi * 2),
        random.uniform(0, math.pi * 2),
        random.uniform(0, math.pi * 2)
    )

    # emissive neon material
    color = neon_colors[i % len(neon_colors)]
    mat = makeEmissiveMaterial(f'DiceMat_{i}', color=color, strength=1.5)

    # also add glossy on top of emissive for reflections
    mat2 = makeGlossyMaterial(f'DiceGlossy_{i}', color=color)
    die.data.materials.append(mat)
    die.data.materials.append(mat2)

    # rigid body - bouncy
    addRigidBody(die, body_type='ACTIVE', mass=1.0, restitution=0.4, friction=0.6)

    # give initial random spin velocity via angular keyframes
    die.rigid_body.angular_damping = 0.1
    die.rigid_body.linear_damping  = 0.05

    dice.append(die)

# ─── BAKE PHYSICS ────────────────────────────────────────
bakePhysics(frame_start=1, frame_end=frames)

# ─── CAMERA - low dramatic angle ─────────────────────────
addCamera(
    location=(0, -9, 3.5),
    rotation=(math.radians(75), 0, 0),
    fov=40
)

# ─── LIGHTING ────────────────────────────────────────────
# top soft white
addAreaLight(location=(0,  0,  12), energy=300,  color=(1.0, 1.0, 1.0), size=6)
# neon sides
addAreaLight(location=(-6, -4, 4),  energy=1000, color=(0.0, 0.5, 1.0), size=3)
addAreaLight(location=(6,  -4, 4),  energy=1000, color=(1.0, 0.0, 0.5), size=3)
addAreaLight(location=(0,   5, 4),  energy=500,  color=(0.5, 0.0, 1.0), size=3)
# dramatic floor bounce
addAreaLight(location=(0,   0, 0.5),energy=200,  color=(0.0, 1.0, 0.8), size=4)

# ─── BACKGROUND ──────────────────────────────────────────
setBackground(color=(0.0, 0.0, 0.0, 1))

# ─── RENDER ──────────────────────────────────────────────
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
renderFrames(frames_dir)

subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=2.0*PTS',
    '/home/zolo/Desktop/YT/3d/outputs/output_dice.mp4'
])

print("Done! Dice video saved to output_dice.mp4")