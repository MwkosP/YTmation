import bpy
import sys
import math
import subprocess
import os
sys.path.insert(0, '/home/zolo/Desktop/YT/3d/')
from utils import *

cleanScene()

frames = 250

# ─── FRAME / STRUCTURE ───────────────────────────────────
frame_color = (0.0, 0.8, 1.0, 1)  # cyan neon

# top bar
bpy.ops.mesh.primitive_cylinder_add(radius=0.05, depth=5.5, location=(0, 0, 3))
top_bar = bpy.context.active_object
top_bar.rotation_euler = (0, math.radians(90), 0)
applyMaterial(top_bar, makeEmissiveMaterial('TopBar', color=frame_color, strength=2))

# left leg front
bpy.ops.mesh.primitive_cylinder_add(radius=0.05, depth=3, location=(-2.5, -0.8, 1.5))
applyMaterial(bpy.context.active_object, makeEmissiveMaterial('Leg', color=frame_color, strength=2))

# left leg back
bpy.ops.mesh.primitive_cylinder_add(radius=0.05, depth=3, location=(-2.5, 0.8, 1.5))
applyMaterial(bpy.context.active_object, makeEmissiveMaterial('Leg', color=frame_color, strength=2))

# right leg front
bpy.ops.mesh.primitive_cylinder_add(radius=0.05, depth=3, location=(2.5, -0.8, 1.5))
applyMaterial(bpy.context.active_object, makeEmissiveMaterial('Leg', color=frame_color, strength=2))

# right leg back
bpy.ops.mesh.primitive_cylinder_add(radius=0.05, depth=3, location=(2.5, 0.8, 1.5))
applyMaterial(bpy.context.active_object, makeEmissiveMaterial('Leg', color=frame_color, strength=2))

# base bar front
bpy.ops.mesh.primitive_cylinder_add(radius=0.05, depth=5.5, location=(0, -0.8, 0))
base_f = bpy.context.active_object
base_f.rotation_euler = (0, math.radians(90), 0)
applyMaterial(base_f, makeEmissiveMaterial('Base', color=frame_color, strength=2))

# base bar back
bpy.ops.mesh.primitive_cylinder_add(radius=0.05, depth=5.5, location=(0, 0.8, 0))
base_b = bpy.context.active_object
base_b.rotation_euler = (0, math.radians(90), 0)
applyMaterial(base_b, makeEmissiveMaterial('Base', color=frame_color, strength=2))

# ─── BALLS ───────────────────────────────────────────────
num_balls = 5
ball_radius = 0.38
spacing = ball_radius * 2 + 0.01
string_length = 3.0
ball_colors = [
    (1.0, 0.0, 0.5, 1),   # pink
    (0.0, 1.0, 0.8, 1),   # cyan
    (1.0, 0.5, 0.0, 1),   # orange
    (0.5, 0.0, 1.0, 1),   # purple
    (0.0, 0.8, 1.0, 1),   # blue
]

balls = []
rest_z = 3.0 - string_length  # resting height

for i in range(num_balls):
    x = (i - (num_balls - 1) / 2) * spacing
    bpy.ops.mesh.primitive_uv_sphere_add(radius=ball_radius, location=(x, 0, rest_z))
    ball = bpy.context.active_object
    ball.name = f'Ball_{i}'
    bpy.ops.object.shade_smooth()
    applyMaterial(ball, makeGlossyMaterial(f'BallMat_{i}', color=ball_colors[i]))
    balls.append(ball)

# ─── STRINGS ─────────────────────────────────────────────
for i, ball in enumerate(balls):
    x = ball.location.x
    mid_z = (3.0 + rest_z) / 2

    bpy.ops.mesh.primitive_cylinder_add(
        radius=0.008,
        depth=string_length,
        location=(x, -0.3, mid_z)
    )
    s1 = bpy.context.active_object
    applyMaterial(s1, makeEmissiveMaterial(f'String_{i}_f', color=(1,1,1,1), strength=0.5))

    bpy.ops.mesh.primitive_cylinder_add(
        radius=0.008,
        depth=string_length,
        location=(x, 0.3, mid_z)
    )
    s2 = bpy.context.active_object
    applyMaterial(s2, makeEmissiveMaterial(f'String_{i}_b', color=(1,1,1,1), strength=0.5))

# ─── ANIMATE FIRST BALL SWINGING ─────────────────────────
# ─── ANIMATE - proper pendulum math ──────────────────────
import math

string_length = 3.0
pivot_z = 3.0
swing_angle = math.radians(50)
period = 35  # frames per half swing

def getBallPos(pivot_x, angle):
    x = pivot_x + string_length * math.sin(angle)
    z = pivot_z - string_length * math.cos(angle)
    return x, z

pivots = [ball.location.x for ball in balls]

for frame in range(frames + 1):
    t = frame / period * math.pi

    # cycle: ball 0 swings in, ball 4 swings out, repeat
    cycle = (frame // period) % 4

    for i, ball in enumerate(balls):
        if cycle == 0:
            # ball 0 swings right toward rest
            angle = swing_angle * math.cos(t) if i == 0 else 0.0
        elif cycle == 1:
            # ball 4 swings left away
            angle = -swing_angle * math.cos(t) if i == 4 else 0.0
        elif cycle == 2:
            # ball 4 swings back
            angle = -swing_angle * math.cos(t) if i == 4 else 0.0
        else:
            # ball 0 swings out again
            angle = swing_angle * math.cos(t) if i == 0 else 0.0

        x, z = getBallPos(pivots[i], angle)
        ball.location.x = x
        ball.location.z = z
        ball.keyframe_insert(data_path='location', frame=frame)

# ─── CAMERA - front straight on ──────────────────────────
addCamera(location=(0, -10, 1.5), rotation=(math.radians(90), 0, 0), fov=50)

# ─── LIGHTING ────────────────────────────────────────────
addAreaLight(location=(0,  -6, 6),  energy=800,  color=(1.0, 1.0, 1.0), size=4)
addAreaLight(location=(-5, -3, 3),  energy=600,  color=(0.0, 0.5, 1.0), size=3)
addAreaLight(location=(5,  -3, 3),  energy=600,  color=(1.0, 0.0, 0.5), size=3)
addAreaLight(location=(0,   4, 5),  energy=200,  color=(0.5, 0.0, 1.0), size=2)

# ─── BACKGROUND ──────────────────────────────────────────
setBackground(color=(0.0, 0.0, 0.0, 1))

# ─── RENDER ──────────────────────────────────────────────
setupRender(frames=frames, fps=60, resolution=(1920, 1080), engine='BLENDER_EEVEE')

frames_dir = '/home/zolo/Desktop/YT/3d/frames/'
renderFrames(frames_dir)

subprocess.run([
    'ffmpeg', '-y',
    '-framerate', '60',
    '-i', frames_dir + 'frame_%04d.png',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-vf', 'setpts=2.0*PTS',
    '/home/zolo/Desktop/YT/3d/outputs/output_cradle.mp4'
])

print("Done! Newton's cradle saved to output_cradle.mp4")