# Blender - 3D physics renders

Creates short 3D animations and physics simulations for YouTube visuals. Use this module for rendered clips such as dice rolls, fluid pours, falling chains, glass breaks, dominoes, marble runs, kinetic sculptures, and product/object turntables.

## Layout

```text
Blender/
├── SKILL.md
├── main.py
├── utils.py
├── scripts/
│   ├── chainFalling.py
│   ├── diceRoll.py
│   ├── earthOrbit.py
│   ├── fluid.py
│   ├── glassShatter.py
│   ├── marbleCascade.py
│   ├── minecraftGrassCloth.py
│   ├── minecraftVoxelCollapse.py
│   ├── satisfyingBlockDrop.py
│   └── ...
├── frames/
├── outputs/
└── TripoSR/
```

Outputs should go to `Blender/outputs/`. Temporary rendered PNG frames should go to `Blender/outputs/frames/` or `Blender/frames/`.

## When To Use

Use Blender when a storyboard scene asks for:

- physics objects falling, rolling, bouncing, breaking, pouring, or colliding
- cinematic object renders or 3D product shots
- abstract visual loops for shorts
- AI image-to-3D assets through `Blender/TripoSR/`

## Script Pattern

Each render script in `Blender/scripts/` should:

1. Add `Blender/` to `sys.path`.
2. Import helpers from `utils.py`.
3. Call `cleanScene()`.
4. Build objects, materials, camera, lights, and physics.
5. Bake physics when needed.
6. Render PNG frames.
7. Convert frames to `.mp4` with ffmpeg.

Recommended path setup:

```python
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from utils import *

OUTPUTS_DIR = ROOT / "outputs"
FRAMES_DIR = OUTPUTS_DIR / "frames"
```

## Run

From the repo root:

```bash
/home/zolo/Desktop/Apps/blender-5.1.1-linux-x64/blender --background --python Blender/scripts/marbleCascade.py
/home/zolo/Desktop/Apps/blender-5.1.1-linux-x64/blender --background --python Blender/scripts/earthOrbit.py
/home/zolo/Desktop/Apps/blender-5.1.1-linux-x64/blender --background --python Blender/scripts/minecraftGrassCloth.py
/home/zolo/Desktop/Apps/blender-5.1.1-linux-x64/blender --background --python Blender/scripts/minecraftVoxelCollapse.py
/home/zolo/Desktop/Apps/blender-5.1.1-linux-x64/blender --background --python Blender/scripts/satisfyingBlockDrop.py
```

Or from Python:

```python
from Blender.main import runScript

runScript("earthOrbit")
runScript("marbleCascade")
runScript("minecraftGrassCloth")
runScript("minecraftVoxelCollapse")
runScript("satisfyingBlockDrop")
```

## Existing Helpers

`Blender/utils.py` provides:

| Helper | Purpose |
|--------|---------|
| `cleanScene()` | Clear the active Blender scene |
| `setupRender()` | Configure frames, FPS, resolution, engine |
| `renderFrames()` | Render numbered PNG frames |
| `renderToVideo()` | Convert frames to mp4 with ffmpeg |
| `addCamera()` / `addOrbitCamera()` | Add static or animated cameras |
| `addAreaLight()` / `addSunLight()` | Add lighting |
| `makeMaterial()` / `makeEmissiveMaterial()` | Create reusable materials |
| `addRigidBody()` / `bakePhysics()` | Add and bake rigid body physics |

## Storyboard Fit

Typical storyboard scene fields:

```json
{
  "module": "Blender",
  "type": "physics",
  "visual": "neon marbles cascade through glass ramps",
  "sfx": "impact_heavy"
}
```

Name scripts after the visual concept, keep outputs predictable, and prefer reusable helpers over duplicating render setup.
