"""
Blender Abstractions
---------------------
High-level bpy helper functions. Import these inside Blender scripts.
Never called directly from workflows — used by scripts/ only.

Usage inside a script:
    from blenderAbstractions import (
        cleanScene, setupRender, addCamera,
        addRigidBody, makeMaterial, renderFrames
    )
"""

import bpy
import math
import os


# ─── SCENE ───────────────────────────────────────────────────────────────────

def cleanScene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete()
    bpy.ops.outliner.orphans_purge(do_recursive=True)


def setBackground(color=(0, 0, 0, 1)):
    world = bpy.context.scene.world
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs[0].default_value = color


def setBackgroundStrength(strength=1.0):
    world = bpy.context.scene.world
    world.use_nodes = True
    world.node_tree.nodes['Background'].inputs[1].default_value = strength


def setGravity(x=0, y=0, z=-9.8):
    bpy.context.scene.gravity = (x, y, z)


# ─── RENDER ──────────────────────────────────────────────────────────────────

def setupRender(
    frames=120,
    fps=24,
    resolution=(1080, 1920),
    engine='BLENDER_EEVEE',
    samples=128,
):
    scene = bpy.context.scene
    scene.frame_start = 0
    scene.frame_end = frames
    scene.render.fps = fps
    scene.render.resolution_x = resolution[0]
    scene.render.resolution_y = resolution[1]
    scene.render.engine = engine
    scene.render.image_settings.file_format = 'PNG'

    if engine == 'CYCLES':
        scene.cycles.samples = samples


def setupRenderFromEnv():
    """Read render config from env vars set by utils._runBlender and apply."""
    from utils import _getConfig
    cfg = _getConfig()
    setupRender(
        frames=cfg["frames"],
        fps=cfg["fps"],
        resolution=(cfg["res_x"], cfg["res_y"]),
        engine=cfg["engine"],
        samples=cfg["samples"],
    )
    return cfg


def renderFrames(output_dir):
    os.makedirs(output_dir, exist_ok=True)
    for f in os.listdir(output_dir):
        if f.endswith('.png'):
            os.remove(os.path.join(output_dir, f))
    bpy.context.scene.render.filepath = os.path.join(output_dir, 'frame_')
    bpy.ops.render.render(animation=True)


# ─── CAMERA ──────────────────────────────────────────────────────────────────

def addCamera(location=(3, -3, 2), rotation=(1.1, 0, 0.785), fov=50):
    bpy.ops.object.camera_add(location=location)
    cam = bpy.context.active_object
    cam.rotation_euler = rotation
    cam.data.lens = fov
    bpy.context.scene.camera = cam
    return cam


def addOrbitCamera(radius=4, height=2, frames=120):
    cam_data = bpy.data.cameras.new('OrbitCamera')
    cam_obj  = bpy.data.objects.new('OrbitCamera', cam_data)
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj

    for i in range(frames + 1):
        t     = i / frames
        angle = t * 2 * math.pi
        cam_obj.location = (
            math.sin(angle) * radius,
            -math.cos(angle) * radius,
            height,
        )
        direction = cam_obj.location.copy()
        direction.negate()
        rot_quat = direction.to_track_quat('-Z', 'Y')
        cam_obj.rotation_euler = rot_quat.to_euler()
        cam_obj.keyframe_insert(data_path='location',       frame=i)
        cam_obj.keyframe_insert(data_path='rotation_euler', frame=i)

    return cam_obj


def addSpiralCamera(radius=4, height_start=0.5, height_end=4, frames=120):
    cam_data = bpy.data.cameras.new('SpiralCamera')
    cam_obj  = bpy.data.objects.new('SpiralCamera', cam_data)
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj

    for i in range(frames + 1):
        t      = i / frames
        angle  = t * 2 * math.pi
        height = height_start + t * (height_end - height_start)
        cam_obj.location = (
            math.sin(angle) * radius,
            -math.cos(angle) * radius,
            height,
        )
        direction = cam_obj.location.copy()
        direction.negate()
        rot_quat = direction.to_track_quat('-Z', 'Y')
        cam_obj.rotation_euler = rot_quat.to_euler()
        cam_obj.keyframe_insert(data_path='location',       frame=i)
        cam_obj.keyframe_insert(data_path='rotation_euler', frame=i)

    return cam_obj


# ─── LIGHTS ──────────────────────────────────────────────────────────────────

def addSunLight(location=(5, 5, 10), energy=3, color=(1, 1, 1)):
    bpy.ops.object.light_add(type='SUN', location=location)
    light = bpy.context.active_object
    light.data.energy = energy
    light.data.color  = color
    return light


def addAreaLight(location=(0, 0, 5), energy=500, color=(1, 1, 1), size=2):
    bpy.ops.object.light_add(type='AREA', location=location)
    light = bpy.context.active_object
    light.data.energy = energy
    light.data.color  = color
    light.data.size   = size
    return light


def addPointLight(location=(0, 0, 5), energy=500, color=(1, 1, 1)):
    bpy.ops.object.light_add(type='POINT', location=location)
    light = bpy.context.active_object
    light.data.energy = energy
    light.data.color  = color
    return light


def addThreePointLighting(energy_key=800, energy_fill=300, energy_back=500):
    key  = addAreaLight(location=(-4, -2, 4), energy=energy_key,  color=(1.0, 0.95, 0.9))
    fill = addAreaLight(location=(4,  -2, 2), energy=energy_fill, color=(0.7, 0.85, 1.0))
    back = addAreaLight(location=(0,   4, 5), energy=energy_back, color=(1.0, 0.9,  0.8))
    return key, fill, back


def addNeonLighting(color_left=(0, 0.5, 1), color_right=(1, 0, 0.8), energy=500):
    left  = addAreaLight(location=(-3, -1, 2), energy=energy, color=color_left)
    right = addAreaLight(location=(3,  -1, 2), energy=energy, color=color_right)
    return left, right


# ─── MATERIALS ───────────────────────────────────────────────────────────────

def makeMaterial(name, color=(1, 1, 1, 1), metallic=0.0, roughness=0.5):
    mat  = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes['Principled BSDF']
    bsdf.inputs['Base Color'].default_value = color
    bsdf.inputs['Metallic'].default_value   = metallic
    bsdf.inputs['Roughness'].default_value  = roughness
    return mat


def makeGlossyMaterial(name, color=(1, 1, 1, 1)):
    return makeMaterial(name, color=color, metallic=0.9, roughness=0.05)


def makeMetallicMaterial(name, color=(0.8, 0.8, 0.8, 1)):
    return makeMaterial(name, color=color, metallic=1.0, roughness=0.2)


def makeGlassMaterial(name):
    mat   = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out   = nodes.new('ShaderNodeOutputMaterial')
    glass = nodes.new('ShaderNodeBsdfGlass')
    glass.inputs['IOR'].default_value = 1.45
    links.new(glass.outputs['BSDF'], out.inputs['Surface'])
    mat.blend_method = 'BLEND'
    return mat


def makeEmissiveMaterial(name, color=(0, 1, 0.8, 1), strength=3.0):
    mat   = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out      = nodes.new('ShaderNodeOutputMaterial')
    emission = nodes.new('ShaderNodeEmission')
    emission.inputs['Color'].default_value    = color
    emission.inputs['Strength'].default_value = strength
    links.new(emission.outputs['Emission'], out.inputs['Surface'])
    return mat


def applyMaterial(obj, mat):
    obj.data.materials.clear()
    obj.data.materials.append(mat)


# ─── OBJECTS ─────────────────────────────────────────────────────────────────

def addCube(location=(0, 0, 0), size=1):
    bpy.ops.mesh.primitive_cube_add(size=size, location=location)
    return bpy.context.active_object


def addSphere(location=(0, 0, 0), radius=1):
    bpy.ops.mesh.primitive_uv_sphere_add(radius=radius, location=location)
    return bpy.context.active_object


def addPlane(location=(0, 0, 0), size=10):
    bpy.ops.mesh.primitive_plane_add(size=size, location=location)
    return bpy.context.active_object


def addCylinder(location=(0, 0, 0), radius=1, depth=2):
    bpy.ops.mesh.primitive_cylinder_add(radius=radius, depth=depth, location=location)
    return bpy.context.active_object


def addText(text="Hello", location=(0, 0, 0), size=1):
    bpy.ops.object.text_add(location=location)
    obj = bpy.context.active_object
    obj.data.body = text
    obj.data.size = size
    return obj


def centerObject(obj):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
    obj.location = (0, 0, 0)


def moveObject(obj, location=(0, 0, 0)):
    obj.location = location


def scaleObject(obj, scale=(1, 1, 1)):
    obj.scale = scale


def rotateObject(obj, rotation=(0, 0, 0)):
    obj.rotation_euler = rotation


# ─── ANIMATION ───────────────────────────────────────────────────────────────

def addRotationSpin(obj, frames=120, axis='Z', tilt=0.2):
    for i in range(frames + 1):
        angle = (i / frames) * 2 * math.pi
        if axis == 'Z':
            obj.rotation_euler = (tilt, 0, angle)
        elif axis == 'Y':
            obj.rotation_euler = (tilt, angle, 0)
        elif axis == 'X':
            obj.rotation_euler = (angle, 0, tilt)
        obj.keyframe_insert(data_path='rotation_euler', frame=i)


def addBounceAnimation(obj, frames=120, height=3):
    for i in range(frames + 1):
        t = i / frames
        y = abs(math.sin(t * math.pi * 4)) * height
        obj.location.z = y
        obj.keyframe_insert(data_path='location', frame=i)


def addPulseAnimation(obj, frames=120, min_scale=0.8, max_scale=1.2):
    for i in range(frames + 1):
        t = i / frames
        s = min_scale + (max_scale - min_scale) * (0.5 + 0.5 * math.sin(t * math.pi * 4))
        obj.scale = (s, s, s)
        obj.keyframe_insert(data_path='scale', frame=i)


def addFlyInAnimation(obj, start_location, end_location=(0, 0, 0), frame_start=0, frame_end=40):
    obj.location = start_location
    obj.keyframe_insert(data_path='location', frame=frame_start)
    obj.location = end_location
    obj.keyframe_insert(data_path='location', frame=frame_end)


# ─── PHYSICS ─────────────────────────────────────────────────────────────────

def addRigidBody(obj, body_type='ACTIVE', mass=1.0, restitution=0.3, friction=0.8):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.rigidbody.object_add()
    obj.rigid_body.type        = body_type
    obj.rigid_body.mass        = mass
    obj.rigid_body.restitution = restitution
    obj.rigid_body.friction    = friction


def addClothModifier(obj, quality=5, mass=0.3, tension=15, compression=15):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_add(type='CLOTH')
    cloth = obj.modifiers['Cloth'].settings
    cloth.quality          = quality
    cloth.mass             = mass
    cloth.tension_stiffness    = tension
    cloth.compression_stiffness = compression


def addCollision(obj):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_add(type='COLLISION')


def bakePhysics(frame_start=1, frame_end=120):
    bpy.context.scene.rigidbody_world.point_cache.frame_start = frame_start
    bpy.context.scene.rigidbody_world.point_cache.frame_end   = frame_end
    bpy.ops.ptcache.bake_all(bake=True)


def addSubdivision(obj, levels=2):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_add(type='SUBSURF')
    obj.modifiers['Subdivision'].levels = levels


def addWireframe(obj, thickness=0.005):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_add(type='WIREFRAME')
    obj.modifiers['Wireframe'].thickness    = thickness
    obj.modifiers['Wireframe'].use_replace  = False