import importlib
import random
from datetime import datetime
from pathlib import Path
from Blender.utils import _runBlender

ROOT       = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = Path(__file__).resolve().parent / "scripts"
CACHE_DIR  = ROOT / "Cache" / "blender"


def listScenes() -> list[str]:
    """List all available Blender scripts."""
    return [
        f.stem for f in sorted(SCRIPTS_DIR.glob("*.py"))
        if not f.stem.startswith("_")
    ]


def renderScene(
    name: str,
    output: Path   = None,
    frames: int    = 120,
    fps: int       = 24,
    resolution: tuple = (1080, 1920),
    engine: str    = "BLENDER_EEVEE",
    quality: str   = "medium",
    **params,
) -> Path:
    """
    Render a Blender scene by name.

    e.g. renderScene("cloth_sim", frames=240, resolution=(1080, 1920))
    e.g. renderScene("rigid_body", frames=120, engine="CYCLES")
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"{name}_{stamp}.mp4"

    script = SCRIPTS_DIR / f"{name}.py"
    if not script.exists():
        available = listScenes()
        raise FileNotFoundError(
            f"Script '{name}' not found. Available: {available}"
        )

    return _runBlender(
        script=script,
        output=Path(output),
        frames=frames,
        fps=fps,
        resolution=resolution,
        engine=engine,
        quality=quality,
        **params,
    )


def previewScene(
    name: str,
    output: Path = None,
    **params,
) -> Path:
    """Render 60 frames at low quality for quick preview."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"preview_{name}_{stamp}.mp4"

    return renderScene(
        name,
        output=output,
        frames=60,
        fps=24,
        resolution=(540, 960),
        engine="BLENDER_EEVEE",
        quality="low",
        **params,
    )


def getScene(name: str) -> Path:
    """Get the most recently cached render of a scene."""
    matches = sorted(CACHE_DIR.glob(f"{name}_*.mp4"), reverse=True)
    if not matches:
        raise FileNotFoundError(
            f"No cached render for '{name}'. Run renderScene('{name}') first."
        )
    return matches[0]


def randomScene(**params) -> Path:
    """Pick a random scene and render it."""
    available = listScenes()
    if not available:
        raise FileNotFoundError(f"No scripts found in {SCRIPTS_DIR}")
    name = random.choice(available)
    print(f"Random scene: {name}")
    return renderScene(name, **params)