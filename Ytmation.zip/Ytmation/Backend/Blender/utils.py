import os
import json
import subprocess
import tempfile
from pathlib import Path

ROOT        = Path(__file__).resolve().parent.parent
BLENDER_BIN = "/home/zolo/Apps/blender-5.1.1-linux-x64/blender"
BLENDER_DIR = Path(__file__).resolve().parent
CACHE_DIR   = ROOT / "Cache" / "blender"

QUALITY_SAMPLES = {
    "low":    32,
    "medium": 128,
    "high":   512,
}


def _runBlender(
    script: Path,
    output: Path,
    frames: int       = 120,
    fps: int          = 24,
    resolution: tuple = (1080, 1920),
    engine: str       = "BLENDER_EEVEE",
    quality: str      = "medium",
    **params,
) -> Path:
    """
    Run a Blender script as a subprocess.
    Passes render config + params to the script via env vars.
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    frames_dir = CACHE_DIR / f"frames_{script.stem}"
    frames_dir.mkdir(parents=True, exist_ok=True)

    # pass config to blender script via environment
    env = os.environ.copy()
    env["PYTHONPATH"]      = str(BLENDER_DIR)
    env["YT_OUTPUT_DIR"]   = str(frames_dir)
    env["YT_FRAMES"]       = str(frames)
    env["YT_FPS"]          = str(fps)
    env["YT_RES_X"]        = str(resolution[0])
    env["YT_RES_Y"]        = str(resolution[1])
    env["YT_ENGINE"]       = engine
    env["YT_SAMPLES"]      = str(QUALITY_SAMPLES.get(quality, 128))
    env["YT_PARAMS"]       = json.dumps(params)

    print(f"   Running Blender: {script.name}")
    result = subprocess.run([
        BLENDER_BIN, "--background",
        "--python", str(script),
    ], env=env, capture_output=True, text=True)

    if result.returncode != 0:
        raise RuntimeError(f"Blender failed:\n{result.stderr[-2000:]}")

    # encode frames to mp4
    print(f"   Encoding frames → {output}")
    subprocess.run([
        "ffmpeg", "-hide_banner", "-y",
        "-framerate", str(fps),
        "-i", str(frames_dir / "frame_%04d.png"),
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-pix_fmt", "yuv420p",
        str(output)
    ], check=True)

    print(f"   Done: {output}")
    return output


def _getConfig() -> dict:
    """
    Called from INSIDE a Blender script to read render config passed by utils.
    Import this in your scripts: from utils import _getConfig
    """
    import json
    return {
        "output_dir": os.environ.get("YT_OUTPUT_DIR", "/tmp/blender_frames"),
        "frames":     int(os.environ.get("YT_FRAMES",  120)),
        "fps":        int(os.environ.get("YT_FPS",     24)),
        "res_x":      int(os.environ.get("YT_RES_X",   1080)),
        "res_y":      int(os.environ.get("YT_RES_Y",   1920)),
        "engine":     os.environ.get("YT_ENGINE",      "BLENDER_EEVEE"),
        "samples":    int(os.environ.get("YT_SAMPLES", 128)),
        "params":     json.loads(os.environ.get("YT_PARAMS", "{}")),
    }