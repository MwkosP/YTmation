import json
import os
import re
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SOURCES_DIR = Path(__file__).resolve().parent / "sources"
OUTPUT_DIR = ROOT / "Cache" / "trends"
USER_AGENT = "YT-Trends/1.0 (local research)"
REDDIT_BASE = "https://www.reddit.com"
GOOGLE_RSS = "https://trends.google.com/trending/rss?geo={geo}"
GOOGLE_NEWS_RSS = "https://news.google.com/rss/search?q={query}&hl=en-US&gl={geo}&ceid={geo}:en"
YOUTUBE_API = "https://www.googleapis.com/youtube/v3"

VALID_SOURCES = ("reddit", "google", "youtube")
DEFAULT_SOURCES = ("reddit", "google")
DEFAULT_LIMIT = 10


def parse_sources(sources: str | list[str] | tuple[str, ...] | None = None) -> tuple[str, ...]:
    """Parse 'reddit', 'reddit,google', or ['reddit', 'google'] into a tuple."""
    if sources is None:
        return DEFAULT_SOURCES
    if isinstance(sources, str):
        parts = [p.strip().lower() for p in sources.split(",") if p.strip()]
    else:
        parts = [str(p).strip().lower() for p in sources]
    invalid = [p for p in parts if p not in VALID_SOURCES]
    if invalid:
        raise ValueError(f"Unknown source(s): {invalid}. Use: {', '.join(VALID_SOURCES)}")
    if not parts:
        return DEFAULT_SOURCES
    return tuple(dict.fromkeys(parts))


def fetch_url(url: str, *, headers: dict | None = None) -> bytes:
    h = {"User-Agent": USER_AGENT}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read()
    except urllib.error.URLError as e:
        raise RuntimeError(f"Failed to fetch {url}\n{e}") from e


def fetch_json(url: str) -> dict | list:
    return json.loads(fetch_url(url))


def load_niche_config(name: str = "niches") -> dict:
    return json.loads((SOURCES_DIR / f"{name}.json").read_text(encoding="utf-8"))


def load_instances() -> dict:
    path = SOURCES_DIR / "instances.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {"piped": [], "invidious": []}


def list_niches() -> list[str]:
    return sorted(k for k in load_niche_config() if k != "all")


def reddit_posts(data: dict, subreddit: str = "") -> list[dict]:
    posts = []
    for child in data.get("data", {}).get("children", []):
        p = child.get("data", {})
        if p.get("stickied"):
            continue
        posts.append({
            "source": "reddit",
            "title": p.get("title", ""),
            "score": p.get("score", 0),
            "comments": p.get("num_comments", 0),
            "subreddit": subreddit or p.get("subreddit", ""),
            "url": f"https://reddit.com{p.get('permalink', '')}",
        })
    return posts


def traffic_to_score(traffic: str) -> int:
    """Turn '200K+' style strings into a sortable number."""
    m = re.search(r"([\d.]+)\s*([KMB])?", traffic.upper())
    if not m:
        return 0
    n = float(m.group(1))
    mult = {"K": 1_000, "M": 1_000_000, "B": 1_000_000_000}.get(m.group(2) or "", 1)
    return int(n * mult)


def youtube_api_key() -> str | None:
    return os.environ.get("YOUTUBE_API_KEY") or os.environ.get("GOOGLE_API_KEY")


def matches_keywords(text: str, keywords: list[str]) -> bool:
    if not keywords:
        return True
    lower = text.lower()
    return any(k.lower() in lower for k in keywords)


def score_item(item: dict, keywords: list[str]) -> float:
    score = float(item.get("score", 0) or 0)
    score += item.get("comments", 0) * 2
    title = item.get("title", "").lower()
    for kw in keywords:
        if kw.lower() in title:
            score += 100
    return score


def topic_keywords(topic: str) -> list[str]:
    words = [w for w in topic.lower().split() if len(w) > 2]
    return list(dict.fromkeys([topic.lower(), *words]))


def slug(text: str) -> str:
    return re.sub(r"[^\w]+", "_", text.strip())[:40].strip("_") or "topic"


def save_trends(trends: list[dict], niche: str, sources: tuple[str, ...]) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = OUTPUT_DIR / f"{slug(niche)}_{stamp}.json"
    by_source: dict[str, int] = {}
    for trend in trends:
        by_source[trend["source"]] = by_source.get(trend["source"], 0) + 1
    payload = {
        "query": niche,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "sources_used": list(sources),
        "count_by_source": by_source,
        "count": len(trends),
        "trends": trends,
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path
