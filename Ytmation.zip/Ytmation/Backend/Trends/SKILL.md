# Trends — what it does

**Picks your next video topic** by scanning what's hot right now, filtered for your niche (same names as `Workflows/pipelines/`).

Runs at the **start** of a workflow (`Trends/ → find trending …`) before Script or Storyboard.

## Three sources

| Source | What it pulls | API key? |
|--------|----------------|----------|
| **Reddit** | Hot posts from niche subreddits | No |
| **Google** | Daily trends (niches) or News search (topics) | No |
| **YouTube** | Trending + keyword search | Optional (recommended) |

Results are merged, keyword-filtered, ranked, and saved to `Cache/trends/*.json`.

## YouTube setup (recommended)

Free key: [Google Cloud Console](https://console.cloud.google.com/) → enable **YouTube Data API v3** → create API key.

```bash
export YOUTUBE_API_KEY="your-key-here"
python Trends/trends.py manhwa_recap
```

Without a key, the module tries public Piped/Invidious instances in `sources/instances.json` (often unreliable). Add a working instance URL there if you find one.

## CLI

```bash
python Trends/trends.py --list
python Trends/trends.py manhwa_recap
python Trends/trends.py blender_physics --sources reddit,google
python Trends/trends.py soundscape_sleep --geo US --region US -n 10
```

## Python

```python
from Trends.trends import getTrends, pickTopic

getTrends(sources="reddit", limit=5)           # GENERAL r/all hot (no niche)
getTrends(sources="google", limit=10)          # GENERAL Google daily trends
getTrends("manhwa_recap")                      # workflow niche (filtered)
getTrends("ice cream", "reddit", limit=5)      # topic search
getTrends("manhwa_recap", "reddit,google")     # both
getTrends("manhwa_recap", "youtube", limit=5)  # youtube only, top 5

topic = pickTopic(trends)                      # #1 by score → Script
```

Defaults: `sources=reddit,google`, `limit=10`, sorted by relevance score.

## Output example

```json
{
  "niche": "manhwa_recap",
  "count_by_source": { "reddit": 5, "google": 2, "youtube": 8 },
  "trends": [
    { "source": "youtube", "title": "...", "views": 1200000, "url": "..." }
  ]
}
```

## Config

- `sources/niches.json` — subreddits, keywords, `google_geo`, `youtube_region` per niche
- `sources/instances.json` — backup Piped/Invidious URLs for YouTube without API key
