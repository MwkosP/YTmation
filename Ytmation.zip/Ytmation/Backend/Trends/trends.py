#!/usr/bin/env python3
"""
Trends — discover video topics before production.

Sources:
  - Reddit     hot posts in niche subreddits (no API key)
  - Google     daily search trends RSS (no API key)
  - YouTube    trending + niche search (needs YOUTUBE_API_KEY, or Piped/Invidious)
"""

import argparse
import json
import sys
import urllib.parse
import xml.etree.ElementTree as ET

try:
    from .utils import (
        DEFAULT_LIMIT,
        GOOGLE_NEWS_RSS,
        GOOGLE_RSS,
        REDDIT_BASE,
        YOUTUBE_API,
        fetch_json,
        fetch_url,
        list_niches,
        load_instances,
        load_niche_config,
        matches_keywords,
        parse_sources,
        reddit_posts,
        save_trends,
        score_item,
        topic_keywords,
        traffic_to_score,
        youtube_api_key,
    )
except ImportError:
    from utils import (
        DEFAULT_LIMIT,
        GOOGLE_NEWS_RSS,
        GOOGLE_RSS,
        REDDIT_BASE,
        YOUTUBE_API,
        fetch_json,
        fetch_url,
        list_niches,
        load_instances,
        load_niche_config,
        matches_keywords,
        parse_sources,
        reddit_posts,
        save_trends,
        score_item,
        topic_keywords,
        traffic_to_score,
        youtube_api_key,
    )


# ─── Reddit ─────────────────────────────────────────────────────────────

def fetchReddit(subreddit: str, limit: int = 10) -> list[dict]:
    url = f"{REDDIT_BASE}/r/{subreddit}/hot.json?limit={limit}"
    return reddit_posts(fetch_json(url), subreddit)


def fetchRedditSearch(query: str, limit: int = 10) -> list[dict]:
    q = urllib.parse.quote(query)
    url = f"{REDDIT_BASE}/search.json?q={q}&sort=hot&limit={limit}&restrict_sr=0"
    return reddit_posts(fetch_json(url))


# ─── Google Trends (RSS) ───────────────────────────────────────────────

def fetchGoogleTrends(geo: str = "US", limit: int = 20) -> list[dict]:
    raw = fetch_url(GOOGLE_RSS.format(geo=geo)).decode("utf-8", errors="replace")
    root = ET.fromstring(raw)
    ns = {"ht": "https://trends.google.com/trending/rss"}
    trends = []
    for item in root.findall(".//item")[:limit]:
        title = (item.findtext("title") or "").strip()
        traffic = item.findtext("ht:approx_traffic", "", ns) or ""
        pub = item.findtext("pubDate") or ""
        trends.append({
            "source": "google",
            "title": title,
            "traffic": traffic,
            "geo": geo,
            "published": pub,
            "url": f"https://trends.google.com/trends/explore?q={urllib.parse.quote(title)}&geo={geo}",
            "score": traffic_to_score(traffic),
        })
    return trends


def fetchGoogleNews(query: str, geo: str = "US", limit: int = 20) -> list[dict]:
    """Google News search — used for free-form topics (e.g. 'ice cream')."""
    url = GOOGLE_NEWS_RSS.format(query=urllib.parse.quote(query), geo=geo)
    raw = fetch_url(url).decode("utf-8", errors="replace")
    root = ET.fromstring(raw)
    trends = []
    for i, item in enumerate(root.findall(".//item")[:limit]):
        title = (item.findtext("title") or "").strip()
        trends.append({
            "source": "google",
            "type": "news",
            "title": title,
            "query": query,
            "geo": geo,
            "published": item.findtext("pubDate") or "",
            "url": item.findtext("link") or "",
            "score": max(limit - i, 1) * 100,
        })
    return trends


# ─── YouTube ───────────────────────────────────────────────────────────

def fetchYoutubeTrendingApi(region: str = "US", limit: int = 15) -> list[dict]:
    key = youtube_api_key()
    if not key:
        return []
    params = urllib.parse.urlencode({
        "part": "snippet,statistics",
        "chart": "mostPopular",
        "regionCode": region,
        "maxResults": min(limit, 50),
        "key": key,
    })
    data = fetch_json(f"{YOUTUBE_API}/videos?{params}")
    trends = []
    for item in data.get("items", []):
        sn = item.get("snippet", {})
        st = item.get("statistics", {})
        vid = item.get("id", "")
        trends.append({
            "source": "youtube",
            "title": sn.get("title", ""),
            "channel": sn.get("channelTitle", ""),
            "views": int(st.get("viewCount", 0) or 0),
            "url": f"https://youtube.com/watch?v={vid}",
            "score": int(st.get("viewCount", 0) or 0),
        })
    return trends


def fetchYoutubeSearchApi(query: str, limit: int = 10) -> list[dict]:
    key = youtube_api_key()
    if not key:
        return []
    params = urllib.parse.urlencode({
        "part": "snippet",
        "q": query,
        "type": "video",
        "order": "viewCount",
        "maxResults": min(limit, 25),
        "key": key,
    })
    data = fetch_json(f"{YOUTUBE_API}/search?{params}")
    trends = []
    for item in data.get("items", []):
        sn = item.get("snippet", {})
        vid = item.get("id", {}).get("videoId", "")
        trends.append({
            "source": "youtube",
            "title": sn.get("title", ""),
            "channel": sn.get("channelTitle", ""),
            "query": query,
            "url": f"https://youtube.com/watch?v={vid}",
            "score": 0,
        })
    return trends


def fetchPipedTrending(base: str, region: str, limit: int) -> list[dict]:
    data = fetch_json(f"{base.rstrip('/')}/trending?region={region}")
    if not isinstance(data, list):
        return []
    trends = []
    for v in data[:limit]:
        vid = v.get("url") or v.get("id") or ""
        if "/" in str(vid):
            vid = str(vid).rsplit("/", 1)[-1]
        trends.append({
            "source": "youtube",
            "title": v.get("title", ""),
            "channel": v.get("uploader") or v.get("uploaderName", ""),
            "views": v.get("views", 0) or 0,
            "url": f"https://youtube.com/watch?v={vid}",
            "score": v.get("views", 0) or 0,
        })
    return trends


def fetchInvidiousTrending(base: str, region: str, limit: int) -> list[dict]:
    data = fetch_json(f"{base.rstrip('/')}/api/v1/trends?region={region}")
    if not isinstance(data, list):
        return []
    trends = []
    for v in data[:limit]:
        vid = v.get("videoId", "")
        trends.append({
            "source": "youtube",
            "title": v.get("title", ""),
            "channel": v.get("author", ""),
            "views": v.get("viewCount", 0) or 0,
            "url": f"https://youtube.com/watch?v={vid}" if vid else "",
            "score": v.get("viewCount", 0) or 0,
        })
    return trends


def fetchYoutubeTrending(region: str = "US", limit: int = 15) -> list[dict]:
    if youtube_api_key():
        return fetchYoutubeTrendingApi(region, limit)

    instances = load_instances()
    for base in instances.get("piped", []):
        try:
            hits = fetchPipedTrending(base, region, limit)
            if hits:
                return hits
        except RuntimeError:
            continue
    for base in instances.get("invidious", []):
        try:
            hits = fetchInvidiousTrending(base, region, limit)
            if hits:
                return hits
        except RuntimeError:
            continue

    print(
        "YouTube: no data. Set YOUTUBE_API_KEY or add a working Piped/Invidious URL in "
        "Trends/sources/instances.json",
        file=sys.stderr,
    )
    return []


# ─── Merge & rank ──────────────────────────────────────────────────────

def resolveSearch(query: str | None) -> dict:
    """
    general  — no niche/topic: platform-wide trends, no keyword filter
    niche    — workflow name from niches.json (manhwa_recap, …)
    topic    — free-form search (ice cream, Bitcoin, …)
    """
    if query is None or str(query).strip().lower() in ("", "general", "all"):
        return {
            "query": "general",
            "mode": "general",
            "topic": None,
            "keywords": [],
            "subreddits": ["all"],
            "google_geo": "US",
            "youtube_region": "US",
        }

    config = load_niche_config()
    if query in config and query != "all":
        cfg = config[query]
        return {
            "query": query,
            "mode": "niche",
            "topic": None,
            "keywords": cfg.get("keywords", []),
            "subreddits": cfg.get("subreddits", []),
            "google_geo": cfg.get("google_geo", "US"),
            "youtube_region": cfg.get("youtube_region", "US"),
        }
    return {
        "query": query,
        "mode": "topic",
        "topic": query,
        "keywords": topic_keywords(query),
        "subreddits": [],
        "google_geo": "US",
        "youtube_region": "US",
    }


def fetchNicheTrends(
    niche: str | None = None,
    sources: str | list[str] | tuple[str, ...] | None = None,
    *,
    geo: str = "US",
    region: str = "US",
    limit: int = DEFAULT_LIMIT,
) -> list[dict]:
    sources = parse_sources(sources)
    limit_per_source = max(limit, 15)
    cfg = resolveSearch(niche)
    keywords = cfg["keywords"]
    geo = cfg["google_geo"] if cfg["google_geo"] else geo
    region = cfg["youtube_region"] if cfg["youtube_region"] else region
    queryLabel = cfg["query"]

    seen: set[str] = set()
    merged: list[dict] = []

    def addItems(items: list[dict]) -> None:
        for item in items:
            key = item.get("title", "").lower().strip()
            if not key or key in seen:
                continue
            if not matches_keywords(item["title"], keywords):
                continue
            seen.add(key)
            item = dict(item)
            item["query"] = queryLabel
            if cfg["topic"]:
                item["topic"] = cfg["topic"]
            else:
                item["niche"] = queryLabel
            if keywords:
                item["relevance"] = score_item(item, keywords)
            else:
                item["relevance"] = float(item.get("score", 0) or 0) + item.get("comments", 0) * 2
            merged.append(item)

    if "reddit" in sources:
        try:
            if cfg["topic"]:
                addItems(fetchRedditSearch(cfg["topic"], limit=limit_per_source))
            else:
                for sub in cfg["subreddits"]:
                    try:
                        addItems(fetchReddit(sub, limit=limit_per_source))
                    except RuntimeError as e:
                        print(f"Warning: reddit r/{sub}: {e}", file=sys.stderr)
        except RuntimeError as e:
            print(f"Warning: reddit: {e}", file=sys.stderr)

    if "google" in sources:
        try:
            if cfg["topic"]:
                addItems(fetchGoogleNews(cfg["topic"], geo=geo, limit=limit_per_source))
            else:
                addItems(fetchGoogleTrends(geo=geo, limit=limit_per_source))
        except RuntimeError as e:
            print(f"Warning: google: {e}", file=sys.stderr)

    if "youtube" in sources:
        if cfg["topic"]:
            try:
                addItems(fetchYoutubeSearchApi(cfg["topic"], limit=limit_per_source))
            except RuntimeError as e:
                print(f"Warning: youtube search: {e}", file=sys.stderr)
        else:
            try:
                addItems(fetchYoutubeTrending(region=region, limit=limit_per_source))
            except RuntimeError as e:
                print(f"Warning: youtube trending: {e}", file=sys.stderr)
            for kw in keywords[:3]:
                try:
                    addItems(fetchYoutubeSearchApi(kw, limit=5))
                except RuntimeError as e:
                    print(f"Warning: youtube search '{kw}': {e}", file=sys.stderr)

    merged.sort(key=lambda x: x.get("relevance", x.get("score", 0)), reverse=True)
    return merged[:limit]


def getTrends(
    niche: str | None = None,
    sources: str | list[str] | tuple[str, ...] | None = None,
    *,
    limit: int = DEFAULT_LIMIT,
    save: bool = True,
    geo: str = "US",
    region: str = "US",
) -> list[dict]:
    """
    Fetch top trends by score.

    niche=None          → general platform trends (r/all, Google daily, YT trending)
    niche='manhwa_recap' → workflow niche from niches.json
    niche='ice cream'   → topic search on each source
    """
    src = parse_sources(sources)
    cfg = resolveSearch(niche)
    trends = fetchNicheTrends(niche, sources=src, geo=geo, region=region, limit=limit)

    queryLabel = cfg["query"]
    mode = cfg["mode"]
    print(f"{mode}: {queryLabel}  |  sources: {', '.join(src)}  |  top {len(trends)} by score\n")
    for i, t in enumerate(trends, 1):
        sourceLabel = t.get("source", "?")
        extra = ""
        if sourceLabel == "reddit":
            extra = f"r/{t.get('subreddit', '')} score={t.get('score', 0)}"
        elif sourceLabel == "google":
            kind = t.get("type", "trend")
            extra = f"{kind} score={t.get('score', 0)}"
            if t.get("traffic"):
                extra = f"traffic={t['traffic']} {extra}"
        elif sourceLabel == "youtube":
            extra = f"views={t.get('views', 0)} score={t.get('score', 0)}"
        print(f"{i:2}. [{sourceLabel:7}] {t['title'][:65]}  (relevance={t.get('relevance', 0):.0f})")
        if extra:
            print(f"         {extra}")
        print(f"         {t.get('url', '')}\n")

    if save and trends:
        path = save_trends(trends, queryLabel, src)
        print(f"Saved: {path}", file=sys.stderr)

    return trends


def pickTopic(trends: list[dict]) -> str | None:
    return trends[0]["title"] if trends else None


def runCli() -> int:
    parser = argparse.ArgumentParser(description="Trends: Reddit + Google + YouTube")
    parser.add_argument("niche", nargs="?", default=None,
                        help="Omit for general trends, or pass niche/topic")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("-n", "--limit", type=int, default=DEFAULT_LIMIT)
    parser.add_argument("--sources", default="reddit,google",
                        help="Comma-separated: reddit, google, youtube (default: reddit,google)")
    parser.add_argument("--geo", default="US", help="Google Trends region")
    parser.add_argument("--region", default="US", help="YouTube region")
    parser.add_argument("--no-save", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.list:
        for name in list_niches():
            c = load_niche_config()[name]
            print(f"{name:22} {', '.join(c.get('subreddits', [])[:2])}…")
        return 0

    if args.json:
        trends = fetchNicheTrends(
            args.niche, args.sources, geo=args.geo, region=args.region, limit=args.limit
        )
        print(json.dumps(trends, indent=2))
    else:
        getTrends(
            args.niche, args.sources,
            limit=args.limit, save=not args.no_save,
            geo=args.geo, region=args.region,
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(runCli())
