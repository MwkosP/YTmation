import json
import subprocess
from pathlib import Path


def _downloadYT(url: str, dest: Path):
    """Download a YouTube URL as mp3 using yt-dlp."""
    subprocess.run([
        "yt-dlp",
        "--extract-audio",
        "--audio-format", "mp3",
        "--audio-quality", "0",
        "--output", str(dest.with_suffix("")) + ".%(ext)s",
        "--no-playlist",
        url
    ], check=True)

    # yt-dlp may add .mp3 extension automatically — rename if needed
    maybe = dest.with_suffix("").with_suffix(".mp3")
    if maybe.exists() and maybe != dest:
        maybe.rename(dest)


def _trimAudio(
    src: Path,
    dest: Path,
    start: float = 0.0,
    end: float   = None,
):
    """Trim an audio file from start to end (seconds)."""
    args = [
        "ffmpeg", "-hide_banner", "-y",
        "-i", str(src),
        "-ss", str(start),
    ]
    if end is not None:
        args += ["-to", str(end)]

    args += ["-c:a", "libmp3lame", "-q:a", "2", str(dest)]
    subprocess.run(args, check=True)


def _loopAudio(
    src: Path,
    dest: Path,
    duration: float,
    fade_out: float = 2.0,
):
    """
    Loop audio to fill duration, then trim and add fade out.
    Uses ffmpeg aloop filter.
    """
    fade_start = max(0, duration - fade_out)

    subprocess.run([
        "ffmpeg", "-hide_banner", "-y",
        "-stream_loop", "-1",
        "-i", str(src),
        "-af", f"afade=t=out:st={fade_start}:d={fade_out}",
        "-t", str(duration),
        "-c:a", "libmp3lame", "-q:a", "2",
        str(dest)
    ], check=True)


def _getAudioDuration(path: Path) -> float:
    """Get duration of an audio file in seconds."""
    result = subprocess.run([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(path)
    ], capture_output=True, text=True, check=True)
    return float(result.stdout.strip())


def _extractSlice(
    src: Path,
    dest: Path,
    start: float,
    duration: float,
    fade_ms: float = 8,
) -> None:
    """Extract one slice from src at start (seconds) with short fades."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    fade_s = min(fade_ms / 1000.0, max(duration / 3.0, 0.001))
    fade_out_start = max(duration - fade_s, 0.0)
    subprocess.run([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-ss", str(start),
        "-i", str(src),
        "-t", str(duration),
        "-af", (
            f"afade=t=in:st=0:d={fade_s},"
            f"afade=t=out:st={fade_out_start}:d={fade_s}"
        ),
        "-ar", "44100",
        "-ac", "1",
        str(dest),
    ], check=True)


def _writeSliceManifest(manifest: dict, output_dir: Path) -> Path:
    path = output_dir / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return path


def _readSliceManifest(pack_dir: Path) -> dict:
    path = pack_dir / "manifest.json"
    if not path.is_file():
        raise FileNotFoundError(f"No slice manifest in {pack_dir}")
    return json.loads(path.read_text(encoding="utf-8"))