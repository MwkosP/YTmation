# Music Module

## Purpose
Music library management. Downloads tracks from YouTube, prepares them for video use.
All actual audio mixing is done in Stitching/stitching.py.

## Location
`Music/music.py`

## Library
Music files live in `Music/library/`. Supported formats: .mp3 .wav .ogg .m4a

## Functions

### downloadMusic(url, name, trim_start, trim_end) -> Path
Downloads a YouTube video as mp3 and saves to library.
```python
from Music.music import downloadMusic
downloadMusic("https://youtube.com/watch?v=xxx", "chill_beat")
downloadMusic("https://youtube.com/watch?v=xxx", "chill_beat", trim_start=10, trim_end=70)
```

### getMusic(name) -> Path
Returns path to a music track by name. Raises FileNotFoundError if not found.
```python
from Music.music import getMusic
track = getMusic("chill_beat")
```

### listMusic() -> list[str]
Lists all available tracks in the library.
```python
from Music.music import listMusic
print(listMusic())  # ['chill_beat', 'lofi_rain']
```

### prepareMusic(name, duration, fade_out) -> Path
Loops/trims a track to fit a target duration, adds fade out. Use before overlayMusic.
```python
from Music.music import prepareMusic
ready = prepareMusic("chill_beat", duration=60, fade_out=2.0)
```

### sliceIntoAudios(path, start, end, slice_ms, ...) -> Path
Low-level: slice any audio file between two timestamps into short wav clips.
```python
from Music.music import sliceIntoAudios
pack = sliceIntoAudios("/path/to/track.mp3", start=2.0, end=10.0, slice_ms=150)
```

### sliceMusic(name, start, end, slice_ms, ...) -> Path
Slice a library track by name (wrapper around sliceIntoAudios + getMusic).
```python
from Music.music import sliceMusic
pack = sliceMusic("chill_beat", start=2.0, end=10.0, slice_ms=150)
```

### getSlice(pack, index) -> Path
Get one slice from a cue pack (for collision audio / supervisors).
```python
from Music.music import getSlice
hit = getSlice("chill_beat", 3)
```

Cue packs live in `Music/library/cues/<pack>/` with `slice_00.wav`, `manifest.json`, etc.

Used by Games `collision_audio` mode **`revealMusic`** (collision N → `getSlice(pack, N)`).

## Typical Workflow
```python
from Music.music import getMusic, prepareMusic
from Stitching.stitching import overlayMusic

music  = prepareMusic("chill_beat", duration=60)
video  = overlayMusic(video, music=music, volume=0.15, fade_out=2.0)
```