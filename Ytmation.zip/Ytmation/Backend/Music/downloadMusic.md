# Download Music Safely (YouTube-Monetization Friendly)

This guide is for building a **safe music library** for YT videos with clear usage rights.

## Goal

Use only tracks you can confidently monetize with, and keep proof for each track.

---

## Safest Source (Free): YouTube Audio Library

Use this as your default source for free tracks.

### Recommended filter setup

In YouTube Audio Library, filter by:

- **Attribution not required** (safest for automation)
- Genre / Mood / Duration for your channel style
- Instrumental when possible (better under voiceover)

If you do choose tracks that require attribution, save the exact attribution text.

---

## Core Rule

Do not use a track in production unless it has a local license record.

---

## Folder Layout

Suggested structure:

```text
Music/
  library/                 # actual audio files (.mp3/.wav/.m4a/.ogg)
  licenses.json            # per-track license/provenance records
  downloadMusic.md         # this file
```

---

## Per-Track License Record (Required)

For each downloaded track, record:

- `name` (local filename stem)
- `title` (official track title)
- `artist`
- `source` (URL to track page or library entry)
- `source_type` (`youtube_audio_library`, `paid_library`, etc.)
- `downloaded_at` (ISO timestamp)
- `attribution_required` (`true/false`)
- `attribution_text` (exact required text, if any)
- `notes` (optional)

### Example `licenses.json`

```json
[
  {
    "name": "calm_math_loop_01",
    "title": "Calm Future Bass",
    "artist": "Example Artist",
    "source": "https://studio.youtube.com/channel/.../music",
    "source_type": "youtube_audio_library",
    "downloaded_at": "2026-05-28T03:00:00Z",
    "attribution_required": false,
    "attribution_text": "",
    "notes": "Used for mathmwk explainers"
  }
]
```

---

## Acquisition Workflow (Manual + Safe)

1. Open YouTube Audio Library.
2. Apply safe filters (prefer no attribution required).
3. Download selected tracks.
4. Rename consistently and place in `Music/library/`.
5. Add/update a record in `Music/licenses.json`.
6. Keep a screenshot/export of track details if possible (optional extra proof).

---

## Naming Convention (Recommended)

Use predictable names so workflows stay clean:

- `calm_math_01`
- `ambient_soft_02`
- `uplift_explainer_03`

Avoid spaces and special characters in filenames.

---

## What Not To Do

- Do not bulk pull random YouTube songs with `yt-dlp` unless you own rights.
- Do not trust "no copyright" claims without clear license terms.
- Do not store tracks in `Music/library/` without a corresponding license record.

---

## Quality Tips for Voiceover Videos

- Prefer low-density instrumental tracks under narration.
- Keep music bed quiet (`~10-20%` mix depending on voice level).
- Prepare exact-length loops with fade out before final stitch.

---

## Later Automation (Planned)

Future improvement idea:

- Add a `Music` guard that refuses `prepareMusic(...)` for tracks missing `licenses.json` entries.
- Add `listSafeMusic()` to show only validated tracks.

