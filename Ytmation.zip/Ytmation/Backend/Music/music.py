from __future__ import annotations

from datetime import datetime
from pathlib import Path

from Music.utils import (
    _downloadYT,
    _extractSlice,
    _getAudioDuration,
    _loopAudio,
    _readSliceManifest,
    _trimAudio,
    _writeSliceManifest,
)

ROOT        = Path(__file__).resolve().parent.parent
LIBRARY_DIR = Path(__file__).resolve().parent / "library"
CUES_DIR    = LIBRARY_DIR / "cues"
CACHE_DIR   = ROOT / "Cache" / "music"


def listMusic() -> list[str]:
    """List all available music names in the library."""
    LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
    exts = {".mp3", ".wav", ".ogg", ".m4a"}
    return [f.stem for f in sorted(LIBRARY_DIR.iterdir()) if f.suffix in exts]


def getMusic(name: str) -> Path:
    """Get path to a music track by name. e.g. getMusic('chill_beat')"""
    for ext in [".mp3", ".wav", ".ogg", ".m4a"]:
        path = LIBRARY_DIR / f"{name}{ext}"
        if path.exists():
            return path
    raise FileNotFoundError(
        f"Music '{name}' not found in {LIBRARY_DIR}. "
        f"Use listMusic() to see available tracks or downloadMusic() to add one."
    )


def downloadMusic(
    url: str,
    name: str,
    trim_start: float = 0.0,
    trim_end: float   = None,
) -> Path:
    """
    Download a YouTube video as mp3 and save to library.

    e.g. downloadMusic("https://youtube.com/watch?v=xxx", "chill_beat")
    e.g. downloadMusic("https://youtube.com/watch?v=xxx", "chill_beat", trim_start=10, trim_end=70)
    """
    LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
    dest = LIBRARY_DIR / f"{name}.mp3"

    print(f"⬇️  Downloading '{name}'...")
    _downloadYT(url, dest)

    if trim_start > 0.0 or trim_end is not None:
        print(f"   Trimming {trim_start}s → {trim_end}s...")
        _trimAudio(dest, dest, start=trim_start, end=trim_end)

    print(f"   Saved: {dest}")
    return dest


def prepareMusic(
    name: str,
    duration: float,
    output: Path = None,
    fade_out: float = 2.0,
) -> Path:
    """
    Prepare a music track for a video — loops if too short, trims if too long,
    adds fade out at the end.

    e.g. prepareMusic("chill_beat", duration=60)
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"music_{name}_{stamp}.mp3"

    src = getMusic(name)

    print(f"🎵 Preparing '{name}' for {duration}s...")
    _loopAudio(src, output, duration=duration, fade_out=fade_out)

    return Path(output)


def _resolveSlicePack(pack: str | Path) -> Path:
    pack_path = Path(pack)
    if pack_path.is_dir():
        return pack_path.resolve()
    return (CUES_DIR / str(pack)).resolve()


def sliceIntoAudios(
    path: str | Path,
    start: float,
    end: float,
    slice_ms: float = 150,
    count: int | None = None,
    output_dir: str | Path | None = None,
    fade_ms: float = 8,
    pack_name: str | None = None,
) -> Path:
    """
    Slice an audio file between start/end into many short wav clips.

    Returns the output folder (contains slice_00.wav, slice_01.wav, ... + manifest.json).
  """
    src = Path(path).resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Audio file not found: {src}")

    if end <= start:
        raise ValueError(f"end ({end}) must be greater than start ({start})")

    slice_sec = slice_ms / 1000.0
    window = end - start
    if count is None:
        count = max(1, int(window // slice_sec))

    if output_dir is None:
        label = pack_name or src.stem
        output_dir = CUES_DIR / label
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    print(
        f"🎵 Slicing {src.name} [{start:.2f}s → {end:.2f}s] "
        f"into {count} x {slice_ms:.0f}ms clips → {output_dir}",
        flush=True,
    )

    slices_meta: list[dict] = []
    made = 0
    for i in range(count):
        t0 = start + i * slice_sec
        if t0 >= end:
            break
        duration = min(slice_sec, end - t0)
        if duration <= 0.01:
            break

        out = output_dir / f"slice_{i:02d}.wav"
        _extractSlice(src, out, t0, duration, fade_ms=fade_ms)
        slices_meta.append({
            "index": i,
            "file": out.name,
            "start": round(t0, 4),
            "duration": round(duration, 4),
        })
        made += 1

    if made == 0:
        raise ValueError("No slices created — check start/end/slice_ms")

    manifest = {
        "source": str(src),
        "pack": output_dir.name,
        "start": start,
        "end": end,
        "slice_ms": slice_ms,
        "fade_ms": fade_ms,
        "count": made,
        "slices": slices_meta,
    }
    _writeSliceManifest(manifest, output_dir)
    print(f"   Created {made} slices", flush=True)
    return output_dir


def sliceMusic(
    name: str,
    start: float,
    end: float,
    slice_ms: float = 150,
    count: int | None = None,
    output_dir: str | Path | None = None,
    fade_ms: float = 8,
) -> Path:
    """
    Slice a library track by name between start/end (seconds).

    e.g. sliceMusic("chill_beat", start=2.0, end=10.0, slice_ms=150)
    """
    src = getMusic(name)
    if output_dir is None:
        output_dir = CUES_DIR / name
    return sliceIntoAudios(
        src,
        start=start,
        end=end,
        slice_ms=slice_ms,
        count=count,
        output_dir=output_dir,
        fade_ms=fade_ms,
        pack_name=name,
    )


def listSlicePacks() -> list[str]:
    """List cue packs that have a manifest under Music/library/cues/."""
    CUES_DIR.mkdir(parents=True, exist_ok=True)
    packs = []
    for entry in sorted(CUES_DIR.iterdir()):
        if entry.is_dir() and (entry / "manifest.json").is_file():
            packs.append(entry.name)
    return packs


def listSlices(pack: str | Path) -> list[Path]:
    """Return ordered slice file paths for a pack."""
    pack_dir = _resolveSlicePack(pack)
    manifest = _readSliceManifest(pack_dir)
    paths = []
    for item in manifest.get("slices", []):
        path = pack_dir / item["file"]
        if path.is_file():
            paths.append(path)
    if paths:
        return paths
    return sorted(pack_dir.glob("slice_*.wav"))


def getSlice(pack: str | Path, index: int) -> Path:
    """
    Get one slice wav from a pack (by library name or pack folder path).

    e.g. getSlice("chill_beat", 3) → .../cues/chill_beat/slice_03.wav
    """
    pack_dir = _resolveSlicePack(pack)
    path = pack_dir / f"slice_{index:02d}.wav"
    if path.is_file():
        return path

    manifest = _readSliceManifest(pack_dir)
    for item in manifest.get("slices", []):
        if item.get("index") == index:
            candidate = pack_dir / item["file"]
            if candidate.is_file():
                return candidate

    raise FileNotFoundError(
        f"Slice {index} not found in pack '{pack_dir.name}'. "
        f"Use listSlices('{pack_dir.name}') to see available slices."
    )