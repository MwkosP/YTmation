#!/usr/bin/env python3
"""Interactive CLI to create a video — like Next.js create-next-app."""

import questionary
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

BLENDER_CHANNELS = ["neon_physics", "soundscape", "realistic"]
PARKOUR_CHANNELS = ["psychology_parkour", "finance_parkour", "cs_parkour", "reddit_parkour"]
MANHWA_CHANNELS  = ["manhwa"]

def main():
    print("\n🎬  YT Agent — Make a Video\n")

    # ─── CHANNEL ─────────────────────────────────────────
    channel = questionary.select(
        "Which channel?",
        choices=[
            "neon_physics",
            "soundscape",
            "realistic",
            "manhwa",
            "psychology_parkour",
            "finance_parkour",
            "cs_parkour",
            "reddit_parkour",
        ]
    ).ask()

    if not channel:
        sys.exit(0)

    # ─── PRESET ──────────────────────────────────────────
    preset = questionary.select(
        "Video format?",
        choices=[
            "short_60s   — YouTube Short 60s  9:16",
            "short_30s   — YouTube Short 30s  9:16",
            "long_10min  — Long form 10min   16:9",
            "reel_15s    — Instagram Reel 15s 9:16",
        ]
    ).ask()

    if not preset:
        sys.exit(0)

    preset_id = preset.split()[0]

    # ─── TOPIC ───────────────────────────────────────────
    topic_mode = questionary.select(
        "Topic?",
        choices=[
            "Auto — let Trends/ find what's hot",
            "Manual — I'll type it",
        ]
    ).ask()

    if not topic_mode:
        sys.exit(0)

    topic = None
    if "Manual" in topic_mode:
        topic = questionary.text("Enter topic:").ask()
        if not topic:
            sys.exit(0)

    # ─── BLENDER ONLY OPTIONS ────────────────────────────
    style_id  = None
    script_id = None

    if channel in BLENDER_CHANNELS:
        style = questionary.select(
            "Visual style?",
            choices=[
                "neon       — dark bg, glowing colors",
                "realistic  — concrete, steel, daylight",
                "gold       — luxury dark gold",
                "clay       — minimal white clay",
            ]
        ).ask()

        if not style:
            sys.exit(0)

        style_id = style.split()[0]

        script = questionary.select(
            "Which render?",
            choices=[
                "render_balls      — bouncing balls",
                "render_cloth      — cloth simulation",
                "render_chain      — chain falling",
                "render_cradle     — newton's cradle",
                "render_dice       — dice rolling",
                "render_dominoes   — dominoes falling",
                "render_wrecking   — wrecking ball",
                "render_glass      — glass shattering",
                "render_fluid      — fluid pouring",
            ]
        ).ask()

        if not script:
            sys.exit(0)

        script_id = script.split()[0]

    # ─── UPLOAD ──────────────────────────────────────────
    upload = questionary.select(
        "After rendering?",
        choices=[
            "Upload now",
            "Schedule — pick best time",
            "Save only — don't upload",
        ]
    ).ask()

    if not upload:
        sys.exit(0)

    # ─── CONFIRM ─────────────────────────────────────────
    print(f"""
┌─────────────────────────────────┐
│  Ready to create your video     │
├─────────────────────────────────┤
│  Channel  : {channel:<23}│
│  Preset   : {preset_id:<23}│
│  Topic    : {(topic or 'auto'):<23}│
│  Style    : {(style_id or 'n/a'):<23}│
│  Script   : {(script_id or 'n/a'):<23}│
│  Upload   : {upload:<23}│
└─────────────────────────────────┘""")

    confirm = questionary.confirm("Start?").ask()

    if not confirm:
        print("\nCancelled.\n")
        sys.exit(0)

    # ─── RUN ─────────────────────────────────────────────
    print(f"\n🚀 Starting pipeline...\n")

    cmd = [
        sys.executable,
        str(ROOT / "main.py"),
        "--channel",  channel,
        "--preset",   preset_id,
        "--upload",   upload,
        *(["--topic",  topic]     if topic     else []),
        *(["--style",  style_id]  if style_id  else []),
        *(["--script", script_id] if script_id else []),
    ]

    subprocess.run(cmd)


if __name__ == "__main__":
    main()