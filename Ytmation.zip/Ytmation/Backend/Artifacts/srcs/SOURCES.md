# Sources & dependencies

Master inventory of **CLI tools, Python libraries, ML models, external APIs, and asset libraries** used in Ytmation.

- **Part 1** — everything the system uses (global list).  
- **Part 2** — same items mapped **per module** (what each folder actually calls).

Canonical pip list: `pyproject.toml`  
Last reviewed: 2026-05-29 (Voice: added `generateSpeech` router)

---

# Part 1 — System-wide inventory

Everything below appears somewhere in the project. Module-specific usage is in Part 2.

---

## 1.1 CLI & system binaries

| Binary | Role |
|--------|------|
| **ffmpeg** | Video encode, concat, xfade, overlay, audio mix, trim, fade |
| **ffprobe** | Media duration / stream metadata |
| **yt-dlp** | Download audio from YouTube |
| **Ollama** (`ollama serve`, `http://127.0.0.1:11434`) | Local LLM HTTP API |
| **Blender** (local install) | 3D rendering via bundled Python scripts |
| **manim** | Math animation CLI |

---

## 1.2 Python libraries — direct (`pyproject.toml`)

### Core dependencies

| Package | Type |
|---------|------|
| **pillow** | Library |
| **pygame** | Library |
| **gtts** | Library (calls Google TTS online) |
| **openai-whisper** | Library |
| **rembg[cpu]** | Library |
| **ddgs** | Library |
| **yt-dlp** | Library (+ CLI) |
| **manim** | Library + CLI |
| **anthropic** | Library — **declared, not wired in code** |
| **elevenlabs** | Library — **declared, not wired in code** |

### Optional extras

| Extra | Packages |
|-------|----------|
| `math-community` | manim-dsa, manim-ml, manim-voiceover, shapely, manim-physics |
| `voice-orpheus` | gradio_client |
| `dev` | pytest, ruff |

---

## 1.3 Python libraries — transitive / implicit

Installed via core deps; used directly in some scripts.

| Package | Pulled in by | Used in |
|---------|--------------|---------|
| **numpy** | rembg, pygame, manim, whisper | `Characters/cutoutCharacters.py`, image arrays |
| **scipy** | (manual / rembg stack) | `Characters/cutoutCharacters.py` |
| **onnxruntime** | rembg[cpu] | Background removal inference |
| **requests** | ddgs / common deps | `Image/image.py` |
| **torch** | whisper, manim, TripoSR | Whisper, Manim, TripoSR sub-project |
| **torchaudio** | whisper | Whisper |
| **tiktoken** / **numba** | whisper | Whisper |
| **opencv-python-headless** | rembg | rembg preprocessing |
| **pooch** | rembg | Model file download/cache |
| **tqdm** | rembg, whisper | Progress bars |
| **click** | manim | Manim CLI |
| **rich** | manim | Manim output |
| **networkx** | manim | Manim graphs |
| **mapbox-earcut** / **skia-pathops** | manim | Manim geometry |
| **moderngl** | manim (optional paths) | GL rendering |
| **CairoSVG** / **svglib** | manim | SVG import |

---

## 1.4 ML models & remote inference

| Model / service | ID or default | Cached / hosted | Used for |
|-----------------|---------------|-----------------|----------|
| **Ollama chat models** | Default: **`qwen2.5-coder:3b`** (any pulled model works) | Local Ollama | Scripts, hooks, keywords |
| **Whisper** | **`base`** | Downloaded on first use | Word timestamps, captions |
| **rembg / u2net** | Default session **`u2net`** (ONNX) | `~/.u2net/` | Character/image BG removal |
| **Orpheus TTS** | HF Space **`MohamedRashad/Orpheus-TTS`** | Remote (Gradio) | Neural TTS |
| **TripoSR** | HF **`stabilityai/TripoSR`** | Downloaded on first run | Image → 3D mesh |
| **gTTS** | Google Translate TTS (no local model) | Remote API | Speech MP3 via `generateSpeech(model="gtts")` |
| **Anthropic Claude** | — | Remote API | **Not wired** |
| **ElevenLabs** | — | Remote API | **Not wired** |

### Orpheus voices (remote)

`tara`, `leah`, `jess`, `leo`, `dan`, `mia`, `zac`, `zoe`

### rembg models available (not all used)

Project default is **u2net**. rembg also supports e.g. `isnet-anime`, `birefnet-general`, `silueta`, `sam`, etc. — see rembg docs if switching sessions.

---

## 1.5 External APIs & feeds (non-ML)

| Service | Endpoint / access | Used for |
|---------|-------------------|----------|
| **Google TTS** | via gTTS | Voice MP3 |
| **DuckDuckGo Images** | via ddgs | Stock image search |
| **Hugging Face Gradio** | Orpheus Space | Orpheus TTS |
| **Hugging Face Hub** | model weights | TripoSR, rembg ONNX |
| **Reddit** | public JSON/HTML | `Trends/` research |
| **Google Trends RSS** | trending feed | `Trends/` |
| **Google News RSS** | search feed | `Trends/` |
| **YouTube Data API v3** | optional API key | `Trends/` (youtube source) |

**Env vars:** `HF_TOKEN` / `HUGGINGFACE_HUB_TOKEN` (Orpheus), `YOUTUBE_API_KEY` or similar for Trends YouTube source.

---

## 1.6 TripoSR sub-stack (separate venv)

`Blender/TripoSR/requirements.txt` — not merged into main `pyproject.toml`.

| Package | Notes |
|---------|--------|
| torch, transformers | TripoSR inference |
| trimesh, xatlas, einops | Mesh processing |
| omegaconf | Config |
| rembg, huggingface-hub | BG removal + weights |
| gradio, imageio[ffmpeg] | Demo app |
| moderngl | 3D preview |
| torchmcubes | Iso-surface extraction |

**Model:** `stabilityai/TripoSR`

---

## 1.7 Bundled assets & data (no ML)

| Asset | Location |
|-------|----------|
| SFX library | `SFX/library/` + `manifest.json` (39 tags) |
| SFX ad-hoc | `SFX/sounds/` |
| Music library | `Music/library/`, `Music/library/cues/` |
| Character poses | `Templates/characters/` |
| Game / transition templates | `Games/templates/` |
| Character segment presets | `Characters/templates/` |
| Thumbnail templates | `Thumbnail/templates/` |
| Prompts | `Prompts/system.md`, `Prompts/Prompts/*.md` |
| Hook heuristics | `Hooks/patterns.json` |
| Channel branding | `Branding/channels/` |
| Trend source configs | `Trends/sources/` |

---

## 1.8 Stdlib only (no extra pip deps)

These modules use Python stdlib + ffmpeg only:

`Storage/`, `Footage/` (mostly), `Revenue/`, `Branding/branding.py` (JSON loaders), `Games/templates/registry.py`

---

# Part 2 — Module-wise breakdown

For each module: **libraries**, **models**, **APIs/services**, **assets**, **entry files**.

---

## Script

| Kind | Items |
|------|--------|
| **Libraries** | stdlib (`json`, `urllib`); **Ollama** via HTTP (no SDK) |
| **Models** | Ollama — default **`qwen2.5-coder:3b`** |
| **APIs** | Ollama `POST /api/chat` @ `127.0.0.1:11434` |
| **Assets** | `Prompts/system.md`, `Prompts/Prompts/*.md` |
| **Code** | `Script/script.py`, `Script/utils.py`, `Script/keywords.py`, `Script/psychology_fact.py` |

---

## Hooks

| Kind | Items |
|------|--------|
| **Libraries** | stdlib (`json`, `urllib`, `re`) |
| **Models** | Ollama — default **`qwen2.5-coder:3b`** (generator + critic pass) |
| **APIs** | Ollama chat API |
| **Assets** | `Prompts/hooks_system.md`, `Prompts/Prompts/hooks.md`, `Hooks/patterns.json` |
| **Code** | `Hooks/hooks.py`, `Hooks/utils.py` |

---

## Voice

| Kind | Items |
|------|--------|
| **Primary API** | **`Voice/speech.py`** — `generateSpeech(text, model=...)`, `listSpeechModels()` |
| **Libraries** | **gtts**, **openai-whisper**, **gradio_client** (optional extra), stdlib **subprocess** |
| **Models** | Whisper **`base`**; Orpheus (remote, no local weights) |
| **APIs** | Google TTS (gTTS); HF Gradio **`MohamedRashad/Orpheus-TTS`** |
| **CLI** | **ffmpeg** (Orpheus WAV→MP3), **ffprobe** (duration) |
| **Legacy** | `Voice/voice.py` (`generateVoice`), `Voice/orpheus.py` (`generateOrpheusVoice`) |
| **Docs** | `Voice/SKILL.md` |

---

## Math

| Kind | Items |
|------|--------|
| **Libraries** | **manim**; optional: **manim-voiceover**, **manim-dsa**, **manim-ml**, **manim-physics**, **shapely** |
| **Models** | Whisper **`base`** (when `transcription_model` set); uses Voice stack for gTTS/Orpheus |
| **APIs** | gTTS / Orpheus (via `Math/voiceover/helpers.py`) |
| **CLI** | **manim**, **ffmpeg** |
| **Code** | `Math/math.py`, `Math/library/*`, `Math/voiceover/` |

---

## SFX

| Kind | Items |
|------|--------|
| **Libraries** | stdlib (`json`, `pathlib`, `urllib.request` for `downloadSFX`) |
| **Models** | — |
| **Assets** | `SFX/library/manifest.json`, `SFX/library/**`, `SFX/sounds/` |
| **Code** | `SFX/sfx.py` |

---

## Music

| Kind | Items |
|------|--------|
| **Libraries** | stdlib **subprocess** |
| **CLI** | **yt-dlp**, **ffmpeg** (trim, loop, slice) |
| **Models** | — |
| **Assets** | `Music/library/`, `Music/library/cues/` |
| **Code** | `Music/music.py`, `Music/utils.py` |

---

## Stitching

| Kind | Items |
|------|--------|
| **Libraries** | stdlib, **Pillow** (indirect via overlays if any) |
| **CLI** | **ffmpeg** (overlay, amix, drawtext, scale, copy) |
| **Models** | — |
| **Code** | `Stitching/stitching.py`, `Stitching/utils.py` |

---

## Transitions

| Kind | Items |
|------|--------|
| **Libraries** | stdlib |
| **CLI** | **ffmpeg**, **ffprobe** (xfade concat, normalize inputs) |
| **Models** | — |
| **Assets** | xfade preset names in `Transitions/utils.py` |
| **Code** | `Transitions/transitions.py`, `Transitions/utils.py` |

---

## Games

| Kind | Items |
|------|--------|
| **Libraries** | **pygame**, stdlib (`tempfile`, `subprocess`, `math`, `random`) |
| **CLI** | **ffmpeg** (PNG sequence → H.264) |
| **Models** | — |
| **Audio** | **SFX** via `Games/collision_audio.py` → `SFX.getSFX()` |
| **Assets** | `Games/templates/bb/`, `Games/templates/transitions/` |
| **Code** | `Games/games.py`, `Games/animations/bb/*`, `Games/animations/transitions/transition*.py`, `Games/collision_audio.py` |

---

## Characters

| Kind | Items |
|------|--------|
| **Libraries** | **pygame**, **numpy**, **scipy** (cutout script), **Pillow** + **rembg** (cutout script) |
| **Models** | rembg **`u2net`** ONNX (`~/.u2net/`) |
| **CLI** | **ffmpeg** |
| **Assets** | `Templates/characters/*.png` (`*B.png` manual cutouts) |
| **Code** | `Characters/characters.py`, `Characters/spoken.py`, `Characters/poses.py`, `Characters/cutoutCharacters.py`, `Characters/templates/` |
| **Planned** | `renderSpokenCharacterTimeline`, `renderCharacterIntro` → `Voice.generateSpeech` + `Stitching.overlayAudio` |
| **Docs** | `Characters/SKILL.md` |

---

## Image

| Kind | Items |
|------|--------|
| **Libraries** | **Pillow**, **ddgs**, **requests**, **rembg** |
| **Models** | rembg **`u2net`** |
| **APIs** | DuckDuckGo Images; HTTP image URLs |
| **Code** | `Image/image.py` |

---

## Thumbnail

| Kind | Items |
|------|--------|
| **Libraries** | **Pillow** only |
| **Models** | — |
| **Assets** | `Thumbnail/templates/` (bold_text, gradient, radial_glow) |
| **Code** | `Thumbnail/thumbnail.py`, `Thumbnail/utils.py` |

---

## Blender

| Kind | Items |
|------|--------|
| **Libraries** | Blender embedded **bpy** API |
| **CLI** | **Blender** binary |
| **Models** | — (meshes from TripoSR or imported OBJ) |
| **Code** | `Blender/blender.py`, `Blender/scripts/*`, `Blender/blenderAbstractions.py` |

---

## Blender / TripoSR

| Kind | Items |
|------|--------|
| **Libraries** | torch, transformers, trimesh, rembg, gradio, … (see §1.6) |
| **Models** | **`stabilityai/TripoSR`**; rembg session for input cleanup |
| **APIs** | Hugging Face Hub (weights) |
| **Code** | `Blender/TripoSR/run.py`, `Blender/TripoSR/gradio_app.py` |

---

## Footage

| Kind | Items |
|------|--------|
| **Libraries** | stdlib |
| **CLI** | **ffmpeg** |
| **Models** | — |
| **Assets** | Local video folders (per workflow) |
| **Code** | `Footage/footage.py`, `Footage/utils.py` |

---

## Branding

| Kind | Items |
|------|--------|
| **Libraries** | stdlib |
| **CLI** | **ffmpeg** (watermark, lower-third burn-in) |
| **Models** | — |
| **Assets** | `Branding/channels/{channel}/channel.json`, `branding.json`, presets |
| **Code** | `Branding/branding.py`, `Branding/utils.py` |

---

## Trends

| Kind | Items |
|------|--------|
| **Libraries** | stdlib (`urllib`, `xml.etree`) |
| **APIs** | Reddit, Google Trends RSS, Google News RSS, YouTube Data API v3 |
| **Models** | — |
| **Assets** | `Trends/sources/` |
| **Code** | `Trends/trends.py`, `Trends/utils.py` |

---

## Storage

| Kind | Items |
|------|--------|
| **Libraries** | stdlib (`json`) |
| **Models** | — |
| **Assets** | JSON logs under `Storage/` (upload history, cache, run logs) |
| **Code** | `Storage/storage.py`, `Storage/utils.py` |

---

## Workflows

Orchestration only — no unique libraries. Each workflow composes modules above.

| Workflow example | Modules touched |
|------------------|-----------------|
| `Workflows/channels/bouncemwk/workflowShowcase.py` | Characters, Games, Transitions (+ Voice planned for intro) |
| `Workflows/channels/bouncemwk/characterPhotoDemo.py` | Characters |
| `Workflows/channels/mathmwk/*Voiceover.py` | Math, Voice (`generateSpeech`), Transitions, Stitching |
| `Workflows/channels/mathKnn.py` | Math, Voice, Image, Stitching |

---

## Planned / declared but unused

| Package | Intended use (README / pyproject) |
|---------|-----------------------------------|
| **anthropic** | Claude script generation |
| **elevenlabs** | Premium TTS |

---

# Quick reference — what must be running

| If you run… | Need |
|-------------|------|
| Script / Hooks / keywords | Ollama + pulled model |
| gTTS voice | Internet |
| Whisper captions | First-run model download |
| Orpheus | `gradio_client`, internet, HF token optional |
| Character cutout | rembg → u2net download first run |
| Games / Characters render | pygame, ffmpeg |
| Math Manim | manim CLI, ffmpeg |
| TripoSR | Separate venv, torch, HF model download |
| Music from URL | yt-dlp, ffmpeg |
| Trends (YouTube) | YouTube API key |

---

## See also

- `pyproject.toml` — install commands & optional extras  
- `README.md` — module layout  
- `Games/templates/transitions/README.md` — transition catalog  
- `Artifacts/srcs/sources.txt` — credits & production notes  
