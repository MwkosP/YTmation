#!/usr/bin/env python3
"""Wire collision_audio boilerplate into bb animations (fast, no heavy regex)."""

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BB = ROOT / "Games" / "animations" / "bb"
SKIP = {"bouncingBalls.py"}

AUDIO_INIT = '''
    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
'''

FINALIZE = '''    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration)
'''


def patch_file(path: Path) -> bool:
    text = path.read_text()
    orig = text

    if "collision_audio: dict | None = None," not in text and "**kwargs," in text:
        text = text.replace(
            "    **kwargs,\n) -> Path:",
            "    collision_audio: dict | None = None,\n    **kwargs,\n) -> Path:",
            1,
        )

    marker = 'os.environ.setdefault("SDL_AUDIODRIVER", "dummy")\n'
    if marker in text and "CollisionAudioSession(collision_audio_cfg)" not in text:
        text = text.replace(marker, marker + AUDIO_INIT, 1)

    if "ball_collision" in text and "if audio.enabled:\n        ball_collision = True" not in text:
        text = text.replace(
            "audio = CollisionAudioSession(collision_audio_cfg)\n",
            "audio = CollisionAudioSession(collision_audio_cfg)\n"
            "    if audio.enabled:\n        ball_collision = True\n",
            1,
        )

    end_block = (
        '    pygame.quit()\n'
        '    print(f"   Done → {output}")\n'
        "    return Path(output)"
    )
    if end_block in text and "finalizeCollisionAudio" not in text:
        text = text.replace(
            end_block,
            '    pygame.quit()\n'
            '    print(f"   Done → {output}")\n'
            + FINALIZE
            + "    return output",
            1,
        )

    if text != orig:
        path.write_text(text)
        return True
    return False


def main():
    changed = [p.name for p in BB.glob("*.py") if p.name not in SKIP and patch_file(p)]
    print("Boilerplate patched:", ", ".join(changed) or "(none)")


if __name__ == "__main__":
    main()
