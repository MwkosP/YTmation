#!/usr/bin/env python3
"""Second pass: fix gaps and wire collision logging in bb animations."""

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BB = ROOT / "Games" / "animations" / "bb"
SKIP = {"bouncingBalls.py"}

AUDIO_INIT = '''
    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
'''

LOG_BEFORE_RETURN_HIT = (
    "    if hit and audio is not None:\n"
    "        log_wall_from_ball(audio, t, ball)\n"
    "    return hit\n"
)

AUDIO_SUFFIX = ", audio=audio if audio.enabled else None, t=frame / fps"


def patch_file(path: Path) -> list[str]:
    text = path.read_text()
    orig = text
    notes = []

    if "collision_audio: dict | None = None," not in text:
        if "**kwargs,\n) -> Path:" in text:
            text = text.replace(
                "**kwargs,\n) -> Path:",
                "collision_audio: dict | None = None,\n    **kwargs,\n) -> Path:",
                1,
            )
            notes.append("param->Path")
        elif "**kwargs,\n):" in text:
            text = text.replace(
                "**kwargs,\n):",
                "collision_audio: dict | None = None,\n    **kwargs,\n):",
                1,
            )
            notes.append("param")

    for marker in (
        'os.environ.setdefault("SDL_AUDIODRIVER", "dummy")\n',
        'os.environ.setdefault("SDL_AUDIODRIVER","dummy")\n',
    ):
        if marker in text and "CollisionAudioSession(collision_audio_cfg)" not in text:
            text = text.replace(marker, marker + AUDIO_INIT, 1)
            notes.append("init")
            break

    if (
        "ball_collision" in text
        and "if audio.enabled:\n        ball_collision = True" not in text
        and "CollisionAudioSession(collision_audio_cfg)" in text
    ):
        text = text.replace(
            "audio = CollisionAudioSession(collision_audio_cfg)\n",
            "audio = CollisionAudioSession(collision_audio_cfg)\n"
            "    if audio.enabled:\n        ball_collision = True\n",
            1,
        )
        notes.append("ball_collision")

    old_def = "angle_offset=0.0):"
    new_def = "angle_offset=0.0, audio=None, t: float = 0.0):"
    if f"def _resolve_shape_collision(" in text and new_def not in text:
        text = text.replace(
            "def _resolve_shape_collision(" + text.split("def _resolve_shape_collision(", 1)[1].split("):", 1)[0] + "):",
            "def _resolve_shape_collision("
            + text.split("def _resolve_shape_collision(", 1)[1].split("):", 1)[0]
            + new_def[1:],
            1,
        )
        # simpler: only replace in def line
        lines = text.splitlines(keepends=True)
        for i, line in enumerate(lines):
            if line.startswith("def _resolve_shape_collision(") and old_def in line:
                lines[i] = line.replace(old_def, new_def)
                notes.append("shape_def")
                break
        text = "".join(lines)

    if "def _resolve_shape_collision(" in text and LOG_BEFORE_RETURN_HIT.split("\n")[0] not in text:
        if "    return hit\n" in text:
            text = text.replace("    return hit\n", LOG_BEFORE_RETURN_HIT, 1)
            notes.append("shape_log")

    # _resolveShapeCollision def (camelCase)
    lines = text.splitlines(keepends=True)
    for i, line in enumerate(lines):
        if line.startswith("def _resolveShapeCollision(") and "audio=None" not in line:
            lines[i] = line.replace(old_def, new_def)
            notes.append("shape_def_camel")
    text = "".join(lines)

    # Calls: append audio suffix before closing paren on _resolve_shape_collision lines
    out_lines = []
    for line in text.splitlines(keepends=True):
        stripped = line.lstrip()
        if (
            "_resolve_shape_collision(" in stripped
            and not stripped.startswith("def ")
            and AUDIO_SUFFIX not in line
            and line.rstrip().endswith(")")
        ):
            line = line.rstrip()[:-1] + AUDIO_SUFFIX + ")\n"
            notes.append("shape_call")
        out_lines.append(line)
    text = "".join(out_lines)

    # After hit= _resolveShapeCollision(...) — log at call site for multi-return fns
    if "_resolveShapeCollision(" in text:
        repls = [
            (
                "hit=_resolveShapeCollision(",
                "hit=_resolveShapeCollision(",
            ),
        ]
        # Add log after lines that assign hit from _resolveShapeCollision
        lines = text.splitlines(keepends=True)
        new_lines = []
        i = 0
        while i < len(lines):
            new_lines.append(lines[i])
            s = lines[i]
            if (
                "_resolveShapeCollision(" in s
                and not s.strip().startswith("def ")
                and "log_wall_from_ball" not in s
            ):
                # next line might be continuation; find statement end
                stmt = s
                j = i
                while not stmt.rstrip().endswith(")") and j + 1 < len(lines):
                    j += 1
                    stmt += lines[j]
                    new_lines.append(lines[j])
                i = j
                indent = s[: len(s) - len(s.lstrip())]
                if "hit" in stmt and "log_wall_from_ball" not in lines[i + 1 : i + 3]:
                    new_lines.append(
                        f"{indent}if hit:\n"
                        f"{indent}    log_wall_from_ball(audio, frame / fps, ball)\n"
                    )
                    notes.append("shape_call_log")
            i += 1
        text = "".join(new_lines)

    # Ball-ball: replace calls to use resolve_ball_collisions from module
    if "_resolveBallCollisions(balls, bounce)" in text:
        text = text.replace(
            "_resolveBallCollisions(balls, bounce)",
            "resolve_ball_collisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)",
        )
        notes.append("ball_call")
    if "_resolveBallCollisions(balls, bounce, rest_threshold)" in text:
        text = text.replace(
            "_resolveBallCollisions(balls, bounce, rest_threshold)",
            "resolve_ball_collisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None, skip_settled=True)",
        )
        notes.append("ball_call_settled")
    if "_resolveBallCollisions(inner_balls, bounce_floor)" in text:
        text = text.replace(
            "_resolveBallCollisions(inner_balls, bounce_floor)",
            "resolve_ball_collisions(inner_balls, bounce_floor, t=frame / fps, audio=audio if audio.enabled else None)",
        )
        notes.append("ball_call_inner")

    if "col = _resolveBallCollisions(active_balls, bounce)" in text:
        text = text.replace(
            "col = _resolveBallCollisions(active_balls, bounce)",
            "col = _resolveBallCollisions(active_balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)",
        )
        notes.append("ball_call_active")

    if text != orig:
        path.write_text(text)
    return notes


def main():
    for py in sorted(BB.glob("*.py")):
        if py.name in SKIP:
            continue
        notes = patch_file(py)
        if notes:
            print(py.name, ":", ", ".join(sorted(set(notes))))


if __name__ == "__main__":
    main()
