"""
Games/utils.py  — internal helpers only, never called directly
"""

import os
import random
import subprocess
from pathlib import Path


# ── colour helpers ─────────────────────────────────────────────────────────────

def hexToRgb(hex_color: str) -> tuple:
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


def randomColor() -> tuple:
    return (random.randint(60, 255), random.randint(60, 255), random.randint(60, 255))


# ── frame helpers ──────────────────────────────────────────────────────────────

def saveFrame(surface, frames_dir: Path, frame_index: int):
    """Save a pygame surface as a PNG frame."""
    import pygame
    path = frames_dir / f"frame_{frame_index:06d}.png"
    pygame.image.save(surface, str(path))


def framestoVideo(frames_dir: Path, output: Path, fps: int = 60):
    """Encode PNG frames to MP4 using ffmpeg."""
    output.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-y",
        "-framerate", str(fps),
        "-i", str(frames_dir / "frame_%06d.png"),
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-preset", "fast",
        "-crf", "18",
        str(output)
    ]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def cleanFrames(frames_dir: Path):
    """Delete all PNG frames from a directory."""
    for f in frames_dir.glob("*.png"):
        f.unlink()