# Games Module

## Purpose
Programmatic 2D animations using pygame. Renders animations to mp4 files
that can be used as footage or overlaid on videos.

## Location
`Games/games.py`

## Animations
Animation scripts live in `Games/animations/`. Each is a .py file with a run() function.
Current animations: bouncing_balls, bouncingBallsInsideCircle

## Functions

### renderAnimation(name, duration, output, **params) -> Path
Render an animation by name. Params are passed to the animation's run() function.
```python
from Games.games import renderAnimation
result = renderAnimation("bouncing_balls", duration=10, ball_count=8, colors=["#FF4500"])
```

### previewAnimation(name, **params) -> Path
Renders only 3 seconds for quick testing.
```python
from Games.games import previewAnimation
result = previewAnimation("bouncing_balls", ball_count=5)
```

### listAnimations() -> list[str]
Lists all available animation names.
```python
from Games.games import listAnimations
print(listAnimations())  # ['bouncing_balls', 'bouncingBallsInsideCircle']
```

### getAnimation(name) -> Path
Gets the most recently cached render of an animation.
```python
from Games.games import getAnimation
result = getAnimation("bouncing_balls")
```

### randomAnimation(duration, **params) -> Path
Picks a random animation and renders it.
```python
from Games.games import randomAnimation
result = randomAnimation(duration=10)
```

### collision_audio (all `bb` animations)
Pass `collision_audio={...}` to any `renderAnimation` in `animations/bb/`. Output becomes `*_collision.mp4` when hits are logged.

**Mode `sfx`** — static one-shots (`SFX.getSFX`, includes `SFX/sounds/`). Default `clip_s`: 1.0s per hit.
```python
renderAnimation("pinball", collision_audio={
    "mode": "sfx",
    "wall": "marioCoin",
    "ball": "marioCoin",
    "clip_s": 0.15,
})
```

**Mode `revealMusic`** — sequential slices (`Music.getSlice`):
```python
# once: sliceMusic("my_beat", start=2.0, end=10.0, slice_ms=150)
renderAnimation("chaseBall", collision_audio={
    "mode": "revealMusic",
    "pack": "my_beat",
})
```

## Animation Params

### bouncing_balls
- ball_count, colors, bg_color, fps, width, height
- min_radius, max_radius, gravity, bounce

### bouncingBallsInsideCircle
- ball_count, colors, bg_color, circle_color, circle_radius
- fps, width, height, min_radius, max_radius
- gravity, bounce, circle_thick

## Adding New Animations
Drop a .py file in Games/animations/ with:
```python
def run(duration=10, output=None, **params) -> Path:
    ...
```
It appears automatically in listAnimations().

## Visual presets

Look presets live in `Games/templates/` (`bb/`, `transitions/`). See `Games/templates/README.md`.

```python
from Games.templates.templates import getTemplate, applyTemplate, listTemplates

getTemplate("neon_dark")
applyTemplate("neon_dark", "bouncingBalls")
```