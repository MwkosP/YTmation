"""
Collision audio for Games animations.

Modes:
  - sfx: static one-shot per hit (SFX.getSFX)
  - revealMusic: sequential Music slices (Music.getSlice)
"""

from __future__ import annotations

import math
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = ROOT / "Cache" / "games" / "collision_audio"


class CollisionAudioSession:
    """Collect collision times; resolve sounds when logging."""

    def __init__(self, config: dict | None):
        self.config = dict(config or {})
        self.mode = self.config.get("mode", "sfx")
        self.events: list[dict] = []
        self._reveal_index = 0
        self._last_t: dict[str, float] = {}
        self.cooldown_s = float(self.config.get("cooldown_ms", 50)) / 1000.0
        self.volume = float(self.config.get("volume", 0.85))
        # Max length per hit in sfx mode (seconds); full file plays if None
        self.clip_s = self.config.get("clip_s")
        if self.clip_s is None and self.mode == "sfx":
            self.clip_s = 1.0
        if self.clip_s is not None:
            self.clip_s = float(self.clip_s)
        self._wall_sfx = None
        self._ball_sfx = None
        self._pack = self.config.get("pack", "")
        if self.enabled:
            self._wall_sfx = self._resolve_sfx_path(self.config.get("wall", "thud"))
            self._ball_sfx = self._resolve_sfx_path(
                self.config.get("ball", self.config.get("wall", "pop"))
            )

    @property
    def enabled(self) -> bool:
        return bool(self.config) and self.mode in ("sfx", "revealMusic")

    def _resolve_sfx_path(self, spec: str | None) -> Path | None:
        if not spec:
            return None
        from SFX.sfx import getSFX

        return getSFX(spec)

    def _sound_for(self, kind: str) -> Path:
        if self.mode == "revealMusic":
            from Music.music import getSlice

            pack = self._pack or self.config.get("music", "")
            if not pack:
                raise ValueError("revealMusic mode requires collision_audio['pack']")
            path = getSlice(pack, self._reveal_index)
            self._reveal_index += 1
            return path

        if kind == "ball":
            return self._ball_sfx or self._wall_sfx
        return self._wall_sfx

    def _can_log(self, kind: str, t: float) -> bool:
        last = self._last_t.get(kind, -1.0)
        if t - last < self.cooldown_s:
            return False
        self._last_t[kind] = t
        return True

    def log_wall(self, t: float, intensity: float = 1.0) -> None:
        if not self.enabled:
            return
        if not self._can_log("wall", t):
            return
        self._log("wall", t, intensity)

    def log_ball(self, t: float, intensity: float = 1.0) -> None:
        if not self.enabled:
            return
        if not self._can_log("ball", t):
            return
        self._log("ball", t, intensity)

    def _log(self, kind: str, t: float, intensity: float) -> None:
        try:
            path = self._sound_for(kind)
        except (FileNotFoundError, ValueError) as exc:
            print(f"[CollisionAudio] skip {kind} @ {t:.2f}s: {exc}", flush=True)
            return
        vol = min(1.5, max(0.1, self.volume * (0.5 + 0.5 * min(intensity / 8.0, 1.0))))
        self.events.append({
            "kind": kind,
            "t": round(t, 4),
            "path": str(path),
            "volume": vol,
            "clip_s": self.clip_s,
        })

    def to_overlay_list(self) -> list[dict]:
        return [
            {"path": e["path"], "start": e["t"], "volume": e["volume"]}
            for e in self.events
        ]


def buildCollisionAudio(
    events: list[dict],
    duration: float,
    output: Path | None = None,
) -> Path:
    """Mix collision clips onto a silent bed of `duration` seconds."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        output = CACHE_DIR / f"hits_{int(time.time())}.wav"

    if not events:
        subprocess.run([
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", f"anullsrc=r=44100:cl=mono:d={duration}",
            str(output),
        ], check=True)
        return Path(output)

    # One ffmpeg graph: silent base + delayed hits
    inputs = ["-f", "lavfi", "-i", f"anullsrc=r=44100:cl=mono:d={duration}"]
    parts = []
    labels = ["[0:a]"]
    for i, ev in enumerate(events):
        inputs.extend(["-i", ev["path"]])
        idx = i + 1
        delay_ms = int(ev["t"] * 1000)
        vol = ev.get("volume", 1.0)
        tag = f"h{i}"
        chain = f"[{idx}:a]"
        clip_s = ev.get("clip_s")
        if clip_s is not None and clip_s > 0:
            chain += f"atrim=0:{clip_s},asetpts=PTS-STARTPTS,"
        parts.append(f"{chain}adelay={delay_ms}|{delay_ms},volume={vol}[{tag}]")
        labels.append(f"[{tag}]")

    n = len(labels)
    parts.append(f"{''.join(labels)}amix=inputs={n}:duration=first:dropout_transition=0[aout]")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *inputs,
           "-filter_complex", ";".join(parts),
           "-map", "[aout]", str(output)]
    subprocess.run(cmd, check=True)
    return Path(output)


def setupCollisionAudio(collision_audio=None, **kwargs):
    """Pop collision_audio from kwargs; return session and remaining kwargs."""
    cfg = kwargs.pop("collision_audio", collision_audio)
    return CollisionAudioSession(cfg), kwargs


def finalizeCollisionAudio(output, audio: CollisionAudioSession, duration) -> Path:
    output = Path(output)
    if audio.enabled:
        print(
            f"   Collision audio: {len(audio.events)} hits ({audio.mode})",
            flush=True,
        )
        output = muxCollisionAudio(output, audio, float(duration))
    return output


def log_wall_from_ball(audio: CollisionAudioSession, t: float, ball: dict) -> None:
    if audio.enabled:
        audio.log_wall(t, math.hypot(ball.get("vx", 0), ball.get("vy", 0)))


def log_ball_pair(audio: CollisionAudioSession, t: float, dvx: float, dvy: float) -> None:
    if audio.enabled:
        audio.log_ball(t, math.hypot(dvx, dvy))


def resolve_ball_collisions(
    balls,
    bounce,
    t: float = 0.0,
    audio: CollisionAudioSession | None = None,
    *,
    active_key: str | None = None,
    skip_settled: bool = False,
) -> None:
    """Shared ball–ball resolver with optional collision audio."""
    n = len(balls)
    for i in range(n):
        for j in range(i + 1, n):
            a, b = balls[i], balls[j]
            if active_key and (not a.get(active_key, True) or not b.get(active_key, True)):
                continue
            dx = b["x"] - a["x"]
            dy = b["y"] - a["y"]
            dist = math.hypot(dx, dy)
            md = a["r"] + b["r"]
            if dist < md and dist > 0:
                overlap = (md - dist) / 2
                nx = dx / dist
                ny = dy / dist
                if not (skip_settled and a.get("settled")):
                    a["x"] -= nx * overlap
                    a["y"] -= ny * overlap
                if not (skip_settled and b.get("settled")):
                    b["x"] += nx * overlap
                    b["y"] += ny * overlap
                dvx = a["vx"] - b["vx"]
                dvy = a["vy"] - b["vy"]
                dot = dvx * nx + dvy * ny
                if dot > 0:
                    if not (skip_settled and a.get("settled")):
                        a["vx"] = (a["vx"] - dot * nx) * bounce
                        a["vy"] = (a["vy"] - dot * ny) * bounce
                    if not (skip_settled and b.get("settled")):
                        b["vx"] = (b["vx"] + dot * nx) * bounce
                        b["vy"] = (b["vy"] + dot * ny) * bounce
                if audio is not None:
                    log_ball_pair(audio, t, dvx, dvy)


def muxCollisionAudio(video: Path, session: CollisionAudioSession, duration: float) -> Path:
    """Build hit track and mux onto video (works when video has no audio)."""
    from Stitching.stitching import overlayAudio

    if not session.events:
        return video
    hits = buildCollisionAudio(session.events, duration)
    out = video.with_name(video.stem + "_collision.mp4")
    return overlayAudio(video, hits, output=out)
