"""Bouncing-ball / shape-container animation presets."""
