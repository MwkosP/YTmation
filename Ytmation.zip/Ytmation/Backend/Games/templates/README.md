# Games templates

Visual presets for `renderAnimation`. Each file under `bb/` or `transitions/` exports a `TEMPLATE` dict.

```python
from Games.templates.templates import getTemplate, applyTemplate, listTemplates

listTemplates("bb")          # ['fire', 'galaxy', 'neon_dark', ...]
getTemplate("neon_dark")
applyTemplate("neon_dark", "bouncingBalls", collision_audio={...})
```

One-time migration helpers (if needed): `Games/wireCollisionAudioBb*.py`
