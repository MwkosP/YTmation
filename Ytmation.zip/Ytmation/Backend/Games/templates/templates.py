"""
Games/templates/templates.py — Games-facing template API
-------------------------------------------------------
Presets live under Games/templates/<niche>/ (bb, transitions, …).

Public API:
    listTemplates(niche='bb')     → preset names
    getTemplate(name)             → params dict ('neon_dark' or 'bb/neon_dark')
    applyTemplate(name, animation, output, **overrides) → Path to MP4
"""

from __future__ import annotations

from Games.templates.registry import apply_games_template, get_template, list_templates, parse_template_name

DEFAULT_NICHE = "bb"


def listTemplates(niche: str = DEFAULT_NICHE) -> list:
    """Return preset names for a games niche (default: bb)."""
    return list_templates(niche)


def listAllTemplates() -> list:
    """Return all games presets as 'niche/name'."""
    return list_templates()


def getTemplate(name: str, niche: str = DEFAULT_NICHE) -> dict:
    """Return the full params dict for a template ('neon_dark' or 'transitions/reference')."""
    niche_resolved, preset = parse_template_name(name, default_niche=niche)
    try:
        return get_template(f"{niche_resolved}/{preset}", default_niche=niche)
    except (ValueError, AttributeError, ModuleNotFoundError):
        if "/" not in name:
            return get_template(f"transitions/{preset}", default_niche="transitions")
        raise


def applyTemplate(name: str, animation: str, output=None, niche: str = DEFAULT_NICHE, **overrides):
    """
    Render an animation using a template, with optional param overrides.

    Args:
        name      : template name (e.g. 'neon_dark' or 'bb/ocean')
        animation : animation name (e.g. 'bouncingBalls')
        output    : output path, auto if None
        niche     : games niche folder (default 'bb')
        **overrides: any param to override from the template
    """
    return apply_games_template(
        name,
        animation,
        output=output,
        niche=niche,
        **overrides,
    )
