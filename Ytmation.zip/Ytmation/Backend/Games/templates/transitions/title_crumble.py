"""Default transition5 — scale in, hold, crumble out."""

TEMPLATE = {
    "name": "title_crumble",
    "duration": 5.0,
    "text": "Episode 2",
    "text_x": 0.5,
    "text_y": 0.5,
    "text_in_effect": "scale",
    "in_duration": 1.0,
    "crumble_duration": 1.4,
    "fragment_size": 14,
    "crumble_burst": 4.5,
    "crumble_gravity": 0.38,
    "bg_color": "#0b0c10",
    "bg_color2": "#15182a",
    "bg_gradient_dir": "radial",
    "vignette": 0.35,
}
