TEMPLATE = {
    "name": "aggressive_glitch",
    "duration": 4.0,
    "text": "Episode 2",
    "rupture_in_duration": 0.55,
    "rupture_out_duration": 0.55,
    "glitch_intensity": 1.0,
    "rgb_split_max": 16,
    "accent_flash": "#ff3366",
}
