TEMPLATE = {
    "name": "aggressive_shock",
    "duration": 4.0,
    "text": "Episode 2",
    "impact_duration": 0.35,
    "slam_duration": 0.45,
    "shock_color": "#ff4d4d",
    "shake_strength": 22.0,
    "slam_scale": 1.75,
}
