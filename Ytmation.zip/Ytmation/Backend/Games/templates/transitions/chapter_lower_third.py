TEMPLATE = {
    "name": "chapter_lower_third",
    "duration": 5.0,
    "text": "Episode 2",
    "subtitle": "Prime Numbers",
    "text_y": 0.82,
    "slide_in_duration": 0.55,
    "bar_accent": "#00c8ff",
}
