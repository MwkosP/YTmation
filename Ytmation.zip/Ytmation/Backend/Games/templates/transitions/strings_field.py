TEMPLATE = {
    "name": "strings_field",
    "duration": 5.0,
    "text": "Episode 2",
    "subtitle": "Prime Numbers",
    "reveal_duration": 1.2,
    "string_count": 18,
    "inner_ring": True,
    "string_color": "#8aa8c8",
    "bg_color": "#0a0a0c",
    "bg_color2": "#101018",
}
