"""Default transition6 — spotlight sweep reveal."""

TEMPLATE = {
    "name": "title_spotlight",
    "duration": 5.0,
    "text": "Episode 2",
    "text_x": 0.5,
    "text_y": 0.5,
    "text_in_effect": "fade",
    "text_out_effect": "fade",
    "in_duration": 1.8,
    "out_duration": 1.0,
    "spotlight_path": "sweep",
    "spotlight_radius": 480.0,
    "spotlight_softness": 0.68,
    "ambient_dark": 28,
    "hold_ambient": 175,
    "idle_motion": True,
    "bg_color": "#0b0c10",
    "bg_color2": "#15182a",
    "bg_gradient_dir": "radial",
    "vignette": 0.4,
    "show_ripples": False,
}
