TEMPLATE = {
    "name": "water_tide",
    "duration": 5.0,
    "text": "Episode 2",
    "rise_duration": 2.2,
    "water_deep": "#0c3a52",
    "water_shallow": "#1a6a8a",
    "text_color": "#f0fcff",
}
