TEMPLATE = {
    "name": "minimal_sonar",
    "duration": 5.0,
    "text": "Episode 2",
    "ring_interval": 0.55,
    "ring_color": "#8a96a8",
    "pulse_count": 4,
    "bg_color": "#0c0c0e",
}
