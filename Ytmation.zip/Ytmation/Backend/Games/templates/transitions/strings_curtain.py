TEMPLATE = {
    "name": "strings_curtain",
    "duration": 5.0,
    "text": "Episode 2",
    "subtitle": "",
    "reveal_duration": 1.1,
    "string_count": 14,
    "string_color": "#9ab4d4",
    "orbit_speed": 1.0,
    "panel_color": "#0e0e10",
}
