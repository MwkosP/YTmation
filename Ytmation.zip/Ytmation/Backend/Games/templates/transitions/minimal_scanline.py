TEMPLATE = {
    "name": "minimal_scanline",
    "duration": 5.0,
    "text": "Episode 2",
    "scan_duration": 1.4,
    "line_height": 1.0,
    "line_axis_y": 0.5,
    "line_color": "#ffffff",
    "line_glow_color": "#88ccff",
    "reverse_out": True,
}
