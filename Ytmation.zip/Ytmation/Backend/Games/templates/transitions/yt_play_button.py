TEMPLATE = {
    "name": "yt_play_button",
    "duration": 5.0,
    "text": "Episode 2",
    "play_color": "#ff0000",
    "play_hold": 1.1,
    "bg_color": "#0f0f0f",
}
