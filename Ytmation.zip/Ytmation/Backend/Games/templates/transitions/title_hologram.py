"""Default transition8 — hologram / signal decode."""

TEMPLATE = {
    "name": "title_hologram",
    "duration": 5.0,
    "text": "Episode 2",
    "text_x": 0.5,
    "text_y": 0.5,
    "static_duration": 0.35,
    "decode_duration": 1.6,
    "out_duration": 0.9,
    "accent_color": "#00e5ff",
    "chroma_split_max": 14.0,
    "static_intensity": 0.85,
    "bg_color": "#050810",
    "bg_color2": "#0c1830",
    "vignette": 0.38,
}
