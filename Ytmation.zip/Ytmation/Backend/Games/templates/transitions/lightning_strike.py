TEMPLATE = {
    "name": "lightning_strike",
    "duration": 4.5,
    "text": "Episode 2",
    "strike_delay": 0.4,
    "strike_from": "top",
    "bolt_color": "#c8e8ff",
    "flash_strength": 190,
    "bg_color": "#060810",
}
