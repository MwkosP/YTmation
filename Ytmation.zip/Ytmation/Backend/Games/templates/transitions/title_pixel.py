"""Default transition2 — pixel in, fade out."""

TEMPLATE = {
    "name": "title_pixel",
    "duration": 5.0,
    "text": "Next Simulation",
    "text_x": 0.5,
    "text_y": 0.5,
    "text_in_effect": "pixelize",
    "text_out_effect": "fade",
    "in_duration": 1.2,
    "out_duration": 1.0,
    "bg_color": "#0b0c10",
    "bg_color2": "#15182a",
    "bg_gradient_dir": "radial",
    "vignette": 0.35,
    "text_box": False,
    "text_glow": False,
}
