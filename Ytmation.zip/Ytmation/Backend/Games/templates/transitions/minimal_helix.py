TEMPLATE = {
    "name": "minimal_helix",
    "duration": 5.0,
    "text": "Episode 2",
    "subtitle": "Prime Numbers",
    "helix_separation": 200,
    "strand_color": "#8ea4be",
    "drift_speed": 1.0,
    "bg_color": "#0c0c0e",
}
