TEMPLATE = {
    "name": "title_ink",
    "duration": 5.0,
    "text": "Episode 2",
    "bleed_duration": 2.0,
    "ink_color": "#2a8fa8",
    "text_color": "#1a1410",
    "bg_color": "#1a1814",
}
