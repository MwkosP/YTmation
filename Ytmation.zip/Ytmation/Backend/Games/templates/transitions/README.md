# Games transition presets

Animations (`renderAnimation("transitionN", ...)`):

| ID | Style |
|----|--------|
| 1 | Ramp fountains → smash text |
| 2 | Title card effects (fade, pixelize, …) |
| 3 | Boids form text → leave |
| 4 | Flock around text (2D/3D) |
| 5 | Crumble / shatter out |
| 6 | Spotlight reveal |
| 7 | Paintball splash |
| 8 | Hologram signal decode |
| 9 | Lower third + subtitle bar |
| 10 | Ink bleed reveal |
| 11 | Warp starfield → title |
| 12 | Soft focus + light leak (modern minimal) |
| 13 | Center curtain + rule line (editorial) |
| 14 | Nebula parallax drift (slow space cruise) |
| 15 | Planet horizon rise (atmosphere rim) |
| 16 | Curtain reveal + orbital strings (like 13) |
| 17 | Open string field + inner ring (like 13, no curtain) |
| 18 | Corner brackets lock in |
| 19 | Sonar pulse rings |
| 20 | Dual helix strands |

**Minimal editorial family:** 13 curtain · 16–17 strings · 18–20 lines  
**Aggressive:** 21 shockwave · 22 glitch rupture  
**Electric:** 23 lightning strike · 24 arc crackle  
**Liquid / water:** 25 drop ripple pool · 26 tide rise wash  
**YouTube iconic:** 27 red play button (thumbnail click) · 28 subscribe + bell CTA  
**Editorial:** 29 vertical scan line reveal · 30 boid-arrow scan (same wipe)  

Presets: … `minimal_scanline`, `minimal_boid_scan`
