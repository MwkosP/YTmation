TEMPLATE = {
    "name": "modern_focus",
    "duration": 5.0,
    "text": "Episode 2",
    "in_duration": 1.4,
    "out_duration": 1.0,
    "text_color": "#f2f2f2",
    "orb_color": "#8b9cff",
    "blur_amount": 0.55,
    "grain": 0.06,
    "bg_color": "#0c0c0e",
    "bg_color2": "#141418",
}
