"""Default transition3 — boids assemble into title, then disperse."""

TEMPLATE = {
    "name": "title_boids",
    "duration": 5.0,
    "text": "Episode 2",
    "text_x": 0.5,
    "text_y": 0.5,
    "in_duration": 2.5,
    "out_duration": 1.2,
    "boid_count": 3500,
    "boid_radius": 2,
    "sample_step": 2,
    "exit_mode": "radial",
    "bg_color": "#0b0c10",
    "bg_color2": "#15182a",
    "bg_gradient_dir": "radial",
    "vignette": 0.35,
    "show_ripples": True,
}
