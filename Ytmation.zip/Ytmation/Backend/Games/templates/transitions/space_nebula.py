TEMPLATE = {
    "name": "space_nebula",
    "duration": 5.0,
    "text": "Episode 2",
    "star_count": 280,
    "nebula_strength": 1.0,
    "text_glow": True,
    "bg_color": "#030510",
    "bg_color2": "#0a1428",
}
