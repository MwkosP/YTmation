"""Typewriter in, wipe out."""

TEMPLATE = {
    "name": "title_typewriter",
    "duration": 5.0,
    "text_in_effect": "typewriter",
    "text_out_effect": "wipe",
    "in_duration": 2.0,
    "out_duration": 0.8,
}
