TEMPLATE = {
    "name": "modern_curtain",
    "duration": 5.0,
    "text": "Episode 2",
    "subtitle": "",
    "reveal_duration": 1.1,
    "panel_color": "#0e0e10",
    "line_color": "#c8c8cc",
    "text_color": "#f0f0f0",
}
