TEMPLATE = {
    "name": "lightning_crackle",
    "duration": 5.0,
    "text": "Episode 2",
    "strike_rate": 0.12,
    "arc_count": 5,
    "orbit_radius": 280,
    "bolt_color": "#7ec8ff",
    "glow_pulse": True,
}
