TEMPLATE = {
    "name": "yt_subscribe",
    "duration": 5.0,
    "text": "Episode 2",
    "text_y": 0.38,
    "cta_y": 0.58,
    "show_like": True,
    "subscribe_red": "#ff0000",
}
