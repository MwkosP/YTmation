TEMPLATE = {
    "name": "minimal_bracket",
    "duration": 5.0,
    "text": "Episode 2",
    "bracket_in_duration": 0.9,
    "bracket_color": "#a8b0bc",
    "bg_color": "#0c0c0e",
}
