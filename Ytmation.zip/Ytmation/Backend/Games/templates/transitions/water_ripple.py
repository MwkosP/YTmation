TEMPLATE = {
    "name": "water_ripple",
    "duration": 5.0,
    "text": "Episode 2",
    "drop_delay": 0.35,
    "water_color": "#0a2838",
    "ripple_color": "#6ec8e8",
    "text_color": "#e8f8ff",
}
