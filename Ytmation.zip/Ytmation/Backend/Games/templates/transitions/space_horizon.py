TEMPLATE = {
    "name": "space_horizon",
    "duration": 5.0,
    "text": "Episode 2",
    "text_y": 0.42,
    "rise_duration": 2.2,
    "planet_radius": 920,
    "atmosphere_color": "#ff9a6e",
    "text_glow": True,
    "bg_color": "#020408",
}
