TEMPLATE = {
    "name": "title_warp",
    "duration": 5.0,
    "text": "Episode 2",
    "warp_duration": 1.8,
    "star_count": 220,
    "text_glow": True,
    "bg_color": "#020408",
}
