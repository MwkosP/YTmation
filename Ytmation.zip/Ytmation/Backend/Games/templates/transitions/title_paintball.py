"""Default transition7 — paintball splash, text on paint."""

TEMPLATE = {
    "name": "title_paintball",
    "duration": 5.0,
    "text": "Episode 2",
    "text_x": 0.5,
    "text_y": 0.5,
    "fly_duration": 0.55,
    "splash_duration": 1.35,
    "text_reveal_duration": 0.9,
    "out_duration": 0.8,
    "text_in_effect": "fade",
    "paintball_from": "left",
    "paint_color": "#1e6b8a",
    "paintball_color": "#e040fb",
    "splash_radius": 520.0,
    "bg_color": "#0b0c10",
    "bg_color2": "#12141c",
    "vignette": 0.32,
}
