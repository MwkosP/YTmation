TEMPLATE = {
    "name": "minimal_boid_scan",
    "duration": 5.0,
    "text": "Episode 2",
    "scan_duration": 1.4,
    "arrow_size": 12.0,
    "line_height": 0.35,
    "line_axis_y": 0.5,
    "trail_count": 2,
    "probe_line": True,
    "reverse_out": True,
}
