"""
Discover and load Games preset modules under Games/templates/<niche>/<name>.py

Each preset exposes a TEMPLATE dict (params for renderAnimation).
"""

from __future__ import annotations

import importlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def parse_template_name(name: str, default_niche: str | None = "bb") -> tuple[str, str]:
    """
    'neon_dark' + default_niche 'bb' -> ('bb', 'neon_dark')
    'bb/neon_dark' -> ('bb', 'neon_dark')
    """
    parts = name.replace("\\", "/").strip("/").split("/")
    if parts and parts[0] == "games":
        parts = parts[1:]
    if len(parts) >= 2:
        return parts[0], parts[-1]
    if len(parts) == 1 and default_niche:
        return default_niche, parts[0]
    if len(parts) == 1:
        raise ValueError(f"Template name must include niche, e.g. 'bb/{name}'")
    raise ValueError(f"Invalid template name: {name!r}")


def _niche_dir(niche: str) -> Path:
    path = ROOT / niche
    if not path.is_dir():
        raise ValueError(f"Unknown games template niche: {niche} (no such folder)")
    return path


def list_templates(niche: str | None = None) -> list[str]:
    """List preset ids. With niche=None, returns 'niche/name' for all subfolders."""
    if niche:
        return sorted(
            p.stem
            for p in _niche_dir(niche).glob("*.py")
            if not p.stem.startswith("_")
        )

    found: list[str] = []
    for sub in sorted(ROOT.iterdir()):
        if not sub.is_dir() or sub.name.startswith("_"):
            continue
        if sub.name == "__pycache__":
            continue
        for py in sorted(sub.glob("*.py")):
            if not py.stem.startswith("_"):
                found.append(f"{sub.name}/{py.stem}")
    return found


def get_template(name: str, *, default_niche: str | None = "bb") -> dict:
    """Load TEMPLATE dict from Games/templates/<niche>/<name>.py"""
    niche, preset = parse_template_name(name, default_niche=default_niche)
    mod_path = f"Games.templates.{niche}.{preset}"
    mod = importlib.import_module(mod_path)
    if not hasattr(mod, "TEMPLATE"):
        raise AttributeError(f"{mod_path} has no TEMPLATE dict")
    return dict(mod.TEMPLATE)


def apply_games_template(
    name: str,
    animation: str,
    output=None,
    *,
    niche: str = "bb",
    **overrides,
):
    """Render a Games animation using a bb (or other niche) preset."""
    from Games.games import renderAnimation

    niche_resolved, preset = parse_template_name(name, default_niche=niche)
    params = get_template(f"{niche_resolved}/{preset}", default_niche=niche)
    params.pop("name", None)
    params.update(overrides)
    print(f"[Games/templates] {niche_resolved}/{preset} → {animation}")
    return renderAnimation(animation, output=output, template=None, **params)
