"""
Games/games.py  — supervisor for all animations
------------------------------------------------
Public API:
    listAnimations()                        → list of available animation names
    getAnimation(name)                      → dict with animation info
    renderAnimation(name, output, **params) → Path to rendered MP4
    previewAnimation(name, **params)        → renders short 3s preview
    randomAnimation(**params)               → picks and renders a random animation
"""

import importlib
import random
from pathlib import Path

ROOT           = Path(__file__).resolve().parent.parent
ANIMATIONS_DIR = Path(__file__).resolve().parent / "animations"


# ── discovery ──────────────────────────────────────────────────────────────────

def _discoverAnimations() -> dict:
    """Walk animations/ subfolders and find all run()-capable modules."""
    found = {}
    for pyfile in ANIMATIONS_DIR.rglob("*.py"):
        if pyfile.name.startswith("_"):
            continue
        # build module name relative to Games/
        rel   = pyfile.relative_to(Path(__file__).resolve().parent)
        parts = list(rel.with_suffix("").parts)
        mod_path = "Games." + ".".join(parts)
        name  = pyfile.stem  # e.g. bouncing_balls_circle
        category = pyfile.parent.name  # e.g. physics
        found[name] = {
            "name":     name,
            "category": category,
            "module":   mod_path,
            "path":     str(pyfile),
        }
    return found


# ── public API ─────────────────────────────────────────────────────────────────

def listAnimations() -> list:
    """Return list of all available animation names."""
    animations = _discoverAnimations()
    result = []
    for name, info in animations.items():
        result.append({
            "name":     info["name"],
            "category": info["category"],
        })
    return result


def getAnimation(name: str) -> dict:
    """Return info dict for a specific animation."""
    animations = _discoverAnimations()
    if name not in animations:
        raise ValueError(f"Animation '{name}' not found. Available: {list(animations.keys())}")
    return animations[name]


def renderAnimation(name: str, output: Path = None, template: str = None, **params) -> Path:
    """
    Render an animation to MP4.

    Args:
        name     : animation name (e.g. 'bouncingBallsInsideCircle')
        output   : output path, auto-generated if None
        template : optional template name (e.g. 'neon_dark') — params override template
        **params : passed directly to animation's run(), overrides template values

    Collision audio (bb animations): pass ``collision_audio`` — not a top-level ``sfx`` arg.
    SFX names inside that dict are resolved via ``SFX.getSFX`` (e.g. ``"marioCoin"``)::

        renderAnimation("bouncingBalls", collision_audio={
            "mode": "sfx",
            "wall": "marioCoin",
            "ball": "marioCoin",
            "clip_s": 0.15,
        })

    Returns:
        Path to rendered MP4
    """
    animations = _discoverAnimations()
    if name not in animations:
        raise ValueError(f"Animation '{name}' not found. Available: {list(animations.keys())}")

    # load template first, then apply params on top
    final_params = {}
    if template:
        from Games.templates.templates import getTemplate
        t = getTemplate(template)
        t.pop("name", None)
        final_params.update(t)

    final_params.update(params)

    collision_audio_cfg = final_params.pop("collision_audio", None)

    mod = importlib.import_module(animations[name]["module"])
    if not hasattr(mod, "run"):
        raise AttributeError(f"Animation '{name}' has no run() function.")

    if collision_audio_cfg is not None:
        final_params["collision_audio"] = collision_audio_cfg

    print(f"[Games] Rendering '{name}'" + (f" with template '{template}'" if template else "") + "...")
    result = mod.run(output=output, **final_params)
    print(f"[Games] Done → {result}")
    return result


def previewAnimation(name: str, **params) -> Path:
    """Render a short 3-second preview of an animation."""
    params["duration"] = 3
    params["fps"]      = params.get("fps", 30)
    return renderAnimation(name, **params)


def randomAnimation(**params) -> Path:
    """Pick a random animation and render it."""
    animations = _discoverAnimations()
    name = random.choice(list(animations.keys()))
    print(f"[Games] Random pick: '{name}'")
    return renderAnimation(name, **params)