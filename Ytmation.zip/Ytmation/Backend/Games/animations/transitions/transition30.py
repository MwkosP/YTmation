"""
Transition 30 — Boid-arrow scan reveal
--------------------------------------
Minimal triangle boid sweeps left → right, revealing title (same timing as transition29).
"""

from __future__ import annotations

import math
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _arrow_points(size: float) -> list[tuple[float, float]]:
    s = max(2.0, float(size))
    return [(s * 1.7, 0.0), (-s * 0.95, s * 0.8), (-s * 0.55, 0.0), (-s * 0.95, -s * 0.8)]


def _rotate_pts(points: list[tuple[float, float]], cx: float, cy: float, angle: float) -> list[tuple[int, int]]:
    ca, sa = math.cos(angle), math.sin(angle)
    out = []
    for x, y in points:
        rx = x * ca - y * sa
        ry = x * sa + y * ca
        out.append((int(cx + rx), int(cy + ry)))
    return out


def _draw_boid_arrow(layer, cx: float, cy: float, size: float, color: tuple, alpha: int, facing_right: bool) -> None:
    import pygame

    angle = 0.0 if facing_right else math.pi
    pts = _rotate_pts(_arrow_points(size), cx, cy, angle)
    col = color if alpha >= 255 else (*color[:3], alpha)
    pygame.draw.polygon(layer, col, pts)
    pygame.draw.polygon(layer, col, pts, 1)


def _draw_probe(layer, x: float, y0: float, y1: float, color: tuple, width: int) -> None:
    import pygame

    pygame.draw.line(layer, color, (int(x), int(y0)), (int(x), int(y1)), max(1, width))


def _scan_span(height: int, text_rect, pad_y: int, line_height: float, line_axis_y: float, line_full_height) -> tuple[float, float, float]:
    if line_full_height is not None:
        lh = 1.0 if line_full_height else min(1.0, (text_rect.height + 2 * pad_y) / max(height, 1))
    else:
        lh = max(0.0, min(1.0, float(line_height)))
    axis_y = max(0.0, min(1.0, float(line_axis_y))) * height
    span = height * lh
    return axis_y, axis_y - span / 2, axis_y + span / 2


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f2f2f2",
    scan_duration: float = 1.4,
    hold_duration: float = 1.8,
    scan_out_duration: float = 0.9,
    scan_delay: float = 0.25,
    arrow_size: float = 12.0,
    arrow_color: str = "#e8eef4",
    trail_count: int = 2,
    trail_spacing: float = 22.0,
    trail_alpha: int = 90,
    probe_line: bool = True,
    probe_width: int = 1,
    probe_color: str = "#5a6470",
    line_height: float = 0.35,
    line_axis_y: float = 0.5,
    line_full_height: bool | None = None,
    line_pad_y: float = 0.06,
    reverse_out: bool = True,
    bg_color: str = "#0c0c0e",
    bg_color2: str = "#141418",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.35,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "boidscan"
        output = CACHE_DIR / f"transition30_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    fx_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    ac = _hex(arrow_color)
    pc = (*_hex(probe_color), 70)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.095))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    text_rect = text_surf.get_rect(center=(int(text_cx), int(text_cy)))
    pad_y = int(height * line_pad_y)
    axis_y, probe_y0, probe_y1 = _scan_span(height, text_rect, pad_y, line_height, line_axis_y, line_full_height)

    total_frames = max(1, int(duration * fps))
    delay_f = int(scan_delay * fps)
    scan_f = max(1, int(scan_duration * fps))
    hold_f = int(hold_duration * fps)
    out_f = max(1, int(scan_out_duration * fps))
    scan_start = delay_f
    out_start = min(scan_start + scan_f + hold_f, total_frames - out_f)

    grad_cache: dict = {}
    trail_n = max(0, min(6, int(trail_count)))

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if vignette > 0:
                _draw_vignette(surface, vignette)

            scanning_in = scan_start <= frame < scan_start + scan_f
            scanning_out = reverse_out and frame >= out_start and frame < out_start + out_f

            if scanning_in:
                prog = _ease_out_cubic((frame - scan_start) / scan_f)
                scan_x = _lerp(text_rect.left, text_rect.right + 2, prog)
                facing_right = True
            elif scanning_out:
                prog = _ease_in_cubic((frame - out_start) / out_f)
                scan_x = _lerp(text_rect.right + 2, text_rect.left, prog)
                facing_right = False
            elif frame >= scan_start + scan_f and (not reverse_out or frame < out_start):
                scan_x = text_rect.right + 2
                facing_right = True
            else:
                scan_x = text_rect.left
                facing_right = True

            clip_w = max(0, int(scan_x - text_rect.left))
            if clip_w > 0:
                visible = text_surf.subsurface((0, 0, min(clip_w, text_surf.get_width()), text_surf.get_height()))
                surface.blit(visible, text_rect.topleft)

            show_probe = scanning_in or scanning_out
            if show_probe:
                fx_layer.fill((0, 0, 0, 0))
                if probe_line and probe_y1 > probe_y0:
                    _draw_probe(fx_layer, scan_x, probe_y0, probe_y1, pc, probe_width)
                sign = 1.0 if facing_right else -1.0
                for i in range(trail_n, -1, -1):
                    tx = scan_x - sign * i * trail_spacing
                    ta = 255 if i == 0 else trail_alpha
                    sz = arrow_size if i == 0 else max(4.0, arrow_size * (0.55 - i * 0.08))
                    _draw_boid_arrow(fx_layer, tx, axis_y, sz, ac, ta, facing_right)
                surface.blit(fx_layer, (0, 0))
            elif frame >= scan_start + scan_f and frame < out_start:
                surface.blit(text_surf, text_rect)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
