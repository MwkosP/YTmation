"""
Transition 17 — String field (open)
------------------------------------
Orbital vibrating strings always visible; title + rule fade in gently.
No curtain — airy, minimal, string-theory alive center.
"""

from __future__ import annotations

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.string_theory_lines import (
    draw_strings,
    spawn_strings,
)
from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _draw_inner_ring(
    target,
    cx: float,
    cy: float,
    radius: float,
    time_s: float,
    color: tuple,
    *,
    segments: int = 64,
    wobble: float = 12.0,
) -> None:
    import pygame

    pts: list[tuple[int, int]] = []
    for i in range(segments + 1):
        u = (i / segments) * math.tau
        r = radius + math.sin(u * 5 + time_s * 2.8) * wobble
        pts.append((int(cx + math.cos(u + time_s * 0.15) * r), int(cy + math.sin(u + time_s * 0.15) * r)))
    pygame.draw.aalines(target, color, True, pts, 1)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    subtitle: str = "",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    subtitle_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f0f0f0",
    subtitle_color: str = "#7a8494",
    reveal_duration: float = 1.2,
    out_duration: float = 0.9,
    line_color: str = "#b0b8c4",
    string_color: str = "#8aa8c8",
    accent_color: str = "#c4d4e8",
    string_count: int = 18,
    string_radius: float = 420.0,
    string_line_width: int = 1,
    inner_ring: bool = True,
    inner_ring_radius: float = 200.0,
    orbit_speed: float = 1.0,
    line_width_ratio: float = 0.18,
    rule_grow_duration: float = 0.55,
    text_delay: float = 0.2,
    bg_color: str = "#0a0a0c",
    bg_color2: str = "#101018",
    bg_gradient_dir: str = "radial",
    seed: int = 42,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "field"
        output = CACHE_DIR / f"transition17_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, sc, lc, stc, acc = _hex(text_color), _hex(subtitle_color), _hex(line_color), _hex(string_color), _hex(accent_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(42, int(min(width, height) * 0.07))
    if subtitle_size is None:
        subtitle_size = max(22, int(font_size * 0.45))

    try:
        title_font = pygame.font.SysFont(font_name, font_size, bold=False)
        sub_font = pygame.font.SysFont(font_name, subtitle_size, bold=False)
    except Exception:
        title_font = pygame.font.Font(None, font_size)
        sub_font = pygame.font.Font(None, subtitle_size)

    title_surf = title_font.render(text, True, tc)
    sub_surf = sub_font.render(subtitle, True, sc) if subtitle else None

    block_h = title_surf.get_height() + (sub_surf.get_height() + 20 if sub_surf else 0) + 36
    line_y = text_cy + block_h // 2 - 14
    line_full_w = int(width * line_width_ratio)

    rng = random.Random(seed)
    strings = spawn_strings(string_count, text_cx, text_cy, string_radius, rng)

    total_frames = max(1, int(duration * fps))
    rev_frames = max(1, int(reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    rule_frames = max(1, int(rule_grow_duration * fps))
    text_delay_f = max(0, int(text_delay * fps))
    out_start = max(rev_frames + int(fps * 0.5), total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            t_sec = frame / max(fps, 1)
            layer.fill((0, 0, 0, 0))
            draw_strings(
                layer, text_cx, text_cy, strings, t_sec, stc,
                line_width=string_line_width, orbit_mul=orbit_speed,
            )
            if inner_ring:
                _draw_inner_ring(
                    layer, text_cx, text_cy, inner_ring_radius, t_sec,
                    (*acc, 70), wobble=10.0,
                )
            surface.blit(layer, (0, 0))

            if frame < out_start + out_frames:
                if frame < rev_frames:
                    prog = frame / rev_frames
                    rule_t = _ease_out_cubic(min(1.0, max(0.0, (frame - text_delay_f) / max(1, rev_frames - text_delay_f))))
                    text_t = _ease_out_cubic(min(1.0, (frame - text_delay_f) / max(1, rev_frames * 0.7)))
                elif frame >= out_start:
                    out_t = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                    rule_t = text_t = 1.0 - out_t
                else:
                    rule_t = text_t = 1.0

                lw = int(line_full_w * rule_t)
                if lw > 0:
                    pygame.draw.rect(surface, lc, pygame.Rect(int(text_cx - lw // 2), int(line_y), lw, 1))

                ta = int(255 * text_t)
                if ta > 0:
                    ty = text_cy - block_h // 2 + title_surf.get_height() // 2
                    tt = title_surf.copy()
                    tt.set_alpha(ta)
                    surface.blit(tt, tt.get_rect(center=(int(text_cx), int(ty))))
                    if sub_surf:
                        sy = ty + title_surf.get_height() // 2 + 14 + sub_surf.get_height() // 2
                        ss = sub_surf.copy()
                        ss.set_alpha(ta)
                        surface.blit(ss, ss.get_rect(center=(int(text_cx), int(sy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / f"frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
