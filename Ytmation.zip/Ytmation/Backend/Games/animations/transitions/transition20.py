"""
Transition 20 — Dual helix lines
--------------------------------
Two intertwined sine strands drift vertically; title appears between them.
Minimal scientific motion (string-theory cousin to 16/17).
"""

from __future__ import annotations

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _norm_xy,
    _render_text_surface,
)


def _draw_helix_strand(
    target,
    cx: float,
    base_y: float,
    height: float,
    amplitude: float,
    phase: float,
    time_s: float,
    color: tuple,
    *,
    freq: float = 0.012,
    drift: float = 0.4,
) -> None:
    import pygame

    pts: list[tuple[int, int]] = []
    steps = 120
    for i in range(steps + 1):
        y = base_y + (i / steps) * height
        u = y * freq + time_s * drift + phase
        x = cx + math.sin(u) * amplitude
        pts.append((int(x), int(y)))
    if len(pts) >= 2:
        pygame.draw.aalines(target, color, False, pts, 1)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    subtitle: str = "",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    subtitle_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f0f0f0",
    subtitle_color: str = "#7a808a",
    helix_reveal_duration: float = 1.4,
    text_reveal_duration: float = 0.75,
    out_duration: float = 0.85,
    helix_amplitude: float = 120.0,
    helix_separation: float = 200.0,
    strand_color: str = "#8ea4be",
    strand_color2: str = "#6a849c",
    drift_speed: float = 1.0,
    line_color: str = "#b0b8c4",
    line_width_ratio: float = 0.18,
    bg_color: str = "#0c0c0e",
    bg_color2: str = "#10141c",
    bg_gradient_dir: str = "radial",
    seed: int = 42,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "helix"
        output = CACHE_DIR / f"transition20_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    strand_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, sc, c1, c2, lc = _hex(text_color), _hex(subtitle_color), _hex(strand_color), _hex(strand_color2), _hex(line_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(42, int(min(width, height) * 0.07))
    if subtitle_size is None:
        subtitle_size = max(22, int(font_size * 0.45))

    try:
        title_font = pygame.font.SysFont(font_name, font_size, bold=False)
        sub_font = pygame.font.SysFont(font_name, subtitle_size, bold=False)
    except Exception:
        title_font = pygame.font.Font(None, font_size)
        sub_font = pygame.font.Font(None, subtitle_size)

    title_surf = title_font.render(text, True, tc)
    sub_surf = sub_font.render(subtitle, True, sc) if subtitle else None
    block_h = title_surf.get_height() + (sub_surf.get_height() + 20 if sub_surf else 0) + 36
    line_y = text_cy + block_h // 2 - 14
    line_full = int(width * line_width_ratio)

    rng = random.Random(seed)
    phase_a = rng.uniform(0, math.tau)
    phase_b = phase_a + math.pi

    total_frames = max(1, int(duration * fps))
    helix_frames = max(1, int(helix_reveal_duration * fps))
    rev_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    rev_start = int(helix_frames * 0.5)
    out_start = max(rev_start + rev_frames, total_frames - out_frames)

    strand_h = height * 0.75
    base_y = (height - strand_h) / 2
    left_cx = text_cx - helix_separation / 2
    right_cx = text_cx + helix_separation / 2

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            t_sec = frame / max(fps, 1) * drift_speed
            helix_alpha = min(1.0, frame / helix_frames) if frame < helix_frames else 1.0
            if frame >= out_start:
                helix_alpha *= 1.0 - _ease_in_cubic((frame - out_start) / max(1, out_frames))

            strand_layer.fill((0, 0, 0, 0))
            a1 = int(90 * helix_alpha)
            a2 = int(70 * helix_alpha)
            if a1 > 0:
                _draw_helix_strand(
                    strand_layer, left_cx, base_y, strand_h, helix_amplitude, phase_a, t_sec,
                    (*c1, a1),
                )
            if a2 > 0:
                _draw_helix_strand(
                    strand_layer, right_cx, base_y, strand_h, helix_amplitude * 0.92, phase_b, t_sec,
                    (*c2, a2), freq=0.013,
                )
            surface.blit(strand_layer, (0, 0))

            if frame >= rev_start and frame < out_start + out_frames:
                if frame < out_start:
                    rt = min(1.0, (frame - rev_start) / rev_frames)
                    ta = int(255 * _ease_out_cubic(rt))
                    rule_t = _ease_out_cubic(rt)
                else:
                    ot = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                    ta, rule_t = int(255 * (1.0 - ot)), 1.0 - ot
                lw = int(line_full * rule_t)
                if lw > 0:
                    pygame.draw.rect(surface, lc, pygame.Rect(int(text_cx - lw // 2), int(line_y), lw, 1))
                if ta > 0:
                    ty = text_cy - block_h // 2 + title_surf.get_height() // 2
                    tt = title_surf.copy()
                    tt.set_alpha(ta)
                    surface.blit(tt, tt.get_rect(center=(int(text_cx), int(ty))))
                    if sub_surf:
                        ss = sub_surf.copy()
                        ss.set_alpha(ta)
                        sy = ty + title_surf.get_height() // 2 + 14 + sub_surf.get_height() // 2
                        surface.blit(ss, ss.get_rect(center=(int(text_cx), int(sy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
