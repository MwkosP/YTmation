"""
Transition 26 — Tide rise
-------------------------
Liquid rises from below with a wavy surface; title surfaces through the water.
"""

from __future__ import annotations

import math
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _lerp_color,
    _norm_xy,
    _render_text_surface,
)


def _wave_surface(w: int, level_y: float, t: float, color: tuple, foam_color: tuple) -> "object":
    """Filled water below wavy surface line."""
    import pygame

    surf = pygame.Surface((w, int(level_y) + 4), pygame.SRCALPHA)
    h = surf.get_height()
    points = [(0, h)]
    steps = max(40, w // 24)
    for i in range(steps + 1):
        x = (i / steps) * w
        y = 8 * math.sin(x * 0.012 + t * 2.2) + 4 * math.sin(x * 0.025 - t * 1.4)
        points.append((x, y))
    points.append((w, h))
    points.append((0, h))
    pygame.draw.polygon(surf, color, points)
    # foam crest
    crest = [(p[0], p[1]) for p in points[1:-2]]
    if len(crest) >= 2:
        pygame.draw.lines(surf, foam_color, False, crest, 2)
    return surf


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f0fcff",
    rise_duration: float = 2.2,
    hold_duration: float = 1.2,
    drain_duration: float = 0.9,
    water_deep: str = "#0c3a52",
    water_shallow: str = "#1a6a8a",
    water_alpha: int = 210,
    foam_color: str = "#c8f0ff",
    bg_color: str = "#081018",
    bg_color2: str = "#0e1a28",
    bg_gradient_dir: str = "radial",
    text_surface_offset: float = 0.08,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "tide"
        output = CACHE_DIR / f"transition26_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    wd, ws = _hex(water_deep), _hex(water_shallow)
    tc, fc = _hex(text_color), _hex(foam_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    text_reveal_y = text_cy + height * text_surface_offset

    if font_size is None:
        font_size = max(52, int(min(width, height) * 0.1))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)

    total_frames = max(1, int(duration * fps))
    rise_frames = max(1, int(rise_duration * fps))
    drain_frames = max(1, int(drain_duration * fps))
    drain_start = max(rise_frames + int(hold_duration * fps), total_frames - drain_frames)

    grad_cache: dict = {}
    water_col = (*_lerp_color(wd, ws, 0.5), water_alpha)

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            t_sec = frame / max(fps, 1)

            if frame < rise_frames:
                prog = _ease_out_cubic(frame / rise_frames)
                level = _lerp(height + 20, text_reveal_y + 40, prog)
            elif frame >= drain_start:
                prog = _ease_in_cubic((frame - drain_start) / max(1, drain_frames))
                level = _lerp(text_reveal_y + 40, -30, prog)
            else:
                level = text_reveal_y + 40

            wave = _wave_surface(width, level, t_sec, water_col, fc)
            surface.blit(wave, (0, int(level - wave.get_height())))

            if level >= text_reveal_y - 20:
                if frame < drain_start:
                    sub = min(1.0, (level - text_reveal_y + 20) / 60.0)
                    ta = int(255 * _ease_out_cubic(sub))
                else:
                    ta = int(255 * (1.0 - _ease_in_cubic((frame - drain_start) / max(1, drain_frames))))
                if ta > 0:
                    ts = text_surf.copy()
                    ts.set_alpha(ta)
                    surface.blit(ts, ts.get_rect(center=(int(text_cx), int(text_cy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
