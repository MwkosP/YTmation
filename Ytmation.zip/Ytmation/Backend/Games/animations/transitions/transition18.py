"""
Transition 18 — Bracket lock-in
--------------------------------
Corner brackets glide inward; title and rule appear. Minimal, editorial.
"""

from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_out_cubic,
    _ease_in_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _draw_brackets(
    target,
    cx: float,
    cy: float,
    half_w: float,
    half_h: float,
    arm: float,
    color: tuple,
    width: int,
) -> None:
    import pygame

    x0, x1 = cx - half_w, cx + half_w
    y0, y1 = cy - half_h, cy + half_h
    # top-left
    pygame.draw.line(target, color, (x0, y0), (x0 + arm, y0), width)
    pygame.draw.line(target, color, (x0, y0), (x0, y0 + arm), width)
    # top-right
    pygame.draw.line(target, color, (x1, y0), (x1 - arm, y0), width)
    pygame.draw.line(target, color, (x1, y0), (x1, y0 + arm), width)
    # bottom-left
    pygame.draw.line(target, color, (x0, y1), (x0 + arm, y1), width)
    pygame.draw.line(target, color, (x0, y1), (x0, y1 - arm), width)
    # bottom-right
    pygame.draw.line(target, color, (x1, y1), (x1 - arm, y1), width)
    pygame.draw.line(target, color, (x1, y1), (x1, y1 - arm), width)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    subtitle: str = "",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    subtitle_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f0f0f0",
    subtitle_color: str = "#7a808a",
    bracket_in_duration: float = 0.9,
    text_reveal_duration: float = 0.7,
    out_duration: float = 0.8,
    bracket_arm: float = 36.0,
    bracket_color: str = "#a8b0bc",
    line_color: str = "#c0c4cc",
    line_width_ratio: float = 0.2,
    frame_pad_x: float = 0.22,
    frame_pad_y: float = 0.14,
    bg_color: str = "#0c0c0e",
    bg_color2: str = "#121216",
    bg_gradient_dir: str = "radial",
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "bracket"
        output = CACHE_DIR / f"transition18_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, sc, bc, lc = _hex(text_color), _hex(subtitle_color), _hex(bracket_color), _hex(line_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(42, int(min(width, height) * 0.07))
    if subtitle_size is None:
        subtitle_size = max(22, int(font_size * 0.45))

    try:
        title_font = pygame.font.SysFont(font_name, font_size, bold=False)
        sub_font = pygame.font.SysFont(font_name, subtitle_size, bold=False)
    except Exception:
        title_font = pygame.font.Font(None, font_size)
        sub_font = pygame.font.Font(None, subtitle_size)

    title_surf = title_font.render(text, True, tc)
    sub_surf = sub_font.render(subtitle, True, sc) if subtitle else None

    tw = title_surf.get_width() + 80
    th = title_surf.get_height() + (sub_surf.get_height() + 24 if sub_surf else 0) + 50
    target_hw = tw / 2 + frame_pad_x * width * 0.5
    target_hh = th / 2 + frame_pad_y * height * 0.5
    start_hw, start_hh = width * 0.48, height * 0.42
    line_y = text_cy + th // 2 - 16
    line_full = int(width * line_width_ratio)

    total_frames = max(1, int(duration * fps))
    br_frames = max(1, int(bracket_in_duration * fps))
    rev_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    rev_start = br_frames
    out_start = max(rev_start + rev_frames, total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            if frame < br_frames:
                t = _ease_out_cubic(frame / br_frames)
                hw = _lerp(start_hw, target_hw, t)
                hh = _lerp(start_hh, target_hh, t)
            elif frame >= out_start:
                t = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                hw = _lerp(target_hw, start_hw * 0.9, t)
                hh = _lerp(target_hh, start_hh * 0.9, t)
            else:
                hw, hh = target_hw, target_hh

            _draw_brackets(surface, text_cx, text_cy, hw, hh, bracket_arm, bc, 1)

            if frame >= rev_start and frame < out_start + out_frames:
                if frame < out_start:
                    rt = min(1.0, (frame - rev_start) / rev_frames)
                    rule_t = _ease_out_cubic(rt)
                    ta = int(255 * rt)
                else:
                    ot = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                    rule_t, ta = 1.0 - ot, int(255 * (1.0 - ot))

                lw = int(line_full * rule_t)
                if lw > 0:
                    pygame.draw.rect(surface, lc, pygame.Rect(int(text_cx - lw // 2), int(line_y), lw, 1))
                if ta > 0:
                    ty = text_cy - th // 2 + title_surf.get_height() // 2
                    tt = title_surf.copy()
                    tt.set_alpha(ta)
                    surface.blit(tt, tt.get_rect(center=(int(text_cx), int(ty))))
                    if sub_surf:
                        ss = sub_surf.copy()
                        ss.set_alpha(ta)
                        sy = ty + title_surf.get_height() // 2 + 14 + sub_surf.get_height() // 2
                        surface.blit(ss, ss.get_rect(center=(int(text_cx), int(sy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
