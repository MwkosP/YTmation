"""
Transition 2 — Text reveal / outro
----------------------------------
Centered title with configurable in/out effects (~4–5 s default).

Text effects (text_in_effect / text_out_effect):
  fade, pixelize, scale, slide_up, slide_down, typewriter, blur, glitch, wipe

Layout params:
  text, text_x, text_y (0–1), font_size, font_name, text_color
  text_box (placeholder panel behind text), text_glow (soft halo on letter shapes)

Timing:
  duration, in_duration, out_duration  (hold = remainder)

Background:
  bg_color, bg_color2, bg_gradient_dir, vignette, show_ripples, ripple_*
"""

from __future__ import annotations

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games" / "transitions"

TEXT_EFFECTS = (
    "fade",
    "pixelize",
    "scale",
    "slide_up",
    "slide_down",
    "typewriter",
    "blur",
    "glitch",
    "wipe",
)


def _hex(h: str) -> tuple[int, int, int]:
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * max(0.0, min(1.0, t))


def _lerp_color(c1, c2, t: float):
    t = max(0.0, min(1.0, t))
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def _norm_xy(nx: float, ny: float, w: float, h: float) -> tuple[float, float]:
    return nx * w, ny * h


def _ease_out_cubic(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 1.0 - (1.0 - t) ** 3


def _ease_in_cubic(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return t ** 3


def _ease_in_out(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 3 * t**2 - 2 * t**3


def _gradient_surface(w: int, h: int, c1, c2, direction: str = "vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "radial":
        cx, cy = w // 2, h // 2
        max_r = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max(max_r, 1))
                surf.set_at((x, y), _lerp_color(c1, c2, t))
        return surf
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            pygame.draw.line(surf, _lerp_color(c1, c2, t), (x, 0), (x, h))
        return surf
    for y in range(h):
        t = y / max(1, h - 1)
        pygame.draw.line(surf, _lerp_color(c1, c2, t), (0, y), (w, y))
    return surf


def _draw_background(surf, w, h, bg1, bg2, gradient_dir, cache: dict) -> None:
    if bg2 and gradient_dir and gradient_dir != "none":
        key = (bg1, bg2, gradient_dir, w, h)
        if key not in cache:
            cache[key] = _gradient_surface(w, h, bg1, bg2, gradient_dir)
        surf.blit(cache[key], (0, 0))
    else:
        surf.fill(bg1)


def _draw_vignette(surf, strength: float = 0.45):
    import pygame

    if strength <= 0:
        return
    w, h = surf.get_size()
    overlay = pygame.Surface((w, h), pygame.SRCALPHA)
    cx, cy = w // 2, h // 2
    max_r = math.hypot(cx, cy)
    for y in range(0, h, 4):
        for x in range(0, w, 4):
            t = min(1.0, math.hypot(x - cx, y - cy) / max_r)
            alpha = int(255 * strength * (t**1.8))
            if alpha > 8:
                pygame.draw.rect(overlay, (0, 0, 0, alpha), (x, y, 4, 4))
    surf.blit(overlay, (0, 0))


def _draw_ripples(surf, cx, cy, w, h, color, count: int):
    import pygame

    for i in range(1, count + 1):
        r = int(min(w, h) * 0.07 * i)
        alpha = max(5, 36 - i * 2)
        ring = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
        pygame.draw.circle(ring, (*color[:3], alpha), (r + 1, r + 1), r, 1)
        surf.blit(ring, (int(cx - r - 1), int(cy - r - 1)))


def _render_text_surface(text: str, font, color: tuple) -> "pygame.Surface":
    import pygame

    return font.render(text, True, color)


def _build_typewriter_surfaces(text: str, font, color: tuple) -> list:
    import pygame

    surfaces = []
    shown = ""
    for ch in text:
        shown += ch
        surfaces.append(font.render(shown, True, color))
    return surfaces


def _pixelize_surface(src, blockiness: float) -> "pygame.Surface":
    """blockiness 1 = chunky pixels, 0 = sharp."""
    import pygame

    tw, th = src.get_size()
    if tw < 2 or th < 2:
        return src.copy()
    cells = max(2, int(_lerp(2, min(tw, th) // 2, blockiness)))
    sw = max(1, tw // cells)
    sh = max(1, th // cells)
    small = pygame.transform.scale(src, (sw, sh))
    return pygame.transform.scale(small, (tw, th))


def _blur_via_scale(src, amount: float) -> "pygame.Surface":
    import pygame

    if amount <= 0.01:
        return src.copy()
    tw, th = src.get_size()
    shrink = max(2, int(_lerp(tw, tw // 8, amount)))
    sh = max(2, int(_lerp(th, th // 8, amount)))
    small = pygame.transform.smoothscale(src, (shrink, sh))
    return pygame.transform.smoothscale(small, (tw, th))


def _glitch_surface(src, intensity: float, seed: int) -> "pygame.Surface":
    import pygame

    if intensity <= 0.01:
        return src.copy()
    random.seed(seed)
    out = src.copy()
    tw, th = src.get_size()
    strip_h = max(2, th // 24)
    for y in range(0, th, strip_h):
        if random.random() < intensity * 0.65:
            dx = int(random.uniform(-8, 8) * intensity)
            rect = pygame.Rect(0, y, tw, min(strip_h, th - y))
            strip = src.subsurface(rect).copy()
            out.blit(strip, (dx, y))
    return out


def _wipe_surface(src, progress: float, inward: bool) -> "pygame.Surface":
    import pygame

    out = pygame.Surface(src.get_size(), pygame.SRCALPHA)
    tw, th = src.get_size()
    if inward:
        visible = int(tw * progress)
        if visible > 0:
            out.blit(src, (0, 0), pygame.Rect(0, 0, visible, th))
    else:
        cut = int(tw * (1.0 - progress))
        if cut < tw:
            out.blit(src, (0, 0), pygame.Rect(cut, 0, tw - cut, th))
    return out


def _draw_text_effect(
    target,
    text_surf,
    cx: float,
    cy: float,
    effect: str,
    progress: float,
    *,
    outward: bool = False,
    typewriter_frames: list | None = None,
    frame_idx: int = 0,
    glitch_seed: int = 0,
    pixel_block_max: int = 40,
) -> None:
    import pygame

    effect = (effect or "fade").lower().strip()
    if effect not in TEXT_EFFECTS:
        effect = "fade"

    p = _ease_out_cubic(progress) if not outward else 1.0 - _ease_in_cubic(progress)
    tw, th = text_surf.get_size()
    alpha = int(255 * max(0.0, min(1.0, p if effect != "wipe" else progress)))

    if effect == "typewriter" and typewriter_frames:
        n = len(typewriter_frames)
        if outward:
            idx = max(0, n - 1 - int(p * n))
        else:
            idx = min(n - 1, int(p * n))
        surf = typewriter_frames[idx]
        tw, th = surf.get_size()
    else:
        surf = text_surf
        if effect == "pixelize":
            blockiness = _lerp(1.0, 0.0, p if not outward else 1.0 - p)
            surf = _pixelize_surface(text_surf, blockiness * pixel_block_max / max(min(tw, th), 8))
        elif effect == "blur":
            surf = _blur_via_scale(text_surf, 1.0 - p if not outward else p)
        elif effect == "glitch":
            surf = _glitch_surface(text_surf, 1.0 - p if not outward else p, glitch_seed + frame_idx)
        elif effect == "wipe":
            surf = _wipe_surface(text_surf, p if not outward else 1.0 - p, inward=not outward)

    surf = surf.copy()
    if effect not in ("wipe",) and alpha < 255:
        surf.set_alpha(alpha)

    scale = 1.0
    ox, oy = 0.0, 0.0
    if effect == "scale":
        scale = _lerp(0.55, 1.0, p) if not outward else _lerp(1.0, 0.88, 1.0 - p)
    elif effect == "slide_up":
        oy = _lerp(50, 0, p) if not outward else _lerp(0, -40, 1.0 - p)
    elif effect == "slide_down":
        oy = _lerp(-50, 0, p) if not outward else _lerp(0, 40, 1.0 - p)

    if scale != 1.0:
        nw, nh = max(1, int(tw * scale)), max(1, int(th * scale))
        surf = pygame.transform.smoothscale(surf, (nw, nh))
        tw, th = surf.get_size()

    dest = surf.get_rect(center=(int(cx + ox), int(cy + oy)))
    target.blit(surf, dest)


def _draw_text_box(
    target,
    text_surf,
    cx: float,
    cy: float,
    color: tuple,
    alpha: int,
    padding: int,
    radius: int,
) -> None:
    """Optional rounded rectangle placeholder behind the title."""
    import pygame

    if alpha <= 0:
        return
    tw, th = text_surf.get_size()
    rect = pygame.Rect(0, 0, tw + padding * 2, th + padding * 2)
    rect.center = (int(cx), int(cy))
    box = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.rect(box, (*color, alpha), box.get_rect(), border_radius=radius)
    target.blit(box, rect.topleft)


def _draw_text_glow(target, text_surf, cx, cy, color, layers: int, strength: int):
    """Halo that follows letter shapes (not a solid box)."""
    import pygame

    if layers <= 0 or strength <= 0:
        return
    tw, th = text_surf.get_size()
    pad = layers * 4 + 4
    for i in range(layers, 0, -1):
        alpha = max(8, strength // i)
        scale = 1.0 + i * 0.06
        nw, nh = max(1, int(tw * scale)), max(1, int(th * scale))
        layer = pygame.transform.smoothscale(text_surf, (nw, nh))
        layer.set_alpha(alpha)
        tint = pygame.Surface(layer.get_size(), pygame.SRCALPHA)
        tint.fill((*color, alpha))
        layer.blit(tint, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        dest = layer.get_rect(center=(int(cx), int(cy)))
        target.blit(layer, dest, special_flags=pygame.BLEND_RGBA_ADD)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # text
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f4f4f4",
    text_box: bool = False,
    text_box_color: str = "#ffffff",
    text_box_alpha: int = 35,
    text_box_padding: int = 28,
    text_box_radius: int = 14,
    text_glow: bool = False,
    text_glow_layers: int = 4,
    text_glow_strength: int = 35,
    # timing
    in_duration: float = 1.2,
    out_duration: float = 1.0,
    # effects
    text_in_effect: str = "pixelize",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    # background
    bg_color: str = "#0b0c10",
    bg_color2: str = "#15182a",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.35,
    show_ripples: bool = True,
    ripple_color: str = "#2a2d3a",
    ripple_count: int = 10,
    ripple_x: float | None = None,
    ripple_y: float | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    if "text_placeholder_box" in kwargs:
        text_box = bool(kwargs.pop("text_placeholder_box"))

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "title"
        output = CACHE_DIR / f"transition2_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    ric = _hex(ripple_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    ripple_cx = ripple_x * width if ripple_x is not None else text_cx
    ripple_cy = ripple_y * height if ripple_y is not None else text_cy

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    total_frames = max(1, int(duration * fps))
    in_frames = max(1, int(in_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    out_start = max(0, total_frames - out_frames)

    grad_cache: dict = {}
    random.seed(42)

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if show_ripples:
                _draw_ripples(surface, ripple_cx, ripple_cy, width, height, ric, ripple_count)
            if vignette > 0:
                _draw_vignette(surface, vignette)

            if text_box:
                _draw_text_box(
                    surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                    text_box_alpha, text_box_padding, text_box_radius,
                )
            if text_glow:
                _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)

            if frame < in_frames:
                prog = frame / in_frames
                _draw_text_effect(
                    surface, text_surf, text_cx, text_cy, text_in_effect, prog,
                    outward=False,
                    typewriter_frames=typewriter_in,
                    frame_idx=frame,
                    glitch_seed=7,
                    pixel_block_max=pixel_block_max,
                )
            elif frame >= out_start:
                prog = (frame - out_start) / out_frames
                _draw_text_effect(
                    surface, text_surf, text_cx, text_cy, text_out_effect, prog,
                    outward=True,
                    typewriter_frames=typewriter_out,
                    frame_idx=frame,
                    glitch_seed=99,
                    pixel_block_max=pixel_block_max,
                )
            else:
                surface.blit(
                    text_surf,
                    text_surf.get_rect(center=(int(text_cx), int(text_cy))),
                )

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-framerate", str(fps),
                "-i", str(frames_dir / "frame_%06d.png"),
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "fast", "-crf", "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)
