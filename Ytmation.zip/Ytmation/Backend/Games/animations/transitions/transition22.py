"""
Transition 22 — Glitch rupture
------------------------------
RGB tear, slice displacement, harsh flicker; title rips in and tears out.
"""

from __future__ import annotations

import random
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _norm_xy,
    _render_text_surface,
)


def _rupture_surface(
    src,
    intensity: float,
    frame: int,
    seed: int,
    *,
    rgb_split: int = 12,
    slice_px: int = 10,
) -> "object":
    import pygame

    if intensity <= 0.02:
        return src.copy()
    rng = random.Random(seed + frame * 97)
    out = src.copy()
    tw, th = src.get_size()

    # RGB channels offset
    if rgb_split > 0:
        r = src.copy()
        r.fill((80, 0, 0, 0), special_flags=pygame.BLEND_RGBA_ADD)
        b = src.copy()
        b.fill((0, 0, 120, 0), special_flags=pygame.BLEND_RGBA_ADD)
        off = int(rgb_split * intensity)
        out.fill((0, 0, 0, 0))
        out.blit(r, (-off, 0))
        out.blit(src, (0, 0))
        out.blit(b, (off, 0))

    strip_h = max(4, int(slice_px))
    for y in range(0, th, strip_h):
        if rng.random() < 0.55 * intensity:
            dx = int(rng.uniform(-1, 1) * 28 * intensity)
            rect = pygame.Rect(0, y, tw, min(strip_h, th - y))
            strip = out.subsurface(rect).copy()
            out.fill((0, 0, 0, 0), rect)
            out.blit(strip, (dx, y))

    if rng.random() < 0.25 * intensity:
        bar = pygame.Surface((tw, max(2, th // 40)), pygame.SRCALPHA)
        bar.fill((255, 255, 255, int(180 * intensity)))
        by = rng.randint(0, max(0, th - bar.get_height()))
        out.blit(bar, (0, by))

    return out


def run(
    duration: float = 4.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#ffffff",
    rupture_in_duration: float = 0.55,
    hold_duration: float = 1.2,
    rupture_out_duration: float = 0.55,
    glitch_intensity: float = 1.0,
    rgb_split_max: int = 16,
    slice_strength: int = 12,
    flicker: bool = True,
    bg_color: str = "#0a0a0c",
    bg_color2: str = "#120818",
    bg_gradient_dir: str = "radial",
    accent_flash: str = "#ff3366",
    seed: int = 99,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "rupture"
        output = CACHE_DIR / f"transition22_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    flash = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, ac = _hex(text_color), _hex(accent_flash)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(56, int(min(width, height) * 0.11))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    tw, th = text_surf.get_size()

    total_frames = max(1, int(duration * fps))
    in_frames = max(1, int(rupture_in_duration * fps))
    hold_frames = max(1, int(hold_duration * fps))
    out_frames = max(1, int(rupture_out_duration * fps))
    hold_start = in_frames
    out_start = max(hold_start + hold_frames, total_frames - out_frames)

    grad_cache: dict = {}
    rng = random.Random(seed)

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            if frame < in_frames:
                prog = frame / in_frames
                gi = glitch_intensity * (1.0 - _ease_out_cubic(prog) * 0.85)
                alpha = int(255 * _ease_out_cubic(prog))
            elif frame >= out_start:
                prog = (frame - out_start) / max(1, out_frames)
                gi = glitch_intensity * _ease_in_cubic(prog)
                alpha = int(255 * (1.0 - _ease_in_cubic(prog)))
            else:
                gi = 0.08 if flicker and frame % 9 < 2 else 0.0
                alpha = 255

            if gi > 0.15 and rng.random() < 0.2:
                flash.fill((*ac, int(40 * gi)))
                surface.blit(flash, (0, 0))

            if alpha > 0:
                chunk = _rupture_surface(
                    text_surf, gi, frame, seed,
                    rgb_split=int(rgb_split_max * gi), slice_px=slice_strength,
                )
                chunk.set_alpha(alpha)
                surface.blit(chunk, chunk.get_rect(center=(int(text_cx), int(text_cy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
