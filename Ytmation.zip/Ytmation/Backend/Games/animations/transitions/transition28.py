"""
Transition 28 — YouTube subscribe + bell
----------------------------------------
Classic red SUBSCRIBE pill, flip to SUBSCRIBED, notification bell rings.
"""

from __future__ import annotations

import math
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _draw_subscribe_btn(layer, x: int, y: int, w: int, h: int, label: str, bg: tuple, fg: tuple, font) -> None:
    import pygame

    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(surf, bg, (0, 0, w, h), border_radius=h // 2)
    txt = font.render(label, True, fg)
    surf.blit(txt, txt.get_rect(center=(w // 2, h // 2)))
    layer.blit(surf, (x, y))


def _draw_bell(layer, cx: float, cy: float, size: float, color: tuple) -> None:
    import pygame

    s = size
    body = [
        (cx - s * 0.35, cy - s * 0.05),
        (cx - s * 0.28, cy - s * 0.42),
        (cx + s * 0.28, cy - s * 0.42),
        (cx + s * 0.35, cy - s * 0.05),
        (cx + s * 0.38, cy + s * 0.12),
        (cx - s * 0.38, cy + s * 0.12),
    ]
    pygame.draw.polygon(layer, color, [(int(x), int(y)) for x, y in body])
    pygame.draw.arc(
        layer, color,
        (int(cx - s * 0.22), int(cy + s * 0.08), int(s * 0.44), int(s * 0.2)),
        math.pi * 0.1, math.pi * 0.9, 3,
    )
    pygame.draw.circle(layer, color, (int(cx), int(cy + s * 0.22)), max(3, int(s * 0.08)))


def _draw_bell_ding(layer, cx: float, cy: float, size: float, color: tuple, spread: float) -> None:
    import pygame

    for side in (-1, 1):
        arc_rect = pygame.Rect(
            int(cx + side * size * 0.15 - size * 0.35 * spread),
            int(cy - size * 0.55),
            int(size * 0.7 * spread),
            int(size * 0.5 * spread),
        )
        pygame.draw.arc(layer, color, arc_rect, math.pi * 0.15, math.pi * 0.85, 3)


def _draw_thumbs(layer, cx: float, cy: float, size: float, color: tuple) -> None:
    import pygame

    s = size
    pygame.draw.rect(layer, color, (int(cx - s * 0.12), int(cy - s * 0.05), int(s * 0.24), int(s * 0.35)))
    pygame.draw.polygon(
        layer, color,
        [
            (int(cx - s * 0.12), int(cy + s * 0.05)),
            (int(cx - s * 0.38), int(cy + s * 0.22)),
            (int(cx - s * 0.38), int(cy - s * 0.12)),
            (int(cx - s * 0.12), int(cy - s * 0.05)),
        ],
    )


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.38,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f1f1f1",
    cta_y: float = 0.58,
    slide_in_duration: float = 0.45,
    subscribe_at: float = 0.9,
    bell_at: float = 1.35,
    subscribed_at: float = 1.75,
    hold_duration: float = 1.4,
    slide_out_duration: float = 0.45,
    show_like: bool = True,
    subscribe_red: str = "#ff0000",
    subscribed_gray: str = "#606060",
    bell_color: str = "#ffffff",
    ding_color: str = "#ffcc00",
    bg_color: str = "#0f0f0f",
    bg_color2: str = "#181818",
    vignette: float = 0.35,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "sub"
        output = CACHE_DIR / f"transition28_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    ui = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    red, gray = _hex(subscribe_red), _hex(subscribed_gray)
    bell_c, ding_c, tc = _hex(bell_color), _hex(ding_color), _hex(text_color)
    title_x, title_y = _norm_xy(text_x, text_y, width, height)
    cta_cy = int(height * cta_y)

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.085))
    btn_font_size = max(22, int(height * 0.038))
    try:
        title_font = pygame.font.SysFont(font_name, font_size, bold=True)
        btn_font = pygame.font.SysFont(font_name, btn_font_size, bold=True)
    except Exception:
        title_font = pygame.font.Font(None, font_size)
        btn_font = pygame.font.Font(None, btn_font_size)

    title_surf = _render_text_surface(text, title_font, tc)
    btn_w, btn_h = int(width * 0.11), int(height * 0.065)
    bell_size = btn_h * 1.15
    like_size = btn_h * 0.95
    gap = int(width * 0.012)
    group_w = (btn_w + gap + int(bell_size * 1.1) + (int(like_size * 1.4) + gap if show_like else 0))
    rest_x = (width - group_w) // 2
    off_x = width + 40

    total_frames = max(1, int(duration * fps))
    slide_in_f = max(1, int(slide_in_duration * fps))
    sub_frame = int(subscribe_at * fps)
    bell_frame = int(bell_at * fps)
    subscribed_frame = int(subscribed_at * fps)
    hold_f = int(hold_duration * fps)
    slide_out_f = max(1, int(slide_out_duration * fps))
    out_start = min(subscribed_frame + hold_f, total_frames - slide_out_f)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, "radial", grad_cache)
            if vignette > 0:
                _draw_vignette(surface, vignette)

            ui.fill((0, 0, 0, 0))
            ta = 255
            if frame < slide_in_f:
                et = frame / slide_in_f
                ta = int(255 * _ease_out_cubic(et))
            elif frame >= out_start:
                et = (frame - out_start) / slide_out_f
                ta = int(255 * (1.0 - _ease_in_cubic(et)))

            if ta > 0:
                ts = title_surf.copy()
                ts.set_alpha(ta)
                ui.blit(ts, ts.get_rect(center=(int(title_x), int(title_y))))

            if frame >= sub_frame:
                if frame < slide_in_f + sub_frame:
                    st = min(1.0, (frame - sub_frame) / slide_in_f)
                    bx = _lerp(off_x, rest_x, _ease_out_cubic(st))
                elif frame >= out_start:
                    st = (frame - out_start) / slide_out_f
                    bx = _lerp(rest_x, off_x, _ease_in_cubic(st))
                else:
                    bx = rest_x

                subscribed = frame >= subscribed_frame
                label = "SUBSCRIBED" if subscribed else "SUBSCRIBE"
                bg = gray if subscribed else red
                _draw_subscribe_btn(ui, int(bx), cta_cy - btn_h // 2, btn_w, btn_h, label, bg, (255, 255, 255), btn_font)

                bell_x = bx + btn_w + gap + bell_size * 0.55
                bell_y = cta_cy
                if frame >= bell_frame:
                    bt = (frame - bell_frame) / max(1, fps * 0.5)
                    wobble = math.sin(bt * math.pi * 6) * (1.0 - min(1.0, bt)) * 12
                    if frame < bell_frame + int(fps * 0.45):
                        spread = min(1.0, (frame - bell_frame) / (fps * 0.25))
                        _draw_bell_ding(ui, bell_x, bell_y - bell_size * 0.15, bell_size, ding_c, spread)
                    bell_layer = pygame.Surface((int(bell_size * 2), int(bell_size * 2)), pygame.SRCALPHA)
                    _draw_bell(bell_layer, bell_size, bell_size * 0.9, bell_size * 0.85, bell_c)
                    rotated = pygame.transform.rotate(bell_layer, wobble)
                    ui.blit(rotated, rotated.get_rect(center=(int(bell_x), int(bell_y))))

                if show_like:
                    like_x = bx + btn_w + gap + bell_size * 1.15 + like_size * 0.5
                    _draw_thumbs(ui, like_x, cta_cy, like_size, (180, 180, 180))

            surface.blit(ui, (0, 0))
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
