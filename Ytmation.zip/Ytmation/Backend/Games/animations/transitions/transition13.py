"""
Transition 13 — Curtain reveal (modern editorial)
-------------------------------------------------
Soft panels part from center; thin rule grows under the title.
Clean, broadcast-documentary — no particles or game VFX.
"""

from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_out,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _draw_soft_panel(target, rect, color: tuple, edge_soft: int) -> None:
    """Panel with slightly softer inner edge (layered rects)."""
    import pygame

    pygame.draw.rect(target, color, rect)
    if edge_soft > 0:
        inner = rect.inflate(-edge_soft * 2, -edge_soft * 2)
        if inner.width > 0 and inner.height > 0:
            hi = tuple(min(255, c + 8) for c in color[:3])
            pygame.draw.rect(target, (*hi, 255), inner)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    subtitle: str = "",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    subtitle_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f0f0f0",
    subtitle_color: str = "#888890",
    reveal_duration: float = 1.1,
    out_duration: float = 0.85,
    panel_color: str = "#0e0e10",
    line_color: str = "#c8c8cc",
    line_height: int = 1,
    line_width_ratio: float = 0.22,
    rule_grow_duration: float = 0.5,
    text_delay: float = 0.15,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "curtain"
        output = CACHE_DIR / f"transition13_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))

    bg1 = bg2 = _hex(panel_color)
    tc, sc, lc = _hex(text_color), _hex(subtitle_color), _hex(line_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(42, int(min(width, height) * 0.07))
    if subtitle_size is None:
        subtitle_size = max(22, int(font_size * 0.45))

    try:
        title_font = pygame.font.SysFont(font_name, font_size, bold=False)
        sub_font = pygame.font.SysFont(font_name, subtitle_size, bold=False)
    except Exception:
        title_font = pygame.font.Font(None, font_size)
        sub_font = pygame.font.Font(None, subtitle_size)

    title_surf = title_font.render(text, True, tc)
    sub_surf = sub_font.render(subtitle, True, sc) if subtitle else None

    block_h = title_surf.get_height() + (sub_surf.get_height() + 20 if sub_surf else 0) + 40
    line_y = text_cy + block_h / 2 - 18
    line_full_w = int(width * line_width_ratio)

    total_frames = max(1, int(duration * fps))
    rev_frames = max(1, int(reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    rule_frames = max(1, int(rule_grow_duration * fps))
    text_delay_frames = max(0, int(text_delay * fps))
    out_start = max(rev_frames + int(fps), total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, "none", grad_cache)

            if frame < rev_frames:
                t = _ease_in_out(frame / rev_frames)
                gap = _lerp(0, width, t)
            elif frame >= out_start:
                t = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                gap = _lerp(width, 0, t)
            else:
                gap = width

            half_gap = gap / 2
            left_rect = pygame.Rect(0, 0, int(text_cx - half_gap), height)
            right_rect = pygame.Rect(int(text_cx + half_gap), 0, width - int(text_cx + half_gap), height)
            if left_rect.width > 0:
                _draw_soft_panel(surface, left_rect, bg1, 0)
            if right_rect.width > 0:
                _draw_soft_panel(surface, right_rect, bg1, 0)

            reveal_done = frame >= rev_frames
            if reveal_done and frame < out_start + out_frames:
                rf = min(frame - rev_frames, rule_frames)
                rule_t = _ease_out_cubic(rf / rule_frames) if frame < out_start else 1.0
                if frame >= out_start:
                    rule_t = 1.0 - _ease_in_cubic((frame - out_start) / max(1, out_frames))

                lw = int(line_full_w * rule_t)
                if lw > 0:
                    pygame.draw.rect(
                        surface, lc,
                        pygame.Rect(int(text_cx - lw // 2), int(line_y), lw, line_height),
                    )

                if frame >= rev_frames + text_delay_frames:
                    if frame < out_start:
                        ta = int(255 * _ease_out_cubic(
                            min(1.0, (frame - rev_frames - text_delay_frames) / max(1, rev_frames * 0.6))
                        ))
                    else:
                        ta = int(255 * (1.0 - _ease_in_cubic((frame - out_start) / max(1, out_frames))))
                    if ta > 0:
                        ty = text_cy - block_h / 2 + title_surf.get_height() // 2
                        tt = title_surf.copy()
                        tt.set_alpha(ta)
                        surface.blit(tt, tt.get_rect(center=(int(text_cx), int(ty))))
                        if sub_surf:
                            sy = ty + title_surf.get_height() // 2 + 16 + sub_surf.get_height() // 2
                            ss = sub_surf.copy()
                            ss.set_alpha(ta)
                            surface.blit(ss, ss.get_rect(center=(int(text_cx), int(sy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
