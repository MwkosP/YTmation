"""
Transition 8 — Hologram / signal decode
---------------------------------------
TV static clears, a scan bar sweeps the screen, and the title
materializes with RGB split that snaps into focus (sci-fi lock-on).

Phases: static burst → decode sweep → hold (subtle flicker) → signal out
"""

from __future__ import annotations

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_ripples,
    _draw_text_box,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _draw_grid(target, w: int, h: int, color: tuple, alpha: int, spacing: int = 48) -> None:
    import pygame

    grid = pygame.Surface((w, h), pygame.SRCALPHA)
    for x in range(0, w, spacing):
        pygame.draw.line(grid, (*color, alpha), (x, 0), (x, h))
    for y in range(0, h, spacing):
        pygame.draw.line(grid, (*color, alpha), (0, y), (w, y))
    target.blit(grid, (0, 0))


def _noise_burst(target, amount: float, seed: int, frame: int) -> None:
    import pygame

    if amount <= 0.01:
        return
    w, h = target.get_size()
    rng = random.Random(seed + frame * 7919)
    step = 5
    for y in range(0, h, step):
        for x in range(0, w, step):
            if rng.random() < amount * 0.35:
                v = rng.randint(0, 255)
                a = int(255 * amount * rng.uniform(0.3, 1.0))
                pygame.draw.rect(target, (v, v, v, a), (x, y, step, step))


def _chromatic_text(
    target,
    text_surf,
    cx: float,
    cy: float,
    *,
    split: float,
    alpha: int,
) -> None:
    import pygame

    if alpha <= 0:
        return
    rect = text_surf.get_rect(center=(int(cx), int(cy)))
    off = int(split)
    if off > 0:
        r = text_surf.copy()
        r.fill((255, 80, 80, 0), special_flags=pygame.BLEND_RGBA_ADD)
        r.set_alpha(alpha)
        g = text_surf.copy()
        g.set_alpha(alpha)
        b = text_surf.copy()
        b.fill((80, 120, 255, 0), special_flags=pygame.BLEND_RGBA_ADD)
        b.set_alpha(alpha)
        target.blit(r, (rect.x - off, rect.y))
        target.blit(b, (rect.x + off, rect.y))
    g.set_alpha(alpha)
    target.blit(g, rect)


def _decode_sweep_text(
    target,
    text_surf,
    cx: float,
    cy: float,
    scan_y: float,
    *,
    split: float,
    alpha: int,
    glitch: float,
    frame: int,
) -> None:
    """Reveal text row-by-row under scan line."""
    import pygame

    rect = text_surf.get_rect(center=(int(cx), int(cy)))
    w, h = text_surf.get_size()
    if scan_y <= rect.top:
        return
    visible_h = min(h, int(scan_y - rect.top))
    if visible_h <= 0:
        return

    strip = text_surf.subsurface((0, 0, w, visible_h)).copy()
    dest = pygame.Rect(rect.x, rect.y, w, visible_h)

    if glitch > 0.05 and frame % 3 == 0:
        dest.x += int(glitch * random.randint(-6, 6))

    strip.set_alpha(alpha)
    off = int(split)
    if off > 0 and alpha > 0:
        rs = strip.copy()
        rs.fill((120, 30, 30, 0), special_flags=pygame.BLEND_RGBA_ADD)
        bs = strip.copy()
        bs.fill((30, 50, 140, 0), special_flags=pygame.BLEND_RGBA_ADD)
        target.blit(rs, (dest.x - off, dest.y))
        target.blit(bs, (dest.x + off, dest.y))
    target.blit(strip, dest.topleft)


def _draw_scan_bar(target, y: float, w: int, color: tuple, glow: int = 3) -> None:
    import pygame

    iy = int(y)
    for i in range(-glow, glow + 1):
        a = max(20, 180 - abs(i) * 50)
        pygame.draw.line(target, (*color, a), (0, iy + i), (w, iy + i), 1)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # text
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f4f4f4",
    text_box: bool = False,
    text_box_color: str = "#ffffff",
    text_box_alpha: int = 35,
    text_box_padding: int = 28,
    text_box_radius: int = 14,
    text_glow: bool = False,
    text_glow_layers: int = 4,
    text_glow_strength: int = 35,
    # timing
    static_duration: float = 0.35,
    decode_duration: float = 1.6,
    out_duration: float = 0.9,
    text_in_effect: str = "fade",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    # hologram look
    accent_color: str = "#00e5ff",
    grid_alpha: int = 22,
    static_intensity: float = 0.85,
    chroma_split_max: float = 14.0,
    scan_glow: bool = True,
    hold_flicker: bool = True,
    seed: int = 42,
    # background
    bg_color: str = "#050810",
    bg_color2: str = "#0c1830",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.38,
    show_ripples: bool = False,
    ripple_color: str = "#1a3a5c",
    ripple_count: int = 8,
    ripple_x: float | None = None,
    ripple_y: float | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    kwargs.pop("text_placeholder_box", None)

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "title"
        output = CACHE_DIR / f"transition8_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    overlay = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    ac = _hex(accent_color)
    ric = _hex(ripple_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    ripple_cx = ripple_x * width if ripple_x is not None else text_cx
    ripple_cy = ripple_y * height if ripple_y is not None else text_cy

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    total_frames = max(1, int(duration * fps))
    static_frames = max(0, int(static_duration * fps))
    decode_frames = max(1, int(decode_duration * fps))
    out_frames = max(1, int(out_duration * fps))

    decode_start = static_frames
    decode_end = decode_start + decode_frames
    out_start = max(decode_end, total_frames - out_frames)
    hold_end = out_start

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            _draw_grid(surface, width, height, ac, grid_alpha)
            if show_ripples:
                _draw_ripples(surface, ripple_cx, ripple_cy, width, height, ric, ripple_count)

            overlay.fill((0, 0, 0, 0))

            if frame < decode_start:
                # pre-static
                noise_amt = static_intensity
                _noise_burst(overlay, noise_amt, seed, frame)
            elif frame < decode_end:
                dec_f = frame - decode_start
                prog = _ease_out_cubic(dec_f / decode_frames)
                scan_y = _lerp(0, height * 1.08, prog)
                noise_amt = static_intensity * (1.0 - prog) * 0.9
                split = chroma_split_max * (1.0 - prog)
                glitch = (1.0 - prog) * 0.8
                text_alpha = int(255 * min(1.0, prog * 1.15))

                _noise_burst(overlay, noise_amt, seed, frame)
                _decode_sweep_text(
                    surface, text_surf, text_cx, text_cy, scan_y,
                    split=split, alpha=text_alpha, glitch=glitch, frame=frame,
                )
                if scan_glow:
                    _draw_scan_bar(overlay, scan_y, width, ac)
            elif frame < out_start:
                flick = 1.0
                if hold_flicker and frame % 11 < 2:
                    flick = 0.92
                if text_box:
                    _draw_text_box(
                        surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                        text_box_alpha, text_box_padding, text_box_radius,
                    )
                if text_glow:
                    _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                ts = text_surf.copy()
                ts.set_alpha(int(255 * flick))
                surface.blit(ts, ts.get_rect(center=(int(text_cx), int(text_cy))))
                # faint rolling scan
                roll = (frame * 3) % height
                _draw_scan_bar(overlay, roll, width, ac, glow=1)
            else:
                out_prog = (frame - out_start) / max(1, out_frames)
                noise_amt = static_intensity * _ease_in_cubic(out_prog)
                _noise_burst(overlay, noise_amt, seed, frame)
                if out_prog < 0.75:
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_out_effect, out_prog / 0.75,
                        outward=True,
                        typewriter_frames=typewriter_out,
                        frame_idx=frame,
                        glitch_seed=42,
                        pixel_block_max=pixel_block_max,
                    )

            surface.blit(overlay, (0, 0))
            if vignette > 0:
                _draw_vignette(surface, vignette)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-framerate", str(fps),
                "-i", str(frames_dir / f"frame_%06d.png"),
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "fast", "-crf", "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
