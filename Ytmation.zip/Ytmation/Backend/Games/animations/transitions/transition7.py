"""
Transition 7 — Paintball splash reveals title
---------------------------------------------
A paintball flies in, splatters on the center, paint spreads across the middle,
then the title appears on the painted area.

Phases: fly → splash grow → text reveal → hold → optional fade out
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_ripples,
    _draw_text_box,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)

PAINTBALL_FROM = ("left", "right", "top", "bottom", "random")


@dataclass
class Droplet:
    x: float
    y: float
    vx: float
    vy: float
    radius: float
    life: float


def _paintball_start(
    side: str,
    w: int,
    h: int,
    target_x: float,
    target_y: float,
    rng: random.Random,
) -> tuple[float, float]:
    side = (side or "random").lower()
    if side == "random":
        side = rng.choice(["left", "right", "top", "bottom"])
    margin = 80
    if side == "left":
        return -margin, target_y + rng.uniform(-120, 120)
    if side == "right":
        return w + margin, target_y + rng.uniform(-120, 120)
    if side == "top":
        return target_x + rng.uniform(-160, 160), -margin
    return target_x + rng.uniform(-160, 160), h + margin


def _stamp_splat(
    layer,
    x: float,
    y: float,
    radius: float,
    color: tuple,
    rng: random.Random,
    *,
    blobs: int = 8,
) -> None:
    import pygame

    r = max(3, int(radius))
    pygame.draw.circle(layer, color, (int(x), int(y)), r)
    for _ in range(blobs):
        ang = rng.uniform(0, math.tau)
        dist = rng.uniform(0.15, 0.85) * r
        br = max(2, int(r * rng.uniform(0.18, 0.45)))
        px = int(x + math.cos(ang) * dist)
        py = int(y + math.sin(ang) * dist)
        pygame.draw.circle(layer, color, (px, py), br)


def _grow_center_paint(
    layer,
    cx: float,
    cy: float,
    radius: float,
    color: tuple,
    rng: random.Random,
    *,
    rings: int = 14,
) -> None:
    import pygame

    for i in range(rings):
        t = i / max(1, rings - 1)
        rr = radius * (0.35 + t * 0.75)
        ox = rng.uniform(-radius * 0.12, radius * 0.12)
        oy = rng.uniform(-radius * 0.12, radius * 0.12)
        _stamp_splat(layer, cx + ox, cy + oy, rr, color, rng, blobs=6)


def _spawn_droplets(
    cx: float,
    cy: float,
    count: int,
    speed: float,
    rng: random.Random,
) -> list[Droplet]:
    drops: list[Droplet] = []
    for _ in range(count):
        ang = rng.uniform(0, math.tau)
        spd = speed * rng.uniform(0.45, 1.25)
        drops.append(
            Droplet(
                x=cx + rng.uniform(-8, 8),
                y=cy + rng.uniform(-8, 8),
                vx=math.cos(ang) * spd,
                vy=math.sin(ang) * spd,
                radius=rng.uniform(4, 14),
                life=1.0,
            )
        )
    return drops


def _update_droplets(drops: list[Droplet], drag: float = 0.94) -> None:
    for d in drops:
        d.x += d.vx
        d.y += d.vy
        d.vx *= drag
        d.vy *= drag
        d.vy += 0.12
        d.life -= 0.028
        d.radius = max(1.0, d.radius * 0.985)


def _draw_paintball(target, x: float, y: float, color: tuple, radius: int = 14) -> None:
    import pygame

    rgb = color[:3]
    pygame.draw.circle(target, (20, 20, 20), (int(x), int(y)), radius + 2)
    pygame.draw.circle(target, rgb, (int(x), int(y)), radius)
    hl = tuple(min(255, c + 50) for c in rgb)
    pygame.draw.circle(target, hl, (int(x) - 4, int(y) - 4), max(3, radius // 3))


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # text
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f4f4f4",
    text_box: bool = False,
    text_box_color: str = "#ffffff",
    text_box_alpha: int = 35,
    text_box_padding: int = 28,
    text_box_radius: int = 14,
    text_glow: bool = False,
    text_glow_layers: int = 4,
    text_glow_strength: int = 35,
    # timing
    fly_duration: float = 0.55,
    splash_duration: float = 1.35,
    text_reveal_duration: float = 0.9,
    out_duration: float = 0.8,
    text_in_effect: str = "fade",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    # paintball / splash
    splash_x: float = 0.5,
    splash_y: float = 0.5,
    paintball_from: str = "left",
    paint_color: str = "#1e6b8a",
    paintball_color: str = "#e040fb",
    splash_radius: float = 520.0,
    splatter_count: int = 48,
    splatter_speed: float = 11.0,
    paint_inner_bright: str = "#2a9cc4",
    seed: int = 42,
    # background
    bg_color: str = "#0b0c10",
    bg_color2: str = "#12141c",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.32,
    show_ripples: bool = False,
    ripple_color: str = "#2a2d3a",
    ripple_count: int = 10,
    ripple_x: float | None = None,
    ripple_y: float | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    kwargs.pop("text_placeholder_box", None)

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "title"
        output = CACHE_DIR / f"transition7_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    paint_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    pc = _hex(paint_color)
    pbc = _hex(paintball_color)
    pib = _hex(paint_inner_bright)
    ric = _hex(ripple_color)

    splash_cx = splash_x * width
    splash_cy = splash_y * height
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    ripple_cx = ripple_x * width if ripple_x is not None else text_cx
    ripple_cy = ripple_y * height if ripple_y is not None else text_cy

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    rng = random.Random(seed)
    start_x, start_y = _paintball_start(paintball_from, width, height, splash_cx, splash_cy, rng)

    total_frames = max(1, int(duration * fps))
    fly_frames = max(1, int(fly_duration * fps))
    splash_frames = max(1, int(splash_duration * fps))
    reveal_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))

    splash_start = fly_frames
    reveal_start = splash_start + int(splash_frames * 0.45)
    out_start = max(reveal_start + reveal_frames, total_frames - out_frames)

    droplets: list[Droplet] = []
    impact_done = False
    grad_cache: dict = {}

    paint_rgba = (*pc, 255)
    paint_bright_rgba = (*pib, 220)

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if show_ripples:
                _draw_ripples(surface, ripple_cx, ripple_cy, width, height, ric, ripple_count)

            # --- paintball flight ---
            if frame < fly_frames:
                t = _ease_in_cubic(frame / fly_frames)
                bx = _lerp(start_x, splash_cx, t)
                by = _lerp(start_y, splash_cy, t)
                trail_steps = 6
                for i in range(trail_steps):
                    tt = max(0.0, t - i * 0.06)
                    tx = _lerp(start_x, splash_cx, tt)
                    ty = _lerp(start_y, splash_cy, tt)
                    alpha = 120 - i * 18
                    if alpha > 0:
                        tr = pygame.Surface((20, 20), pygame.SRCALPHA)
                        pygame.draw.circle(tr, (*pbc, alpha), (10, 10), 8 - i)
                        surface.blit(tr, (int(tx) - 10, int(ty) - 10))
                _draw_paintball(surface, bx, by, pbc)

            # --- impact + growing paint ---
            if frame >= splash_start:
                splash_f = frame - splash_start
                if not impact_done:
                    _stamp_splat(paint_layer, splash_cx, splash_cy, 40, paint_rgba, rng, blobs=12)
                    droplets = _spawn_droplets(splash_cx, splash_cy, splatter_count, splatter_speed, rng)
                    impact_done = True

                grow_t = _ease_out_cubic(min(1.0, splash_f / splash_frames))
                cur_r = splash_radius * grow_t
                if cur_r > 8:
                    _grow_center_paint(paint_layer, splash_cx, splash_cy, cur_r, paint_rgba, rng)
                    if grow_t > 0.35:
                        _grow_center_paint(
                            paint_layer, splash_cx, splash_cy, cur_r * 0.55, paint_bright_rgba, rng, rings=8,
                        )

                for d in droplets:
                    if d.life > 0:
                        _stamp_splat(paint_layer, d.x, d.y, d.radius, paint_rgba, rng, blobs=3)
                _update_droplets(droplets)

            surface.blit(paint_layer, (0, 0))

            # --- text reveal on paint ---
            if frame >= reveal_start:
                if frame < out_start:
                    rev_t = min(1.0, (frame - reveal_start) / reveal_frames)
                    if text_box:
                        _draw_text_box(
                            surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                            text_box_alpha, text_box_padding, text_box_radius,
                        )
                    if text_glow:
                        _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_in_effect, rev_t,
                        outward=False,
                        typewriter_frames=typewriter_in,
                        frame_idx=frame,
                        glitch_seed=7,
                        pixel_block_max=pixel_block_max,
                    )
                else:
                    out_t = (frame - out_start) / max(1, out_frames)
                    if text_box:
                        _draw_text_box(
                            surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                            text_box_alpha, text_box_padding, text_box_radius,
                        )
                    if text_glow:
                        _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_out_effect, out_t,
                        outward=True,
                        typewriter_frames=typewriter_out,
                        frame_idx=frame,
                        glitch_seed=99,
                        pixel_block_max=pixel_block_max,
                    )

            if vignette > 0:
                _draw_vignette(surface, vignette)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-framerate", str(fps),
                "-i", str(frames_dir / f"frame_%06d.png"),
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "fast", "-crf", "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
