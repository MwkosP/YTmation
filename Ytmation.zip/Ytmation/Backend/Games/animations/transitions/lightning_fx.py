"""Shared procedural lightning for transitions 23 & 24."""

from __future__ import annotations

import math
import random
def lightning_path(
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    rng: random.Random,
    *,
    displace: float = 80.0,
    depth: int = 8,
    branch_chance: float = 0.28,
) -> list[tuple[float, float]]:
    def _rec(ax: float, ay: float, bx: float, by: float, disp: float, d: int) -> list[tuple[float, float]]:
        if disp < 3 or d <= 0:
            return [(ax, ay), (bx, by)]
        mx = (ax + bx) / 2 + rng.uniform(-disp, disp)
        my = (ay + by) / 2 + rng.uniform(-disp, disp)
        left = _rec(ax, ay, mx, my, disp * 0.52, d - 1)
        right = _rec(mx, my, bx, by, disp * 0.52, d - 1)
        pts = left[:-1] + right
        if d > 3 and rng.random() < branch_chance:
            ang = rng.uniform(0, math.tau)
            blen = disp * rng.uniform(0.8, 1.6)
            bx2 = mx + math.cos(ang) * blen
            by2 = my + math.sin(ang) * blen
            branch = _rec(mx, my, bx2, by2, disp * 0.35, max(2, d - 3))
            pts = pts + branch[1:]
        return pts

    return _rec(x1, y1, x2, y2, displace, depth)


def draw_bolt(
    target,
    points: list[tuple[float, float]],
    color: tuple,
    *,
    width: int = 2,
    glow: bool = True,
) -> None:
    import pygame

    if len(points) < 2:
        return
    int_pts = [(int(x), int(y)) for x, y in points]
    if glow:
        for w, a in ((width + 6, 35), (width + 3, 70), (width + 1, 120)):
            glow_surf = pygame.Surface(target.get_size(), pygame.SRCALPHA)
            pygame.draw.lines(glow_surf, (*color[:3], a), False, int_pts, w)
            target.blit(glow_surf, (0, 0))
    pygame.draw.lines(target, color, False, int_pts, width)
    for px, py in int_pts[:: max(1, len(int_pts) // 6)]:
        pygame.draw.circle(target, (255, 255, 255), (px, py), max(1, width))
