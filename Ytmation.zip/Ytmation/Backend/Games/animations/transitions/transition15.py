"""
Transition 15 — Planet horizon rise
-----------------------------------
Starfield above a world whose curve rises from below; atmosphere rim glow.
Cinematic space opener (Interstellar-style), not hyperspace streaks.
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _ease_in_out,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


@dataclass
class SkyStar:
    x: float
    y: float
    size: float
    phase: float


def _spawn_sky_stars(count: int, w: int, h: int, horizon_y: float, rng: random.Random) -> list[SkyStar]:
    stars: list[SkyStar] = []
    for _ in range(count):
        stars.append(
            SkyStar(
                x=rng.uniform(0, w),
                y=rng.uniform(0, horizon_y - 20),
                size=rng.uniform(0.8, 2.4),
                phase=rng.uniform(0, math.tau),
            )
        )
    return stars


def _draw_atmosphere_rim(target, cx: float, cy: float, radius: float, rim_color: tuple, width: int) -> None:
    import pygame

    # bright arc along top of planet disc
    rect = pygame.Rect(int(cx - radius), int(cy - radius), int(radius * 2), int(radius * 2))
    pygame.draw.arc(target, rim_color, rect, math.pi * 1.08, math.pi * 1.92, width)
    inner = tuple(min(255, c + 40) for c in rim_color)
    pygame.draw.arc(target, inner, rect, math.pi * 1.12, math.pi * 1.88, max(1, width // 2))


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.42,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f2f6ff",
    text_glow: bool = True,
    text_glow_layers: int = 5,
    text_glow_strength: int = 42,
    rise_duration: float = 2.2,
    text_reveal_duration: float = 1.0,
    out_duration: float = 0.8,
    text_in_effect: str = "fade",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    planet_radius: float = 920.0,
    planet_color: str = "#1a2238",
    planet_shadow: str = "#0c1018",
    atmosphere_color: str = "#ff9a6e",
    atmosphere_width: int = 5,
    star_count: int = 200,
    star_color: str = "#e8f0ff",
    seed: int = 42,
    bg_color: str = "#020408",
    bg_color2: str = "#061020",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.4,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "horizon"
        output = CACHE_DIR / f"transition15_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    pc, ps, ac, sc = _hex(planet_color), _hex(planet_shadow), _hex(atmosphere_color), _hex(star_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    planet_cx = width / 2

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    rng = random.Random(seed)
    rise_frames = max(1, int(rise_duration * fps))
    reveal_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    total_frames = max(1, int(duration * fps))

    planet_start_y = height + planet_radius * 0.55
    planet_end_y = height + planet_radius * 0.12
    reveal_start = int(rise_frames * 0.55)
    out_start = max(reveal_start + reveal_frames, total_frames - out_frames)

    stars = _spawn_sky_stars(star_count, width, height, height * 0.65, rng)
    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            if frame < rise_frames:
                t = _ease_in_out(frame / rise_frames)
                planet_cy = _lerp(planet_start_y, planet_end_y, t)
            else:
                planet_cy = planet_end_y

            horizon_y = planet_cy - planet_radius * 0.15

            for st in stars:
                if st.y > horizon_y - 10:
                    continue
                tw = 0.7 + 0.3 * math.sin(frame * 0.04 + st.phase)
                c = tuple(min(255, int(ch * tw)) for ch in sc)
                pygame.draw.circle(surface, c, (int(st.x), int(st.y)), max(1, int(st.size)))

            pr = int(planet_radius)
            pygame.draw.circle(surface, ps, (int(planet_cx), int(planet_cy)), pr + 2)
            pygame.draw.circle(surface, pc, (int(planet_cx), int(planet_cy)), pr)
            # shadow side
            shade = pygame.Surface((pr * 2 + 4, pr * 2 + 4), pygame.SRCALPHA)
            pygame.draw.circle(shade, (*ps, 120), (pr + 2, pr + 2), pr)
            surface.blit(shade, (int(planet_cx - pr - 2), int(planet_cy - pr - 2)))
            _draw_atmosphere_rim(surface, planet_cx, planet_cy, pr, ac, atmosphere_width)

            if frame >= reveal_start:
                if frame < out_start:
                    rev = min(1.0, (frame - reveal_start) / reveal_frames)
                    if text_glow:
                        _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_in_effect, rev,
                        outward=False, typewriter_frames=typewriter_in, frame_idx=frame,
                        glitch_seed=15, pixel_block_max=pixel_block_max,
                    )
                else:
                    out_t = (frame - out_start) / max(1, out_frames)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_out_effect, out_t,
                        outward=True, typewriter_frames=typewriter_out, frame_idx=frame,
                        glitch_seed=25, pixel_block_max=pixel_block_max,
                    )

            if vignette > 0:
                _draw_vignette(surface, vignette)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
