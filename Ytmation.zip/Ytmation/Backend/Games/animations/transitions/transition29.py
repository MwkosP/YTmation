"""
Transition 29 — Vertical scan line reveal
-----------------------------------------
A vertical line sweeps left → right; title is uncovered behind it.
"""

from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _draw_scan_line(layer, x: float, y0: float, y1: float, color: tuple, width: int, glow: tuple | None, glow_w: int) -> None:
    import pygame

    xi = int(x)
    if glow and glow_w > width:
        pygame.draw.line(layer, glow, (xi, int(y0)), (xi, int(y1)), glow_w)
    pygame.draw.line(layer, color, (xi, int(y0)), (xi, int(y1)), max(1, width))


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f2f2f2",
    scan_duration: float = 1.4,
    hold_duration: float = 1.8,
    scan_out_duration: float = 0.9,
    scan_delay: float = 0.25,
    line_width: int = 3,
    line_glow_width: int = 14,
    line_color: str = "#ffffff",
    line_glow_color: str = "#88ccff",
    line_height: float = 1.0,
    line_axis_y: float = 0.5,
    line_full_height: bool | None = None,
    line_pad_y: float = 0.06,
    reverse_out: bool = True,
    bg_color: str = "#0c0c0e",
    bg_color2: str = "#141418",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.35,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "scan"
        output = CACHE_DIR / f"transition29_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    line_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, lc, gc = _hex(text_color), _hex(line_color), _hex(line_glow_color)
    glow_a = (*gc, 90)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.095))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    text_rect = text_surf.get_rect(center=(int(text_cx), int(text_cy)))
    pad_y = int(height * line_pad_y)

    # line_height: 0 = collapsed on axis; 1 = full frame span (symmetric around line_axis_y)
    if line_full_height is not None:
        lh = 1.0 if line_full_height else min(1.0, (text_rect.height + 2 * pad_y) / max(height, 1))
    else:
        lh = max(0.0, min(1.0, float(line_height)))
    axis_y = max(0.0, min(1.0, float(line_axis_y))) * height
    span = height * lh
    line_y0 = axis_y - span / 2
    line_y1 = axis_y + span / 2

    total_frames = max(1, int(duration * fps))
    delay_f = int(scan_delay * fps)
    scan_f = max(1, int(scan_duration * fps))
    hold_f = int(hold_duration * fps)
    out_f = max(1, int(scan_out_duration * fps))
    scan_start = delay_f
    out_start = min(scan_start + scan_f + hold_f, total_frames - out_f)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if vignette > 0:
                _draw_vignette(surface, vignette)

            scanning_in = scan_start <= frame < scan_start + scan_f
            scanning_out = reverse_out and frame >= out_start and frame < out_start + out_f

            if scanning_in:
                prog = _ease_out_cubic((frame - scan_start) / scan_f)
                scan_x = _lerp(text_rect.left, text_rect.right + 2, prog)
            elif scanning_out:
                prog = _ease_in_cubic((frame - out_start) / out_f)
                scan_x = _lerp(text_rect.right + 2, text_rect.left, prog)
            elif frame >= scan_start + scan_f and (not reverse_out or frame < out_start):
                scan_x = text_rect.right + 2
            else:
                scan_x = text_rect.left

            clip_w = max(0, int(scan_x - text_rect.left))
            if clip_w > 0:
                visible = text_surf.subsurface((0, 0, min(clip_w, text_surf.get_width()), text_surf.get_height()))
                surface.blit(visible, text_rect.topleft)

            show_line = scanning_in or scanning_out
            if show_line:
                line_layer.fill((0, 0, 0, 0))
                _draw_scan_line(line_layer, scan_x, line_y0, line_y1, lc, line_width, glow_a, line_glow_width)
                surface.blit(line_layer, (0, 0))
            elif frame >= scan_start + scan_f and frame < out_start:
                surface.blit(text_surf, text_rect)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
