"""
Transition 4 — Flocking boids around animated text
--------------------------------------------------
Boids swarm continuously (2D or 3D projected) and avoid the title area.
Text reveals / exits with the same effects as transition2.

space: "2d" | "3d"
text_in_effect / text_out_effect: fade, pixelize, scale, slide_*, typewriter, blur, glitch, wipe
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_ripples,
    _draw_text_box,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _hex,
    _norm_xy,
    _render_text_surface,
)
from Games.animations.transitions.transition3 import (
    BOID_ROTATIONS,
    BOID_SHAPES,
    _draw_one_boid,
    _render_text_mask,
)

SPACES = ("2d", "3d")
BOUNDARY_MODES = ("bounce", "wrap")
FLOW_MODES = ("swirl", "left", "right", "up", "down", "angle")


@dataclass
class FlockBoid:
    x: float
    y: float
    z: float
    vx: float
    vy: float
    vz: float
    angle: float = 0.0
    wander_theta: float = 0.0


@dataclass
class _ScreenBoid:
    """Adapter for transition3 draw helpers."""
    x: float
    y: float
    vx: float
    vy: float
    angle: float
    home_x: float = 0.0
    home_y: float = 0.0


def _build_text_obstacles(
    mask,
    text_cx: float,
    text_cy: float,
    *,
    step: int = 8,
    alpha_threshold: int = 48,
) -> tuple[list[tuple[float, float]], tuple[float, float, float, float]]:
    tw, th = mask.get_size()
    left = text_cx - tw / 2
    top = text_cy - th / 2
    pts: list[tuple[float, float]] = []
    st = max(2, int(step))
    for y in range(0, th, st):
        for x in range(0, tw, st):
            if mask.get_at((x, y))[3] >= alpha_threshold:
                pts.append((left + x, top + y))
    rect = (left, top, left + tw, top + th)
    return pts, rect


def _spawn_flock(
    count: int,
    w: int,
    h: int,
    *,
    space: str,
    depth_spread: float,
    rng: random.Random,
) -> list[FlockBoid]:
    boids: list[FlockBoid] = []
    margin = 60
    for _ in range(count):
        x = rng.uniform(margin, w - margin)
        y = rng.uniform(margin, h - margin)
        if space == "3d":
            z = rng.uniform(-depth_spread, depth_spread)
        else:
            z = 0.0
        ang = rng.uniform(0, math.tau)
        spd = rng.uniform(2.0, 4.5)
        boids.append(
            FlockBoid(
                x=x - w / 2,
                y=y - h / 2,
                z=z,
                vx=math.cos(ang) * spd,
                vy=math.sin(ang) * spd,
                vz=rng.uniform(-1.2, 1.2) if space == "3d" else 0.0,
                angle=ang,
                wander_theta=ang,
            )
        )
    return boids


def _project(
    b: FlockBoid,
    w: int,
    h: int,
    *,
    space: str,
    focal: float,
) -> tuple[float, float, float]:
    """World → screen (sx, sy), depth sort key, draw scale."""
    if space == "3d":
        fz = focal + b.z
        fz = max(fz, 40.0)
        scale = focal / fz
        sx = w / 2 + b.x * scale
        sy = h / 2 + b.y * scale
        return sx, sy, b.z, scale
    return w / 2 + b.x, h / 2 + b.y, 0.0, 1.0


def _grid_buckets_world(
    boids: list[FlockBoid],
    cell: float,
    *,
    space: str,
) -> dict[tuple[int, ...], list[int]]:
    buckets: dict[tuple[int, ...], list[int]] = {}
    inv = 1.0 / max(cell, 1.0)
    for i, b in enumerate(boids):
        if space == "3d":
            key = (int(b.x * inv), int(b.y * inv), int(b.z * inv))
        else:
            key = (int(b.x * inv), int(b.y * inv))
        buckets.setdefault(key, []).append(i)
    return buckets


def _text_avoidance(
    sx: float,
    sy: float,
    obstacles: list[tuple[float, float]],
    rect: tuple[float, float, float, float],
    *,
    margin: float,
    radius: float,
    strength: float,
    tangential: float,
) -> tuple[float, float]:
    left, top, right, bottom = rect
    if sx < left - margin or sx > right + margin or sy < top - margin or sy > bottom + margin:
        return 0.0, 0.0

    ax = ay = 0.0
    r = max(radius, 1.0)
    r2 = r * r
    hits: list[tuple[float, float, float]] = []
    for ox, oy in obstacles:
        dx, dy = sx - ox, sy - oy
        d2 = dx * dx + dy * dy
        if d2 < r2:
            hits.append((d2, dx, dy))
    hits.sort(key=lambda t: t[0])
    for d2, dx, dy in hits[:12]:
        d = math.sqrt(d2) or 0.1
        t = (1.0 - d / r) ** 2
        nx, ny = dx / d, dy / d
        tx, ty = -ny, nx
        ax += nx * strength * t + tx * strength * t * tangential
        ay += ny * strength * t + ty * strength * t * tangential

    if left <= sx <= right and top <= sy <= bottom:
        cx, cy = (left + right) / 2, (top + bottom) / 2
        dx, dy = sx - cx, sy - cy
        ln = math.hypot(dx, dy) or 1.0
        ax += (dx / ln) * strength * 0.15
        ay += (dy / ln) * strength * 0.15

    return ax, ay


def _soft_boundary(
    b: FlockBoid,
    w: int,
    h: int,
    *,
    space: str,
    mode: str,
    depth_spread: float,
    edge: float,
) -> tuple[float, float, float]:
    hw, hh = w / 2, h / 2
    ax = ay = az = 0.0

    if mode == "wrap":
        lim_x, lim_y = hw - 4, hh - 4
        if b.x < -lim_x:
            b.x += lim_x * 2
        elif b.x > lim_x:
            b.x -= lim_x * 2
        if b.y < -lim_y:
            b.y += lim_y * 2
        elif b.y > lim_y:
            b.y -= lim_y * 2
        if space == "3d":
            if b.z < -depth_spread:
                b.z += depth_spread * 2
            elif b.z > depth_spread:
                b.z -= depth_spread * 2
        return 0.0, 0.0, 0.0

    def _edge_push(val: float, limit: float) -> float:
        d = limit - abs(val)
        if d >= edge:
            return 0.0
        return math.copysign(((edge - d) / edge) ** 2 * 0.9, -val)

    ax += _edge_push(b.x, hw - 30)
    ay += _edge_push(b.y, hh - 30)
    if space == "3d":
        az += _edge_push(b.z, depth_spread)
    return ax, ay, az


def _wander_force(b: FlockBoid, strength: float) -> tuple[float, float]:
    b.wander_theta += random.uniform(-0.35, 0.35)
    return math.cos(b.wander_theta) * strength, math.sin(b.wander_theta) * strength


def _flow_force(
    b: FlockBoid,
    t: float,
    strength: float,
    *,
    mode: str,
    angle_deg: float,
    lane_wobble: float,
) -> tuple[float, float]:
    """
    Directional drift. Use flow_mode='left' + low cohesion for streaming lines.
    lane_wobble: 0 = straight bands, ~0.35–0.6 = gentle curved lanes (not clusters).
    """
    mode = (mode or "swirl").lower()
    wob = lane_wobble * strength

    if mode == "left":
        return strength, math.sin(b.y * 0.018 + t * 0.7 + b.x * 0.002) * wob
    if mode == "right":
        return -strength, math.sin(b.y * 0.018 + t * 0.7) * wob
    if mode == "up":
        return math.sin(b.x * 0.018 + t * 0.7) * wob, strength
    if mode == "down":
        return math.sin(b.x * 0.018 + t * 0.7) * wob, -strength
    if mode == "angle":
        rad = math.radians(angle_deg)
        ax, ay = math.cos(rad) * strength, math.sin(rad) * strength
        perp = math.sin(b.x * 0.015 + b.y * 0.012 + t * 0.6) * wob
        return ax - math.sin(rad) * perp, ay + math.cos(rad) * perp

    # swirl (default)
    base = math.atan2(b.y, b.x) + math.pi / 2
    wobble = math.sin(t * 0.9 + b.x * 0.004 + b.y * 0.003) * 0.45
    ang = base + wobble
    return math.cos(ang) * strength, math.sin(ang) * strength


def _update_flock(
    boids: list[FlockBoid],
    screen_xy: list[tuple[float, float, float]],
    *,
    w: int,
    h: int,
    space: str,
    time_s: float,
    perception: float,
    separation_radius: float,
    separation_strength: float,
    alignment_strength: float,
    cohesion_strength: float,
    max_speed: float,
    min_speed: float,
    drag: float,
    wander_strength: float,
    flow_strength: float,
    flow_mode: str,
    flow_angle: float,
    flow_lane_wobble: float,
    max_neighbors: int,
    anti_cluster_strength: float,
    obstacles: list[tuple[float, float]],
    text_rect: tuple[float, float, float, float],
    avoid_margin: float,
    avoid_radius: float,
    avoid_strength: float,
    avoid_tangential: float,
    boundary_mode: str,
    depth_spread: float,
    focal: float,
) -> None:
    sep_r2 = separation_radius * separation_radius
    per_r2 = perception * perception
    buckets = _grid_buckets_world(boids, perception, space=space)
    cell = perception
    inv = 1.0 / max(cell, 1.0)

    for i, b in enumerate(boids):
        sx, sy, _ = screen_xy[i]
        if space == "3d":
            gx, gy, gz = int(b.x * inv), int(b.y * inv), int(b.z * inv)
            neighbor_offsets = [
                (gx + ox, gy + oy, gz + oz)
                for ox in (-1, 0, 1)
                for oy in (-1, 0, 1)
                for oz in (-1, 0, 1)
            ]
        else:
            gx, gy = int(b.x * inv), int(b.y * inv)
            neighbor_offsets = [(gx + ox, gy + oy) for ox in (-1, 0, 1) for oy in (-1, 0, 1)]

        sep_x = sep_y = 0.0
        align_vx = align_vy = 0.0
        coh_x = coh_y = 0.0
        n_flock = 0

        for key in neighbor_offsets:
            for j in buckets.get(key, ()):
                if j == i:
                    continue
                o = boids[j]
                dx, dy, dz = b.x - o.x, b.y - o.y, b.z - o.z
                d2 = dx * dx + dy * dy + (dz * dz if space == "3d" else 0.0)
                if d2 < 1e-6:
                    continue
                if d2 < sep_r2:
                    d = math.sqrt(d2)
                    f = (separation_radius - d) / separation_radius
                    sep_x += (dx / d) * f * f
                    sep_y += (dy / d) * f * f
                if d2 < per_r2 and n_flock < max_neighbors:
                    align_vx += o.vx
                    align_vy += o.vy
                    coh_x += o.x
                    coh_y += o.y
                    n_flock += 1

        crowd = max(0, n_flock - 5)
        sep_mul = 1.0 + crowd * 0.22
        ax = sep_x * separation_strength * sep_mul
        ay = sep_y * separation_strength * sep_mul

        if n_flock:
            n = n_flock
            ax += (align_vx / n - b.vx) * alignment_strength
            ay += (align_vy / n - b.vy) * alignment_strength
            coh_scale = cohesion_strength * max(0.0, 1.0 - crowd * 0.18)
            ax += (coh_x / n - b.x) * coh_scale
            ay += (coh_y / n - b.y) * coh_scale
            # push away from local crowd center when too many neighbors
            if crowd > 0 and anti_cluster_strength > 0:
                cx, cy = coh_x / n, coh_y / n
                dx, dy = b.x - cx, b.y - cy
                ln = math.hypot(dx, dy) or 1.0
                push = anti_cluster_strength * (0.5 + crowd * 0.15)
                ax += (dx / ln) * push
                ay += (dy / ln) * push

        wx, wy = _wander_force(b, wander_strength)
        fx, fy = _flow_force(
            b, time_s, flow_strength,
            mode=flow_mode, angle_deg=flow_angle, lane_wobble=flow_lane_wobble,
        )
        ax += wx + fx
        ay += wy + fy

        tax, tay = _text_avoidance(
            sx, sy, obstacles, text_rect,
            margin=avoid_margin, radius=avoid_radius, strength=avoid_strength,
            tangential=avoid_tangential,
        )
        if space == "3d":
            fz = max(40.0, focal + b.z)
            scale = focal / fz
            ax += tax / max(scale, 0.35)
            ay += tay / max(scale, 0.35)
        else:
            ax += tax
            ay += tay

        bax, bay, baz = _soft_boundary(
            b, w, h, space=space, mode=boundary_mode,
            depth_spread=depth_spread, edge=140.0,
        )
        ax += bax
        ay += bay

        b.vx = b.vx * drag + ax
        b.vy = b.vy * drag + ay
        if space == "3d":
            b.vz = b.vz * drag + baz + random.uniform(-0.03, 0.03)

        spd = math.hypot(b.vx, b.vy)
        if spd < min_speed:
            heading = math.atan2(b.vy, b.vx) if spd > 0.08 else b.wander_theta
            b.vx = math.cos(heading) * min_speed
            b.vy = math.sin(heading) * min_speed
            spd = min_speed
        if spd > max_speed > 0:
            b.vx = b.vx / spd * max_speed
            b.vy = b.vy / spd * max_speed
        if space == "3d":
            b.vz = max(-max_speed * 0.5, min(max_speed * 0.5, b.vz))

        b.angle = math.atan2(b.vy, b.vx)
        b.x += b.vx
        b.y += b.vy
        b.z += b.vz


def _draw_flock(
    target,
    boids: list[FlockBoid],
    *,
    w: int,
    h: int,
    space: str,
    focal: float,
    color: tuple,
    size: int,
    shape: str,
    rotation: str,
    alpha: int,
) -> None:
    projected: list[tuple[float, _ScreenBoid, float]] = []
    for b in boids:
        sx, sy, depth, scale = _project(b, w, h, space=space, focal=focal)
        projected.append((
            depth,
            _ScreenBoid(x=sx, y=sy, vx=b.vx, vy=b.vy, angle=b.angle),
            scale,
        ))
    projected.sort(key=lambda t: t[0], reverse=True)
    for _, sb, scale in projected:
        draw_size = max(1, int(size * scale))
        _draw_one_boid(
            target, sb,  # type: ignore[arg-type]
            shape=shape,
            size=draw_size,
            color=color,
            alpha=alpha,
            rotation=rotation,
        )


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # space
    space: str = "2d",
    focal_length: float = 420.0,
    depth_spread: float = 280.0,
    boundary_mode: str = "wrap",
    # text
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f4f4f4",
    text_box: bool = False,
    text_box_color: str = "#ffffff",
    text_box_alpha: int = 35,
    text_box_padding: int = 28,
    text_box_radius: int = 14,
    text_glow: bool = False,
    text_glow_layers: int = 4,
    text_glow_strength: int = 35,
    # text animation (transition2)
    in_duration: float = 1.2,
    out_duration: float = 1.0,
    text_in_effect: str = "pixelize",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    # flock
    boid_count: int = 420,
    boid_radius: int = 3,
    boid_shape: str = "triangle",
    boid_rotation: str = "velocity",
    boid_color: str | None = None,
    boid_alpha: int = 220,
    perception_radius: float = 85.0,
    separation_radius: float = 48.0,
    separation_strength: float = 3.4,
    alignment_strength: float = 0.32,
    cohesion_strength: float = 0.015,
    anti_cluster_strength: float = 0.55,
    max_speed: float = 6.0,
    min_speed: float = 2.2,
    drag: float = 0.965,
    wander_strength: float = 0.14,
    flow_strength: float = 0.07,
    flow_mode: str = "swirl",
    flow_angle: float = 0.0,
    flow_lane_wobble: float = 0.45,
    max_flock_neighbors: int = 8,
    text_avoid_radius: float = 72.0,
    text_avoid_strength: float = 1.15,
    text_avoid_margin: float = 50.0,
    text_avoid_tangential: float = 0.75,
    text_obstacle_step: int = 10,
    physics_substeps: int = 2,
    seed: int = 42,
    draw_boids_behind_text: bool = True,
    # background
    bg_color: str = "#0b0c10",
    bg_color2: str = "#15182a",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.35,
    show_ripples: bool = True,
    ripple_color: str = "#2a2d3a",
    ripple_count: int = 10,
    ripple_x: float | None = None,
    ripple_y: float | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    kwargs.pop("text_placeholder_box", None)

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "title"
        output = CACHE_DIR / f"transition4_{safe}_{stamp}.mp4"

    space = (space or "2d").lower()
    if space not in SPACES:
        space = "2d"
    boundary_mode = (boundary_mode or "wrap").lower()
    if boundary_mode not in BOUNDARY_MODES:
        boundary_mode = "wrap"
    flow_mode = (flow_mode or "swirl").lower()
    if flow_mode not in FLOW_MODES:
        flow_mode = "swirl"

    shape = (boid_shape or "circle").lower()
    if shape not in BOID_SHAPES:
        shape = "circle"
    rot = (boid_rotation or "velocity").lower()
    if rot not in BOID_ROTATIONS:
        rot = "velocity"

    pygame.init()
    surface = pygame.Surface((width, height))
    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    bc = _hex(boid_color or text_color)
    ric = _hex(ripple_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    ripple_cx = ripple_x * width if ripple_x is not None else text_cx
    ripple_cy = ripple_y * height if ripple_y is not None else text_cy

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_mask = _render_text_mask(text, font, tc)
    text_surf = _render_text_surface(text, font, tc)
    obstacles, text_rect = _build_text_obstacles(
        text_mask, text_cx, text_cy, step=text_obstacle_step,
    )
    if not obstacles:
        tw, th = text_mask.get_size()
        obstacles = [(text_cx, text_cy)]
        text_rect = (text_cx - tw / 2, text_cy - th / 2, text_cx + tw / 2, text_cy + th / 2)

    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    rng = random.Random(seed)
    boids = _spawn_flock(
        max(20, int(boid_count)), width, height,
        space=space, depth_spread=depth_spread, rng=rng,
    )

    total_frames = max(1, int(duration * fps))
    in_frames = max(1, int(in_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    out_start = max(0, total_frames - out_frames)
    substeps = max(1, int(physics_substeps))
    grad_cache: dict = {}

    def _draw_text_layer(frame: int) -> None:
        if text_box:
            _draw_text_box(
                surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                text_box_alpha, text_box_padding, text_box_radius,
            )
        if text_glow:
            _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)

        if frame < in_frames:
            prog = frame / in_frames
            _draw_text_effect(
                surface, text_surf, text_cx, text_cy, text_in_effect, prog,
                outward=False,
                typewriter_frames=typewriter_in,
                frame_idx=frame,
                glitch_seed=7,
                pixel_block_max=pixel_block_max,
            )
        elif frame >= out_start:
            prog = (frame - out_start) / max(1, out_frames)
            _draw_text_effect(
                surface, text_surf, text_cx, text_cy, text_out_effect, prog,
                outward=True,
                typewriter_frames=typewriter_out,
                frame_idx=frame,
                glitch_seed=99,
                pixel_block_max=pixel_block_max,
            )
        else:
            surface.blit(text_surf, text_surf.get_rect(center=(int(text_cx), int(text_cy))))

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            screen_xy: list[tuple[float, float, float]] = []
            for b in boids:
                sx, sy, depth, _ = _project(b, width, height, space=space, focal=focal_length)
                screen_xy.append((sx, sy, depth))

            for _ in range(substeps):
                _update_flock(
                    boids,
                    screen_xy,
                    w=width,
                    h=height,
                    space=space,
                    time_s=frame / max(fps, 1),
                    perception=perception_radius,
                    separation_radius=separation_radius,
                    separation_strength=separation_strength,
                    alignment_strength=alignment_strength,
                    cohesion_strength=cohesion_strength,
                    max_speed=max_speed,
                    min_speed=min_speed,
                    drag=drag,
                    wander_strength=wander_strength,
                    flow_strength=flow_strength,
                    flow_mode=flow_mode,
                    flow_angle=flow_angle,
                    flow_lane_wobble=flow_lane_wobble,
                    max_neighbors=max_flock_neighbors,
                    anti_cluster_strength=anti_cluster_strength,
                    obstacles=obstacles,
                    text_rect=text_rect,
                    avoid_margin=text_avoid_margin,
                    avoid_radius=text_avoid_radius,
                    avoid_strength=text_avoid_strength,
                    avoid_tangential=text_avoid_tangential,
                    boundary_mode=boundary_mode,
                    depth_spread=depth_spread,
                    focal=focal_length,
                )
                screen_xy = []
                for b in boids:
                    sx, sy, depth, _ = _project(b, width, height, space=space, focal=focal_length)
                    screen_xy.append((sx, sy, depth))

            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if show_ripples:
                _draw_ripples(surface, ripple_cx, ripple_cy, width, height, ric, ripple_count)
            if vignette > 0:
                _draw_vignette(surface, vignette)

            if draw_boids_behind_text:
                _draw_flock(
                    surface, boids,
                    w=width, h=height, space=space, focal=focal_length,
                    color=bc, size=boid_radius, shape=shape, rotation=rot, alpha=boid_alpha,
                )
                _draw_text_layer(frame)
            else:
                _draw_text_layer(frame)
                _draw_flock(
                    surface, boids,
                    w=width, h=height, space=space, focal=focal_length,
                    color=bc, size=boid_radius, shape=shape, rotation=rot, alpha=boid_alpha,
                )

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-framerate", str(fps),
                "-i", str(frames_dir / "frame_%06d.png"),
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "fast", "-crf", "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
