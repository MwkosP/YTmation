"""
Transition 3 — Boids form text, then leave screen
-------------------------------------------------
Each boid is assigned a pixel on the rendered text mask, flies in from off-screen,
settles into readable letter shapes, holds, then exits.

Phases: in_duration (assemble) → hold → out_duration (disperse)

Draw: boid_shape (circle, triangle, arrow, …), boid_rotation (velocity, none, toward_home)
— appearance only; physics / text formation unchanged.
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _draw_ripples,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
)

EXIT_MODES = ("radial", "random", "up", "down", "left", "right", "explode")


BOID_SHAPES = ("circle", "dot", "triangle", "arrow", "diamond", "square", "line", "cross")
BOID_ROTATIONS = ("velocity", "none", "toward_home")


@dataclass
class Boid:
    start_x: float
    start_y: float
    home_x: float
    home_y: float
    x: float
    y: float
    vx: float
    vy: float
    exit_x: float
    exit_y: float
    angle: float = 0.0


def _render_text_mask(text: str, font, color: tuple) -> "pygame.Surface":
    """Text on transparent background so we can sample letter pixels."""
    import pygame

    raw = font.render(text, True, color)
    mask = pygame.Surface(raw.get_size(), pygame.SRCALPHA)
    mask.blit(raw, (0, 0))
    return mask


def _collect_letter_points(
    mask,
    screen_cx: float,
    screen_cy: float,
    count: int,
    *,
    alpha_threshold: int = 48,
    sample_step: int = 1,
) -> list[tuple[float, float]]:
    """Every opaque pixel (subsampled) → screen coordinates centered on text."""
    tw, th = mask.get_size()
    left = screen_cx - tw / 2
    top = screen_cy - th / 2
    step = max(1, int(sample_step))
    points: list[tuple[float, float]] = []

    for y in range(0, th, step):
        for x in range(0, tw, step):
            if mask.get_at((x, y))[3] >= alpha_threshold:
                points.append((left + x + 0.5, top + y + 0.5))

    if not points:
        return [(screen_cx, screen_cy)]

    if len(points) > count:
        rng = random.Random(0)
        rng.shuffle(points)
        return points[:count]

    # fewer samples than boids: repeat exact letter pixels (no jitter blur)
    out = list(points)
    i = 0
    while len(out) < count:
        out.append(points[i % len(points)])
        i += 1
    return out


def _exit_target(
    hx: float,
    hy: float,
    cx: float,
    cy: float,
    w: float,
    h: float,
    mode: str,
    rng: random.Random,
) -> tuple[float, float]:
    margin = max(w, h) * 0.7
    mode = (mode or "radial").lower()
    if mode == "up":
        return hx, -margin
    if mode == "down":
        return hx, h + margin
    if mode == "left":
        return -margin, hy
    if mode == "right":
        return w + margin, hy
    if mode in ("random", "explode"):
        ang = rng.uniform(0, math.tau)
        dist = margin * (1.15 if mode == "explode" else 0.95)
        return hx + math.cos(ang) * dist, hy + math.sin(ang) * dist
    dx, dy = hx - cx, hy - cy
    ln = math.hypot(dx, dy) or 1.0
    return hx + dx / ln * margin, hy + dy / ln * margin


def _spawn_boids(
    homes: list[tuple[float, float]],
    w: int,
    h: int,
    text_cx: float,
    text_cy: float,
    exit_mode: str,
    rng: random.Random,
) -> list[Boid]:
    boids: list[Boid] = []
    for hx, hy in homes:
        edge = rng.randint(0, 3)
        if edge == 0:
            sx, sy = rng.uniform(0, w), -rng.uniform(40, h * 0.45)
        elif edge == 1:
            sx, sy = rng.uniform(0, w), h + rng.uniform(40, h * 0.45)
        elif edge == 2:
            sx, sy = -rng.uniform(40, w * 0.45), rng.uniform(0, h)
        else:
            sx, sy = w + rng.uniform(40, w * 0.45), rng.uniform(0, h)
        if rng.random() < 0.25:
            sx, sy = rng.uniform(0, w), rng.uniform(0, h)
        ex, ey = _exit_target(hx, hy, text_cx, text_cy, w, h, exit_mode, rng)
        boids.append(
            Boid(
                start_x=sx, start_y=sy,
                home_x=hx, home_y=hy,
                x=sx, y=sy,
                vx=rng.uniform(-1, 1), vy=rng.uniform(-1, 1),
                exit_x=ex, exit_y=ey,
            )
        )
    return boids


def _grid_buckets(boids: list[Boid], cell: float) -> dict[tuple[int, int], list[int]]:
    buckets: dict[tuple[int, int], list[int]] = {}
    inv = 1.0 / max(cell, 1.0)
    for i, b in enumerate(boids):
        key = (int(b.x * inv), int(b.y * inv))
        buckets.setdefault(key, []).append(i)
    return buckets


def _spring_toward(
    b: Boid, tx: float, ty: float, *, spring: float, damp: float, max_speed: float,
) -> None:
    dx, dy = tx - b.x, ty - b.y
    dist = math.hypot(dx, dy)
    if dist < 0.35:
        b.x, b.y = tx, ty
        b.vx *= 0.5
        b.vy *= 0.5
        return
    ax = dx * spring - b.vx * damp
    ay = dy * spring - b.vy * damp
    b.vx += ax
    b.vy += ay
    spd = math.hypot(b.vx, b.vy)
    if spd > max_speed > 0:
        b.vx = b.vx / spd * max_speed
        b.vy = b.vy / spd * max_speed
    if spd > 0.4:
        b.angle = math.atan2(b.vy, b.vx)
    b.x += b.vx
    b.y += b.vy


def _update_boids(
    boids: list[Boid],
    *,
    phase: str,
    form_t: float,
    disperse_t: float,
    max_speed: float,
    spring_assemble: float,
    spring_hold: float,
    spring_disperse: float,
    damp: float,
    separation_radius: float,
    separation_strength: float,
    wander_strength: float,
) -> None:
    sep_r2 = separation_radius * separation_radius
    buckets = _grid_buckets(boids, separation_radius)

    for i, b in enumerate(boids):
        if phase == "hold":
            b.x, b.y = b.home_x, b.home_y
            b.vx = b.vy = 0.0
            continue

        if phase == "assemble":
            t = _ease_out_cubic(form_t)
            tx = _lerp(b.start_x, b.home_x, t)
            ty = _lerp(b.start_y, b.home_y, t)
            cap = max_speed
            spring = spring_assemble
            # last part of assemble: pull tight onto letter pixels
            if form_t > 0.72:
                snap = (form_t - 0.72) / 0.28
                b.x = _lerp(b.x, b.home_x, snap * 0.35)
                b.y = _lerp(b.y, b.home_y, snap * 0.35)
        else:
            tx, ty = b.exit_x, b.exit_y
            cap = max_speed * 1.4
            spring = spring_disperse * _ease_in_cubic(disperse_t)

        _spring_toward(b, tx, ty, spring=spring, damp=damp, max_speed=cap)

        if phase == "assemble" and wander_strength > 0:
            b.vx += random.uniform(-wander_strength, wander_strength)
            b.vy += random.uniform(-wander_strength, wander_strength)

        # separation only when boids are close to their letter slot (keeps shape readable)
        dist_home = math.hypot(b.x - b.home_x, b.y - b.home_y)
        if phase != "assemble" or dist_home < separation_radius * 1.8:
            gx = int(b.x / max(separation_radius, 1.0))
            gy = int(b.y / max(separation_radius, 1.0))
            sep_x = sep_y = 0.0
            for ox in (-1, 0, 1):
                for oy in (-1, 0, 1):
                    for j in buckets.get((gx + ox, gy + oy), ()):
                        if j == i:
                            continue
                        o = boids[j]
                        dx, dy = b.x - o.x, b.y - o.y
                        d2 = dx * dx + dy * dy
                        if 0 < d2 < sep_r2:
                            f = separation_strength / d2
                            sep_x += dx * f
                            sep_y += dy * f
            b.vx += sep_x
            b.vy += sep_y


def _boid_heading(b: Boid, rotation: str) -> float:
    rotation = (rotation or "velocity").lower()
    if rotation == "toward_home":
        return math.atan2(b.home_y - b.y, b.home_x - b.x)
    if rotation == "none":
        return 0.0
    return b.angle


def _shape_points(shape: str, size: float) -> list[tuple[float, float]]:
    s = max(1.0, float(size))
    shape = (shape or "circle").lower()
    if shape in ("circle", "dot"):
        return []
    if shape == "triangle":
        return [(s * 1.6, 0.0), (-s * 0.9, s * 0.85), (-s * 0.9, -s * 0.85)]
    if shape == "arrow":
        return [
            (s * 2.0, 0.0),
            (-s * 1.1, s * 0.75),
            (-s * 0.5, 0.0),
            (-s * 1.1, -s * 0.75),
        ]
    if shape == "diamond":
        return [(0.0, -s * 1.2), (s, 0.0), (0.0, s * 1.2), (-s, 0.0)]
    if shape == "square":
        return [(-s, -s), (s, -s), (s, s), (-s, s)]
    if shape == "line":
        return [(-s * 1.4, 0.0), (s * 1.4, 0.0)]
    if shape == "cross":
        return [(-s * 1.1, 0.0), (s * 1.1, 0.0), (0.0, -s * 1.1), (0.0, s * 1.1)]
    return [(s * 1.6, 0.0), (-s * 0.9, s * 0.85), (-s * 0.9, -s * 0.85)]


def _rotate_points(points: list[tuple[float, float]], cx: float, cy: float, angle: float) -> list[tuple[int, int]]:
    ca, sa = math.cos(angle), math.sin(angle)
    out: list[tuple[int, int]] = []
    for px, py in points:
        rx = px * ca - py * sa
        ry = px * sa + py * ca
        out.append((int(cx + rx), int(cy + ry)))
    return out


def _draw_one_boid(
    target,
    b: Boid,
    *,
    shape: str,
    size: int,
    color: tuple,
    alpha: int,
    rotation: str,
) -> None:
    import pygame

    if size <= 0:
        return
    rgb = color[:3]
    shape = (shape or "circle").lower()
    cx, cy = b.x, b.y

    if shape in ("circle", "dot"):
        r = max(1, size if shape == "circle" else max(1, size - 1))
        if alpha >= 255:
            pygame.draw.circle(target, rgb, (int(cx), int(cy)), r)
        else:
            dot = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
            pygame.draw.circle(dot, (*rgb, alpha), (r + 1, r + 1), r)
            target.blit(dot, (int(cx) - r - 1, int(cy) - r - 1))
        return

    pts_local = _shape_points(shape, size)
    angle = _boid_heading(b, rotation)
    pts = _rotate_points(pts_local, cx, cy, angle)
    col = rgb if alpha >= 255 else (*rgb, alpha)

    if shape == "line":
        if len(pts) >= 2:
            pygame.draw.line(target, col, pts[0], pts[1], max(1, size // 2 + 1))
        return
    if shape == "cross" and len(pts) >= 4:
        pygame.draw.line(target, col, pts[0], pts[1], max(1, size // 2))
        pygame.draw.line(target, col, pts[2], pts[3], max(1, size // 2))
        return
    if len(pts) >= 3:
        pygame.draw.polygon(target, col, pts)


def _draw_boids(
    target,
    boids: list[Boid],
    color: tuple,
    size: int,
    *,
    shape: str = "circle",
    rotation: str = "velocity",
    alpha: int = 255,
) -> None:
    for b in boids:
        _draw_one_boid(
            target, b, shape=shape, size=size, color=color, alpha=alpha, rotation=rotation,
        )


def _boids_visible_alpha(frame: int, in_frames: int, out_start: int, out_frames: int) -> int:
    if frame < in_frames:
        return int(255 * _ease_out_cubic(frame / max(1, in_frames)))
    if frame >= out_start:
        t = (frame - out_start) / max(1, out_frames)
        return int(255 * (1.0 - _ease_in_cubic(t)))
    return 255


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # text
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f4f4f4",
    show_text_overlay: bool = False,
    # timing
    in_duration: float = 2.5,
    out_duration: float = 1.2,
    # boids
    boid_count: int = 3500,
    boid_radius: int = 2,
    boid_shape: str = "circle",
    boid_rotation: str = "velocity",
    boid_color: str | None = None,
    sample_step: int = 2,
    sample_alpha: int = 48,
    max_speed: float = 9.0,
    spring_assemble: float = 0.14,
    spring_hold: float = 0.2,
    spring_disperse: float = 0.12,
    damp: float = 0.88,
    separation_radius: float = 5.0,
    separation_strength: float = 0.35,
    wander_strength: float = 0.04,
    exit_mode: str = "radial",
    physics_substeps: int = 3,
    seed: int = 42,
    # background
    bg_color: str = "#0b0c10",
    bg_color2: str = "#15182a",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.35,
    show_ripples: bool = True,
    ripple_color: str = "#2a2d3a",
    ripple_count: int = 10,
    ripple_x: float | None = None,
    ripple_y: float | None = None,
    # legacy names from first version
    assemble_strength: float | None = None,
    disperse_strength: float | None = None,
    alignment_strength: float | None = None,
    cohesion_strength: float | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    if assemble_strength is not None:
        spring_assemble = 0.06 + assemble_strength * 0.04
    if disperse_strength is not None:
        spring_disperse = 0.06 + disperse_strength * 0.03

    kwargs.pop("text_placeholder_box", None)
    kwargs.pop("text_glow", None)

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "title"
        output = CACHE_DIR / f"transition3_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    tc = _hex(boid_color or text_color)
    ric = _hex(ripple_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    ripple_cx = ripple_x * width if ripple_x is not None else text_cx
    ripple_cy = ripple_y * height if ripple_y is not None else text_cy

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_mask = _render_text_mask(text, font, tc)
    rng = random.Random(seed)
    homes = _collect_letter_points(
        text_mask, text_cx, text_cy, max(100, int(boid_count)),
        alpha_threshold=sample_alpha,
        sample_step=sample_step,
    )
    boids = _spawn_boids(homes, width, height, text_cx, text_cy, exit_mode, rng)
    text_surf = text_mask  # for optional overlay

    shape = (boid_shape or "circle").lower()
    if shape not in BOID_SHAPES:
        shape = "circle"
    rot = (boid_rotation or "velocity").lower()
    if rot not in BOID_ROTATIONS:
        rot = "velocity"

    total_frames = max(1, int(duration * fps))
    in_frames = max(1, int(in_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    out_start = max(in_frames, total_frames - out_frames)

    grad_cache: dict = {}
    substeps = max(1, int(physics_substeps))

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            if frame < in_frames:
                phase = "assemble"
                form_t = frame / in_frames
                disperse_t = 0.0
            elif frame >= out_start:
                phase = "disperse"
                form_t = 1.0
                disperse_t = (frame - out_start) / max(1, out_frames)
            else:
                phase = "hold"
                form_t = 1.0
                disperse_t = 0.0

            for _ in range(substeps):
                _update_boids(
                    boids,
                    phase=phase,
                    form_t=form_t,
                    disperse_t=disperse_t,
                    max_speed=max_speed,
                    spring_assemble=spring_assemble,
                    spring_hold=spring_hold,
                    spring_disperse=spring_disperse,
                    damp=damp,
                    separation_radius=separation_radius,
                    separation_strength=separation_strength,
                    wander_strength=wander_strength if phase == "assemble" else 0.0,
                )

            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if show_ripples:
                _draw_ripples(surface, ripple_cx, ripple_cy, width, height, ric, ripple_count)
            if vignette > 0:
                _draw_vignette(surface, vignette)

            alpha = _boids_visible_alpha(frame, in_frames, out_start, out_frames)
            _draw_boids(
                surface, boids, tc, boid_radius,
                shape=shape, rotation=rot, alpha=alpha,
            )

            if show_text_overlay and phase == "hold":
                overlay_alpha = int(120 * min(1.0, (frame - in_frames) / max(1, fps * 0.3)))
                if overlay_alpha > 0:
                    ts = text_surf.copy()
                    ts.set_alpha(overlay_alpha)
                    surface.blit(ts, ts.get_rect(center=(int(text_cx), int(text_cy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-framerate", str(fps),
                "-i", str(frames_dir / "frame_%06d.png"),
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "fast", "-crf", "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
