"""
Transition 6 — Spotlight reveal
-------------------------------
Dark frame; a soft moving light sweeps in and reveals the title.
Text in/out uses transition2 effects; exit can dim or use text_out_effect.

spotlight_path: sweep | circle | pan | settle
"""

from __future__ import annotations

import math
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_ripples,
    _draw_text_box,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)

SPOTLIGHT_PATHS = ("sweep", "circle", "pan", "settle")


def _make_spot_gradient(diameter: int, softness: float) -> "object":
    """White center → dark edge (for BLEND_ADD on light map)."""
    import pygame

    d = max(64, int(diameter))
    surf = pygame.Surface((d, d), pygame.SRCALPHA)
    cx = cy = d / 2.0
    max_r = d / 2.0
    soft = max(0.08, min(0.95, softness))
    inner = max_r * (1.0 - soft) * 0.55

    for y in range(d):
        for x in range(d):
            dist = math.hypot(x - cx, y - cy)
            if dist <= inner:
                v = 255
            elif dist >= max_r:
                v = 0
            else:
                t = (dist - inner) / max(max_r - inner, 1.0)
                v = int(255 * (1.0 - t * t))
            surf.set_at((x, y), (v, v, v, 255))
    return surf


def _spotlight_position(
    path: str,
    t: float,
    w: int,
    h: int,
    text_cx: float,
    text_cy: float,
) -> tuple[float, float]:
    path = (path or "sweep").lower()
    t = max(0.0, min(1.0, t))

    if path == "circle":
        ang = t * math.tau * 1.1 - math.pi / 2
        r = min(w, h) * 0.32
        return text_cx + math.cos(ang) * r, text_cy + math.sin(ang) * r * 0.75
    if path == "pan":
        return _lerp(w * 0.12, w * 0.88, t), _lerp(h * 0.25, h * 0.72, t)
    if path == "settle":
        # start off-side, end on text
        return _lerp(-w * 0.15, text_cx, _ease_out_cubic(t)), _lerp(h * 0.35, text_cy, _ease_out_cubic(t))
    # sweep (default): left → right across text
    return _lerp(-w * 0.12, w * 1.12, t), text_cy


def _apply_spotlight(
    target,
    light_map,
    spot_grad,
    cx: float,
    cy: float,
    radius: float,
    ambient: int,
) -> None:
    import pygame

    w, h = target.get_size()
    light_map.fill((ambient, ambient, ambient))
    diam = max(32, int(radius * 2))
    spot = pygame.transform.smoothscale(spot_grad, (diam, diam))
    px = int(cx - radius)
    py = int(cy - radius)
    light_map.blit(spot, (px, py), special_flags=pygame.BLEND_ADD)
    target.blit(light_map, (0, 0), special_flags=pygame.BLEND_MULT)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # text
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f4f4f4",
    text_box: bool = False,
    text_box_color: str = "#ffffff",
    text_box_alpha: int = 35,
    text_box_padding: int = 28,
    text_box_radius: int = 14,
    text_glow: bool = False,
    text_glow_layers: int = 4,
    text_glow_strength: int = 35,
    # timing
    in_duration: float = 1.8,
    out_duration: float = 1.0,
    text_in_effect: str = "fade",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    # spotlight
    spotlight_path: str = "sweep",
    spotlight_radius: float = 480.0,
    spotlight_softness: float = 0.68,
    ambient_dark: int = 28,
    hold_ambient: int = 175,
    idle_motion: bool = True,
    dim_on_out: bool = True,
    # background
    bg_color: str = "#0b0c10",
    bg_color2: str = "#15182a",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.4,
    show_ripples: bool = False,
    ripple_color: str = "#2a2d3a",
    ripple_count: int = 10,
    ripple_x: float | None = None,
    ripple_y: float | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    kwargs.pop("text_placeholder_box", None)

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "title"
        output = CACHE_DIR / f"transition6_{safe}_{stamp}.mp4"

    path = (spotlight_path or "sweep").lower()
    if path not in SPOTLIGHT_PATHS:
        path = "sweep"

    pygame.init()
    surface = pygame.Surface((width, height))
    light_map = pygame.Surface((width, height))
    spot_grad = _make_spot_gradient(int(spotlight_radius * 2.2), spotlight_softness)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    ric = _hex(ripple_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    ripple_cx = ripple_x * width if ripple_x is not None else text_cx
    ripple_cy = ripple_y * height if ripple_y is not None else text_cy

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    total_frames = max(1, int(duration * fps))
    in_frames = max(1, int(in_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    out_start = max(in_frames, total_frames - out_frames)
    hold_end = out_start

    grad_cache: dict = {}
    max_r = spotlight_radius

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if show_ripples:
                _draw_ripples(surface, ripple_cx, ripple_cy, width, height, ric, ripple_count)

            if frame < in_frames:
                prog = frame / in_frames
                spot_t = _ease_out_cubic(prog)
                scx, scy = _spotlight_position(path, spot_t, width, height, text_cx, text_cy)
                radius = _lerp(max_r * 0.25, max_r, spot_t)
                ambient = int(_lerp(ambient_dark, hold_ambient, spot_t))

                if text_box:
                    _draw_text_box(
                        surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                        text_box_alpha, text_box_padding, text_box_radius,
                    )
                if text_glow:
                    _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                _draw_text_effect(
                    surface, text_surf, text_cx, text_cy, text_in_effect, prog,
                    outward=False,
                    typewriter_frames=typewriter_in,
                    frame_idx=frame,
                    glitch_seed=7,
                    pixel_block_max=pixel_block_max,
                )
            elif frame >= out_start:
                out_prog = (frame - out_start) / max(1, out_frames)
                scx, scy = text_cx, text_cy
                if dim_on_out:
                    radius = _lerp(max_r, max_r * 0.2, _ease_in_cubic(out_prog))
                    ambient = int(_lerp(hold_ambient, ambient_dark, _ease_in_cubic(out_prog)))
                else:
                    radius = max_r
                    ambient = hold_ambient

                if text_box:
                    _draw_text_box(
                        surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                        text_box_alpha, text_box_padding, text_box_radius,
                    )
                if text_glow:
                    _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                _draw_text_effect(
                    surface, text_surf, text_cx, text_cy, text_out_effect, out_prog,
                    outward=True,
                    typewriter_frames=typewriter_out,
                    frame_idx=frame,
                    glitch_seed=99,
                    pixel_block_max=pixel_block_max,
                )
            else:
                hold_prog = (frame - in_frames) / max(1, hold_end - in_frames)
                if idle_motion:
                    scx, scy = _spotlight_position(
                        "circle", hold_prog * 0.35 + 0.1, width, height, text_cx, text_cy,
                    )
                else:
                    scx, scy = text_cx, text_cy
                radius = max_r
                ambient = hold_ambient

                if text_box:
                    _draw_text_box(
                        surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                        text_box_alpha, text_box_padding, text_box_radius,
                    )
                if text_glow:
                    _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                surface.blit(text_surf, text_surf.get_rect(center=(int(text_cx), int(text_cy))))

            _apply_spotlight(surface, light_map, spot_grad, scx, scy, radius, ambient)
            if vignette > 0:
                _draw_vignette(surface, vignette * 0.85)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-framerate", str(fps),
                "-i", str(frames_dir / f"frame_%06d.png"),
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "fast", "-crf", "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
