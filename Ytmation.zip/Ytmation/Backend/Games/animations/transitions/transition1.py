"""
Transition 1 — Ramp fountain → shatter text
-----------------------------------------
Balls roll U-shaped guides into centered (configurable) title text.

Layout / style params (all optional on run()):
  Text:     text, text_x, text_y (0–1, 0.5=center), font_size, font_name, text_color
  Ramps:    ramp_outer_x, ramp_top_y, ramp_bowl_y, ramp_size, text_margin,
            ramp_color, ramp_line_width, ramp_glow, ramp_glow_layers, ramp_glow_strength,
            show_ramps
  Background: bg_color, bg_color2, bg_gradient_dir, show_ripples,
            ripple_color, ripple_count, ripple_x, ripple_y
  Balls:    ball_radius, spawn_rate, ball_speed, max_ball_speed,
            start_speed, gravity, roll_friction, fly_drag, heat_colors
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games" / "transitions"

HEAT_COLORS = [
    (72, 210, 88),
    (238, 228, 58),
    (255, 148, 38),
    (255, 58, 48),
]


def _hex(h: str) -> tuple[int, int, int]:
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * max(0.0, min(1.0, t))


def _lerp_color(c1, c2, t: float):
    t = max(0.0, min(1.0, t))
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def _norm_xy(nx: float, ny: float, w: float, h: float) -> tuple[float, float]:
    """Normalized 0–1 coords; (0.5, 0.5) = screen center."""
    return nx * w, ny * h


def _heat_color(
    x: float, y: float, cx: float, cy: float, w: float, h: float, palette: list[tuple],
) -> tuple:
    dist = math.hypot(x - cx, y - cy)
    max_d = math.hypot(w * 0.42, h * 0.38)
    t = 1.0 - min(1.0, dist / max(max_d, 1.0))
    if len(palette) < 2:
        return palette[0] if palette else (255, 255, 255)
    if len(palette) == 2:
        return _lerp_color(palette[0], palette[1], t)
    if t < 0.33:
        return _lerp_color(palette[0], palette[1], t / 0.33)
    if t < 0.66:
        return _lerp_color(palette[1], palette[2], (t - 0.33) / 0.33)
    return _lerp_color(palette[2], palette[3], (t - 0.66) / 0.34)


def _parse_heat_colors(colors: list | None) -> list[tuple]:
    if not colors:
        return list(HEAT_COLORS)
    return [_hex(c) if isinstance(c, str) else tuple(c[:3]) for c in colors]


def _gradient_surface(w: int, h: int, c1, c2, direction: str = "vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "radial":
        cx, cy = w // 2, h // 2
        max_r = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max(max_r, 1))
                surf.set_at((x, y), _lerp_color(c1, c2, t))
        return surf
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            col = _lerp_color(c1, c2, t)
            pygame.draw.line(surf, col, (x, 0), (x, h))
        return surf
    for y in range(h):
        t = y / max(1, h - 1)
        pygame.draw.line(surf, _lerp_color(c1, c2, t), (0, y), (w, y))
    return surf


def _draw_background(
    surf,
    w: int,
    h: int,
    bg1,
    bg2,
    gradient_dir: str | None,
    grad_cache: dict,
) -> None:
    if bg2 and gradient_dir and gradient_dir != "none":
        key = (bg1, bg2, gradient_dir, w, h)
        if key not in grad_cache:
            grad_cache[key] = _gradient_surface(w, h, bg1, bg2, gradient_dir)
        surf.blit(grad_cache[key], (0, 0))
    else:
        surf.fill(bg1)


def _cubic(p0, p1, p2, p3, t: float) -> tuple[float, float]:
    u = 1 - t
    x = u**3 * p0[0] + 3 * u**2 * t * p1[0] + 3 * u * t**2 * p2[0] + t**3 * p3[0]
    y = u**3 * p0[1] + 3 * u**2 * t * p1[1] + 3 * u * t**2 * p2[1] + t**3 * p3[1]
    return x, y


@dataclass
class GuidePath:
    points: list[tuple[float, float]]
    cum_len: list[float]
    total_len: float
    side: str

    def at(self, s: float) -> tuple[float, float, float, float]:
        if not self.points:
            return 0.0, 0.0, 1.0, 0.0
        s = max(0.0, min(1.0, s))
        target = s * self.total_len
        i = 0
        while i < len(self.cum_len) - 1 and self.cum_len[i + 1] < target:
            i += 1
        seg_len = self.cum_len[i + 1] - self.cum_len[i]
        t = (target - self.cum_len[i]) / seg_len if seg_len > 1e-6 else 0.0
        x0, y0 = self.points[i]
        x1, y1 = self.points[i + 1]
        x = _lerp(x0, x1, t)
        y = _lerp(y0, y1, t)
        tx, ty = x1 - x0, y1 - y0
        mag = math.hypot(tx, ty) or 1.0
        return x, y, tx / mag, ty / mag


def _build_guide_path(
    side: str,
    w: float,
    h: float,
    target_x: float,
    target_y: float,
    *,
    outer_x: float = 0.028,
    top_y: float = 0.10,
    mid_y: float = 0.50,
    bowl_y: float = 0.76,
    ramp_size: float = 1.0,
) -> GuidePath:
    """
    Compact U on the far edge — lip ends at (target_x, target_y) outside the text.
    outer_x: inset from screen edge (fraction of width).
    ramp_size: scales horizontal reach of the curve (1.0 = default).
    """
    rs = max(0.5, min(1.5, ramp_size))
    ty, my, by = top_y * h, mid_y * h, bowl_y * h
    sign = 1.0 if side == "left" else -1.0
    ox = outer_x * w if side == "left" else (1.0 - outer_x) * w

    def px(frac: float) -> float:
        """Horizontal fraction from outer edge toward center, scaled."""
        return ox + sign * frac * w * rs

    segs = [
        ((ox, ty), (ox, (ty + my) / 2), (ox, my), (px(0.032), by * 0.86)),
        ((px(0.032), by * 0.86), (px(0.072), by), (px(0.112), by * 0.97), (px(0.142), by * 0.84)),
        ((px(0.142), by * 0.84), (px(0.172), by * 0.73), (px(0.202), my), (target_x, target_y)),
    ]

    pts: list[tuple[float, float]] = []
    for p0, p1, p2, p3 in segs:
        for i in range(20):
            pts.append(_cubic(p0, p1, p2, p3, i / 19))
    pts.append(segs[-1][3])

    cum = [0.0]
    for i in range(1, len(pts)):
        cum.append(cum[-1] + math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]))

    return GuidePath(pts, cum, cum[-1], side)


def _draw_guide(
    surf,
    path: GuidePath,
    color: tuple,
    width: int = 1,
    glow: bool = False,
    glow_layers: int = 4,
    glow_strength: int = 55,
    dashed: bool = False,
) -> None:
    import pygame

    if len(path.points) < 2:
        return
    pts = [(int(x), int(y)) for x, y in path.points]

    if glow and glow_layers > 0:
        for layer in range(glow_layers, 0, -1):
            alpha = max(8, glow_strength // layer)
            gw = width + layer * 2
            glow_surf = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
            if dashed:
                for i in range(0, len(pts) - 1, 2):
                    pygame.draw.line(
                        glow_surf, (*color, alpha), pts[i], pts[i + 1], gw,
                    )
            else:
                pygame.draw.lines(glow_surf, (*color, alpha), False, pts, gw)
            surf.blit(glow_surf, (0, 0))

    if dashed:
        for i in range(0, len(pts) - 1, 2):
            pygame.draw.aalines(surf, color, False, [pts[i], pts[i + 1]])
            if width > 1:
                pygame.draw.line(surf, color, pts[i], pts[i + 1], width)
    else:
        pygame.draw.aalines(surf, color, False, pts)
        if width > 1:
            pygame.draw.lines(surf, color, False, pts, width)


def _draw_ripples(surf, cx, cy, w, h, color, count: int):
    import pygame

    for i in range(1, count + 1):
        r = int(min(w, h) * 0.075 * i)
        alpha = max(6, 38 - i * 2)
        ring = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
        pygame.draw.circle(ring, (*color[:3], alpha), (r + 1, r + 1), r, 1)
        surf.blit(ring, (int(cx - r - 1), int(cy - r - 1)))


def _build_letter_pieces(
    text: str,
    font,
    cx: float,
    cy: float,
    color: tuple,
) -> tuple[list[dict], float, float]:
    import pygame

    space_w = font.size(" ")[0]
    glyphs: list = []
    for ch in text:
        if ch == " ":
            glyphs.append(None)
        else:
            glyphs.append(font.render(ch, True, color))

    widths = [g.get_width() if g else space_w for g in glyphs]
    heights = [g.get_height() if g else 0 for g in glyphs if g]
    total_w = sum(widths)
    max_h = max(heights) if heights else font.get_height()

    x = cx - total_w / 2
    pieces: list[dict] = []
    for ch, g in zip(text, glyphs):
        if g is None:
            x += space_w
            continue
        py = cy - g.get_height() / 2
        pieces.append({
            "surf": g,
            "char": ch,
            "x": float(x),
            "y": float(py),
            "vx": 0.0,
            "vy": 0.0,
            "angle": 0.0,
            "spin": 0.0,
            "broken": False,
            "w": g.get_width(),
            "h": g.get_height(),
        })
        x += g.get_width()

    return pieces, total_w, max_h


def _spawn_debris(piece: dict, debris: list[dict], count: int = 6) -> None:
    """Tiny shards when a letter breaks."""
    import pygame

    col = (240, 240, 240)
    for _ in range(count):
        debris.append({
            "x": piece["x"] + random.uniform(0, piece["w"]),
            "y": piece["y"] + random.uniform(0, piece["h"]),
            "vx": random.uniform(-4, 4) + piece.get("vx", 0) * 0.2,
            "vy": random.uniform(-5, 2) + piece.get("vy", 0) * 0.2,
            "r": random.randint(2, 4),
            "life": random.randint(18, 40),
            "color": col,
        })


def _piece_rect(piece: dict) -> tuple[float, float, float, float]:
    return piece["x"], piece["y"], piece["w"], piece["h"]


def _collide_ball_piece(ball: dict, piece: dict, debris: list[dict], impulse: float, bounce: float) -> bool:
    px, py, pw, ph = _piece_rect(piece)
    br = ball["r"]
    cx = max(px + br, min(px + pw - br, ball["x"]))
    cy = max(py + br, min(py + ph - br, ball["y"]))
    dx, dy = ball["x"] - cx, ball["y"] - cy
    dist = math.hypot(dx, dy)
    if dist >= br or dist < 1e-6:
        return False

    nx, ny = dx / dist, dy / dist
    ball["x"] = cx + nx * br
    ball["y"] = cy + ny * br
    dot = ball["vx"] * nx + ball["vy"] * ny
    if dot < 0:
        ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
        ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce

    if not piece["broken"]:
        piece["broken"] = True
        piece["vx"] = ball["vx"] * impulse + random.uniform(-2, 2)
        piece["vy"] = ball["vy"] * impulse + random.uniform(-3, 1)
        piece["spin"] = random.uniform(-10, 10)
        _spawn_debris(piece, debris)
    else:
        piece["vx"] += ball["vx"] * impulse * 0.15
        piece["vy"] += ball["vy"] * impulse * 0.15
        piece["spin"] += random.uniform(-2, 2)

    return True


def _update_piece(piece: dict, gravity: float) -> None:
    if not piece["broken"]:
        return
    piece["vy"] += gravity * 0.55
    piece["vx"] *= 0.985
    piece["vy"] *= 0.985
    piece["x"] += piece["vx"]
    piece["y"] += piece["vy"]
    piece["angle"] += piece["spin"]
    piece["spin"] *= 0.99


def _draw_piece(surf, piece: dict) -> None:
    import pygame

    img = piece["surf"]
    if abs(piece["angle"]) > 0.5:
        img = pygame.transform.rotate(img, piece["angle"])
    rect = img.get_rect(center=(int(piece["x"] + piece["w"] / 2), int(piece["y"] + piece["h"] / 2)))
    surf.blit(img, rect)


def _spawn_ball(side: str, path: GuidePath, radius: int, start_speed: float) -> dict:
    x, y, tx, ty = path.at(0.0)
    return {
        "x": x,
        "y": y,
        "vx": tx * start_speed,
        "vy": ty * start_speed,
        "r": radius,
        "side": side,
        "phase": "chute",
        "s": 0.0,
    }


def _cap_speed(b: dict, max_speed: float | None) -> None:
    if max_speed is None or max_speed <= 0:
        return
    sp = math.hypot(b["vx"], b["vy"])
    if sp > max_speed:
        s = max_speed / sp
        b["vx"] *= s
        b["vy"] *= s


def _advance_chute(
    b: dict,
    path: GuidePath,
    gravity: float,
    roll_friction: float,
    max_speed: float | None,
) -> None:
    """Roll along the U with gravity; at the lip, keep velocity — no shot impulse."""
    if b["phase"] != "chute":
        return

    _, _, tx, ty = path.at(min(1.0, b["s"]))
    b["vy"] += gravity

    speed = b["vx"] * tx + b["vy"] * ty
    if speed < 0:
        speed = 0.0
    speed *= roll_friction

    b["vx"] = tx * speed
    b["vy"] = ty * speed
    _cap_speed(b, max_speed)
    b["s"] += speed / max(path.total_len, 1.0)

    if b["s"] >= 1.0:
        b["s"] = 1.0
        x, y, tx, ty = path.at(1.0)
        b["x"] = x
        b["y"] = y
        b["phase"] = "fly"
        return

    x, y, _, _ = path.at(b["s"])
    b["x"] = x
    b["y"] = y


def run(
    duration: int = 8,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # ── text (normalized 0–1; 0.5 = center) ─────────────────────────────────
    text: str = "First Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f5f5f5",
    # ── ramps / guides ──────────────────────────────────────────────────────
    ramp_outer_x: float = 0.028,
    ramp_top_y: float = 0.10,
    ramp_mid_y: float = 0.50,
    ramp_bowl_y: float = 0.76,
    ramp_size: float = 1.0,
    text_margin: float | None = None,
    ramp_color: str = "#6e6e6e",
    ramp_line_width: int = 1,
    ramp_glow: bool = False,
    ramp_glow_layers: int = 5,
    ramp_glow_strength: int = 60,
    ramp_dash: bool = False,
    show_ramps: bool = True,
    # ── background ──────────────────────────────────────────────────────────
    bg_color: str = "#121212",
    bg_color2: str | None = None,
    bg_gradient_dir: str = "none",
    show_ripples: bool = True,
    ripple_color: str = "#2a2a2a",
    ripple_count: int = 12,
    ripple_x: float | None = None,
    ripple_y: float | None = None,
    # ── balls / physics ───────────────────────────────────────────────────────
    spawn_rate: int = 2,
    balls_per_spawn: int = 3,
    max_balls: int = 500,
    ball_radius: int = 6,
    heat_colors: list | None = None,
    ball_speed: float = 1.0,
    max_ball_speed: float | None = 22.0,
    start_speed: float = 0.8,
    roll_friction: float = 0.998,
    gravity: float = 0.32,
    fly_drag: float = 0.996,
    text_hit_impulse: float = 0.42,
    text_bounce: float = 0.5,
    shard_gravity: float = 0.18,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
    )

    kwargs.pop("launch_speed", None)
    kwargs.pop("chute_speed", None)

    speed_scale = max(0.1, float(ball_speed))
    start_speed *= speed_scale
    gravity *= speed_scale

    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "title"
        output = CACHE_DIR / f"transition1_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    rc = _hex(ramp_color)
    tc = _hex(text_color)
    ric = _hex(ripple_color)
    palette = _parse_heat_colors(heat_colors)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    ripple_cx = ripple_x * width if ripple_x is not None else text_cx
    ripple_cy = ripple_y * height if ripple_y is not None else text_cy

    if font_size is None:
        font_size = max(52, int(min(width, height) * 0.095))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    letters, text_w, text_h = _build_letter_pieces(text, font, text_cx, text_cy, tc)
    margin = text_margin if text_margin is not None else width * 0.055
    left_aim = (text_cx - text_w / 2 - margin, text_cy)
    right_aim = (text_cx + text_w / 2 + margin, text_cy)

    ramp_kw = dict(
        outer_x=ramp_outer_x,
        top_y=ramp_top_y,
        mid_y=ramp_mid_y,
        bowl_y=ramp_bowl_y,
        ramp_size=ramp_size,
    )
    left_path = _build_guide_path("left", width, height, left_aim[0], left_aim[1], **ramp_kw)
    right_path = _build_guide_path("right", width, height, right_aim[0], right_aim[1], **ramp_kw)

    balls: list[dict] = []
    debris: list[dict] = []
    grad_cache: dict = {}
    total_frames = max(1, int(duration * fps))

    guide_kw = dict(
        width=ramp_line_width,
        glow=ramp_glow,
        glow_layers=ramp_glow_layers,
        glow_strength=ramp_glow_strength,
        dashed=ramp_dash,
    )

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if show_ripples:
                _draw_ripples(surface, ripple_cx, ripple_cy, width, height, ric, ripple_count)

            if show_ramps:
                _draw_guide(surface, left_path, rc, **guide_kw)
                _draw_guide(surface, right_path, rc, **guide_kw)

            if frame % max(1, spawn_rate) == 0:
                for _ in range(balls_per_spawn):
                    if len(balls) < max_balls:
                        balls.append(_spawn_ball("left", left_path, ball_radius, start_speed))
                    if len(balls) < max_balls:
                        balls.append(_spawn_ball("right", right_path, ball_radius, start_speed))

            t_sec = frame / fps

            for piece in letters:
                _update_piece(piece, shard_gravity)

            for d in debris:
                d["vy"] += shard_gravity
                d["x"] += d["vx"]
                d["y"] += d["vy"]
                d["life"] -= 1
            debris = [d for d in debris if d["life"] > 0]

            alive = []
            for b in balls:
                path = left_path if b["side"] == "left" else right_path

                if b["phase"] == "chute":
                    _advance_chute(b, path, gravity, roll_friction, max_ball_speed)
                else:
                    b["vy"] += gravity
                    b["vx"] *= fly_drag
                    b["vy"] *= fly_drag
                    _cap_speed(b, max_ball_speed)
                    b["x"] += b["vx"]
                    b["y"] += b["vy"]

                    for piece in letters:
                        if _collide_ball_piece(b, piece, debris, text_hit_impulse, text_bounce):
                            log_wall_from_ball(audio, t_sec, b)

                if -30 <= b["x"] <= width + 30 and -30 <= b["y"] <= height + 30:
                    alive.append(b)

            balls = alive[:max_balls]

            for piece in letters:
                _draw_piece(surface, piece)

            for d in debris:
                pygame.draw.circle(
                    surface, d["color"], (int(d["x"]), int(d["y"])), d["r"],
                )

            for b in balls:
                col = _heat_color(b["x"], b["y"], text_cx, text_cy, width, height, palette)
                pygame.draw.circle(surface, col, (int(b["x"]), int(b["y"])), b["r"])

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                broken = sum(1 for p in letters if p["broken"])
                print(
                    f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%) "
                    f"| balls: {len(balls)} | broken letters: {broken}/{len(letters)}"
                )

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-framerate", str(fps),
                "-i", str(frames_dir / "frame_%06d.png"),
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "fast", "-crf", "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration=float(duration))
    print(f"   Done → {output}")
    return output
