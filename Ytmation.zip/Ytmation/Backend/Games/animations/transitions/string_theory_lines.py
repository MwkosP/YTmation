"""Shared vibrating orbital lines for transitions 16 & 17."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass


@dataclass
class TheoryString:
    rx: float
    ry: float
    tilt: float
    phase: float
    wave_freq: float
    wave_amp: float
    spin: float
    alpha: int


def spawn_strings(
    count: int,
    cx: float,
    cy: float,
    base_radius: float,
    rng: random.Random,
) -> list[TheoryString]:
    strings: list[TheoryString] = []
    for i in range(count):
        t = i / max(count, 1)
        r = base_radius * (0.45 + t * 0.75) + rng.uniform(-30, 30)
        strings.append(
            TheoryString(
                rx=r * rng.uniform(0.85, 1.15),
                ry=r * rng.uniform(0.75, 1.05),
                tilt=rng.uniform(0, math.tau),
                phase=rng.uniform(0, math.tau),
                wave_freq=rng.uniform(2.0, 6.0),
                wave_amp=rng.uniform(6.0, 22.0),
                spin=rng.uniform(-0.25, 0.25),
                alpha=rng.randint(40, 110),
            )
        )
    return strings


def draw_strings(
    target,
    cx: float,
    cy: float,
    strings: list[TheoryString],
    time_s: float,
    color: tuple,
    *,
    line_width: int = 1,
    segments: int = 96,
    alpha_mul: float = 1.0,
    orbit_mul: float = 1.0,
) -> None:
    import pygame

    for s in strings:
        a = int(max(0, min(255, s.alpha * alpha_mul)))
        if a <= 0:
            continue
        col = (*color[:3], a)
        pts: list[tuple[int, int]] = []
        for i in range(segments + 1):
            u = (i / segments) * math.tau
            wob = math.sin(u * s.wave_freq + time_s * 3.2 + s.phase) * s.wave_amp
            wob2 = math.cos(u * s.wave_freq * 0.5 + time_s * 2.0) * s.wave_amp * 0.35
            ang = u + s.tilt + time_s * s.spin * orbit_mul
            rx = s.rx + wob
            ry = s.ry + wob2
            x = cx + math.cos(ang) * rx
            y = cy + math.sin(ang) * ry
            pts.append((int(x), int(y)))
        if len(pts) >= 2:
            pygame.draw.aalines(target, col, False, pts, line_width)
