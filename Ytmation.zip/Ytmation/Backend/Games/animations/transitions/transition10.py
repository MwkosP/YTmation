"""
Transition 10 — Ink bleed reveal
--------------------------------
Organic ink blots spread across the center; title emerges through the wash.
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_text_box,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


@dataclass
class InkBlot:
    x: float
    y: float
    growth: float
    max_r: float
    phase: float


def _stamp_ink(layer, x: float, y: float, r: float, color: tuple, rng: random.Random) -> None:
    import pygame

    r = max(4, int(r))
    pygame.draw.circle(layer, color, (int(x), int(y)), r)
    for _ in range(5):
        ang = rng.uniform(0, math.tau)
        d = rng.uniform(0.2, 0.75) * r
        br = max(2, int(r * rng.uniform(0.2, 0.5)))
        pygame.draw.circle(
            layer, color,
            (int(x + math.cos(ang) * d), int(y + math.sin(ang) * d)),
            br,
        )


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#1a1410",
    text_box: bool = False,
    text_glow: bool = False,
    bleed_duration: float = 2.0,
    text_reveal_duration: float = 1.0,
    out_duration: float = 0.8,
    text_in_effect: str = "fade",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    ink_color: str = "#2a8fa8",
    ink_color2: str = "#4ec4d8",
    blot_count: int = 9,
    bleed_radius: float = 580.0,
    paper_color: str = "#e8e4dc",
    paper_show: float = 0.92,
    seed: int = 42,
    bg_color: str = "#1a1814",
    bg_color2: str = "#2a2620",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.28,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "ink"
        output = CACHE_DIR / f"transition10_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    ink_layer = pygame.Surface((width, height), pygame.SRCALPHA)
    paper_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    ic1, ic2 = _hex(ink_color), _hex(ink_color2)
    paper = _hex(paper_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    rng = random.Random(seed)
    blots: list[InkBlot] = []
    for i in range(blot_count):
        ang = (i / blot_count) * math.tau + rng.uniform(-0.2, 0.2)
        dist = rng.uniform(0, bleed_radius * 0.35)
        blots.append(
            InkBlot(
                x=text_cx + math.cos(ang) * dist,
                y=text_cy + math.sin(ang) * dist,
                growth=rng.uniform(0.85, 1.15),
                max_r=bleed_radius * rng.uniform(0.45, 1.0),
                phase=rng.uniform(0, math.tau),
            )
        )

    total_frames = max(1, int(duration * fps))
    bleed_frames = max(1, int(bleed_duration * fps))
    reveal_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    reveal_start = int(bleed_frames * 0.55)
    out_start = max(reveal_start + reveal_frames, total_frames - out_frames)

    grad_cache: dict = {}
    ink_rgba = (*ic1, 210)
    ink2_rgba = (*ic2, 180)

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            if frame < out_start:
                prog = min(1.0, frame / bleed_frames)
                grow = _ease_out_cubic(prog)
                ink_layer.fill((0, 0, 0, 0))
                paper_layer.fill((0, 0, 0, 0))
                for b in blots:
                    r = b.max_r * grow * b.growth * (0.9 + 0.1 * math.sin(frame * 0.08 + b.phase))
                    c = ink_rgba if rng.random() > 0.4 else ink2_rgba
                    _stamp_ink(ink_layer, b.x, b.y, r * 0.35, c, rng)
                    _stamp_ink(ink_layer, b.x, b.y, r, c, rng)
                pr = int(255 * paper_show * grow)
                paper_layer.fill((*paper, pr))
                surface.blit(paper_layer, (0, 0))
                surface.blit(ink_layer, (0, 0))

            if frame >= reveal_start:
                if frame < out_start:
                    rev = min(1.0, (frame - reveal_start) / reveal_frames)
                    if text_glow:
                        _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, 3, 25)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_in_effect, rev,
                        outward=False, typewriter_frames=typewriter_in, frame_idx=frame,
                        glitch_seed=3, pixel_block_max=pixel_block_max,
                    )
                else:
                    out_t = (frame - out_start) / max(1, out_frames)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_out_effect, out_t,
                        outward=True, typewriter_frames=typewriter_out, frame_idx=frame,
                        glitch_seed=9, pixel_block_max=pixel_block_max,
                    )

            if vignette > 0:
                _draw_vignette(surface, vignette)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
