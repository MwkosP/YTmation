"""
Transition 24 — Electric crackle
--------------------------------
Repeated arcs around the title; buzzing energy, flickering electric glow.
"""

from __future__ import annotations

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.lightning_fx import draw_bolt, lightning_path
from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _norm_xy,
    _render_text_surface,
)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#e8f4ff",
    text_reveal_duration: float = 0.8,
    out_duration: float = 0.7,
    arc_count: int = 5,
    strike_rate: float = 0.12,
    bolt_color: str = "#7ec8ff",
    core_color: str = "#ffffff",
    glow_pulse: bool = True,
    flash_on_strike: int = 80,
    bolt_displace: float = 55.0,
    orbit_radius: float = 280.0,
    seed: int = 24,
    bg_color: str = "#05060c",
    bg_color2: str = "#0c1428",
    bg_gradient_dir: str = "radial",
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "arc"
        output = CACHE_DIR / f"transition24_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    bolt_layer = pygame.Surface((width, height), pygame.SRCALPHA)
    flash = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, bc, cc = _hex(text_color), _hex(bolt_color), _hex(core_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(54, int(min(width, height) * 0.1))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    tw, th = text_surf.get_size()
    rng = random.Random(seed)

    total_frames = max(1, int(duration * fps))
    rev_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    rev_start = int(fps * 0.2)
    out_start = max(rev_start + rev_frames, total_frames - out_frames)

    active_bolts: list[tuple[list[tuple[float, float]], int]] = []
    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            if rng.random() < strike_rate:
                ang = rng.uniform(0, math.tau)
                ex = text_cx + math.cos(ang) * orbit_radius * rng.uniform(0.7, 1.1)
                ey = text_cy + math.sin(ang) * orbit_radius * rng.uniform(0.6, 1.0)
                inner = rng.uniform(0.25, 0.55)
                ix = text_cx + (ex - text_cx) * inner
                iy = text_cy + (ey - text_cy) * inner
                pts = lightning_path(ex, ey, ix, iy, rng, displace=bolt_displace, depth=7, branch_chance=0.35)
                active_bolts.append((pts, 8))

            bolt_layer.fill((0, 0, 0, 0))
            flash_a = 0
            still: list[tuple[list[tuple[float, float]], int]] = []
            for pts, life in active_bolts:
                if life > 0:
                    alpha = min(255, 80 + life * 22)
                    draw_bolt(bolt_layer, pts, (*bc, alpha), width=2, glow=True)
                    if life >= 6:
                        flash_a = max(flash_a, flash_on_strike)
                    still.append((pts, life - 1))
            active_bolts = still

            if flash_a > 0:
                flash.fill((200, 230, 255, flash_a))
                surface.blit(flash, (0, 0))
            surface.blit(bolt_layer, (0, 0))

            if frame >= rev_start:
                if frame < out_start:
                    rt = min(1.0, (frame - rev_start) / rev_frames)
                    ta = int(255 * _ease_out_cubic(rt))
                else:
                    ot = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                    ta = int(255 * (1.0 - ot))

                if glow_pulse and ta > 0:
                    pulse = 0.65 + 0.35 * math.sin(frame * 0.35)
                    glow = pygame.Surface((tw + 40, th + 40), pygame.SRCALPHA)
                    pygame.draw.ellipse(glow, (*bc, int(50 * pulse)), glow.get_rect())
                    surface.blit(glow, glow.get_rect(center=(int(text_cx), int(text_cy))))

                if ta > 0:
                    ts = text_surf.copy()
                    ts.set_alpha(ta)
                    surface.blit(ts, ts.get_rect(center=(int(text_cx), int(text_cy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
