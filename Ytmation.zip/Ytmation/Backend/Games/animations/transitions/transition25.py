"""
Transition 25 — Drop ripple pool
--------------------------------
Water surface: droplet impact, rings expand; title emerges as ripples fade.
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _norm_xy,
    _render_text_surface,
)


@dataclass
class Ripple:
    x: float
    y: float
    radius: float
    speed: float
    born: float


def _draw_caustics(layer, w: int, h: int, t: float, color: tuple, strength: float) -> None:
    import pygame

    for i in range(6):
        cx = (w * (0.2 + i * 0.13) + math.sin(t * 0.4 + i) * 80) % w
        cy = (h * (0.3 + i * 0.1) + math.cos(t * 0.35 + i * 1.2) * 60) % h
        r = 120 + 40 * math.sin(t * 0.5 + i)
        blob = pygame.Surface((int(r * 2), int(r * 2)), pygame.SRCALPHA)
        pygame.draw.circle(blob, (*color, int(18 * strength)), (int(r), int(r)), int(r))
        layer.blit(blob, (int(cx - r), int(cy - r)))


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#e8f8ff",
    drop_delay: float = 0.35,
    ripple_speed: float = 280.0,
    text_reveal_duration: float = 1.0,
    out_duration: float = 0.8,
    water_color: str = "#0a2838",
    water_color2: str = "#143850",
    ripple_color: str = "#6ec8e8",
    drop_color: str = "#b8ecff",
    caustics_strength: float = 1.0,
    seed: int = 25,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "ripple"
        output = CACHE_DIR / f"transition25_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    caustic_layer = pygame.Surface((width, height), pygame.SRCALPHA)
    ripple_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    w1, w2 = _hex(water_color), _hex(water_color2)
    tc, rc, dc = _hex(text_color), _hex(ripple_color), _hex(drop_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(52, int(min(width, height) * 0.1))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    ripples: list[Ripple] = []
    drop_done = False
    rng = random.Random(seed)

    total_frames = max(1, int(duration * fps))
    drop_frame = max(0, int(drop_delay * fps))
    rev_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    rev_start = drop_frame + int(fps * 0.5)
    out_start = max(rev_start + rev_frames, total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, w1, w2, "radial", grad_cache)
            t_sec = frame / max(fps, 1)

            caustic_layer.fill((0, 0, 0, 0))
            _draw_caustics(caustic_layer, width, height, t_sec, (120, 200, 230), caustics_strength)
            surface.blit(caustic_layer, (0, 0))

            if frame == drop_frame and not drop_done:
                pygame.draw.circle(ripple_layer, (*dc, 220), (int(text_cx), int(text_cy)), 8)
                for _ in range(4):
                    ripples.append(Ripple(text_cx, text_cy, 12.0, ripple_speed * rng.uniform(0.85, 1.1), t_sec))
                drop_done = True

            if frame > drop_frame and frame % 8 == 0 and len(ripples) < 14:
                ripples.append(Ripple(text_cx, text_cy, 20.0, ripple_speed * 0.7, t_sec))

            ripple_layer.fill((0, 0, 0, 0))
            alive: list[Ripple] = []
            for rip in ripples:
                age = t_sec - rip.born
                r = rip.radius + age * rip.speed
                if r > max(width, height) * 0.85:
                    continue
                fade = max(0.0, 1.0 - (r / (max(width, height) * 0.7)) ** 1.3)
                alpha = int(140 * fade)
                if alpha > 2:
                    pygame.draw.circle(ripple_layer, (*rc, alpha), (int(rip.x), int(rip.y)), int(r), 2)
                rip.radius = r
                alive.append(rip)
            ripples = alive
            surface.blit(ripple_layer, (0, 0))

            if frame >= rev_start:
                if frame < out_start:
                    rt = min(1.0, (frame - rev_start) / rev_frames)
                    ta = int(255 * _ease_out_cubic(rt))
                else:
                    ot = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                    ta = int(255 * (1.0 - ot))
                if ta > 0:
                    ts = text_surf.copy()
                    ts.set_alpha(ta)
                    surface.blit(ts, ts.get_rect(center=(int(text_cx), int(text_cy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
