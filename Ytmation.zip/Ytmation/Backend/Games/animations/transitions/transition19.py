"""
Transition 19 — Sonar rings
---------------------------
Thin concentric rings pulse outward from center; title fades in. Calm, minimal.
"""

from __future__ import annotations

import math
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _norm_xy,
    _render_text_surface,
)


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    subtitle: str = "",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    subtitle_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f0f0f0",
    subtitle_color: str = "#7a808a",
    text_reveal_duration: float = 1.0,
    out_duration: float = 0.85,
    ring_interval: float = 0.55,
    ring_speed: float = 340.0,
    ring_max_radius: float = 720.0,
    ring_color: str = "#8a96a8",
    line_color: str = "#b8bcc4",
    line_width_ratio: float = 0.18,
    pulse_count: int = 4,
    bg_color: str = "#0c0c0e",
    bg_color2: str = "#111118",
    bg_gradient_dir: str = "radial",
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "sonar"
        output = CACHE_DIR / f"transition19_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    ring_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, sc, rc, lc = _hex(text_color), _hex(subtitle_color), _hex(ring_color), _hex(line_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(42, int(min(width, height) * 0.07))
    if subtitle_size is None:
        subtitle_size = max(22, int(font_size * 0.45))

    try:
        title_font = pygame.font.SysFont(font_name, font_size, bold=False)
        sub_font = pygame.font.SysFont(font_name, subtitle_size, bold=False)
    except Exception:
        title_font = pygame.font.Font(None, font_size)
        sub_font = pygame.font.Font(None, subtitle_size)

    title_surf = title_font.render(text, True, tc)
    sub_surf = sub_font.render(subtitle, True, sc) if subtitle else None
    block_h = title_surf.get_height() + (sub_surf.get_height() + 20 if sub_surf else 0) + 36
    line_y = text_cy + block_h // 2 - 14
    line_full = int(width * line_width_ratio)

    total_frames = max(1, int(duration * fps))
    rev_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    rev_start = int(fps * 0.35)
    out_start = max(rev_start + rev_frames, total_frames - out_frames)

    interval_f = max(1, int(ring_interval * fps))
    grad_cache: dict = {}
    t0 = 0.0

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            ring_layer.fill((0, 0, 0, 0))
            t_sec = frame / max(fps, 1)
            for i in range(pulse_count):
                birth = t0 + i * (ring_interval * 0.85)
                age = t_sec - birth
                if age < 0:
                    continue
                r = age * ring_speed
                if r > ring_max_radius:
                    continue
                fade = 1.0 - (r / ring_max_radius) ** 1.4
                alpha = int(120 * fade)
                if alpha > 2:
                    pygame.draw.circle(ring_layer, (*rc, alpha), (int(text_cx), int(text_cy)), int(r), 1)
            t0 += 1.0 / fps
            surface.blit(ring_layer, (0, 0))

            if frame >= rev_start and frame < out_start + out_frames:
                if frame < out_start:
                    rt = min(1.0, (frame - rev_start) / rev_frames)
                    ta = int(255 * _ease_out_cubic(rt))
                    rule_t = _ease_out_cubic(rt)
                else:
                    ot = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                    ta, rule_t = int(255 * (1.0 - ot)), 1.0 - ot
                lw = int(line_full * rule_t)
                if lw > 0:
                    pygame.draw.rect(surface, lc, pygame.Rect(int(text_cx - lw // 2), int(line_y), lw, 1))
                if ta > 0:
                    ty = text_cy - block_h // 2 + title_surf.get_height() // 2
                    tt = title_surf.copy()
                    tt.set_alpha(ta)
                    surface.blit(tt, tt.get_rect(center=(int(text_cx), int(ty))))
                    if sub_surf:
                        ss = sub_surf.copy()
                        ss.set_alpha(ta)
                        sy = ty + title_surf.get_height() // 2 + 14 + sub_surf.get_height() // 2
                        surface.blit(ss, ss.get_rect(center=(int(text_cx), int(sy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
