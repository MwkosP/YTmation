"""
Transition 5 — Title in, then crumble / shatter out
---------------------------------------------------
Opposite vibe to transition3: text reveals (transition2 effects), holds,
then breaks into falling fragments with gravity.

Phases: in_duration → hold → crumble_duration
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_ripples,
    _draw_text_box,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _hex,
    _norm_xy,
    _render_text_surface,
)
from Games.animations.transitions.transition3 import _render_text_mask


@dataclass
class Fragment:
    surf: object
    home_x: float
    home_y: float
    x: float
    y: float
    vx: float
    vy: float
    angle: float
    spin: float
    alpha: float


def _cell_has_ink(surf, alpha_threshold: int) -> bool:
    w, h = surf.get_size()
    for y in range(0, h, max(1, h // 4)):
        for x in range(0, w, max(1, w // 4)):
            if surf.get_at((x, y))[3] >= alpha_threshold:
                return True
    return False


def _build_fragments(
    mask,
    text_cx: float,
    text_cy: float,
    *,
    cell_size: int,
    alpha_threshold: int,
    rng: random.Random,
) -> list[Fragment]:
    import pygame

    tw, th = mask.get_size()
    left = text_cx - tw / 2
    top = text_cy - th / 2
    cell = max(4, int(cell_size))
    frags: list[Fragment] = []

    for gy in range(0, th, cell):
        for gx in range(0, tw, cell):
            cw = min(cell, tw - gx)
            ch = min(cell, th - gy)
            rect = pygame.Rect(gx, gy, cw, ch)
            sub = mask.subsurface(rect).copy()
            if not _cell_has_ink(sub, alpha_threshold):
                continue
            hx = left + gx + cw / 2
            hy = top + gy + ch / 2
            frags.append(
                Fragment(
                    surf=sub,
                    home_x=hx,
                    home_y=hy,
                    x=hx + rng.uniform(-1, 1),
                    y=hy + rng.uniform(-1, 1),
                    vx=0.0,
                    vy=0.0,
                    angle=rng.uniform(-8, 8),
                    spin=rng.uniform(-2.5, 2.5),
                    alpha=255.0,
                )
            )
    return frags


def _burst_fragments(
    frags: list[Fragment],
    text_cx: float,
    text_cy: float,
    *,
    burst_speed: float,
    upward_bias: float,
    rng: random.Random,
) -> None:
    for f in frags:
        dx, dy = f.home_x - text_cx, f.home_y - text_cy
        ln = math.hypot(dx, dy) or 1.0
        f.vx = (dx / ln) * burst_speed + rng.uniform(-1.2, 1.2)
        f.vy = (dy / ln) * burst_speed + rng.uniform(-1.2, 1.2) - upward_bias
        f.spin = rng.uniform(-4.0, 4.0)


def _step_fragments(
    frags: list[Fragment],
    *,
    gravity: float,
    wind_x: float,
    drag: float,
    fade_rate: float,
) -> None:
    for f in frags:
        f.vx = f.vx * drag + wind_x
        f.vy = f.vy * drag + gravity
        f.x += f.vx
        f.y += f.vy
        f.angle += f.spin
        f.alpha = max(0.0, f.alpha - fade_rate)


def _draw_fragments(target, frags: list[Fragment]) -> None:
    import pygame

    for f in frags:
        if f.alpha <= 2:
            continue
        img = pygame.transform.rotate(f.surf, f.angle)
        img.set_alpha(int(min(255, f.alpha)))
        target.blit(img, img.get_rect(center=(int(f.x), int(f.y))))


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # text
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f4f4f4",
    text_box: bool = False,
    text_box_color: str = "#ffffff",
    text_box_alpha: int = 35,
    text_box_padding: int = 28,
    text_box_radius: int = 14,
    text_glow: bool = False,
    text_glow_layers: int = 4,
    text_glow_strength: int = 35,
    # timing
    in_duration: float = 1.0,
    crumble_duration: float = 1.4,
    # text in (transition2); out is always crumble
    text_in_effect: str = "scale",
    pixel_block_max: int = 36,
    # crumble
    fragment_size: int = 14,
    crumble_burst: float = 4.5,
    crumble_upward: float = 1.2,
    crumble_gravity: float = 0.38,
    crumble_wind: float = 0.04,
    crumble_drag: float = 0.985,
    crumble_fade: float = 2.8,
    crumble_spin: float = 1.0,
    seed: int = 42,
    # background
    bg_color: str = "#0b0c10",
    bg_color2: str = "#15182a",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.35,
    show_ripples: bool = True,
    ripple_color: str = "#2a2d3a",
    ripple_count: int = 10,
    ripple_x: float | None = None,
    ripple_y: float | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    kwargs.pop("text_placeholder_box", None)

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "title"
        output = CACHE_DIR / f"transition5_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    ric = _hex(ripple_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    ripple_cx = ripple_x * width if ripple_x is not None else text_cx
    ripple_cy = ripple_y * height if ripple_y is not None else text_cy

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_mask = _render_text_mask(text, font, tc)
    text_surf = _render_text_surface(text, font, tc)
    rng = random.Random(seed)
    fragments = _build_fragments(
        text_mask, text_cx, text_cy,
        cell_size=fragment_size, alpha_threshold=48, rng=rng,
    )
    if not fragments:
        fragments = _build_fragments(
            text_mask, text_cx, text_cy,
            cell_size=max(6, fragment_size // 2), alpha_threshold=32, rng=rng,
        )

    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None

    total_frames = max(1, int(duration * fps))
    in_frames = max(1, int(in_duration * fps))
    crumble_frames = max(1, int(crumble_duration * fps))
    crumble_start = max(in_frames, total_frames - crumble_frames)
    hold_end = crumble_start

    grad_cache: dict = {}
    burst_done = False

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if show_ripples:
                _draw_ripples(surface, ripple_cx, ripple_cy, width, height, ric, ripple_count)
            if vignette > 0:
                _draw_vignette(surface, vignette)

            if frame < in_frames:
                if text_box:
                    _draw_text_box(
                        surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                        text_box_alpha, text_box_padding, text_box_radius,
                    )
                if text_glow:
                    _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                prog = frame / in_frames
                _draw_text_effect(
                    surface, text_surf, text_cx, text_cy, text_in_effect, prog,
                    outward=False,
                    typewriter_frames=typewriter_in,
                    frame_idx=frame,
                    glitch_seed=7,
                    pixel_block_max=pixel_block_max,
                )
            elif frame >= crumble_start:
                if not burst_done:
                    _burst_fragments(
                        fragments, text_cx, text_cy,
                        burst_speed=crumble_burst, upward_bias=crumble_upward, rng=rng,
                    )
                    for f in fragments:
                        f.spin *= crumble_spin
                    burst_done = True
                _step_fragments(
                    fragments,
                    gravity=crumble_gravity,
                    wind_x=crumble_wind,
                    drag=crumble_drag,
                    fade_rate=crumble_fade,
                )
                _draw_fragments(surface, fragments)
            else:
                if text_box:
                    _draw_text_box(
                        surface, text_surf, text_cx, text_cy, _hex(text_box_color),
                        text_box_alpha, text_box_padding, text_box_radius,
                    )
                if text_glow:
                    _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                surface.blit(text_surf, text_surf.get_rect(center=(int(text_cx), int(text_cy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg", "-y",
                "-framerate", str(fps),
                "-i", str(frames_dir / "frame_%06d.png"),
                "-c:v", "libx264", "-pix_fmt", "yuv420p",
                "-preset", "fast", "-crf", "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
