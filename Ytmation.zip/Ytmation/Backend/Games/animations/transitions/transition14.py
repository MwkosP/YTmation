"""
Transition 14 — Nebula parallax drift
-------------------------------------
Slow cruise through deep space: layered stars + soft nebula clouds.
Calm counterpart to transition11's hyperspace warp.
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


@dataclass
class DriftStar:
    x: float
    y: float
    layer: int
    size: float
    brightness: int


@dataclass
class NebulaCloud:
    x: float
    y: float
    radius: float
    color: tuple
    alpha: int
    drift_x: float
    drift_y: float


def _spawn_stars(count: int, w: int, h: int, rng: random.Random) -> list[DriftStar]:
    stars: list[DriftStar] = []
    for _ in range(count):
        layer = rng.choices([0, 1, 2], weights=[5, 3, 2])[0]
        stars.append(
            DriftStar(
                x=rng.uniform(0, w),
                y=rng.uniform(0, h),
                layer=layer,
                size=rng.uniform(0.8, 1.0 + layer * 1.2),
                brightness=rng.randint(90, 220) + layer * 15,
            )
        )
    return stars


def _spawn_nebulae(w: int, h: int, rng: random.Random) -> list[NebulaCloud]:
    palettes = [
        ((90, 40, 140), 28),
        ((40, 80, 160), 24),
        ((160, 50, 100), 22),
    ]
    clouds: list[NebulaCloud] = []
    for i, (col, alpha) in enumerate(palettes):
        clouds.append(
            NebulaCloud(
                x=rng.uniform(w * 0.2, w * 0.8),
                y=rng.uniform(h * 0.15, h * 0.85),
                radius=rng.uniform(280, 520),
                color=col,
                alpha=alpha,
                drift_x=rng.uniform(-0.15, 0.15),
                drift_y=rng.uniform(-0.08, 0.08),
            )
        )
    return clouds


def _draw_nebula(layer, cloud: NebulaCloud) -> None:
    import pygame

    d = max(64, int(cloud.radius * 2))
    orb = pygame.Surface((d, d), pygame.SRCALPHA)
    c = cloud.x - d // 2
    r = cloud.y - d // 2
    center = d // 2
    max_r = int(cloud.radius)
    for rad in range(max_r, 0, -6):
        a = int(cloud.alpha * (rad / max(max_r, 1)) ** 1.6)
        if a > 1:
            pygame.draw.circle(orb, (*cloud.color, a), (center, center), rad)
    layer.blit(orb, (int(c), int(r)))


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f0f4ff",
    text_glow: bool = True,
    text_glow_layers: int = 4,
    text_glow_strength: int = 38,
    drift_duration: float = 5.0,
    text_reveal_duration: float = 1.1,
    out_duration: float = 0.8,
    text_in_effect: str = "fade",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    star_count: int = 280,
    layer_speeds: tuple[float, float, float] = (0.12, 0.28, 0.55),
    star_color: str = "#dce8ff",
    nebula_strength: float = 1.0,
    seed: int = 42,
    bg_color: str = "#030510",
    bg_color2: str = "#0a1428",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.45,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "nebula"
        output = CACHE_DIR / f"transition14_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    nebula_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, sc = _hex(text_color), _hex(star_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    rng = random.Random(seed)
    stars = _spawn_stars(star_count, width, height, rng)
    nebulae = _spawn_nebulae(width, height, rng)
    speeds = layer_speeds

    total_frames = max(1, int(duration * fps))
    reveal_start = max(1, int(drift_duration * fps * 0.35))
    reveal_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    out_start = max(reveal_start + reveal_frames, total_frames - out_frames)

    grad_cache: dict = {}
    drift_angle = rng.uniform(0, math.tau)

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            nebula_layer.fill((0, 0, 0, 0))
            for cloud in nebulae:
                cloud.x += cloud.drift_x * nebula_strength
                cloud.y += cloud.drift_y * nebula_strength
                if cloud.x < -cloud.radius:
                    cloud.x = width + cloud.radius
                elif cloud.x > width + cloud.radius:
                    cloud.x = -cloud.radius
                if cloud.y < -cloud.radius:
                    cloud.y = height + cloud.radius
                elif cloud.y > height + cloud.radius:
                    cloud.y = -cloud.radius
                _draw_nebula(nebula_layer, cloud)
            surface.blit(nebula_layer, (0, 0))

            dx_base = math.cos(drift_angle) * 0.35
            dy_base = math.sin(drift_angle) * 0.2
            for st in stars:
                spd = speeds[min(st.layer, 2)]
                st.x += dx_base * spd + st.layer * 0.02
                st.y += dy_base * spd
                if st.x < 0:
                    st.x += width
                elif st.x > width:
                    st.x -= width
                if st.y < 0:
                    st.y += height
                elif st.y > height:
                    st.y -= height
                twinkle = 0.85 + 0.15 * math.sin(frame * 0.05 + st.x * 0.01)
                c = tuple(min(255, int(ch * st.brightness * twinkle / 255)) for ch in sc)
                pygame.draw.circle(surface, c, (int(st.x), int(st.y)), max(1, int(st.size)))

            if frame >= reveal_start:
                if frame < out_start:
                    rev = min(1.0, (frame - reveal_start) / reveal_frames)
                    if text_glow:
                        _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_in_effect, rev,
                        outward=False, typewriter_frames=typewriter_in, frame_idx=frame,
                        glitch_seed=14, pixel_block_max=pixel_block_max,
                    )
                else:
                    out_t = (frame - out_start) / max(1, out_frames)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_out_effect, out_t,
                        outward=True, typewriter_frames=typewriter_out, frame_idx=frame,
                        glitch_seed=24, pixel_block_max=pixel_block_max,
                    )

            if vignette > 0:
                _draw_vignette(surface, vignette)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
