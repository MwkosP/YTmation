"""
Transition 21 — Shockwave impact
--------------------------------
Radial burst, screen shake, flash hit; title slams in with overscale.
Aggressive opener / punch card.
"""

from __future__ import annotations

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _ease_out_back(t: float, s: float = 1.6) -> float:
    t = max(0.0, min(1.0, t))
    return 1.0 + (s + 1.0) * (t - 1.0) ** 3 + s * (t - 1.0) ** 2


def _draw_shockwave(
    target,
    cx: float,
    cy: float,
    radius: float,
    color: tuple,
    *,
    rays: int = 48,
    inner_skip: float = 0.12,
) -> None:
    import pygame

    for i in range(rays):
        ang = (i / rays) * math.tau
        r0 = radius * inner_skip
        r1 = radius * (0.85 + (i % 3) * 0.05)
        x0, y0 = cx + math.cos(ang) * r0, cy + math.sin(ang) * r0
        x1, y1 = cx + math.cos(ang) * r1, cy + math.sin(ang) * r1
        pygame.draw.line(target, color, (int(x0), int(y0)), (int(x1), int(y1)), max(1, 2 - i % 2))


def _shake_offset(frame: int, impact_frame: int, strength: float, seed: int) -> tuple[int, int]:
    if frame < impact_frame:
        return 0, 0
    t = frame - impact_frame
    if t > 18:
        return 0, 0
    rng = random.Random(seed + t * 31)
    falloff = 1.0 - t / 18.0
    return (
        int(rng.uniform(-1, 1) * strength * falloff),
        int(rng.uniform(-1, 1) * strength * falloff),
    )


def run(
    duration: float = 4.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#ffffff",
    impact_duration: float = 0.35,
    slam_duration: float = 0.45,
    out_duration: float = 0.5,
    shock_rays: int = 52,
    shock_color: str = "#ff4d4d",
    flash_strength: int = 200,
    shake_strength: float = 22.0,
    slam_scale: float = 1.75,
    bg_color: str = "#08080a",
    bg_color2: str = "#1a0810",
    bg_gradient_dir: str = "radial",
    seed: int = 42,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "shock"
        output = CACHE_DIR / f"transition21_{safe}_{stamp}.mp4"

    pygame.init()
    base = pygame.Surface((width, height))
    flash = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, sc = _hex(text_color), _hex(shock_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(56, int(min(width, height) * 0.11))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    max_r = math.hypot(width, height) * 0.72

    total_frames = max(1, int(duration * fps))
    impact_frames = max(1, int(impact_duration * fps))
    slam_frames = max(1, int(slam_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    impact_frame = max(0, int(fps * 0.08))
    slam_start = impact_frame + impact_frames
    out_start = max(slam_start + slam_frames, total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(base, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            sx, sy = _shake_offset(frame, impact_frame, shake_strength, seed)
            surface = pygame.Surface((width, height))
            surface.blit(base, (sx, sy))

            if frame >= impact_frame:
                shock_t = min(1.0, (frame - impact_frame) / impact_frames)
                r = max_r * _ease_out_cubic(shock_t)
                alpha = int(255 * (1.0 - shock_t) ** 0.55)
                if alpha > 0:
                    layer = pygame.Surface((width, height), pygame.SRCALPHA)
                    _draw_shockwave(layer, text_cx, text_cy, r, (*sc, alpha), rays=shock_rays)
                    surface.blit(layer, (0, 0))

            if impact_frame <= frame < impact_frame + 4:
                flash_a = int(flash_strength * (1.0 - (frame - impact_frame) / 4.0))
                flash.fill((255, 250, 245, flash_a))
                surface.blit(flash, (0, 0))

            if frame >= slam_start:
                if frame < out_start:
                    st = min(1.0, (frame - slam_start) / slam_frames)
                    scale = _lerp(slam_scale, 1.0, _ease_out_back(st, 1.65))
                    tw, th = text_surf.get_size()
                    nw, nh = max(1, int(tw * scale)), max(1, int(th * scale))
                    import pygame as pg
                    scaled = pg.transform.smoothscale(text_surf, (nw, nh))
                    surface.blit(scaled, scaled.get_rect(center=(int(text_cx + sx), int(text_cy + sy))))
                else:
                    ot = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                    ts = text_surf.copy()
                    ts.set_alpha(int(255 * (1.0 - ot)))
                    zoom = 1.0 + ot * 0.25
                    tw, th = text_surf.get_size()
                    nw, nh = int(tw * zoom), int(th * zoom)
                    import pygame as pg
                    scaled = pg.transform.smoothscale(text_surf, (max(1, nw), max(1, nh)))
                    surface.blit(scaled, scaled.get_rect(center=(int(text_cx), int(text_cy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
