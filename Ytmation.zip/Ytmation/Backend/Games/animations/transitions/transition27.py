"""
Transition 27 — YouTube play button (thumbnail)
------------------------------------------------
Iconic red play tile on a dark thumbnail frame; "click" zooms into the title.
"""

from __future__ import annotations

import math
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _ease_out_back(t: float, s: float = 1.5) -> float:
    t = max(0.0, min(1.0, t))
    return 1.0 + (s + 1.0) * (t - 1.0) ** 3 + s * (t - 1.0) ** 2


def _draw_play_button(layer, cx: float, cy: float, w: float, h: float, red: tuple, white: tuple, alpha: int = 255) -> None:
    import pygame

    rw, rh = int(w), int(h)
    surf = pygame.Surface((rw + 8, rh + 8), pygame.SRCALPHA)
    rect = pygame.Rect(4, 4, rw, rh)
    radius = max(8, int(min(rw, rh) * 0.12))
    pygame.draw.rect(surf, (*red, alpha), rect, border_radius=radius)
    tri_w = int(rw * 0.28)
    tri_h = int(rh * 0.36)
    tx = rect.centerx + int(tri_w * 0.12)
    ty = rect.centery
    pts = [
        (tx - tri_w // 2, ty - tri_h // 2),
        (tx - tri_w // 2, ty + tri_h // 2),
        (tx + tri_w // 2, ty),
    ]
    pygame.draw.polygon(surf, (*white, alpha), pts)
    layer.blit(surf, (int(cx - surf.get_width() / 2), int(cy - surf.get_height() / 2)))


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#ffffff",
    play_delay: float = 0.4,
    play_hold: float = 1.1,
    click_duration: float = 0.22,
    title_in_duration: float = 0.55,
    out_duration: float = 0.7,
    play_button_scale: float = 0.22,
    play_color: str = "#ff0000",
    play_pulse: float = 0.04,
    flash_on_click: int = 200,
    bg_color: str = "#0f0f0f",
    bg_color2: str = "#1a1a1a",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.45,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "play"
        output = CACHE_DIR / f"transition27_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    overlay = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    red, white, tc = _hex(play_color), (255, 255, 255), _hex(text_color)
    cx, cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(52, int(min(width, height) * 0.1))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)
    text_surf = _render_text_surface(text, font, tc)

    btn_w = width * play_button_scale * 1.45
    btn_h = width * play_button_scale

    total_frames = max(1, int(duration * fps))
    play_start = int(play_delay * fps)
    click_start = play_start + int(play_hold * fps)
    click_frames = max(1, int(click_duration * fps))
    title_start = click_start
    title_frames = max(1, int(title_in_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    out_start = max(title_start + title_frames + int(fps * 0.8), total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)
            if vignette > 0:
                _draw_vignette(surface, vignette)

            t_sec = frame / max(fps, 1)
            overlay.fill((0, 0, 0, 0))

            if frame < click_start + click_frames:
                if frame < click_start:
                    pulse = 1.0 + play_pulse * math.sin(t_sec * 4.5)
                    scale = pulse
                    pa = 255
                else:
                    ct = (frame - click_start) / click_frames
                    scale = _lerp(1.0, 2.2, _ease_in_cubic(ct))
                    pa = int(255 * (1.0 - _ease_out_cubic(ct)))
                    if ct < 0.35:
                        flash = int(flash_on_click * (1.0 - ct / 0.35))
                        overlay.fill((255, 255, 255, flash))

                _draw_play_button(
                    overlay, cx, cy,
                    btn_w * scale, btn_h * scale,
                    red, white, pa,
                )

            if frame >= title_start:
                if frame < out_start:
                    tt = min(1.0, (frame - title_start) / title_frames)
                    ts = _ease_out_back(tt)
                    ta = int(255 * _ease_out_cubic(min(1.0, tt * 1.4)))
                    sw = max(1, int(text_surf.get_width() * (0.35 + 0.65 * ts)))
                    sh = max(1, int(text_surf.get_height() * (0.35 + 0.65 * ts)))
                    scaled = pygame.transform.smoothscale(text_surf, (sw, sh))
                    scaled.set_alpha(ta)
                    overlay.blit(scaled, scaled.get_rect(center=(int(cx), int(cy))))
                else:
                    ot = (frame - out_start) / max(1, out_frames)
                    ta = int(255 * (1.0 - _ease_in_cubic(ot)))
                    if ta > 0:
                        ts = text_surf.copy()
                        ts.set_alpha(ta)
                        overlay.blit(ts, ts.get_rect(center=(int(cx), int(cy))))

            surface.blit(overlay, (0, 0))
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
