"""
Transition 9 — Lower third / chapter card
---------------------------------------
Broadcast-style bar slides up with title + subtitle, holds, slides away.
"""

from __future__ import annotations

import math
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _draw_vignette,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
)

BAR_EASE = _ease_out_cubic


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    # lines
    text: str = "Episode 2",
    subtitle: str = "Prime Numbers",
    text_x: float = 0.5,
    text_y: float = 0.82,
    font_size: int | None = None,
    subtitle_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#ffffff",
    subtitle_color: str = "#b8c0d0",
    # bar
    bar_height: float = 0.14,
    bar_color: str = "#141820",
    bar_accent: str = "#00c8ff",
    bar_accent_width: int = 6,
    bar_alpha: int = 230,
    bar_corner: int = 0,
    # timing
    slide_in_duration: float = 0.55,
    slide_out_duration: float = 0.45,
    subtitle_stagger: float = 0.12,
    # background
    bg_color: str = "#0b0c10",
    bg_color2: str = "#15182a",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.3,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "card"
        output = CACHE_DIR / f"transition9_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, sc = _hex(text_color), _hex(subtitle_color)
    bar_c, acc_c = _hex(bar_color), _hex(bar_accent)

    if font_size is None:
        font_size = max(36, int(height * 0.052))
    if subtitle_size is None:
        subtitle_size = max(24, int(font_size * 0.62))

    try:
        title_font = pygame.font.SysFont(font_name, font_size, bold=True)
        sub_font = pygame.font.SysFont(font_name, subtitle_size, bold=False)
    except Exception:
        title_font = pygame.font.Font(None, font_size)
        sub_font = pygame.font.Font(None, subtitle_size)

    title_surf = title_font.render(text, True, tc)
    sub_surf = sub_font.render(subtitle, True, sc) if subtitle else None

    bar_h = int(height * bar_height)
    pad_x = int(width * 0.06)
    text_cx, anchor_y = _norm_xy(text_x, text_y, width, height)
    bar_rest_y = int(anchor_y - bar_h / 2)
    bar_offscreen_y = height + 10

    total_frames = max(1, int(duration * fps))
    in_frames = max(1, int(slide_in_duration * fps))
    out_frames = max(1, int(slide_out_duration * fps))
    out_start = max(in_frames + int(fps * 0.5), total_frames - out_frames)
    stagger_frames = max(1, int(subtitle_stagger * fps))

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            if frame < in_frames:
                t = BAR_EASE(frame / in_frames)
                bar_y = int(_lerp(bar_offscreen_y, bar_rest_y, t))
                title_a = int(255 * min(1.0, t * 1.3))
                sub_a = int(255 * max(0.0, min(1.0, (frame - stagger_frames) / max(1, in_frames - stagger_frames))))
            elif frame >= out_start:
                t = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                bar_y = int(_lerp(bar_rest_y, bar_offscreen_y, t))
                title_a = int(255 * (1.0 - t))
                sub_a = title_a
            else:
                bar_y = bar_rest_y
                title_a = sub_a = 255

            bar_rect = pygame.Rect(pad_x, bar_y, width - pad_x * 2, bar_h)
            bar_surf = pygame.Surface((bar_rect.width, bar_rect.height), pygame.SRCALPHA)
            bar_surf.fill((*bar_c, bar_alpha))
            if bar_corner > 0:
                pygame.draw.rect(bar_surf, (*bar_c, bar_alpha), bar_surf.get_rect(), border_radius=bar_corner)
            pygame.draw.rect(bar_surf, acc_c, (0, 0, bar_accent_width, bar_h))
            surface.blit(bar_surf, bar_rect.topleft)

            ty = bar_y + bar_h // 2 - (title_surf.get_height() + (sub_surf.get_height() + 8 if sub_surf else 0)) // 2
            if title_a > 0:
                ts = title_surf.copy()
                ts.set_alpha(title_a)
                surface.blit(ts, ts.get_rect(midleft=(pad_x + bar_accent_width + 28, ty + title_surf.get_height() // 2)))
            if sub_surf and sub_a > 0:
                ss = sub_surf.copy()
                ss.set_alpha(sub_a)
                sy = ty + title_surf.get_height() + 10
                surface.blit(ss, ss.get_rect(midleft=(pad_x + bar_accent_width + 28, sy + sub_surf.get_height() // 2)))

            if vignette > 0:
                _draw_vignette(surface, vignette)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
