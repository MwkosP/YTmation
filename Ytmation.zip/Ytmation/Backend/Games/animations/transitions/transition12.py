"""
Transition 12 — Soft focus reveal (modern minimal)
--------------------------------------------------
Muted gradient, drifting light leak, title rises slightly into sharp focus.
Editorial / product-film style — not arcade or game-like.
"""

from __future__ import annotations

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


def _blur_surface(src, amount: float):
    import pygame

    if amount <= 0.02:
        return src.copy()
    tw, th = src.get_size()
    shrink_w = max(2, int(tw * (1.0 - amount * 0.88)))
    shrink_h = max(2, int(th * (1.0 - amount * 0.88)))
    small = pygame.transform.smoothscale(src, (shrink_w, shrink_h))
    return pygame.transform.smoothscale(small, (tw, th))


def _soft_orb(layer, cx: float, cy: float, radius: float, color: tuple, alpha: int) -> None:
    import pygame

    d = max(32, int(radius * 2))
    orb = pygame.Surface((d, d), pygame.SRCALPHA)
    center = d // 2
    for r in range(int(radius), 0, -4):
        a = int(alpha * (r / max(radius, 1)) ** 1.8)
        if a > 2:
            pygame.draw.circle(orb, (*color, a), (center, center), r)
    layer.blit(orb, (int(cx - center), int(cy - center)))


def _film_grain(layer, intensity: float, frame: int, seed: int) -> None:
    import pygame

    if intensity <= 0.01:
        return
    w, h = layer.get_size()
    rng = random.Random(seed + frame * 17)
    step = 4
    for y in range(0, h, step):
        for x in range(0, w, step):
            if rng.random() < intensity * 0.12:
                v = rng.randint(0, 40)
                a = int(255 * intensity * rng.uniform(0.15, 0.45))
                pygame.draw.rect(layer, (v, v, v, a), (x, y, step, step))


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#f2f2f2",
    in_duration: float = 1.4,
    out_duration: float = 1.0,
    rise_px: float = 18.0,
    blur_amount: float = 0.55,
    orb_color: str = "#8b9cff",
    orb_radius: float = 420.0,
    orb_alpha: int = 38,
    orb_drift: bool = True,
    grain: float = 0.06,
    bg_color: str = "#0c0c0e",
    bg_color2: str = "#141418",
    bg_gradient_dir: str = "radial",
    seed: int = 42,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "focus"
        output = CACHE_DIR / f"transition12_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    light = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, oc = _hex(text_color), _hex(orb_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(44, int(min(width, height) * 0.075))

    try:
        font = pygame.font.SysFont(font_name, font_size, bold=False)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    total_frames = max(1, int(duration * fps))
    in_frames = max(1, int(in_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    out_start = max(in_frames + int(fps * 0.8), total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            t_sec = frame / max(fps, 1)
            if orb_drift:
                ox = text_cx + math.sin(t_sec * 0.35) * 80
                oy = text_cy + math.cos(t_sec * 0.28) * 50
            else:
                ox, oy = text_cx, text_cy

            light.fill((0, 0, 0, 0))
            _soft_orb(light, ox, oy, orb_radius, oc, orb_alpha)
            surface.blit(light, (0, 0))

            if frame < in_frames:
                p = _ease_out_cubic(frame / in_frames)
                alpha = int(255 * p)
                blur = blur_amount * (1.0 - p)
                y_off = _lerp(rise_px, 0, p)
            elif frame >= out_start:
                p = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                alpha = int(255 * (1.0 - p))
                blur = blur_amount * p * 0.7
                y_off = _lerp(0, -10, p)
            else:
                alpha, blur, y_off = 255, 0.0, 0.0

            if alpha > 0:
                ts = _blur_surface(text_surf, blur)
                ts.set_alpha(alpha)
                rect = ts.get_rect(center=(int(text_cx), int(text_cy + y_off)))
                surface.blit(ts, rect)

            if grain > 0:
                grain_layer = pygame.Surface((width, height), pygame.SRCALPHA)
                _film_grain(grain_layer, grain, frame, seed)
                surface.blit(grain_layer, (0, 0))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
