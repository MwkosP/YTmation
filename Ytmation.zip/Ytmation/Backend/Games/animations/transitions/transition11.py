"""
Transition 11 — Warp starfield
------------------------------
Stars streak from hyperspace, slow to drift; title fades in at center.
"""

from __future__ import annotations

import math
import random
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _build_typewriter_surfaces,
    _draw_background,
    _draw_text_box,
    _draw_text_effect,
    _draw_text_glow,
    _draw_vignette,
    _ease_out_cubic,
    _hex,
    _lerp,
    _norm_xy,
    _render_text_surface,
)


@dataclass
class Star:
    angle: float
    dist: float
    speed: float
    size: float
    brightness: int


def _spawn_stars(count: int, w: int, h: int, rng: random.Random) -> list[Star]:
    stars: list[Star] = []
    for _ in range(count):
        stars.append(
            Star(
                angle=rng.uniform(0, math.tau),
                dist=rng.uniform(0.05, 1.0),
                speed=rng.uniform(0.7, 1.3),
                size=rng.uniform(1.0, 3.2),
                brightness=rng.randint(140, 255),
            )
        )
    return stars


def run(
    duration: float = 5.0,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Next Simulation",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#ffffff",
    text_glow: bool = True,
    text_glow_layers: int = 5,
    text_glow_strength: int = 45,
    warp_duration: float = 1.8,
    settle_duration: float = 0.8,
    text_reveal_duration: float = 0.9,
    out_duration: float = 0.7,
    text_in_effect: str = "fade",
    text_out_effect: str = "fade",
    pixel_block_max: int = 36,
    star_count: int = 220,
    warp_speed_max: float = 28.0,
    star_color: str = "#e8f4ff",
    trail_stretch: float = 1.0,
    seed: int = 42,
    bg_color: str = "#020408",
    bg_color2: str = "#0a1830",
    bg_gradient_dir: str = "radial",
    vignette: float = 0.42,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "warp"
        output = CACHE_DIR / f"transition11_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    cx, cy = width / 2, height / 2

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc = _hex(text_color)
    sc = _hex(star_color)

    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)
    if font_size is None:
        font_size = max(48, int(min(width, height) * 0.1))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    typewriter_in = _build_typewriter_surfaces(text, font, tc) if text_in_effect == "typewriter" else None
    typewriter_out = _build_typewriter_surfaces(text, font, tc) if text_out_effect == "typewriter" else None

    rng = random.Random(seed)
    stars = _spawn_stars(star_count, width, height, rng)
    max_dist = math.hypot(cx, cy)

    total_frames = max(1, int(duration * fps))
    warp_frames = max(1, int(warp_duration * fps))
    settle_frames = max(1, int(settle_duration * fps))
    reveal_frames = max(1, int(text_reveal_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    settle_start = warp_frames
    reveal_start = settle_start + settle_frames
    out_start = max(reveal_start + reveal_frames, total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            if frame < settle_start:
                prog = frame / warp_frames
                speed_mul = _lerp(warp_speed_max, 4.0, _ease_out_cubic(prog))
            elif frame < reveal_start:
                sf = (frame - settle_start) / settle_frames
                speed_mul = _lerp(4.0, 0.35, _ease_out_cubic(sf))
            else:
                speed_mul = 0.35

            for st in stars:
                d = st.dist * max_dist
                move = speed_mul * st.speed * (0.08 + st.dist)
                d = (d + move) % (max_dist * 1.05)
                st.dist = d / max_dist
                px = cx + math.cos(st.angle) * d
                py = cy + math.sin(st.angle) * d
                if frame < settle_start and trail_stretch > 0:
                    ln = min(40, move * trail_stretch * 2)
                    ex = px - math.cos(st.angle) * ln
                    ey = py - math.sin(st.angle) * ln
                    c = tuple(min(255, int(ch * st.brightness / 255)) for ch in sc)
                    pygame.draw.line(
                        surface, c,
                        (int(ex), int(ey)), (int(px), int(py)),
                        max(1, int(st.size)),
                    )
                else:
                    pygame.draw.circle(
                        surface, sc, (int(px), int(py)), max(1, int(st.size)),
                    )

            if frame >= reveal_start:
                if frame < out_start:
                    rev = min(1.0, (frame - reveal_start) / reveal_frames)
                    if text_glow:
                        _draw_text_glow(surface, text_surf, text_cx, text_cy, tc, text_glow_layers, text_glow_strength)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_in_effect, rev,
                        outward=False, typewriter_frames=typewriter_in, frame_idx=frame,
                        glitch_seed=11, pixel_block_max=pixel_block_max,
                    )
                else:
                    out_t = (frame - out_start) / max(1, out_frames)
                    _draw_text_effect(
                        surface, text_surf, text_cx, text_cy, text_out_effect, out_t,
                        outward=True, typewriter_frames=typewriter_out, frame_idx=frame,
                        glitch_seed=21, pixel_block_max=pixel_block_max,
                    )

            if vignette > 0:
                _draw_vignette(surface, vignette)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
