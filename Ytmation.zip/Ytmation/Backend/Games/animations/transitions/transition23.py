"""
Transition 23 — Lightning strike
-------------------------------
Storm dark; a bolt slams down, flash illuminates the title.
"""

from __future__ import annotations

import random
import tempfile
from datetime import datetime
from pathlib import Path

from Games.animations.transitions.lightning_fx import draw_bolt, lightning_path
from Games.animations.transitions.transition2 import (
    CACHE_DIR,
    _draw_background,
    _ease_in_cubic,
    _hex,
    _norm_xy,
    _render_text_surface,
)


def run(
    duration: float = 4.5,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1920,
    height: int = 1080,
    text: str = "Episode 2",
    text_x: float = 0.5,
    text_y: float = 0.5,
    font_size: int | None = None,
    font_name: str = "arial",
    text_color: str = "#ffffff",
    strike_delay: float = 0.4,
    strike_duration: float = 0.25,
    hold_duration: float = 2.0,
    out_duration: float = 0.6,
    bolt_color: str = "#c8e8ff",
    flash_strength: int = 190,
    bolt_displace: float = 95.0,
    strike_from: str = "top",
    seed: int = 23,
    bg_color: str = "#060810",
    bg_color2: str = "#101828",
    bg_gradient_dir: str = "radial",
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c if c.isalnum() else "_" for c in text[:24]).strip("_") or "bolt"
        output = CACHE_DIR / f"transition23_{safe}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height))
    flash = pygame.Surface((width, height), pygame.SRCALPHA)
    bolt_layer = pygame.Surface((width, height), pygame.SRCALPHA)

    bg1, bg2 = _hex(bg_color), _hex(bg_color2) if bg_color2 else None
    tc, bc = _hex(text_color), _hex(bolt_color)
    text_cx, text_cy = _norm_xy(text_x, text_y, width, height)

    if font_size is None:
        font_size = max(56, int(min(width, height) * 0.11))
    try:
        font = pygame.font.SysFont(font_name, font_size, bold=True)
    except Exception:
        font = pygame.font.Font(None, font_size)

    text_surf = _render_text_surface(text, font, tc)
    rng = random.Random(seed)

    side = (strike_from or "top").lower()
    if side == "left":
        x1, y1 = -40, text_cy
        x2, y2 = text_cx, text_cy
    elif side == "right":
        x1, y1 = width + 40, text_cy * 0.7
        x2, y2 = text_cx, text_cy
    else:
        x1, y1 = text_cx + rng.uniform(-120, 120), -50
        x2, y2 = text_cx, text_cy + 30

    bolt_pts = lightning_path(x1, y1, x2, y2, rng, displace=bolt_displace, depth=9)

    total_frames = max(1, int(duration * fps))
    strike_frame = max(0, int(strike_delay * fps))
    strike_frames = max(1, int(strike_duration * fps))
    out_frames = max(1, int(out_duration * fps))
    out_start = max(strike_frame + strike_frames + int(hold_duration * fps), total_frames - out_frames)

    grad_cache: dict = {}

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            _draw_background(surface, width, height, bg1, bg2, bg_gradient_dir, grad_cache)

            bolt_layer.fill((0, 0, 0, 0))
            flash_a = 0
            text_a = 0

            if strike_frame <= frame < strike_frame + strike_frames + 8:
                bf = frame - strike_frame
                if bf < strike_frames:
                    draw_bolt(bolt_layer, bolt_pts, (*bc, 255), width=3, glow=True)
                    flash_a = int(flash_strength * (1.0 - bf / strike_frames))
                    text_a = int(255 * min(1.0, bf / max(1, strike_frames - 2)))
                elif bf < strike_frames + 5:
                    fade = 1.0 - (bf - strike_frames) / 5.0
                    draw_bolt(bolt_layer, bolt_pts, (*bc, int(200 * fade)), width=2, glow=True)
                    flash_a = int(flash_strength * 0.35 * fade)
                    text_a = 255
                else:
                    text_a = 255
            elif frame >= out_start:
                ot = _ease_in_cubic((frame - out_start) / max(1, out_frames))
                text_a = int(255 * (1.0 - ot))
                flash_a = int(30 * ot)
            elif frame > strike_frame:
                text_a = 255

            if flash_a > 0:
                flash.fill((220, 235, 255, flash_a))
                surface.blit(flash, (0, 0))
            surface.blit(bolt_layer, (0, 0))

            if text_a > 0:
                ts = text_surf.copy()
                ts.set_alpha(text_a)
                surface.blit(ts, ts.get_rect(center=(int(text_cx), int(text_cy))))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return output
