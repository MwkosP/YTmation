"""
Roulette Slots Ball — Rim Slot Effects
---------------------------------------
A ball moves inside a circular roulette arena.
When it hits the rim, the impact angle maps to a slot.
Each slot applies an effect (speed, gravity, size, color, etc.).

ROULETTE:
    slot_count            : int   = 16
    spin_speed            : float = 0.65    — wheel rotation (degrees/frame)
    effect_cooldown       : int   = 10      — frames before next slot effect can trigger
    show_slot_labels      : bool  = False

BALL:
    ball_radius           : int   = 24
    ball_color            : str   = "#ffffff"
    ball_glow             : bool  = True
    ball_trail            : bool  = True
    trail_length          : int   = 20
    glow_layers           : int   = 5
    ball_speed_min        : float = 4.0
    ball_speed_max        : float = 8.0

PHYSICS:
    gravity               : float = 0.20
    bounce                : float = 0.99
    friction              : float = 0.998
    speed_limit           : float = 15.0
    center_pull           : float = 0.0

LOOK:
    slot_ring_width       : int   = 38
    slot_alpha            : int   = 120
    indicator_alpha       : int   = 170

BACKGROUND:
    bg_color              : str   = "#0d0d0d"
    bg_color2             : str   = None
    bg_gradient_dir       : str   = "vertical"

OUTPUT:
    fps                   : int   = 60
    width                 : int   = 1080
    height                : int   = 1920
    duration              : int   = 18
"""

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


def _hex(h):
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _with_alpha_circle(surf, color, pos, r, alpha):
    import pygame

    if r <= 0 or alpha <= 0:
        return
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0] - r, pos[1] - r))


def _draw_glow(surf, color, pos, r, layers=5):
    for i in range(layers, 0, -1):
        _with_alpha_circle(surf, color, pos, r + i * 7, int(60 / i))


def _gradient_surface(w, h, c1, c2, direction="vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (x, 0), (x, h))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_d = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max_d)
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                surf.set_at((x, y), (r, g, b))
    else:
        for y in range(h):
            t = y / max(1, h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (0, y), (w, y))
    return surf


def _draw_slot_wheel(surf, cx, cy, r_outer, r_inner, slot_count, angle_offset, slot_colors, alpha, labels=False, font=None):
    import pygame

    wheel = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    span = 2 * math.pi / slot_count
    for i in range(slot_count):
        a0 = angle_offset + i * span
        a1 = a0 + span
        pts = []
        steps = 14
        for s in range(steps + 1):
            a = a0 + (a1 - a0) * s / steps
            pts.append((cx + r_outer * math.cos(a), cy + r_outer * math.sin(a)))
        for s in range(steps, -1, -1):
            a = a0 + (a1 - a0) * s / steps
            pts.append((cx + r_inner * math.cos(a), cy + r_inner * math.sin(a)))
        col = (*slot_colors[i % len(slot_colors)], max(0, min(255, int(alpha))))
        pygame.draw.polygon(wheel, col, [(int(x), int(y)) for x, y in pts])

        if labels and font:
            amid = (a0 + a1) * 0.5
            tx = cx + ((r_outer + r_inner) * 0.5) * math.cos(amid)
            ty = cy + ((r_outer + r_inner) * 0.5) * math.sin(amid)
            ts = font.render(str(i), True, (245, 245, 245))
            wheel.blit(ts, (int(tx - ts.get_width() / 2), int(ty - ts.get_height() / 2)))

    surf.blit(wheel, (0, 0))


def run(
    duration=18,
    output=None,
    fps=60,
    width=1080,
    height=1920,
    slot_count=16,
    spin_speed=0.65,
    effect_cooldown=10,
    show_slot_labels=False,
    ball_radius=24,
    ball_color="#ffffff",
    ball_glow=True,
    ball_trail=True,
    trail_length=20,
    glow_layers=5,
    ball_speed_min=4.0,
    ball_speed_max=8.0,
    gravity=0.20,
    bounce=0.99,
    friction=0.998,
    speed_limit=15.0,
    center_pull=0.0,
    slot_ring_width=38,
    slot_alpha=120,
    indicator_alpha=170,
    bg_color="#0d0d0d",
    bg_color2=None,
    bg_gradient_dir="vertical",
    collision_audio: dict | None = None,
    **kwargs,
):
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    slot_count = max(6, int(slot_count))
    effect_cooldown = max(1, int(effect_cooldown))

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"rouletteSlotsBall_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    total_frames = max(1, int(duration * fps))
    cx, cy = width // 2, height // 2
    cr = min(width, height) // 2 - 80

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    base_ball_color = _hex(ball_color)
    grad_surf = _gradient_surface(width, height, bg1, bg2, bg_gradient_dir) if bg2 else None

    # Roulette palette
    slot_colors = [
        _hex("#ff3344"),
        _hex("#223344"),
        _hex("#11bb66"),
        _hex("#2255ff"),
        _hex("#ffcc33"),
        _hex("#aa44ff"),
        _hex("#33ccee"),
        _hex("#ff8844"),
    ]

    # Effect wheel (cycled per slot index)
    effects = [
        "speed_up",
        "speed_down",
        "gravity_flip",
        "size_up",
        "size_down",
        "color_shift",
        "center_pull_toggle",
        "random_nudge",
    ]

    font = None
    if show_slot_labels:
        try:
            font = pygame.font.SysFont("DejaVu Sans", 24)
        except Exception:
            font = None

    ball = {
        "x": cx + random.uniform(-cr * 0.4, cr * 0.4),
        "y": cy + random.uniform(-cr * 0.4, cr * 0.4),
        "vx": random.choice([-1, 1]) * random.uniform(ball_speed_min, ball_speed_max),
        "vy": random.choice([-1, 1]) * random.uniform(ball_speed_min, ball_speed_max),
        "r": ball_radius,
        "trail": [],
        "effect_cd": 0,
        "color": base_ball_color,
        "gravity_sign": 1,
    }

    wheel_angle = 0.0
    last_slot = None

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg1, 255))

            # Draw roulette slots ring
            r_outer = cr
            r_inner = cr - max(8, int(slot_ring_width))
            _draw_slot_wheel(
                surface,
                cx,
                cy,
                r_outer,
                r_inner,
                slot_count,
                wheel_angle,
                slot_colors,
                slot_alpha,
                labels=show_slot_labels,
                font=font,
            )

            # Physics
            if center_pull > 0:
                ball["vx"] += (cx - ball["x"]) * center_pull * 0.001
                ball["vy"] += (cy - ball["y"]) * center_pull * 0.001

            ball["vy"] += gravity * ball["gravity_sign"]
            ball["vx"] *= friction
            ball["vy"] *= friction

            sp = math.hypot(ball["vx"], ball["vy"])
            if sp > speed_limit:
                s = speed_limit / sp
                ball["vx"] *= s
                ball["vy"] *= s

            ball["x"] += ball["vx"]
            ball["y"] += ball["vy"]

            # Circular boundary collision
            dx = ball["x"] - cx
            dy = ball["y"] - cy
            dist = math.hypot(dx, dy)
            max_d = cr - ball["r"]
            hit = False
            if dist > max_d and dist > 0:
                nx, ny = dx / dist, dy / dist
                ball["x"] = cx + nx * max_d
                ball["y"] = cy + ny * max_d
                dot = ball["vx"] * nx + ball["vy"] * ny
                ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
                ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
                hit = True
                log_wall_from_ball(audio, frame / fps, ball)

            # Slot effect on rim hit
            if ball["effect_cd"] > 0:
                ball["effect_cd"] -= 1

            if hit and ball["effect_cd"] <= 0:
                # map impact angle to slot index, accounting for wheel rotation
                ang = math.atan2(ball["y"] - cy, ball["x"] - cx) - wheel_angle
                ang = (ang + 2 * math.pi) % (2 * math.pi)
                slot_span = 2 * math.pi / slot_count
                slot_idx = int(ang / slot_span) % slot_count
                last_slot = slot_idx
                effect = effects[slot_idx % len(effects)]

                if effect == "speed_up":
                    ball["vx"] *= 1.18
                    ball["vy"] *= 1.18
                elif effect == "speed_down":
                    ball["vx"] *= 0.82
                    ball["vy"] *= 0.82
                elif effect == "gravity_flip":
                    ball["gravity_sign"] *= -1
                elif effect == "size_up":
                    ball["r"] = min(46, ball["r"] + 3)
                elif effect == "size_down":
                    ball["r"] = max(10, ball["r"] - 3)
                elif effect == "color_shift":
                    ball["color"] = random.choice(slot_colors)
                elif effect == "center_pull_toggle":
                    center_pull = 0.10 if center_pull <= 0 else 0.0
                elif effect == "random_nudge":
                    a = random.uniform(0, 2 * math.pi)
                    n = random.uniform(1.5, 4.0)
                    ball["vx"] += math.cos(a) * n
                    ball["vy"] += math.sin(a) * n

                ball["effect_cd"] = effect_cooldown

            # trails
            if ball_trail:
                ball["trail"].append((ball["x"], ball["y"], ball["r"]))
                if len(ball["trail"]) > trail_length:
                    ball["trail"].pop(0)
                n = len(ball["trail"])
                for i, (tx, ty, tr) in enumerate(ball["trail"]):
                    alpha = int(160 * (i / max(1, n)))
                    rad = max(2, int(tr * 0.62 * (i / max(1, n))))
                    _with_alpha_circle(surface, ball["color"], (int(tx), int(ty)), rad, alpha)

            # ball draw
            pos = (int(ball["x"]), int(ball["y"]))
            if ball_glow:
                _draw_glow(surface, ball["color"], pos, ball["r"], layers=glow_layers)
            pygame.draw.circle(surface, ball["color"], pos, ball["r"])
            pygame.draw.circle(surface, (255, 255, 255), (pos[0] - ball["r"] // 4, pos[1] - ball["r"] // 4), max(1, ball["r"] // 5))

            # slot hit indicator
            if last_slot is not None:
                isurf = pygame.Surface((width, height), pygame.SRCALPHA)
                slot_span = 2 * math.pi / slot_count
                a0 = wheel_angle + last_slot * slot_span
                a1 = a0 + slot_span
                amid = (a0 + a1) * 0.5
                ix = cx + (cr - slot_ring_width * 0.45) * math.cos(amid)
                iy = cy + (cr - slot_ring_width * 0.45) * math.sin(amid)
                pygame.draw.circle(isurf, (255, 255, 255, indicator_alpha), (int(ix), int(iy)), 8)
                surface.blit(isurf, (0, 0))

            wheel_angle += math.radians(spin_speed)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-framerate",
                str(fps),
                "-i",
                str(frames_dir / "frame_%06d.png"),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "fast",
                "-crf",
                "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)

