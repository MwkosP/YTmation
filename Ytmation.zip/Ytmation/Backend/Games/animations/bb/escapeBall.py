"""
Escape Ball — Full Customization
----------------------------------
A ball bounces inside a spinning shape that has a gap cut out of one side.
The ball escapes when it reaches the gap. Higher bounce keeps it alive longer.

CORE:
    end_behavior         : str   = "loop"   — "stop" | "loop" (restart ball when escaped)
    loop_count           : int   = 0        — max loops before stopping (0 = infinite)
    show_gap_indicator   : bool  = True     — subtle highlight on the gap opening

SPIN:
    spin_speed           : float = 1.5      — degrees per frame (+ = clockwise)
    spin_accelerate      : bool  = False    — spin gets faster over time
    spin_accel_rate      : float = 0.01     — degrees added per frame when accelerating
    spin_max_speed       : float = 8.0      — cap on spin speed if accelerating
    spin_direction       : str   = "cw"     — "cw" (clockwise) | "ccw"

GAP:
    gap_size             : float = 40.0     — degrees for circle; ignored for polygons (1 full side removed)
    gap_side             : int   = 0        — which side/segment has the gap (0 = top)

SHAPE:
    shape                : str   = "circle" — "circle"|"square"|"triangle"|"pentagon"|"hexagon"|"diamond"
    shape_radius         : int   = None
    ring_color           : str   = "#ffffff"
    ring_width           : int   = 6
    ring_glow            : bool  = False
    ring_double          : bool  = False
    ring_double_gap      : int   = 20

BALL:
    ball_color           : str   = None
    ball_radius          : int   = 22
    ball_glow            : bool  = True
    ball_trail           : bool  = True
    trail_length         : int   = 20
    ball_shine           : bool  = True
    ball_opacity         : int   = 255
    ball_image           : str   = None
    ball_speed           : float = 8.0
    ball_speed_min       : float = 6.0      — random speed range on respawn
    ball_speed_max       : float = 10.0

HIT EFFECTS:
    on_hit_flash         : bool  = False
    on_hit_particles     : bool  = False
    on_hit_ring_pulse    : bool  = False
    particle_count       : int   = 10
    particle_speed       : float = 1.2
    particle_colors      : list  = None
    bg_pulse_on_hit      : bool  = False

PHYSICS:
    gravity              : float = 0.0
    bounce               : float = 1.0      — keep at 1.0 for no energy loss
    friction             : float = 1.0

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"
    bg_image             : str   = None
    bg_image_alpha       : int   = 255

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 15
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=5):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*7, int(55/i))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i, (tx, ty, tr) in enumerate(trail):
        alpha = int(180 * (i / n))
        rad   = max(2, int(tr * 0.85 * (i / n)))
        _withAlpha(surf, color, (int(tx), int(ty)), rad, alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255 * (p["life"] / p["max_life"]))
        r     = max(1, int(p["r"] * (p["life"] / p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]), int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=10, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(2, 9) * speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({
            "x": x, "y": y,
            "vx": math.cos(angle)*speed,
            "vy": math.sin(angle)*speed,
            "r":  random.randint(3, 9),
            "color": c,
            "life": random.randint(12, 28),
            "max_life": 28,
        })
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x/w
            pygame.draw.line(surf, tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)), (x,0),(x,h))
    elif direction == "radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img = pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img, size)


# ── shape / gap drawing ────────────────────────────────────────────────────────

_SHAPE_SIDES = {"triangle":3, "diamond":4, "pentagon":5, "hexagon":6}

def _shapeVertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [(cx + size*math.cos(angle_offset + 2*math.pi*i/sides - math.pi/2),
             cy + size*math.sin(angle_offset + 2*math.pi*i/sides - math.pi/2))
            for i in range(sides)]

def _angleInArc(angle, gap_start, gap_end):
    """Check if angle (radians) falls inside the gap arc [gap_start, gap_end]."""
    angle    = angle % (2*math.pi)
    gap_start = gap_start % (2*math.pi)
    gap_end   = gap_end   % (2*math.pi)
    if gap_start <= gap_end:
        return gap_start <= angle <= gap_end
    else:  # wraps around 0
        return angle >= gap_start or angle <= gap_end

def _drawCircleWithGap(surf, color, cx, cy, r, width,
                       gap_start_deg, gap_end_deg, glow=False):
    """Draw a circle arc skipping the gap region."""
    import pygame
    gap_s = math.radians(gap_start_deg) % (2*math.pi)
    gap_e = math.radians(gap_end_deg)   % (2*math.pi)

    # draw in segments of ~2 degrees, skip gap
    step  = math.radians(2)
    a     = 0.0
    pts   = []
    while a < 2*math.pi:
        if not _angleInArc(a, gap_s, gap_e):
            pts.append((cx + r*math.cos(a), cy + r*math.sin(a)))
        else:
            if len(pts) > 1:
                pygame.draw.lines(surf, color, False,
                    [(int(x),int(y)) for x,y in pts], width)
            pts = []
        a += step
    if len(pts) > 1:
        pygame.draw.lines(surf, color, False,
            [(int(x),int(y)) for x,y in pts], width)

def _drawPolygonWithGap(surf, color, cx, cy, size, shape,
                        angle_offset, gap_side, ring_width, glow=False):
    """Draw polygon edges, skipping the gap_side edge entirely."""
    import pygame
    verts = _shapeVertices(shape, cx, cy, size, angle_offset)
    n     = len(verts)
    for i in range(n):
        if i == gap_side % n:
            continue  # skip this edge — it's the gap
        a = verts[i]
        b = verts[(i+1) % n]
        pygame.draw.line(surf, color, (int(a[0]),int(a[1])), (int(b[0]),int(b[1])), ring_width)

def _drawGapIndicator(surf, shape, cx, cy, cr, angle_offset,
                      gap_start_rad, gap_end_rad, gap_side, color=(255,200,0,120)):
    """Draw a subtle highlight where the gap is."""
    import pygame
    if shape == "circle":
        step = math.radians(2)
        pts  = []
        a    = gap_start_rad
        while a <= gap_end_rad + 0.01:
            pts.append((int(cx + cr*math.cos(a)), int(cy + cr*math.sin(a))))
            a += step
        if len(pts) > 1:
            s = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
            pygame.draw.lines(s, color, False, pts, 8)
            surf.blit(s, (0,0))
    else:
        verts = _shapeVertices(shape, cx, cy, cr, angle_offset)
        n     = len(verts)
        gi    = gap_side % n
        a     = verts[gi]
        b     = verts[(gi+1) % n]
        s     = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        pygame.draw.line(s, color, (int(a[0]),int(a[1])), (int(b[0]),int(b[1])), 8)
        surf.blit(s, (0,0))

def _drawShapeGlow(surf, color, cx, cy, size, shape, angle_offset,
                   gap_start_rad, gap_end_rad, gap_side, layers=3):
    import pygame
    for i in range(layers, 0, -1):
        gs    = size + i*8
        alpha = int(50/i)
        s     = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        gc    = (*color[:3], alpha)
        gw    = max(2, i*3)
        if shape == "circle":
            _drawCircleWithGap(s, gc, cx, cy, gs, gw,
                               math.degrees(gap_start_rad),
                               math.degrees(gap_end_rad))
        else:
            _drawPolygonWithGap(s, gc, cx, cy, gs, shape, angle_offset, gap_side, gw)
        surf.blit(s, (0,0))


# ── collision — gap-aware ──────────────────────────────────────────────────────

def _closestPointOnSegment(px,py,ax,ay,bx,by):
    dx,dy = bx-ax,by-ay
    t = max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2,cy2 = ax+t*dx,ay+t*dy
    nx,ny = px-cx2,py-cy2
    dist = math.hypot(nx,ny)
    if dist<1e-6: nx,ny,dist=-dy,dx,math.hypot(-dy,dx)
    return cx2,cy2,nx/dist,ny/dist,dist

def _resolveCircleWithGap(ball, br, cx, cy, cr, bounce,
                           gap_start_rad, gap_end_rad):
    """
    Returns: "bounce" | "escape" | None
    """
    dx,dy = ball["x"]-cx, ball["y"]-cy
    dist  = math.hypot(dx,dy)
    md    = cr - br

    if dist > md:
        angle = math.atan2(dy, dx) % (2*math.pi)
        if _angleInArc(angle, gap_start_rad, gap_end_rad):
            return "escape"
        # solid wall — bounce
        nx,ny = dx/dist, dy/dist
        ball["x"] = cx + nx*md
        ball["y"] = cy + ny*md
        dot = ball["vx"]*nx + ball["vy"]*ny
        ball["vx"] = (ball["vx"] - 2*dot*nx) * bounce
        ball["vy"] = (ball["vy"] - 2*dot*ny) * bounce
        return "bounce"
    return None

def _resolvePolygonWithGap(ball, br, cx, cy, cr, shape,
                            angle_offset, gap_side, bounce):
    """
    Returns: "bounce" | "escape" | None
    """
    verts = _shapeVertices(shape, cx, cy, cr, angle_offset)
    n     = len(verts)
    result = None
    bx,by = ball["x"], ball["y"]

    for i in range(n):
        ax,ay = verts[i]
        bvx,bvy = verts[(i+1)%n]
        cpx,cpy,nx,ny,dist = _closestPointOnSegment(bx,by,ax,ay,bvx,bvy)
        tcx,tcy = cx-cpx,cy-cpy
        if nx*tcx+ny*tcy < 0: nx,ny = -nx,-ny

        if dist < br:
            if i == gap_side % n:
                # ball reached the gap edge — escape!
                return "escape"
            # solid edge — bounce
            ball["x"] += nx*(br-dist)
            ball["y"] += ny*(br-dist)
            dot = ball["vx"]*nx + ball["vy"]*ny
            if dot < 0:
                ball["vx"] = (ball["vx"]-2*dot*nx)*bounce
                ball["vy"] = (ball["vy"]-2*dot*ny)*bounce
            result = "bounce"

    return result


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    # output
    duration: int               = 15,
    output: Path                = None,
    fps: int                    = 60,
    width: int                  = 1080,
    height: int                 = 1920,
    # core
    end_behavior: str           = "loop",
    loop_count: int             = 0,
    show_gap_indicator: bool    = True,
    # spin
    spin_speed: float           = 1.5,
    spin_accelerate: bool       = False,
    spin_accel_rate: float      = 0.01,
    spin_max_speed: float       = 8.0,
    spin_direction: str         = "cw",
    # gap
    gap_size: float             = 40.0,
    gap_side: int               = 0,
    # shape
    shape: str                  = "circle",
    shape_radius: int           = None,
    ring_color: str             = "#ffffff",
    ring_width: int             = 6,
    ring_glow: bool             = False,
    ring_double: bool           = False,
    ring_double_gap: int        = 20,
    # ball
    ball_color: str             = None,
    ball_radius: int            = 22,
    ball_glow: bool             = True,
    ball_trail: bool            = True,
    trail_length: int           = 20,
    ball_shine: bool            = True,
    ball_opacity: int           = 255,
    ball_image: str             = None,
    ball_speed: float           = 8.0,
    ball_speed_min: float       = 6.0,
    ball_speed_max: float       = 10.0,
    # hit effects
    on_hit_flash: bool          = False,
    on_hit_particles: bool      = False,
    on_hit_ring_pulse: bool     = False,
    particle_count: int         = 10,
    particle_speed: float       = 1.2,
    particle_colors: list       = None,
    bg_pulse_on_hit: bool       = False,
    # physics
    gravity: float              = 0.0,
    bounce: float               = 1.0,
    friction: float             = 1.0,
    # background
    bg_color: str               = "#0d0d0d",
    bg_color2: str              = None,
    bg_gradient_dir: str        = "vertical",
    bg_image: str               = None,
    bg_image_alpha: int         = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape          = shape.lower().strip()
    spin_direction = spin_direction.lower().strip()
    sign           = -1 if spin_direction == "ccw" else 1

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"escapeBall_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width, height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    rc           = _hex(ring_color)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    cr = shape_radius or (min(width, height) // 2 - 80)

    bc = _hex(ball_color) if ball_color else (
        random.randint(80,255), random.randint(80,255), random.randint(80,255))

    # pre-load assets
    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image, (width, height))
        if bg_image_alpha < 255: raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    ball_img = None
    if ball_image and Path(ball_image).exists():
        ball_img = _loadImage(ball_image, (ball_radius*2, ball_radius*2))

    def _spawnBall():
        spd   = random.uniform(ball_speed_min, ball_speed_max)
        angle = random.uniform(0, 2*math.pi)
        return {
            "x":  float(cx + random.randint(-cr//4, cr//4)),
            "y":  float(cy + random.randint(-cr//4, cr//4)),
            "vx": math.cos(angle) * spd,
            "vy": math.sin(angle) * spd,
            "trail": [],
            "escaped": False,
        }

    ball         = _spawnBall()
    shape_angle  = 0.0        # radians, current rotation of shape
    cur_spin     = spin_speed # current spin speed (may accelerate)
    particles    = []
    ring_pulse   = 0
    bg_flash     = 0
    flash_timer  = 0
    loops_done   = 0
    done         = False

    # gap in radians for circle (computed from shape_angle each frame)
    gap_half_rad = math.radians(gap_size / 2)

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                # still render last frame frozen
                pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
                continue

            # ── spin update ───────────────────────────────────────────────
            if spin_accelerate:
                cur_spin = min(spin_max_speed, cur_spin + spin_accel_rate)
            shape_angle += sign * math.radians(cur_spin)

            # gap position in world space (rotates with shape)
            # gap_side for polygon is the edge index; for circle it's an angle
            if shape == "circle":
                # gap centered at shape_angle + gap_side * (pi/2) for variety
                gap_center  = shape_angle + math.radians(gap_side * 90)
                gap_start_r = (gap_center - gap_half_rad) % (2*math.pi)
                gap_end_r   = (gap_center + gap_half_rad) % (2*math.pi)
            else:
                gap_start_r = gap_end_r = 0.0  # unused for polygons

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255)); surface.blit(bg_img_surf,(0,0))
            elif grad_surf:
                surface.blit(grad_surf,(0,0))
            else:
                fa = min(bg_flash*8,40)
                surface.fill((min(255,bg[0]+fa),min(255,bg[1]+fa),min(255,bg[2]+fa),255))
            if bg_flash > 0: bg_flash -= 1

            # ── ring ──────────────────────────────────────────────────────
            cur_rc  = rc
            pulse_r = cr + int(ring_pulse)

            if ring_glow:
                _drawShapeGlow(surface, cur_rc, cx, cy, pulse_r, shape, shape_angle,
                               gap_start_r, gap_end_r, gap_side)

            if shape == "circle":
                _drawCircleWithGap(surface, cur_rc, cx, cy, pulse_r, ring_width,
                                   math.degrees(gap_start_r), math.degrees(gap_end_r))
                if ring_double:
                    inner = max(10, pulse_r - ring_double_gap)
                    _drawCircleWithGap(surface, (*cur_rc,90), cx, cy, inner,
                                       max(1,ring_width-1),
                                       math.degrees(gap_start_r), math.degrees(gap_end_r))
            else:
                _drawPolygonWithGap(surface, cur_rc, cx, cy, pulse_r, shape,
                                    shape_angle, gap_side, ring_width)
                if ring_double:
                    inner = max(10, pulse_r - ring_double_gap)
                    _drawPolygonWithGap(surface, (*cur_rc,90), cx, cy, inner, shape,
                                        shape_angle, gap_side, max(1,ring_width-1))

            # gap indicator
            if show_gap_indicator:
                _drawGapIndicator(surface, shape, cx, cy, pulse_r, shape_angle,
                                  gap_start_r, gap_end_r, gap_side,
                                  color=(255,220,50,140))

            if ring_pulse > 0: ring_pulse = max(0, ring_pulse-2)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface, particles)
                for p in particles:
                    p["x"]+=p["vx"]; p["y"]+=p["vy"]
                    p["vy"]+=0.2;    p["life"]-=1
                particles = [p for p in particles if p["life"]>0]

            # ── physics ───────────────────────────────────────────────────
            if not ball["escaped"]:
                ball["vy"] += gravity
                ball["vx"] *= friction
                ball["vy"] *= friction
                ball["x"]  += ball["vx"]
                ball["y"]  += ball["vy"]

                # maintain speed
                spd = math.hypot(ball["vx"], ball["vy"])
                if spd > 0:
                    ball["vx"] = ball["vx"]/spd * ball_speed
                    ball["vy"] = ball["vy"]/spd * ball_speed

                # collision
                if shape == "circle":
                    result = _resolveCircleWithGap(
                        ball, ball_radius, cx, cy, cr, bounce,
                        gap_start_r, gap_end_r)
                else:
                    result = _resolvePolygonWithGap(
                        ball, ball_radius, cx, cy, cr, shape,
                        shape_angle, gap_side, bounce)

                if result == "escape":
                    ball["escaped"] = True
                    print(f"   Ball escaped at frame {frame}!")
                    if on_hit_particles:
                        particles += _spawnParticles(
                            ball["x"], ball["y"], bc, pcolors,
                            count=particle_count*2, speed_mult=particle_speed*1.5)

                elif result == "bounce":
                    log_wall_from_ball(audio, frame / fps, ball)
                    if on_hit_flash:      flash_timer = 6
                    if on_hit_ring_pulse: ring_pulse  = 18
                    if bg_pulse_on_hit:   bg_flash    = 4
                    if on_hit_particles:
                        particles += _spawnParticles(
                            ball["x"], ball["y"], bc, pcolors,
                            count=particle_count, speed_mult=particle_speed)

                # trail
                if ball_trail:
                    ball["trail"].append((ball["x"], ball["y"], ball_radius))
                    if len(ball["trail"]) > trail_length:
                        ball["trail"].pop(0)

            else:
                # ball escaped — fly off screen, then loop or stop
                ball["x"] += ball["vx"]
                ball["y"] += ball["vy"]
                off = max(width, height) + 100
                if (abs(ball["x"]-cx) > off or abs(ball["y"]-cy) > off):
                    loops_done += 1
                    if end_behavior == "loop" and (loop_count == 0 or loops_done < loop_count):
                        ball = _spawnBall()
                        if spin_accelerate:
                            cur_spin = min(spin_max_speed, cur_spin + 0.5)
                    else:
                        done = True

            # ── draw trail ────────────────────────────────────────────────
            if ball_trail:
                _drawTrail(surface, ball["trail"], bc)

            # ── draw ball ─────────────────────────────────────────────────
            pos        = (int(ball["x"]), int(ball["y"]))
            draw_color = _lighten(bc, 180) if flash_timer > 0 else bc

            if ball_glow:
                _drawGlow(surface, draw_color, pos, ball_radius)

            if ball_img:
                scaled = pygame.transform.smoothscale(ball_img, (ball_radius*2, ball_radius*2))
                if ball_opacity < 255: scaled.set_alpha(ball_opacity)
                surface.blit(scaled, (pos[0]-ball_radius, pos[1]-ball_radius))
            else:
                if ball_opacity < 255:
                    _withAlpha(surface, draw_color, pos, ball_radius, ball_opacity)
                else:
                    pygame.draw.circle(surface, draw_color, pos, ball_radius)
                if ball_shine and ball_radius > 6:
                    pygame.draw.circle(surface, (255,255,255),
                        (pos[0]-ball_radius//4, pos[1]-ball_radius//4),
                        max(1,ball_radius//5))

            if flash_timer > 0: flash_timer -= 1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))

            if frame % (fps*2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| spin: {cur_spin:.2f}°/f | loops: {loops_done}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", str(fps),
            "-i", str(frames_dir/"frame_%06d.png"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "fast", "-crf", "18",
            str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)