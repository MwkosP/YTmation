"""
Team Balls — Push the Puck
----------------------------
Two teams of balls compete to push a neutral puck into the opponent goal.
Left team attacks right goal, right team attacks left goal.

GAME:
    team_size            : int   = 5
    score_to_win         : int   = 7
    end_behavior         : str   = "loop"   — "loop"|"stop"
    loop_count           : int   = 0         — 0 = infinite (for loop mode)
    reset_delay_frames   : int   = 45

TEAMS:
    team_a_color         : str   = "#ff4444"
    team_b_color         : str   = "#4488ff"
    team_radius          : int   = 20
    team_speed_limit     : float = 8.5
    attack_force         : float = 0.24      — acceleration toward puck/opponent goal
    support_force        : float = 0.07      — spacing/positioning noise

PUCK:
    puck_color           : str   = "#ffffff"
    puck_radius          : int   = 15
    puck_speed_limit     : float = 14.0
    puck_bounce          : float = 0.995

GOALS:
    goal_width           : int   = 70
    goal_height_ratio    : float = 0.32      — fraction of arena height
    goal_color           : str   = "#ffffff"
    goal_alpha           : int   = 120

LOOK:
    ball_glow            : bool  = True
    ball_trail           : bool  = True
    trail_length         : int   = 18
    glow_layers          : int   = 4
    show_score           : bool  = True

PHYSICS:
    friction             : float = 0.994
    bounce               : float = 0.98
    collision_bounce     : float = 0.96

SHAPE:
    shape                : str   = "circle" — "circle","square","triangle","pentagon","hexagon","diamond"
    circle_radius        : int   = None
    ring_color           : str   = "#ffffff"
    ring_width           : int   = 4
    ring_glow            : bool  = False
    ring_dash            : bool  = False
    ring_spin            : bool  = False
    ring_spin_speed      : float = 0.5

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 20
"""

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


def _hex(h):
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _with_alpha_circle(surf, color, pos, r, alpha):
    import pygame

    if r <= 0 or alpha <= 0:
        return
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0] - r, pos[1] - r))


def _draw_glow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _with_alpha_circle(surf, color, pos, r + i * 6, int(50 / i))


def _gradient_surface(w, h, c1, c2, direction="vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (x, 0), (x, h))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_d = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max_d)
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                surf.set_at((x, y), (r, g, b))
    else:
        for y in range(h):
            t = y / max(1, h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (0, y), (w, y))
    return surf


_SHAPE_SIDES = {"triangle": 3, "diamond": 4, "pentagon": 5, "hexagon": 6}


def _shape_vertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [
        (
            cx + size * math.cos(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
            cy + size * math.sin(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
        )
        for i in range(sides)
    ]


def _closest_point_on_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-9)
    t = max(0.0, min(1.0, t))
    cx2 = ax + t * dx
    cy2 = ay + t * dy
    nx = px - cx2
    ny = py - cy2
    dist = math.hypot(nx, ny)
    if dist < 1e-6:
        nx, ny = -dy, dx
        dist = math.hypot(nx, ny)
    return cx2, cy2, nx / dist, ny / dist, dist


def _resolve_shape_collision(ball, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx, by, br = ball["x"], ball["y"], ball["r"]
    hit = False
    if shape == "circle":
        dx, dy = bx - cx, by - cy
        dist = math.hypot(dx, dy)
        md = size - br
        if dist > md and dist > 0:
            nx, ny = dx / dist, dy / dist
            ball["x"] = cx + nx * md
            ball["y"] = cy + ny * md
            dot = ball["vx"] * nx + ball["vy"] * ny
            ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
            ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
            hit = True
    elif shape == "square":
        half = size - br
        if bx < cx - half:
            ball["x"] = cx - half
            ball["vx"] = abs(ball["vx"]) * bounce
            hit = True
        elif bx > cx + half:
            ball["x"] = cx + half
            ball["vx"] = -abs(ball["vx"]) * bounce
            hit = True
        if by < cy - half:
            ball["y"] = cy - half
            ball["vy"] = abs(ball["vy"]) * bounce
            hit = True
        elif by > cy + half:
            ball["y"] = cy + half
            ball["vy"] = -abs(ball["vy"]) * bounce
            hit = True
    else:
        verts = _shape_vertices(shape, cx, cy, size, angle_offset)
        for i in range(len(verts)):
            ax, ay = verts[i]
            bx2, by2 = verts[(i + 1) % len(verts)]
            cpx, cpy, nx, ny, dist = _closest_point_on_segment(bx, by, ax, ay, bx2, by2)
            to_center_x = cx - cpx
            to_center_y = cy - cpy
            if nx * to_center_x + ny * to_center_y < 0:
                nx, ny = -nx, -ny
            if dist < br:
                overlap = br - dist
                ball["x"] += nx * overlap
                ball["y"] += ny * overlap
                dot = ball["vx"] * nx + ball["vy"] * ny
                if dot < 0:
                    ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
                    ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
                hit = True
    if hit and audio is not None:
        from Games.collision_audio import log_wall_from_ball
        log_wall_from_ball(audio, t, ball)
    return hit


def _draw_shape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame

    if shape == "circle":
        if dash:
            n = max(1, int(math.pi * size / 20))
            for i in range(n):
                a0 = (2 * math.pi / n) * i
                a1 = a0 + math.pi / n
                pts = []
                for s in range(11):
                    a = a0 + (a1 - a0) * s / 10
                    pts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
                if len(pts) > 1:
                    pygame.draw.lines(surf, color, False, pts, width)
        else:
            pygame.draw.circle(surf, color, (cx, cy), size, width)
        return
    if shape == "square":
        half = size
        pygame.draw.rect(surf, color, pygame.Rect(cx - half, cy - half, half * 2, half * 2), width)
        return
    verts = _shape_vertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x), int(y)) for x, y in verts], width)


def _resolve_pair_collision(a, b, bounce=0.96):
    dx = b["x"] - a["x"]
    dy = b["y"] - a["y"]
    dist = math.hypot(dx, dy)
    min_d = a["r"] + b["r"]
    if dist <= 1e-9 or dist >= min_d:
        return
    nx, ny = dx / dist, dy / dist
    overlap = (min_d - dist) / 2
    a["x"] -= nx * overlap
    a["y"] -= ny * overlap
    b["x"] += nx * overlap
    b["y"] += ny * overlap
    rvx = a["vx"] - b["vx"]
    rvy = a["vy"] - b["vy"]
    rel = rvx * nx + rvy * ny
    if rel <= 0:
        a["vx"] = (a["vx"] - rel * nx) * bounce
        a["vy"] = (a["vy"] - rel * ny) * bounce
        b["vx"] = (b["vx"] + rel * nx) * bounce
        b["vy"] = (b["vy"] + rel * ny) * bounce


def run(
    duration=20,
    output=None,
    fps=60,
    width=1080,
    height=1920,
    team_size=5,
    score_to_win=7,
    end_behavior="loop",
    loop_count=0,
    reset_delay_frames=45,
    team_a_color="#ff4444",
    team_b_color="#4488ff",
    team_radius=20,
    team_speed_limit=8.5,
    attack_force=0.24,
    support_force=0.07,
    puck_color="#ffffff",
    puck_radius=15,
    puck_speed_limit=14.0,
    puck_bounce=0.995,
    goal_width=70,
    goal_height_ratio=0.32,
    goal_color="#ffffff",
    goal_alpha=120,
    ball_glow=True,
    ball_trail=True,
    trail_length=18,
    glow_layers=4,
    show_score=True,
    friction=0.994,
    bounce=0.98,
    collision_bounce=0.96,
    shape="circle",
    circle_radius=None,
    ring_color="#ffffff",
    ring_width=4,
    ring_glow=False,
    ring_dash=False,
    ring_spin=False,
    ring_spin_speed=0.5,
    bg_color="#0d0d0d",
    bg_color2=None,
    bg_gradient_dir="vertical",
    collision_audio: dict | None = None,
    **kwargs,
):
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = (shape or "circle").lower().strip()
    end_behavior = (end_behavior or "loop").lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"teamBalls_{shape}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    total_frames = max(1, int(duration * fps))
    cx, cy = width // 2, height // 2
    cr = circle_radius or (min(width, height) // 2 - 80)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    rc = _hex(ring_color)
    c_a = _hex(team_a_color)
    c_b = _hex(team_b_color)
    c_p = _hex(puck_color)
    c_g = _hex(goal_color)
    grad_surf = _gradient_surface(width, height, bg1, bg2, bg_gradient_dir) if bg2 else None

    font = None
    if show_score:
        try:
            font = pygame.font.SysFont("DejaVu Sans", 34)
        except Exception:
            font = None

    goal_h = int((cr * 2) * max(0.1, min(0.95, goal_height_ratio)))
    goal_y0 = cy - goal_h // 2
    goal_y1 = cy + goal_h // 2

    def spawn_side(left=True):
        side = -1 if left else 1
        x = cx + side * random.uniform(cr * 0.18, cr * 0.65)
        y = cy + random.uniform(-cr * 0.6, cr * 0.6)
        return x, y

    def make_player(team):
        left = team == "A"
        x, y = spawn_side(left=left)
        return {"team": team, "x": x, "y": y, "vx": random.uniform(-2, 2), "vy": random.uniform(-2, 2), "r": team_radius, "trail": []}

    def reset_round():
        players = [make_player("A") for _ in range(max(1, int(team_size)))] + [make_player("B") for _ in range(max(1, int(team_size)))]
        puck = {"x": cx, "y": cy, "vx": random.uniform(-2.5, 2.5), "vy": random.uniform(-2.5, 2.5), "r": puck_radius, "trail": []}
        return players, puck

    players, puck = reset_round()
    score_a = 0
    score_b = 0
    loops_done = 0
    reset_timer = 0
    angle_offset = 0.0
    game_over = False

    def step_body(b, spd_limit, shape_bounce):
        b["vx"] *= friction
        b["vy"] *= friction
        sp = math.hypot(b["vx"], b["vy"])
        if sp > spd_limit:
            s = spd_limit / sp
            b["vx"] *= s
            b["vy"] *= s
        b["x"] += b["vx"]
        b["y"] += b["vy"]
        _resolve_shape_collision(b, shape, cx, cy, cr, shape_bounce, angle_offset, audio=audio if audio.enabled else None, t=frame / fps)

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg1, 255))

            # arena ring
            if ring_glow:
                _draw_glow(surface, rc, (cx, cy), cr, layers=3)
            _draw_shape(surface, shape, rc, cx, cy, cr, ring_width, angle_offset, dash=ring_dash)

            # goal visuals (left/right windows)
            gsurf = pygame.Surface((width, height), pygame.SRCALPHA)
            pygame.draw.rect(gsurf, (*c_g, max(0, min(255, int(goal_alpha)))), pygame.Rect(cx - cr - goal_width // 2, goal_y0, goal_width, goal_h), border_radius=10)
            pygame.draw.rect(gsurf, (*c_g, max(0, min(255, int(goal_alpha)))), pygame.Rect(cx + cr - goal_width // 2, goal_y0, goal_width, goal_h), border_radius=10)
            surface.blit(gsurf, (0, 0))

            if not game_over and reset_timer <= 0:
                # team AI
                for p in players:
                    if p["team"] == "A":
                        goal_x = cx + cr
                        mate_sign = -1
                    else:
                        goal_x = cx - cr
                        mate_sign = 1
                    to_puck_x = puck["x"] - p["x"]
                    to_puck_y = puck["y"] - p["y"]
                    d = math.hypot(to_puck_x, to_puck_y) + 1e-9
                    nx, ny = to_puck_x / d, to_puck_y / d

                    # attack: approach puck, biased toward opponent goal direction
                    gx = goal_x - puck["x"]
                    gy = cy - puck["y"]
                    gd = math.hypot(gx, gy) + 1e-9
                    gnx, gny = gx / gd, gy / gd

                    p["vx"] += nx * attack_force + gnx * (attack_force * 0.35)
                    p["vy"] += ny * attack_force + gny * (attack_force * 0.35)

                    # support: soft horizontal spread so teammates don't stack too much
                    p["vx"] += mate_sign * support_force * random.uniform(0.2, 1.0)
                    p["vy"] += random.uniform(-support_force, support_force)

                # physics
                for p in players:
                    step_body(p, team_speed_limit, bounce)
                step_body(puck, puck_speed_limit, puck_bounce)

                # collisions players<->players and players<->puck
                for i in range(len(players)):
                    for j in range(i + 1, len(players)):
                        _resolve_pair_collision(players[i], players[j], collision_bounce)
                for p in players:
                    _resolve_pair_collision(p, puck, collision_bounce)

                # goal detection (puck crosses left/right in goal y-window)
                if goal_y0 <= puck["y"] <= goal_y1:
                    if puck["x"] <= cx - cr:
                        # right team scores on left goal
                        score_b += 1
                        reset_timer = max(1, int(reset_delay_frames))
                    elif puck["x"] >= cx + cr:
                        # left team scores on right goal
                        score_a += 1
                        reset_timer = max(1, int(reset_delay_frames))

                if score_a >= score_to_win or score_b >= score_to_win:
                    loops_done += 1
                    if end_behavior == "loop" and (loop_count == 0 or loops_done < loop_count):
                        score_a = 0
                        score_b = 0
                        players, puck = reset_round()
                    else:
                        game_over = True

            else:
                reset_timer -= 1
                if reset_timer <= 0 and not game_over:
                    players, puck = reset_round()

            # trails
            if ball_trail:
                for b in players + [puck]:
                    b["trail"].append((b["x"], b["y"], b["r"]))
                    if len(b["trail"]) > trail_length:
                        b["trail"].pop(0)

            def draw_ball(b, color):
                pos = (int(b["x"]), int(b["y"]))
                if ball_trail:
                    n = len(b["trail"])
                    for i, (tx, ty, tr) in enumerate(b["trail"]):
                        alpha = int(150 * (i / max(1, n)))
                        rad = max(2, int(tr * 0.58 * (i / max(1, n))))
                        _with_alpha_circle(surface, color, (int(tx), int(ty)), rad, alpha)
                if ball_glow:
                    _draw_glow(surface, color, pos, b["r"], layers=glow_layers)
                pygame.draw.circle(surface, color, pos, b["r"])

            for p in players:
                draw_ball(p, c_a if p["team"] == "A" else c_b)
            draw_ball(puck, c_p)

            if show_score and font:
                s = font.render(f"{score_a}  -  {score_b}", True, (245, 245, 245))
                surface.blit(s, (cx - s.get_width() // 2, 25))

            if ring_spin:
                angle_offset += math.radians(ring_spin_speed)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%) | score {score_a}-{score_b}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-framerate",
                str(fps),
                "-i",
                str(frames_dir / "frame_%06d.png"),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "fast",
                "-crf",
                "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)

