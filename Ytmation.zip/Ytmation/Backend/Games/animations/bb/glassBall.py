"""
Glass Ball — Full Customization
---------------------------------
A ball bounces inside a shape that cracks on each hit.
After enough hits the shape shatters and the ball escapes.

CORE:
    max_hits             : int   = 12      — hits before shattering
    end_behavior         : str   = "loop"  — "stop" | "loop" (reset after shatter)
    loop_count           : int   = 0
    shatter_frames       : int   = 60      — how long shatter animation plays

SHAPE:
    shape                : str   = "circle"
    shape_radius         : int   = None
    ring_color_intact    : str   = "#aaddff"  — color when undamaged
    ring_color_damaged   : str   = "#ff4400"  — color when near breaking
    ring_width           : int   = 5
    ring_glow            : bool  = True
    ring_spin            : bool  = False
    ring_spin_speed      : float = 0.5
    ring_double          : bool  = False
    ring_double_gap      : int   = 20

CRACKS:
    crack_style          : str   = "spiderweb" — "radial"|"spiderweb"|"lightning"
    crack_count_per_hit  : int   = 3           — crack lines per hit
    crack_length         : int   = None        — auto
    crack_branch_depth   : int   = 2           — sub-branches per crack
    crack_color          : str   = None        — auto matches ring damage color
    crack_width          : int   = 1
    crack_opacity_start  : int   = 220

BALL:
    ball_color           : str   = None
    ball_radius          : int   = 22
    ball_glow            : bool  = True
    ball_trail           : bool  = True
    trail_length         : int   = 20
    ball_shine           : bool  = True
    ball_opacity         : int   = 255
    ball_speed           : float = 7.0

HIT EFFECTS:
    on_hit_flash         : bool  = True
    on_hit_particles     : bool  = True
    particle_count       : int   = 8
    particle_speed       : float = 1.5
    particle_colors      : list  = None
    screen_shake         : bool  = True     — shake intensity grows with damage
    shake_intensity      : int   = 4

PHYSICS:
    gravity              : float = 0.0
    bounce               : float = 1.0
    friction             : float = 1.0

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"
    bg_image             : str   = None
    bg_image_alpha       : int   = 255

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 20
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _lerpColor(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(c1[i]+(c2[i]-c1[i])*t) for i in range(3))

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*7, int(55/i))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i,(tx,ty,tr) in enumerate(trail):
        alpha = int(160*(i/n))
        rad   = max(2, int(tr*0.75*(i/n)))
        _withAlpha(surf, color, (int(tx),int(ty)), rad, alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255*(p["life"]/p["max_life"]))
        r     = max(1, int(p["r"]*(p["life"]/p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]),int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=8, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0,2*math.pi)
        speed = random.uniform(2,9)*speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({"x":x,"y":y,
                    "vx":math.cos(angle)*speed,"vy":math.sin(angle)*speed,
                    "r":random.randint(3,9),"color":c,
                    "life":random.randint(12,28),"max_life":28})
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w,h))
    if direction=="horizontal":
        for x in range(w):
            t=x/w
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(x,0),(x,h))
    elif direction=="radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img = pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img, size)


# ── shape helpers ──────────────────────────────────────────────────────────────

_SHAPE_SIDES = {"triangle":3,"diamond":4,"pentagon":5,"hexagon":6,"heptagon":7,"octagon":8}

def _shapeVertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [(cx+size*math.cos(angle_offset+2*math.pi*i/sides-math.pi/2),
             cy+size*math.sin(angle_offset+2*math.pi*i/sides-math.pi/2))
            for i in range(sides)]

def _drawShape(surf, shape, color, cx, cy, size, width, angle_offset=0.0):
    import pygame
    if size <= 0: return
    if shape=="circle":
        pygame.draw.circle(surf,color,(cx,cy),int(size),width)
    elif shape=="square":
        s=int(size); pygame.draw.rect(surf,color,pygame.Rect(cx-s,cy-s,s*2,s*2),width)
    else:
        verts=_shapeVertices(shape,cx,cy,size,angle_offset)
        pygame.draw.polygon(surf,color,[(int(x),int(y)) for x,y in verts],width)

def _closestPointOnSegment(px,py,ax,ay,bx,by):
    dx,dy=bx-ax,by-ay
    t=max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2,cy2=ax+t*dx,ay+t*dy; nx,ny=px-cx2,py-cy2
    dist=math.hypot(nx,ny)
    if dist<1e-6: nx,ny,dist=-dy,dx,math.hypot(-dy,dx)
    return cx2,cy2,nx/dist,ny/dist,dist

def _resolveShapeCollision(ball, br, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    """Returns (hit: bool, impact_x: float, impact_y: float, normal: (nx,ny))"""
    bx,by = ball["x"],ball["y"]
    if shape=="circle":
        dx,dy=bx-cx,by-cy; dist=math.hypot(dx,dy); md=size-br
        if dist>md:
            nx,ny=dx/dist,dy/dist
            ix,iy=cx+nx*size, cy+ny*size   # impact point on wall
            ball["x"]=cx+nx*md; ball["y"]=cy+ny*md
            dot=ball["vx"]*nx+ball["vy"]*ny
            ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
            ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True,ix,iy,(nx,ny)
        return False,0,0,(0,0)
    elif shape=="square":
        half=size-br; hit=False; nx,ny=0.0,0.0; ix,iy=bx,by
        if bx<cx-half:
            ix=cx-half; ball["x"]=cx-half; ball["vx"]=abs(ball["vx"])*bounce; nx=-1; hit=True
        elif bx>cx+half:
            ix=cx+half; ball["x"]=cx+half; ball["vx"]=-abs(ball["vx"])*bounce; nx=1; hit=True
        if by<cy-half:
            iy=cy-half; ball["y"]=cy-half; ball["vy"]=abs(ball["vy"])*bounce; ny=-1; hit=True
        elif by>cy+half:
            iy=cy+half; ball["y"]=cy+half; ball["vy"]=-abs(ball["vy"])*bounce; ny=1; hit=True
        return hit,ix,iy,(nx,ny)
    else:
        verts=_shapeVertices(shape,cx,cy,size,angle_offset)
        n=len(verts); hit=False; best_nx,best_ny=0.0,0.0; best_ix,best_iy=bx,by
        for i in range(n):
            ax,ay=verts[i]; bvx2,bvy2=verts[(i+1)%n]
            cpx,cpy,enx,eny,dist=_closestPointOnSegment(bx,by,ax,ay,bvx2,bvy2)
            tcx,tcy=cx-cpx,cy-cpy
            if enx*tcx+eny*tcy<0: enx,eny=-enx,-eny
            if dist<br:
                ball["x"]+=enx*(br-dist); ball["y"]+=eny*(br-dist)
                dot=ball["vx"]*enx+ball["vy"]*eny
                if dot<0:
                    ball["vx"]=(ball["vx"]-2*dot*enx)*bounce
                    ball["vy"]=(ball["vy"]-2*dot*eny)*bounce
                best_nx,best_ny=enx,eny; best_ix,best_iy=cpx,cpy; hit=True
        return hit,best_ix,best_iy,(best_nx,best_ny)


# ── crack system ───────────────────────────────────────────────────────────────

def _genCrackLines(ix, iy, nx, ny, style, count, length,
                   branch_depth, rng):
    """
    Generate crack line segments from impact point (ix,iy).
    Returns list of (x0,y0,x1,y1) segments.
    """
    segs = []
    # base angle — along the wall surface (perpendicular to normal)
    wall_angle = math.atan2(ny, nx) + math.pi/2

    if style == "radial":
        # lines radiating inward from impact point
        for i in range(count):
            spread = math.pi * 0.8
            a = wall_angle + rng.uniform(-spread, spread)
            _addCrackBranch(ix,iy,a,length,branch_depth,segs,rng,style)

    elif style == "spiderweb":
        # lines along wall + inward branches
        for i in range(count):
            # some go along wall, some inward
            if i % 2 == 0:
                a = wall_angle + rng.uniform(-0.3, 0.3)
            else:
                inward_angle = math.atan2(-ny,-nx)
                a = inward_angle + rng.uniform(-0.5, 0.5)
            _addCrackBranch(ix,iy,a,length,branch_depth,segs,rng,style)

    else:  # lightning
        # jagged bolt inward
        for i in range(count):
            inward = math.atan2(-ny,-nx) + rng.uniform(-0.4,0.4)
            _addLightningCrack(ix,iy,inward,length,segs,rng)

    return segs


def _addCrackBranch(x, y, angle, length, depth, segs, rng, style):
    if depth < 0 or length < 5: return
    ex = x + math.cos(angle)*length
    ey = y + math.sin(angle)*length
    segs.append((x,y,ex,ey))
    if depth > 0:
        branch_len = length * rng.uniform(0.4, 0.65)
        spread     = rng.uniform(0.3, 0.7)
        _addCrackBranch(ex,ey,angle+spread,branch_len,depth-1,segs,rng,style)
        _addCrackBranch(ex,ey,angle-spread,branch_len,depth-1,segs,rng,style)


def _addLightningCrack(x, y, angle, length, segs, rng):
    """Jagged lightning bolt."""
    steps  = max(3, int(length/15))
    seg_l  = length / steps
    cx2,cy2 = x,y
    for _ in range(steps):
        jitter = rng.uniform(-0.5, 0.5)
        ex = cx2 + math.cos(angle+jitter)*seg_l
        ey = cy2 + math.sin(angle+jitter)*seg_l
        segs.append((cx2,cy2,ex,ey))
        cx2,cy2 = ex,ey


def _drawCracks(surf, cracks, crack_width, alpha_mult=1.0):
    """Draw all accumulated cracks."""
    import pygame
    for crack in cracks:
        color   = crack["color"]
        alpha   = int(crack["alpha"] * alpha_mult)
        if alpha <= 0: continue
        for (x0,y0,x1,y1) in crack["segs"]:
            s = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
            pygame.draw.line(s, (*color, alpha),
                (int(x0),int(y0)),(int(x1),int(y1)), crack_width)
            surf.blit(s,(0,0))


# ── shatter fragments ──────────────────────────────────────────────────────────

def _buildFragments(shape, cx, cy, cr, angle_offset, hit_color, n_frags=18):
    """
    Create wall fragments that fly outward on shatter.
    Each fragment is a small arc/line segment of the shape wall.
    """
    frags = []
    for i in range(n_frags):
        angle = 2*math.pi*i/n_frags + angle_offset
        # position on wall
        if shape=="circle":
            wx = cx + cr*math.cos(angle)
            wy = cy + cr*math.sin(angle)
        elif shape=="square":
            # approximate square perimeter position
            wx = cx + cr*math.cos(angle)
            wy = cy + cr*math.sin(angle)
        else:
            verts = _shapeVertices(shape,cx,cy,cr,angle_offset)
            idx   = int(i/n_frags*len(verts))
            wx,wy = verts[idx]

        # outward velocity
        speed = random.uniform(4, 14)
        frags.append({
            "x": float(wx), "y": float(wy),
            "vx": math.cos(angle)*speed + random.uniform(-2,2),
            "vy": math.sin(angle)*speed + random.uniform(-2,2),
            "angle": angle,
            "spin":  random.uniform(-5,5),
            "size":  random.randint(8,25),
            "color": hit_color,
            "alpha": 255,
            "life":  random.randint(30,60),
            "max_life": 60,
        })
    return frags


def _drawFragments(surf, fragments):
    import pygame
    for f in fragments:
        if f["alpha"] <= 0: continue
        s   = pygame.Surface((f["size"]*2,f["size"]*2), pygame.SRCALPHA)
        pts = [(f["size"]+f["size"]*0.6*math.cos(f["angle"]+j*2.1),
                f["size"]+f["size"]*0.6*math.sin(f["angle"]+j*2.1)) for j in range(3)]
        pygame.draw.polygon(s, (*f["color"][:3],int(f["alpha"])),
            [(int(p[0]),int(p[1])) for p in pts])
        surf.blit(s,(int(f["x"])-f["size"],int(f["y"])-f["size"]))


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    duration: int               = 20,
    output: Path                = None,
    fps: int                    = 60,
    width: int                  = 1080,
    height: int                 = 1920,
    # core
    max_hits: int               = 12,
    end_behavior: str           = "loop",
    loop_count: int             = 0,
    shatter_frames: int         = 60,
    # shape
    shape: str                  = "circle",
    shape_radius: int           = None,
    ring_color_intact: str      = "#aaddff",
    ring_color_damaged: str     = "#ff4400",
    ring_width: int             = 5,
    ring_glow: bool             = True,
    ring_spin: bool             = False,
    ring_spin_speed: float      = 0.5,
    ring_double: bool           = False,
    ring_double_gap: int        = 20,
    # cracks
    crack_style: str            = "spiderweb",
    crack_count_per_hit: int    = 3,
    crack_length: int           = None,
    crack_branch_depth: int     = 2,
    crack_color: str            = None,
    crack_width: int            = 1,
    crack_opacity_start: int    = 220,
    # ball
    ball_color: str             = None,
    ball_radius: int            = 22,
    ball_glow: bool             = True,
    ball_trail: bool            = True,
    trail_length: int           = 20,
    ball_shine: bool            = True,
    ball_opacity: int           = 255,
    ball_speed: float           = 7.0,
    # hit effects
    on_hit_flash: bool          = True,
    on_hit_particles: bool      = True,
    particle_count: int         = 8,
    particle_speed: float       = 1.5,
    particle_colors: list       = None,
    screen_shake: bool          = True,
    shake_intensity: int        = 4,
    # physics
    gravity: float              = 0.0,
    bounce: float               = 1.0,
    friction: float             = 1.0,
    # background
    bg_color: str               = "#0d0d0d",
    bg_color2: str              = None,
    bg_gradient_dir: str        = "vertical",
    bg_image: str               = None,
    bg_image_alpha: int         = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER","dummy")
    os.environ.setdefault("SDL_AUDIODRIVER","dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape       = shape.lower().strip()
    crack_style = crack_style.lower().strip()
    rng         = random.Random()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"glassBall_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width,height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    c_intact     = _hex(ring_color_intact)
    c_damaged    = _hex(ring_color_damaged)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    cr = shape_radius or (min(width,height)//2 - 80)
    cl = crack_length or int(cr * 0.45)

    bc = _hex(ball_color) if ball_color else (
        random.randint(150,255), random.randint(150,255), random.randint(150,255))

    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width,height,bg,bg2,bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image,(width,height))
        if bg_image_alpha<255: raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    def _reset():
        angle  = rng.uniform(0,2*math.pi)
        ball   = {
            "x": float(cx), "y": float(cy),
            "vx": math.cos(angle)*ball_speed,
            "vy": math.sin(angle)*ball_speed,
            "flash": 0, "trail": [],
        }
        return ball, [], []   # ball, cracks, fragments

    ball, cracks, fragments = _reset()
    hits          = 0
    shape_angle   = 0.0
    particles     = []
    flash_timer   = 0
    shattered     = False
    shatter_timer = 0
    loops_done    = 0
    done          = False

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))
                continue

            if ring_spin and not shattered:
                shape_angle += math.radians(ring_spin_speed)

            # damage ratio 0→1
            damage = hits / max(1, max_hits)
            cur_color = _lerpColor(c_intact, c_damaged, damage)

            # screen shake
            shake_x = shake_y = 0
            if screen_shake and flash_timer > 0:
                intensity = int(shake_intensity * damage * flash_timer / 6)
                shake_x   = rng.randint(-intensity, intensity)
                shake_y   = rng.randint(-intensity, intensity)

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255))
                surface.blit(bg_img_surf,(shake_x,shake_y))
            elif grad_surf:
                surface.blit(grad_surf,(shake_x,shake_y))
            else:
                surface.fill((*bg,255))

            # ── draw cracks ───────────────────────────────────────────────
            if not shattered:
                _drawCracks(surface, cracks, crack_width)

            # ── draw shape ────────────────────────────────────────────────
            if not shattered:
                pulse_r = cr
                if ring_glow:
                    _drawGlow(surface, cur_color, (cx+shake_x,cy+shake_y),
                              pulse_r, layers=4)
                _drawShape(surface, shape, cur_color,
                           cx+shake_x, cy+shake_y, pulse_r,
                           ring_width, shape_angle)
                if ring_double:
                    inner = max(10, pulse_r-ring_double_gap)
                    _drawShape(surface, shape, (*cur_color,80),
                               cx+shake_x, cy+shake_y, inner,
                               max(1,ring_width-1), shape_angle)

            # ── fragments (shatter animation) ─────────────────────────────
            if shattered:
                _drawFragments(surface, fragments)
                for f in fragments:
                    f["x"]  += f["vx"]; f["y"]  += f["vy"]
                    f["vy"] += 0.3      # gravity on fragments
                    f["vx"] *= 0.97
                    f["angle"] += f["spin"]*0.05
                    f["life"] -= 1
                    f["alpha"] = int(255*(f["life"]/f["max_life"]))
                fragments = [f for f in fragments if f["life"]>0]

            # ── particles ─────────────────────────────────────────────────
            _drawParticles(surface, particles)
            for p in particles:
                p["x"]+=p["vx"]; p["y"]+=p["vy"]; p["vy"]+=0.2; p["life"]-=1
            particles=[p for p in particles if p["life"]>0]

            # ── physics ───────────────────────────────────────────────────
            if not shattered:
                ball["vy"]+=gravity; ball["vx"]*=friction; ball["vy"]*=friction
                ball["x"]+=ball["vx"]; ball["y"]+=ball["vy"]

                spd=math.hypot(ball["vx"],ball["vy"])
                if spd>0:
                    ball["vx"]=ball["vx"]/spd*ball_speed
                    ball["vy"]=ball["vy"]/spd*ball_speed

                if ball_trail:
                    ball["trail"].append((ball["x"],ball["y"],ball_radius))
                    if len(ball["trail"])>trail_length: ball["trail"].pop(0)

                hit,ix,iy,(nx,ny) = _resolveShapeCollision(
                    ball, ball_radius, shape, cx, cy, cr, bounce, shape_angle)
                if hit:
                    log_wall_from_ball(audio, frame / fps, ball)

                if hit:
                    hits += 1
                    flash_timer = 8
                    damage = hits / max(1, max_hits)
                    hit_color = _lerpColor(c_intact, c_damaged, damage)
                    cc = _hex(crack_color) if crack_color else hit_color

                    # spawn cracks at impact point
                    segs = _genCrackLines(ix,iy,nx,ny,crack_style,
                                          crack_count_per_hit,cl,
                                          crack_branch_depth,rng)
                    cracks.append({
                        "segs": segs,
                        "color": cc,
                        "alpha": crack_opacity_start,
                    })

                    if on_hit_particles:
                        particles+=_spawnParticles(ix,iy,hit_color,pcolors,
                                                   count=particle_count,
                                                   speed_mult=particle_speed)

                    # shatter!
                    if hits >= max_hits:
                        shattered = True
                        shatter_timer = shatter_frames
                        fragments = _buildFragments(
                            shape, cx, cy, cr, shape_angle, hit_color, n_frags=24)
                        # big burst
                        for _ in range(3):
                            particles+=_spawnParticles(
                                cx,cy,hit_color,pcolors,
                                count=particle_count*3,speed_mult=particle_speed*2)
                        print(f"   SHATTERED at frame {frame} after {hits} hits!")

            else:
                # ball flies free after shatter
                ball["vy"]+=gravity
                ball["x"]+=ball["vx"]; ball["y"]+=ball["vy"]
                shatter_timer -= 1

                if shatter_timer <= 0 and not fragments:
                    loops_done += 1
                    if end_behavior=="loop" and (loop_count==0 or loops_done<loop_count):
                        ball,cracks,fragments = _reset()
                        hits=0; shattered=False; particles=[]
                        flash_timer=0; shape_angle=0.0
                    else:
                        done = True

            # ── draw trail ────────────────────────────────────────────────
            if ball_trail:
                _drawTrail(surface, ball["trail"], bc)

            # ── draw ball ─────────────────────────────────────────────────
            pos        = (int(ball["x"])+shake_x, int(ball["y"])+shake_y)
            draw_color = _lighten(bc,180) if flash_timer>0 else bc

            if ball_glow:
                _drawGlow(surface, draw_color, pos, ball_radius)

            if ball_opacity<255:
                _withAlpha(surface, draw_color, pos, ball_radius, ball_opacity)
            else:
                pygame.draw.circle(surface, draw_color, pos, ball_radius)

            if ball_shine and ball_radius>6:
                pygame.draw.circle(surface,(255,255,255),
                    (pos[0]-ball_radius//4,pos[1]-ball_radius//4),
                    max(1,ball_radius//5))

            if flash_timer>0: flash_timer-=1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))

            if frame%(fps*2)==0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| hits: {hits}/{max_hits} | cracks: {len(cracks)} "
                      f"| shattered: {shattered}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg","-y","-framerate",str(fps),
            "-i",str(frames_dir/"frame_%06d.png"),
            "-c:v","libx264","-pix_fmt","yuv420p",
            "-preset","fast","-crf","18",str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration)
    return output