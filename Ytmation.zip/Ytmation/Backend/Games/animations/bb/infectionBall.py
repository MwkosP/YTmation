"""
Infection Ball — Spread or Survive
-------------------------------------
One ball starts infected. Touching spreads infection.
Infected balls slowly fade and die over time.

GOALS:
    goal_mode             : str   = "infect_all"  — "infect_all" | "survive_timer"
    timer_seconds         : float = 18.0          — used when goal_mode="survive_timer"

INFECTION:
    infected_start        : int   = 1
    ball_count            : int   = 14
    catch_multiplier      : float = 1.05
    infect_cooldown       : int   = 8             — frames before same pair can re-trigger

FADE:
    infected_life         : float = 220.0         — frames until infected ball disappears
    fade_rate             : float = 1.0           — life lost per frame (multiplier)

BALLS:
    healthy_color         : str   = "#44aaff"
    infected_color        : str   = "#ff4444"
    ball_radius           : int   = 20
    ball_speed_limit      : float = 7.5
    ball_glow             : bool  = True
    ball_trail            : bool  = True
    trail_length          : int   = 16
    glow_layers           : int   = 4

PHYSICS:
    wander_force          : float = 0.05
    turn_noise            : float = 0.10
    bounce                : float = 0.98
    friction              : float = 0.994
    ball_collision        : bool  = True

SHAPE:
    shape                 : str   = "circle"
    circle_radius         : int   = None
    ring_color            : str   = "#ffffff"
    ring_width            : int   = 4
    ring_glow             : bool  = False
    ring_dash             : bool  = False
    ring_spin             : bool  = False
    ring_spin_speed       : float = 0.5

LOOK:
    show_hud              : bool  = True

BACKGROUND:
    bg_color              : str   = "#0d0d0d"
    bg_color2             : str   = None
    bg_gradient_dir       : str   = "vertical"

OUTPUT:
    fps                   : int   = 60
    width                 : int   = 1080
    height                : int   = 1920
    duration              : int   = 22
"""

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


def _hex(h):
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _with_alpha_circle(surf, color, pos, r, alpha):
    import pygame

    if r <= 0 or alpha <= 0:
        return
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0] - r, pos[1] - r))


def _draw_glow(surf, color, pos, r, layers=4, strength=55):
    for i in range(layers, 0, -1):
        _with_alpha_circle(surf, color, pos, r + i * 6, int(strength / i))


def _gradient_surface(w, h, c1, c2, direction="vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (x, 0), (x, h))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_d = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max_d)
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                surf.set_at((x, y), (r, g, b))
    else:
        for y in range(h):
            t = y / max(1, h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (0, y), (w, y))
    return surf


_SHAPE_SIDES = {"triangle": 3, "diamond": 4, "pentagon": 5, "hexagon": 6}


def _shape_vertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [
        (
            cx + size * math.cos(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
            cy + size * math.sin(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
        )
        for i in range(sides)
    ]


def _closest_point_on_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-9)
    t = max(0.0, min(1.0, t))
    cx2 = ax + t * dx
    cy2 = ay + t * dy
    nx = px - cx2
    ny = py - cy2
    dist = math.hypot(nx, ny)
    if dist < 1e-6:
        nx, ny = -dy, dx
        dist = math.hypot(nx, ny)
    return cx2, cy2, nx / dist, ny / dist, dist


def _resolve_shape_collision(ball, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx, by, br = ball["x"], ball["y"], ball["r"]
    hit = False
    if shape == "circle":
        dx, dy = bx - cx, by - cy
        dist = math.hypot(dx, dy)
        md = size - br
        if dist > md and dist > 0:
            nx, ny = dx / dist, dy / dist
            ball["x"] = cx + nx * md
            ball["y"] = cy + ny * md
            dot = ball["vx"] * nx + ball["vy"] * ny
            ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
            ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
            hit = True
    elif shape == "square":
        half = size - br
        if bx < cx - half:
            ball["x"] = cx - half
            ball["vx"] = abs(ball["vx"]) * bounce
            hit = True
        elif bx > cx + half:
            ball["x"] = cx + half
            ball["vx"] = -abs(ball["vx"]) * bounce
            hit = True
        if by < cy - half:
            ball["y"] = cy - half
            ball["vy"] = abs(ball["vy"]) * bounce
            hit = True
        elif by > cy + half:
            ball["y"] = cy + half
            ball["vy"] = -abs(ball["vy"]) * bounce
            hit = True
    else:
        verts = _shape_vertices(shape, cx, cy, size, angle_offset)
        for i in range(len(verts)):
            ax, ay = verts[i]
            bx2, by2 = verts[(i + 1) % len(verts)]
            cpx, cpy, nx, ny, dist = _closest_point_on_segment(bx, by, ax, ay, bx2, by2)
            to_center_x = cx - cpx
            to_center_y = cy - cpy
            if nx * to_center_x + ny * to_center_y < 0:
                nx, ny = -nx, -ny
            if dist < br:
                overlap = br - dist
                ball["x"] += nx * overlap
                ball["y"] += ny * overlap
                dot = ball["vx"] * nx + ball["vy"] * ny
                if dot < 0:
                    ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
                    ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
                hit = True
    if hit and audio is not None:
        from Games.collision_audio import log_wall_from_ball
        log_wall_from_ball(audio, t, ball)
    return hit


def _draw_shape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame

    if shape == "circle":
        if dash:
            n = max(1, int(math.pi * size / 20))
            for i in range(n):
                a0 = (2 * math.pi / n) * i
                a1 = a0 + math.pi / n
                pts = []
                for s in range(11):
                    a = a0 + (a1 - a0) * s / 10
                    pts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
                if len(pts) > 1:
                    pygame.draw.lines(surf, color, False, pts, width)
        else:
            pygame.draw.circle(surf, color, (cx, cy), size, width)
        return
    if shape == "square":
        half = size
        pygame.draw.rect(surf, color, pygame.Rect(cx - half, cy - half, half * 2, half * 2), width)
        return
    verts = _shape_vertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x), int(y)) for x, y in verts], width)


def _resolve_ball_collision(a, b, bounce=0.96):
    dx = b["x"] - a["x"]
    dy = b["y"] - a["y"]
    dist = math.hypot(dx, dy)
    min_d = a["r"] + b["r"]
    if dist <= 1e-9 or dist >= min_d:
        return False
    nx, ny = dx / dist, dy / dist
    overlap = (min_d - dist) / 2
    a["x"] -= nx * overlap
    a["y"] -= ny * overlap
    b["x"] += nx * overlap
    b["y"] += ny * overlap
    rvx = a["vx"] - b["vx"]
    rvy = a["vy"] - b["vy"]
    rel = rvx * nx + rvy * ny
    if rel > 0:
        a["vx"] = (a["vx"] - rel * nx) * bounce
        a["vy"] = (a["vy"] - rel * ny) * bounce
        b["vx"] = (b["vx"] + rel * nx) * bounce
        b["vy"] = (b["vy"] + rel * ny) * bounce
    return True


def run(
    duration=22,
    output=None,
    fps=60,
    width=1080,
    height=1920,
    goal_mode="infect_all",
    timer_seconds=18.0,
    infected_start=1,
    ball_count=14,
    catch_multiplier=1.05,
    infect_cooldown=8,
    infected_life=220.0,
    fade_rate=1.0,
    healthy_color="#44aaff",
    infected_color="#ff4444",
    ball_radius=20,
    ball_speed_limit=7.5,
    ball_glow=True,
    ball_trail=True,
    trail_length=16,
    glow_layers=4,
    wander_force=0.05,
    turn_noise=0.10,
    bounce=0.98,
    friction=0.994,
    ball_collision=True,
    shape="circle",
    circle_radius=None,
    ring_color="#ffffff",
    ring_width=4,
    ring_glow=False,
    ring_dash=False,
    ring_spin=False,
    ring_spin_speed=0.5,
    show_hud=True,
    bg_color="#0d0d0d",
    bg_color2=None,
    bg_gradient_dir="vertical",
    collision_audio: dict | None = None,
    **kwargs,
):
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = (shape or "circle").lower().strip()
    goal_mode = (goal_mode or "infect_all").lower().strip()
    if goal_mode not in ("infect_all", "survive_timer"):
        goal_mode = "infect_all"

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"infectionBall_{shape}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    total_frames = max(1, int(duration * fps))
    cx, cy = width // 2, height // 2
    cr = circle_radius or (min(width, height) // 2 - 80)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    rc = _hex(ring_color)
    c_healthy = _hex(healthy_color)
    c_infected = _hex(infected_color)
    grad_surf = _gradient_surface(width, height, bg1, bg2, bg_gradient_dir) if bg2 else None

    font = None
    if show_hud:
        try:
            font = pygame.font.SysFont("DejaVu Sans", 32)
        except Exception:
            font = None

    def spawn_pos():
        if shape == "circle":
            ang = random.uniform(0, 2 * math.pi)
            dist = random.uniform(0, max(10, cr - ball_radius - 30))
            return cx + dist * math.cos(ang), cy + dist * math.sin(ang)
        return (
            random.uniform(cx - cr * 0.6, cx + cr * 0.6),
            random.uniform(cy - cr * 0.6, cy + cr * 0.6),
        )

    n = max(2, int(ball_count))
    balls = []
    for _ in range(n):
        x, y = spawn_pos()
        balls.append(
            {
                "x": x,
                "y": y,
                "vx": random.uniform(-3, 3),
                "vy": random.uniform(-3, 3),
                "r": ball_radius,
                "infected": False,
                "life": float(infected_life),
                "max_life": float(infected_life),
                "trail": [],
                "wander": random.uniform(0, 2 * math.pi),
            }
        )

    start_infected = max(1, min(n, int(infected_start)))
    for b in random.sample(balls, start_infected):
        b["infected"] = True
        b["life"] = float(infected_life)
        b["max_life"] = float(infected_life)

    timer_frames = max(1, int(timer_seconds * fps))
    angle_offset = 0.0
    wander_global = random.uniform(0, 2 * math.pi)
    game_result = None  # "infected_win" | "healthy_win"

    def count_states():
        healthy = sum(1 for b in balls if not b["infected"])
        infected = sum(1 for b in balls if b["infected"])
        return healthy, infected

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            if game_result is not None and goal_mode == "infect_all":
                pass  # keep rendering final state briefly
            elif game_result is not None and goal_mode == "survive_timer":
                pass

            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg1, 255))

            if ring_glow:
                _draw_glow(surface, rc, (cx, cy), cr, layers=3)
            _draw_shape(surface, shape, rc, cx, cy, cr, ring_width, angle_offset, dash=ring_dash)

            if frame % max(2, int(1 / max(1e-6, turn_noise))) == 0:
                wander_global += random.uniform(-0.8, 0.8)

            # wander steering
            for b in balls:
                b["wander"] += random.uniform(-0.15, 0.15)
                b["vx"] += math.cos(b["wander"]) * wander_force + math.cos(wander_global) * wander_force * 0.3
                b["vy"] += math.sin(b["wander"]) * wander_force + math.sin(wander_global) * wander_force * 0.3

            # integrate
            for b in balls:
                b["vx"] *= friction
                b["vy"] *= friction
                sp = math.hypot(b["vx"], b["vy"])
                if sp > ball_speed_limit:
                    s = ball_speed_limit / sp
                    b["vx"] *= s
                    b["vy"] *= s
                b["x"] += b["vx"]
                b["y"] += b["vy"]
                _resolve_shape_collision(b, shape, cx, cy, cr, bounce, angle_offset, audio=audio if audio.enabled else None, t=frame / fps)

            # ball-ball collisions + infection
            if ball_collision:
                for i in range(len(balls)):
                    for j in range(i + 1, len(balls)):
                        touched = _resolve_ball_collision(balls[i], balls[j], bounce)
                        if touched:
                            from Games.collision_audio import log_ball_pair
                            log_ball_pair(audio, frame / fps, balls[i]["vx"] - balls[j]["vx"], balls[i]["vy"] - balls[j]["vy"])
                        if not touched:
                            continue
                        a, b2 = balls[i], balls[j]
                        dist2 = (a["x"] - b2["x"]) ** 2 + (a["y"] - b2["y"]) ** 2
                        thresh = ((a["r"] + b2["r"]) * catch_multiplier) ** 2
                        if dist2 > thresh:
                            continue
                        if a["infected"] and not b2["infected"]:
                            b2["infected"] = True
                            b2["life"] = float(infected_life)
                            b2["max_life"] = float(infected_life)
                        elif b2["infected"] and not a["infected"]:
                            a["infected"] = True
                            a["life"] = float(infected_life)
                            a["max_life"] = float(infected_life)

            # infected fade / death
            alive = []
            for b in balls:
                if b["infected"]:
                    b["life"] -= fade_rate
                    if b["life"] <= 0:
                        continue
                alive.append(b)
            balls = alive

            # win checks
            healthy_n, infected_n = count_states()
            if game_result is None:
                if goal_mode == "infect_all" and healthy_n == 0 and infected_n > 0:
                    game_result = "infected_win"
                elif goal_mode == "survive_timer":
                    if frame >= timer_frames and healthy_n > 0:
                        game_result = "healthy_win"
                    elif healthy_n == 0 and infected_n > 0:
                        game_result = "infected_win"

            # draw
            for b in balls:
                col = c_infected if b["infected"] else c_healthy
                alpha = 255
                if b["infected"] and b["max_life"] > 0:
                    alpha = int(255 * max(0.15, b["life"] / b["max_life"]))
                pos = (int(b["x"]), int(b["y"]))
                if ball_trail:
                    b["trail"].append((b["x"], b["y"], b["r"], alpha))
                    if len(b["trail"]) > trail_length:
                        b["trail"].pop(0)
                    ntr = len(b["trail"])
                    for ti, (tx, ty, tr, ta) in enumerate(b["trail"]):
                        t_alpha = int(ta * (ti / max(1, ntr)))
                        rad = max(2, int(tr * 0.55 * (ti / max(1, ntr))))
                        _with_alpha_circle(surface, col, (int(tx), int(ty)), rad, t_alpha)
                if ball_glow:
                    _draw_glow(surface, col, pos, b["r"], layers=glow_layers, strength=int(50 * alpha / 255))
                _with_alpha_circle(surface, col, pos, b["r"], alpha)
                pygame.draw.circle(surface, (255, 255, 255), (pos[0] - b["r"] // 4, pos[1] - b["r"] // 4), max(1, b["r"] // 5))

            if show_hud and font:
                if goal_mode == "survive_timer":
                    left = max(0, timer_frames - frame)
                    hud = f"H:{healthy_n}  I:{infected_n}  T:{left // fps}s"
                else:
                    hud = f"H:{healthy_n}  I:{infected_n}  goal: infect all"
                if game_result == "infected_win":
                    hud += "  | INFECTED WIN"
                elif game_result == "healthy_win":
                    hud += "  | HEALTHY WIN"
                s = font.render(hud, True, (240, 240, 240))
                surface.blit(s, (30, 25))

            if ring_spin:
                angle_offset += math.radians(ring_spin_speed)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(
                    f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%) "
                    f"| H:{healthy_n} I:{infected_n}"
                )

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-framerate",
                str(fps),
                "-i",
                str(frames_dir / "frame_%06d.png"),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "fast",
                "-crf",
                "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)
