"""
Stacking Balls — Full Customization
-------------------------------------
Balls fall from the top and stack up into a growing tower.

SPAWN:
    spawn_mode       : str   = "continuous" — "continuous" | "fixed"
    ball_count       : int   = 50           — total if "fixed", pool size if "continuous"
    spawn_rate       : int   = 20           — frames between each ball drop
    spawn_x          : str   = "random"     — "random" | "center" | "spread" | "alternating"

WALLS:
    has_walls        : bool  = True         — left/right boundary walls
    wall_gap         : int   = None         — width between walls, auto if None
    wall_color       : str   = "#444444"
    wall_width       : int   = 6

CAMERA:
    camera_follow    : bool  = True         — pan up as tower grows
    camera_smoothing : float = 0.05         — 0.01=very slow, 0.1=snappy
    camera_margin    : int   = 300          — px above highest ball before camera moves

PHYSICS:
    gravity          : float = 0.5
    bounce           : float = 0.3          — low bounce = balls settle quickly
    friction         : float = 0.98
    ball_collision   : bool  = True
    speed_limit      : float = 20.0
    rest_threshold   : float = 0.4          — velocity below this = ball is settled

BALLS:
    min_radius       : int   = 25
    max_radius       : int   = 55
    ball_colors      : list  = None         — hex list, random if None
    ball_glow        : bool  = False
    ball_trail       : bool  = False
    trail_length     : int   = 10
    ball_shine       : bool  = True
    ball_opacity     : int   = 255
    ball_collision   : bool  = True

FLOOR:
    floor_color      : str   = "#555555"
    floor_height     : int   = 12           — thickness of floor bar

HIT EFFECTS:
    on_hit_flash     : bool  = False
    on_hit_particles : bool  = False
    particle_count   : int   = 6
    particle_speed   : float = 1.0
    particle_colors  : list  = None

BACKGROUND:
    bg_color         : str   = "#0d0d0d"
    bg_color2        : str   = None
    bg_gradient_dir  : str   = "vertical"

OUTPUT:
    fps              : int   = 60
    width            : int   = 1080
    height           : int   = 1920
    duration         : int   = 20
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*6, int(50/i))

def _drawTrail(surf, trail, color, cam_y):
    n = len(trail)
    if n == 0: return
    for i, (tx, ty, tr) in enumerate(trail):
        alpha = int(160 * (i / n))
        rad   = max(2, int(tr * 0.6 * (i / n)))
        _withAlpha(surf, color, (int(tx), int(ty - cam_y)), rad, alpha)

def _drawParticles(surf, particles, cam_y):
    for p in particles:
        alpha = int(255 * (p["life"] / p["max_life"]))
        r     = max(1, int(p["r"] * (p["life"] / p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]), int(p["y"] - cam_y)), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=6, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(1, 5) * speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({
            "x": x, "y": y,
            "vx": math.cos(angle)*speed,
            "vy": math.sin(angle)*speed,
            "r":  random.randint(2, 6),
            "color": c,
            "life": random.randint(8, 20),
            "max_life": 20,
        })
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / w
            r = int(c1[0] + (c2[0]-c1[0])*t)
            g = int(c1[1] + (c2[1]-c1[1])*t)
            b = int(c1[2] + (c2[2]-c1[2])*t)
            pygame.draw.line(surf, (r,g,b), (x,0), (x,h))
    elif direction == "radial":
        cx2, cy2 = w//2, h//2
        max_d = math.hypot(cx2, cy2)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x-cx2, y-cy2) / max_d)
                r = int(c1[0] + (c2[0]-c1[0])*t)
                g = int(c1[1] + (c2[1]-c1[1])*t)
                b = int(c1[2] + (c2[2]-c1[2])*t)
                surf.set_at((x,y), (r,g,b))
    else:
        for y in range(h):
            t = y / h
            r = int(c1[0] + (c2[0]-c1[0])*t)
            g = int(c1[1] + (c2[1]-c1[1])*t)
            b = int(c1[2] + (c2[2]-c1[2])*t)
            pygame.draw.line(surf, (r,g,b), (0,y), (w,y))
    return surf


# ── ball-ball collision ────────────────────────────────────────────────────────

def _resolveBallCollisions(balls, bounce, rest_threshold, t: float = 0.0, audio=None):
    n = len(balls)
    for i in range(n):
        for j in range(i+1, n):
            a, b  = balls[i], balls[j]
            dx    = b["x"] - a["x"]
            dy    = b["y"] - a["y"]
            dist  = math.hypot(dx, dy)
            md    = a["r"] + b["r"]
            if dist < md and dist > 0:
                overlap = (md - dist) / 2
                nx = dx / dist
                ny = dy / dist
                # only push non-settled balls
                if not a["settled"]:
                    a["x"] -= nx * overlap
                    a["y"] -= ny * overlap
                if not b["settled"]:
                    b["x"] += nx * overlap
                    b["y"] += ny * overlap

                dvx = a["vx"] - b["vx"]
                dvy = a["vy"] - b["vy"]
                dot = dvx*nx + dvy*ny
                if dot > 0:
                    if not a["settled"]:
                        a["vx"] = (a["vx"] - dot*nx) * bounce
                        a["vy"] = (a["vy"] - dot*ny) * bounce
                    if not b["settled"]:
                        b["vx"] = (b["vx"] + dot*nx) * bounce
                        b["vy"] = (b["vy"] + dot*ny) * bounce
                if audio is not None:
                    from Games.collision_audio import log_ball_pair
                    log_ball_pair(audio, t, dvx, dvy)


def _makeBall(x, y, min_radius, max_radius, palette):
    r     = random.randint(min_radius, max_radius)
    color = _hex(random.choice(palette)) if palette else (
        random.randint(80,255), random.randint(80,255), random.randint(80,255))
    return {
        "x": float(x), "y": float(y),
        "vx": random.uniform(-1.0, 1.0),
        "vy": 0.0,
        "r":  r,
        "color": color,
        "flash": 0,
        "trail": [],
        "settled": False,
        "settle_timer": 0,
    }


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    # output
    duration: int           = 20,
    output: Path            = None,
    fps: int                = 60,
    width: int              = 1080,
    height: int             = 1920,
    # spawn
    spawn_mode: str         = "continuous",
    ball_count: int         = 50,
    spawn_rate: int         = 20,
    spawn_x: str            = "random",      # "random"|"center"|"spread"|"alternating"
    # walls
    has_walls: bool         = True,
    wall_gap: int           = None,
    wall_color: str         = "#444444",
    wall_width: int         = 6,
    # camera
    camera_follow: bool     = True,
    camera_smoothing: float = 0.05,
    camera_margin: int      = 300,
    # physics
    gravity: float          = 0.5,
    bounce: float           = 0.3,
    friction: float         = 0.98,
    ball_collision: bool    = True,
    speed_limit: float      = 20.0,
    rest_threshold: float   = 0.4,
    # balls
    min_radius: int         = 25,
    max_radius: int         = 55,
    ball_colors: list       = None,
    ball_glow: bool         = False,
    ball_trail: bool        = False,
    trail_length: int       = 10,
    ball_shine: bool        = True,
    ball_opacity: int       = 255,
    # floor
    floor_color: str        = "#555555",
    floor_height: int       = 12,
    # hit effects
    on_hit_flash: bool      = False,
    on_hit_particles: bool  = False,
    particle_count: int     = 6,
    particle_speed: float   = 1.0,
    particle_colors: list   = None,
    # background
    bg_color: str           = "#0d0d0d",
    bg_color2: str          = None,
    bg_gradient_dir: str    = "vertical",
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"stackingBalls_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width, height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    wc           = _hex(wall_color)
    fc           = _hex(floor_color)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    # layout
    gap       = wall_gap or int(width * 0.75)
    left_wall = (width - gap) // 2
    right_wall= left_wall + gap
    floor_y   = height - 80      # world y of the floor (never changes)
    spawn_top = -height           # spawn balls above the visible area

    # spawn x positions
    _alternating = [left_wall + gap//3, right_wall - gap//3]
    def _next_spawn_x(idx):
        if spawn_x == "center":
            return width // 2
        elif spawn_x == "spread":
            return int(left_wall + (idx % 5 + 1) * gap / 6)
        elif spawn_x == "alternating":
            return _alternating[idx % 2]
        else:  # random
            return random.randint(left_wall + max_radius + 5,
                                  right_wall - max_radius - 5)

    # gradient — tall world surface (3x screen height for camera scroll)
    world_h   = height * 4
    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, world_h, bg, bg2, bg_gradient_dir)

    balls      = []
    particles  = []
    spawned    = 0
    cam_y      = 0.0      # world y that maps to screen top (0 = floor visible at bottom)
    cam_target = 0.0

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            # ── spawn ─────────────────────────────────────────────────────
            should_spawn = (frame % max(1, spawn_rate) == 0)
            if spawn_mode == "continuous" and should_spawn:
                sx = _next_spawn_x(spawned)
                sy = cam_y - max_radius - 10  # just above screen top
                balls.append(_makeBall(sx, sy, min_radius, max_radius, ball_colors))
                spawned += 1
            elif spawn_mode == "fixed" and spawned < ball_count and should_spawn:
                sx = _next_spawn_x(spawned)
                sy = cam_y - max_radius - 10
                balls.append(_makeBall(sx, sy, min_radius, max_radius, ball_colors))
                spawned += 1

            # ── physics ───────────────────────────────────────────────────
            if ball_collision:
                _resolveBallCollisions(balls, bounce, rest_threshold, t=frame / fps, audio=audio if audio.enabled else None)

            highest_ball_y = floor_y  # track topmost ball for camera

            for b in balls:
                if b["settled"]: 
                    highest_ball_y = min(highest_ball_y, b["y"] - b["r"])
                    continue

                # apply physics
                b["vy"] += gravity
                b["vx"] *= friction
                b["vy"] *= friction

                # speed cap
                spd = math.hypot(b["vx"], b["vy"])
                if spd > speed_limit:
                    b["vx"] = b["vx"] / spd * speed_limit
                    b["vy"] = b["vy"] / spd * speed_limit

                b["x"] += b["vx"]
                b["y"] += b["vy"]

                # trail update
                if ball_trail:
                    b["trail"].append((b["x"], b["y"], b["r"]))
                    if len(b["trail"]) > trail_length:
                        b["trail"].pop(0)

                hit = False

                # wall collision
                if has_walls:
                    if b["x"] - b["r"] < left_wall:
                        b["x"] = left_wall + b["r"]
                        b["vx"] = abs(b["vx"]) * bounce
                        hit = True
                    elif b["x"] + b["r"] > right_wall:
                        b["x"] = right_wall - b["r"]
                        b["vx"] = -abs(b["vx"]) * bounce
                        hit = True

                # floor collision
                if b["y"] + b["r"] >= floor_y:
                    b["y"] = floor_y - b["r"]
                    b["vy"] = -abs(b["vy"]) * bounce
                    b["vx"] *= 0.85   # extra friction on floor
                    hit = True

                # settle check
                spd = math.hypot(b["vx"], b["vy"])
                if spd < rest_threshold and b["y"] + b["r"] >= floor_y - 2:
                    b["settle_timer"] += 1
                    if b["settle_timer"] > 8:
                        b["vx"] = 0; b["vy"] = 0
                        b["settled"] = True
                else:
                    b["settle_timer"] = 0

                highest_ball_y = min(highest_ball_y, b["y"] - b["r"])

                if hit:
                    log_wall_from_ball(audio, frame / fps, b)
                    if on_hit_flash:   b["flash"] = 5
                    if on_hit_particles:
                        particles += _spawnParticles(
                            b["x"], b["y"], b["color"], pcolors,
                            count=particle_count, speed_mult=particle_speed)

            # ── camera ────────────────────────────────────────────────────
            if camera_follow:
                # target: keep the highest ball within camera_margin of screen top
                desired_top = highest_ball_y - camera_margin
                # cam_y is world y at screen top; floor at screen bottom = cam_y + height
                # we want floor_y at screen bottom: cam_y = floor_y - height + 80
                min_cam = floor_y - height + 80
                cam_target = max(min_cam, desired_top)
                cam_y += (cam_target - cam_y) * camera_smoothing
            else:
                cam_y = floor_y - height + 80

            # ── draw ──────────────────────────────────────────────────────
            # background
            if grad_surf:
                # blit the portion of the tall gradient that corresponds to current camera
                src_rect = pygame.Rect(0, max(0, int(cam_y)), width, height)
                surface.blit(grad_surf, (0, 0), src_rect)
            else:
                surface.fill((*bg, 255))

            def world_to_screen(wy):
                return int(wy - cam_y)

            # particles
            if on_hit_particles:
                _drawParticles(surface, particles, cam_y)
                for p in particles:
                    p["x"] += p["vx"]; p["y"] += p["vy"]
                    p["vy"] += 0.15;   p["life"] -= 1
                particles = [p for p in particles if p["life"] > 0]

            # walls
            if has_walls:
                wall_top_s = world_to_screen(-world_h)
                wall_bot_s = world_to_screen(floor_y)
                pygame.draw.line(surface, wc, (left_wall, wall_top_s), (left_wall, wall_bot_s), wall_width)
                pygame.draw.line(surface, wc, (right_wall, wall_top_s), (right_wall, wall_bot_s), wall_width)

            # floor
            floor_s = world_to_screen(floor_y)
            pygame.draw.rect(surface, fc, (left_wall, floor_s, gap, floor_height))

            # balls
            for b in balls:
                sy = world_to_screen(b["y"])

                # skip if off screen
                if sy + b["r"] < 0 or sy - b["r"] > height:
                    continue

                if ball_trail:
                    _drawTrail(surface, b["trail"], b["color"], cam_y)

                if ball_glow:
                    _drawGlow(surface, b["color"], (int(b["x"]), sy), b["r"])

                pos        = (int(b["x"]), sy)
                draw_color = _lighten(b["color"], 180) if b["flash"] > 0 else b["color"]

                if ball_opacity < 255:
                    _withAlpha(surface, draw_color, pos, b["r"], ball_opacity)
                else:
                    pygame.draw.circle(surface, draw_color, pos, b["r"])

                if ball_shine and not b["settled"]:
                    pygame.draw.circle(surface, (255,255,255),
                        (pos[0]-b["r"]//4, pos[1]-b["r"]//4), max(1, b["r"]//5))

                if b["flash"] > 0: b["flash"] -= 1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))

            if frame % (fps*2) == 0:
                settled = sum(1 for b in balls if b["settled"])
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| balls: {len(balls)} | settled: {settled} | cam_y: {int(cam_y)}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", str(fps),
            "-i", str(frames_dir/"frame_%06d.png"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "fast", "-crf", "18",
            str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)