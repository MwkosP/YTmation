"""
Laser Grid Ball — Rotating Beams + Rule Flips
-----------------------------------------------
Rotating laser lines sweep the arena. The ball must avoid them.
Each hit flips physics rules (gravity, friction, bounce, speed).

LASERS:
    beam_count            : int   = 6
    beam_rotation_speed   : float = 1.2     — degrees per frame
    beam_width            : int   = 4       — visual line width
    beam_hit_width        : float = 10.0    — collision half-width
    laser_color           : str   = "#ff2244"
    laser_glow            : bool  = True
    hit_cooldown          : int   = 12      — frames after hit before next flip

BALL:
    ball_radius           : int   = 22
    ball_color            : str   = "#00ffff"
    ball_glow             : bool  = True
    ball_trail            : bool  = True
    trail_length          : int   = 18
    glow_layers           : int   = 5
    ball_speed_min        : float = 4.0
    ball_speed_max        : float = 8.0

PHYSICS (base values, flipped on hit):
    gravity               : float = 0.22
    friction              : float = 0.996
    bounce                : float = 0.98
    speed_limit           : float = 13.0
    hit_knockback         : float = 4.5

LOOK:
    show_rules_hud        : bool  = True
    flash_on_hit          : bool  = True

SHAPE:
    shape                 : str   = "circle"
    circle_radius         : int   = None
    ring_color            : str   = "#ffffff"
    ring_width            : int   = 4
    ring_glow             : bool  = False
    ring_dash             : bool  = False
    ring_spin             : bool  = False
    ring_spin_speed       : float = 0.5

BACKGROUND:
    bg_color              : str   = "#0d0d0d"
    bg_color2             : str   = None
    bg_gradient_dir       : str   = "vertical"

OUTPUT:
    fps                   : int   = 60
    width                 : int   = 1080
    height                : int   = 1920
    duration              : int   = 18
"""

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


def _hex(h):
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _with_alpha_circle(surf, color, pos, r, alpha):
    import pygame

    if r <= 0 or alpha <= 0:
        return
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0] - r, pos[1] - r))


def _draw_glow(surf, color, pos, r, layers=5, strength=60):
    for i in range(layers, 0, -1):
        _with_alpha_circle(surf, color, pos, r + i * 7, int(strength / i))


def _gradient_surface(w, h, c1, c2, direction="vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (x, 0), (x, h))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_d = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max_d)
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                surf.set_at((x, y), (r, g, b))
    else:
        for y in range(h):
            t = y / max(1, h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (0, y), (w, y))
    return surf


_SHAPE_SIDES = {"triangle": 3, "diamond": 4, "pentagon": 5, "hexagon": 6}


def _shape_vertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [
        (
            cx + size * math.cos(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
            cy + size * math.sin(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
        )
        for i in range(sides)
    ]


def _closest_point_on_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-9)
    t = max(0.0, min(1.0, t))
    cx2 = ax + t * dx
    cy2 = ay + t * dy
    nx = px - cx2
    ny = py - cy2
    return math.hypot(nx, ny), cx2, cy2


def _resolve_shape_collision(ball, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx, by, br = ball["x"], ball["y"], ball["r"]
    hit = False
    if shape == "circle":
        dx, dy = bx - cx, by - cy
        dist = math.hypot(dx, dy)
        md = size - br
        if dist > md and dist > 0:
            nx, ny = dx / dist, dy / dist
            ball["x"] = cx + nx * md
            ball["y"] = cy + ny * md
            dot = ball["vx"] * nx + ball["vy"] * ny
            ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
            ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
            hit = True
    elif shape == "square":
        half = size - br
        if bx < cx - half:
            ball["x"] = cx - half
            ball["vx"] = abs(ball["vx"]) * bounce
            hit = True
        elif bx > cx + half:
            ball["x"] = cx + half
            ball["vx"] = -abs(ball["vx"]) * bounce
            hit = True
        if by < cy - half:
            ball["y"] = cy - half
            ball["vy"] = abs(ball["vy"]) * bounce
            hit = True
        elif by > cy + half:
            ball["y"] = cy + half
            ball["vy"] = -abs(ball["vy"]) * bounce
            hit = True
    else:
        verts = _shape_vertices(shape, cx, cy, size, angle_offset)
        for i in range(len(verts)):
            ax, ay = verts[i]
            bx2, by2 = verts[(i + 1) % len(verts)]
            dist, cpx, cpy = _closest_point_on_segment(bx, by, ax, ay, bx2, by2)
            to_center_x = cx - cpx
            to_center_y = cy - cpy
            nx = bx - cpx
            ny = by - cpy
            nd = math.hypot(nx, ny) + 1e-9
            nx /= nd
            ny /= nd
            if nx * to_center_x + ny * to_center_y < 0:
                nx, ny = -nx, -ny
            if dist < br:
                overlap = br - dist
                ball["x"] += nx * overlap
                ball["y"] += ny * overlap
                dot = ball["vx"] * nx + ball["vy"] * ny
                if dot < 0:
                    ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
                    ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
                hit = True
    if hit and audio is not None:
        from Games.collision_audio import log_wall_from_ball
        log_wall_from_ball(audio, t, ball)
    return hit


def _draw_shape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame

    if shape == "circle":
        if dash:
            n = max(1, int(math.pi * size / 20))
            for i in range(n):
                a0 = (2 * math.pi / n) * i
                a1 = a0 + math.pi / n
                pts = []
                for s in range(11):
                    a = a0 + (a1 - a0) * s / 10
                    pts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
                if len(pts) > 1:
                    pygame.draw.lines(surf, color, False, pts, width)
        else:
            pygame.draw.circle(surf, color, (cx, cy), size, width)
        return
    if shape == "square":
        half = size
        pygame.draw.rect(surf, color, pygame.Rect(cx - half, cy - half, half * 2, half * 2), width)
        return
    verts = _shape_vertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x), int(y)) for x, y in verts], width)


def _point_line_distance(px, py, x1, y1, x2, y2):
    return _closest_point_on_segment(px, py, x1, y1, x2, y2)[0]


def _flip_rules(rules):
    """Cycle / flip physics rule multipliers."""
    rules["gravity_sign"] *= -1
    # friction: toggle between low and high slip
    rules["friction"] = 0.985 if rules["friction"] > 0.993 else 0.9992
    # bounce: toggle
    rules["bounce"] = 0.92 if rules["bounce"] > 0.95 else 0.995
    # speed: toggle
    rules["speed_limit"] = 9.0 if rules["speed_limit"] > 11.0 else 16.0
    rules["hit_count"] += 1


def run(
    duration=18,
    output=None,
    fps=60,
    width=1080,
    height=1920,
    beam_count=6,
    beam_rotation_speed=1.2,
    beam_width=4,
    beam_hit_width=10.0,
    laser_color="#ff2244",
    laser_glow=True,
    hit_cooldown=12,
    ball_radius=22,
    ball_color="#00ffff",
    ball_glow=True,
    ball_trail=True,
    trail_length=18,
    glow_layers=5,
    ball_speed_min=4.0,
    ball_speed_max=8.0,
    gravity=0.22,
    friction=0.996,
    bounce=0.98,
    speed_limit=13.0,
    hit_knockback=4.5,
    show_rules_hud=True,
    flash_on_hit=True,
    shape="circle",
    circle_radius=None,
    ring_color="#ffffff",
    ring_width=4,
    ring_glow=False,
    ring_dash=False,
    ring_spin=False,
    ring_spin_speed=0.5,
    bg_color="#0d0d0d",
    bg_color2=None,
    bg_gradient_dir="vertical",
    collision_audio: dict | None = None,
    **kwargs,
):
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = (shape or "circle").lower().strip()
    beam_count = max(2, int(beam_count))
    hit_cooldown = max(1, int(hit_cooldown))

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"laserGridBall_{shape}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    total_frames = max(1, int(duration * fps))
    cx, cy = width // 2, height // 2
    cr = circle_radius or (min(width, height) // 2 - 80)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    rc = _hex(ring_color)
    bc = _hex(ball_color)
    lc = _hex(laser_color)
    grad_surf = _gradient_surface(width, height, bg1, bg2, bg_gradient_dir) if bg2 else None

    font = None
    if show_rules_hud:
        try:
            font = pygame.font.SysFont("DejaVu Sans", 26)
        except Exception:
            font = None

    ball = {
        "x": cx + random.uniform(-cr * 0.35, cr * 0.35),
        "y": cy + random.uniform(-cr * 0.35, cr * 0.35),
        "vx": random.choice([-1, 1]) * random.uniform(ball_speed_min, ball_speed_max),
        "vy": random.choice([-1, 1]) * random.uniform(ball_speed_min, ball_speed_max),
        "r": ball_radius,
        "trail": [],
        "flash": 0,
        "hit_cd": 0,
    }

    rules = {
        "gravity_sign": 1,
        "gravity": float(gravity),
        "friction": float(friction),
        "bounce": float(bounce),
        "speed_limit": float(speed_limit),
        "hit_count": 0,
    }

    beam_angle = random.uniform(0, 2 * math.pi)
    angle_offset = 0.0

    def beam_endpoints(angle):
        """Line through center spanning arena."""
        ex = cx + math.cos(angle) * cr
        ey = cy + math.sin(angle) * cr
        sx = cx - math.cos(angle) * cr
        sy = cy - math.sin(angle) * cr
        return sx, sy, ex, ey

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg1, 255))

            if ring_glow:
                _draw_glow(surface, rc, (cx, cy), cr, layers=3)
            _draw_shape(surface, shape, rc, cx, cy, cr, ring_width, angle_offset, dash=ring_dash)

            # draw lasers
            laser_surf = pygame.Surface((width, height), pygame.SRCALPHA)
            hit_thresh = ball["r"] + beam_hit_width
            laser_hit = False
            hit_normal = (0.0, 1.0)

            for i in range(beam_count):
                ang = beam_angle + (2 * math.pi * i / beam_count)
                x1, y1, x2, y2 = beam_endpoints(ang)
                col = (*lc, 220)
                if laser_glow:
                    for w in (beam_width + 8, beam_width + 4):
                        pygame.draw.line(laser_surf, (*lc, 60), (int(x1), int(y1)), (int(x2), int(y2)), w)
                pygame.draw.line(laser_surf, col, (int(x1), int(y1)), (int(x2), int(y2)), max(1, int(beam_width)))

                d = _point_line_distance(ball["x"], ball["y"], x1, y1, x2, y2)
                if d <= hit_thresh and ball["hit_cd"] <= 0:
                    laser_hit = True
                    # normal from line (perpendicular)
                    dx = x2 - x1
                    dy = y2 - y1
                    ln = math.hypot(dx, dy) + 1e-9
                    nx, ny = -dy / ln, dx / ln
                    # point from line toward ball
                    _, cpx, cpy = _closest_point_on_segment(ball["x"], ball["y"], x1, y1, x2, y2)
                    if (ball["x"] - cpx) * nx + (ball["y"] - cpy) * ny < 0:
                        nx, ny = -nx, -ny
                    hit_normal = (nx, ny)

            surface.blit(laser_surf, (0, 0))

            if laser_hit:
                log_wall_from_ball(audio, frame / fps, ball)
                _flip_rules(rules)
                ball["hit_cd"] = hit_cooldown
                if flash_on_hit:
                    ball["flash"] = 8
                ball["vx"] += hit_normal[0] * hit_knockback
                ball["vy"] += hit_normal[1] * hit_knockback

            if ball["hit_cd"] > 0:
                ball["hit_cd"] -= 1
            if ball["flash"] > 0:
                ball["flash"] -= 1

            # ball physics
            ball["vy"] += rules["gravity"] * rules["gravity_sign"]
            ball["vx"] *= rules["friction"]
            ball["vy"] *= rules["friction"]
            sp = math.hypot(ball["vx"], ball["vy"])
            if sp > rules["speed_limit"]:
                s = rules["speed_limit"] / sp
                ball["vx"] *= s
                ball["vy"] *= s
            ball["x"] += ball["vx"]
            ball["y"] += ball["vy"]
            _resolve_shape_collision(ball, shape, cx, cy, cr, rules["bounce"], angle_offset, audio=audio if audio.enabled else None, t=frame / fps)

            if ball_trail:
                ball["trail"].append((ball["x"], ball["y"], ball["r"]))
                if len(ball["trail"]) > trail_length:
                    ball["trail"].pop(0)
                n = len(ball["trail"])
                for i, (tx, ty, tr) in enumerate(ball["trail"]):
                    alpha = int(160 * (i / max(1, n)))
                    rad = max(2, int(tr * 0.62 * (i / max(1, n))))
                    _with_alpha_circle(surface, bc, (int(tx), int(ty)), rad, alpha)

            pos = (int(ball["x"]), int(ball["y"]))
            draw_col = (255, 255, 255) if ball["flash"] > 0 else bc
            if ball_glow:
                _draw_glow(surface, draw_col, pos, ball["r"], layers=glow_layers)
            pygame.draw.circle(surface, draw_col, pos, ball["r"])
            pygame.draw.circle(surface, (255, 255, 255), (pos[0] - ball["r"] // 4, pos[1] - ball["r"] // 4), max(1, ball["r"] // 5))

            if show_rules_hud and font:
                gtxt = "down" if rules["gravity_sign"] > 0 else "up"
                hud = (
                    f"hits:{rules['hit_count']}  g:{gtxt}  "
                    f"fric:{rules['friction']:.3f}  bounce:{rules['bounce']:.2f}  "
                    f"spd:{rules['speed_limit']:.0f}"
                )
                s = font.render(hud, True, (230, 230, 230))
                surface.blit(s, (24, 24))

            beam_angle += math.radians(beam_rotation_speed)
            if ring_spin:
                angle_offset += math.radians(ring_spin_speed)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(
                    f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%) "
                    f"| hits:{rules['hit_count']}"
                )

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-framerate",
                str(fps),
                "-i",
                str(frames_dir / "frame_%06d.png"),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "fast",
                "-crf",
                "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)
