"""
Chase Ball — Role Swap Chase
------------------------------
Two balls move inside a boundary shape. One ball (chaser) accelerates toward
the other (runner). When the chaser "catches" the runner, they swap roles.

Core:
    catch_multiplier     : float = 1.05   — distance threshold multiplier for catch
    swap_cooldown_frames : int   = 18     — prevent instant re-catch after swap

Motion:
    chase_force          : float = 0.22   — acceleration toward target
    evade_force          : float = 0.08   — runner acceleration away from chaser
    wander_force         : float = 0.06   — runner random steering
    turn_noise           : float = 0.10   — how often wander direction changes
    speed_limit          : float = 11.0

Shape:
    shape                : str   = "circle" — "circle","square","triangle","pentagon","hexagon","diamond"
    circle_radius        : int   = None
    ring_color           : str   = "#ffffff"
    ring_width           : int   = 5
    ring_glow            : bool  = False
    ring_dash            : bool  = False
    ring_spin            : bool  = False
    ring_spin_speed      : float = 0.5     — degrees per frame

Balls:
    ball_radius          : int   = 28
    ball_colors          : list  = None    — hex list; uses first two if provided
    ball_glow            : bool  = True
    ball_trail           : bool  = True
    trail_length         : int   = 22
    glow_layers          : int   = 5
    glow_strength        : int   = 60      — alpha scaling for glow layers

Physics:
    bounce               : float = 0.98
    friction             : float = 0.995

Background:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"  — "vertical"|"horizontal"|"radial"

Output:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 18
"""

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


def _hex(h: str) -> tuple[int, int, int]:
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _clamp(x: float, a: float, b: float) -> float:
    return a if x < a else b if x > b else x


def _with_alpha_circle(surf, color, pos, r, alpha: int):
    import pygame

    if r <= 0 or alpha <= 0:
        return
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0] - r, pos[1] - r))


def _draw_glow(surf, color, pos, r, layers=5, strength=60):
    for i in range(layers, 0, -1):
        _with_alpha_circle(surf, color, pos, r + i * 7, int(strength / i))


def _gradient_surface(w: int, h: int, c1, c2, direction="vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (x, 0), (x, h))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_d = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max_d)
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                surf.set_at((x, y), (r, g, b))
    else:
        for y in range(h):
            t = y / max(1, h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (0, y), (w, y))
    return surf


_SHAPE_SIDES = {
    "triangle": 3,
    "diamond": 4,
    "pentagon": 5,
    "hexagon": 6,
}


def _shape_vertices(shape: str, cx: int, cy: int, size: int, angle_offset: float = 0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    verts = []
    for i in range(sides):
        a = angle_offset + (2 * math.pi * i / sides) - math.pi / 2
        verts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
    return verts


def _closest_point_on_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-9)
    t = _clamp(t, 0.0, 1.0)
    cx2 = ax + t * dx
    cy2 = ay + t * dy
    nx = px - cx2
    ny = py - cy2
    dist = math.hypot(nx, ny)
    if dist < 1e-6:
        nx, ny = -dy, dx
        dist = math.hypot(nx, ny)
    return cx2, cy2, nx / dist, ny / dist, dist


def _resolve_shape_collision(ball: dict, shape: str, cx: int, cy: int, size: int, bounce: float, angle_offset=0.0, audio=None, t: float = 0.0):
    bx, by, br = ball["x"], ball["y"], ball["r"]
    hit = False

    if shape == "circle":
        dx = bx - cx
        dy = by - cy
        dist = math.hypot(dx, dy)
        md = size - br
        if dist > md and dist > 0:
            nx = dx / dist
            ny = dy / dist
            ball["x"] = cx + nx * md
            ball["y"] = cy + ny * md
            dot = ball["vx"] * nx + ball["vy"] * ny
            ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
            ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
            hit = True

    elif shape == "square":
        half = size - br
        if bx < cx - half:
            ball["x"] = cx - half
            ball["vx"] = abs(ball["vx"]) * bounce
            hit = True
        elif bx > cx + half:
            ball["x"] = cx + half
            ball["vx"] = -abs(ball["vx"]) * bounce
            hit = True
        if by < cy - half:
            ball["y"] = cy - half
            ball["vy"] = abs(ball["vy"]) * bounce
            hit = True
        elif by > cy + half:
            ball["y"] = cy + half
            ball["vy"] = -abs(ball["vy"]) * bounce
            hit = True

    else:
        verts = _shape_vertices(shape, cx, cy, size, angle_offset)
        n = len(verts)
        for i in range(n):
            ax, ay = verts[i]
            bx2, by2 = verts[(i + 1) % n]
            cpx, cpy, nx, ny, dist = _closest_point_on_segment(bx, by, ax, ay, bx2, by2)

            # Make normal point inward (toward center)
            to_center_x = cx - cpx
            to_center_y = cy - cpy
            if nx * to_center_x + ny * to_center_y < 0:
                nx, ny = -nx, -ny

            if dist < br:
                overlap = br - dist
                ball["x"] += nx * overlap
                ball["y"] += ny * overlap
                dot = ball["vx"] * nx + ball["vy"] * ny
                if dot < 0:
                    ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
                    ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
                hit = True

    if hit and audio is not None:
        from Games.collision_audio import log_wall_from_ball
        log_wall_from_ball(audio, t, ball)
    return hit


def _draw_shape(surf, shape: str, color, cx: int, cy: int, size: int, width: int, angle_offset: float = 0.0, dash: bool = False):
    import pygame

    if shape == "circle":
        if dash:
            n = max(1, int(math.pi * size / 22))
            for i in range(n):
                a0 = (2 * math.pi / n) * i
                a1 = a0 + math.pi / n
                pts = []
                for s in range(11):
                    a = a0 + (a1 - a0) * s / 10
                    pts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
                if len(pts) > 1:
                    pygame.draw.lines(surf, color, False, pts, width)
        else:
            pygame.draw.circle(surf, color, (cx, cy), size, width)
        return

    if shape == "square":
        half = size
        rect = pygame.Rect(cx - half, cy - half, half * 2, half * 2)
        pygame.draw.rect(surf, color, rect, width)
        return

    verts = _shape_vertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x), int(y)) for x, y in verts], width)


def run(
    duration: int = 18,
    output: Path | None = None,
    fps: int = 60,
    width: int = 1080,
    height: int = 1920,
    shape: str = "circle",
    circle_radius: int | None = None,
    ring_color: str = "#ffffff",
    ring_width: int = 5,
    ring_glow: bool = False,
    ring_dash: bool = False,
    ring_spin: bool = False,
    ring_spin_speed: float = 0.5,
    ball_radius: int = 28,
    ball_colors: list | None = None,
    colors: list | None = None,
    ball_glow: bool = True,
    ball_trail: bool = True,
    trail_length: int = 22,
    glow_layers: int = 5,
    glow_strength: int = 60,
    chase_force: float = 0.22,
    evade_force: float = 0.08,
    wander_force: float = 0.06,
    turn_noise: float = 0.10,
    speed_limit: float = 11.0,
    bounce: float = 0.98,
    friction: float = 0.995,
    catch_multiplier: float = 1.05,
    swap_cooldown_frames: int = 18,
    bg_color: str = "#0d0d0d",
    bg_color2: str | None = None,
    bg_gradient_dir: str = "vertical",
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = (shape or "circle").lower().strip()
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"chase_{shape}_{stamp}.mp4"

    palette = ball_colors or colors or ["#00ffff", "#ff00ff"]
    c_chaser = _hex(palette[0] if len(palette) > 0 else "#00ffff")
    c_runner = _hex(palette[1] if len(palette) > 1 else "#ff00ff")
    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    rc = _hex(ring_color)

    pygame.init()
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    total_frames = max(1, int(duration * fps))

    cx = width // 2
    cy = height // 2
    cr = circle_radius or (min(width, height) // 2 - 80)

    grad_surf = None
    if bg2:
        grad_surf = _gradient_surface(width, height, bg1, bg2, bg_gradient_dir)

    # balls
    def spawn_pos():
        if shape == "circle":
            ang = random.uniform(0, 2 * math.pi)
            dist = random.uniform(0, max(10, cr - ball_radius - 30))
            return cx + dist * math.cos(ang), cy + dist * math.sin(ang)
        # basic spawn for non-circles: inside the square-ish bounds
        return (
            random.uniform(cx - cr * 0.6, cx + cr * 0.6),
            random.uniform(cy - cr * 0.6, cy + cr * 0.6),
        )

    x1, y1 = spawn_pos()
    x2, y2 = spawn_pos()

    balls = [
        {"x": x1, "y": y1, "vx": random.uniform(-3, 3), "vy": random.uniform(-3, 3), "r": ball_radius, "trail": []},
        {"x": x2, "y": y2, "vx": random.uniform(-3, 3), "vy": random.uniform(-3, 3), "r": ball_radius, "trail": []},
    ]

    chaser_idx = 0
    cooldown = 0

    # runner wander direction
    w_ang = random.uniform(0, 2 * math.pi)
    angle_offset = 0.0

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):
            # background
            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg1, 255))

            # ring
            if ring_glow:
                _draw_glow(surface, rc, (cx, cy), cr, layers=3, strength=55)

            _draw_shape(surface, shape, rc, cx, cy, cr, ring_width, angle_offset, dash=ring_dash)

            if ring_spin:
                angle_offset += math.radians(ring_spin_speed)

            # steering
            if frame % max(2, int(1 / max(1e-6, turn_noise))) == 0:
                w_ang += random.uniform(-1.0, 1.0)

            runner_idx = 1 - chaser_idx
            ch = balls[chaser_idx]
            ru = balls[runner_idx]

            dx = ru["x"] - ch["x"]
            dy = ru["y"] - ch["y"]
            dist = math.hypot(dx, dy) + 1e-9
            nx, ny = dx / dist, dy / dist

            # chaser accelerates toward runner
            ch["vx"] += nx * chase_force
            ch["vy"] += ny * chase_force

            # runner accelerates away + wander
            ru["vx"] += (-nx) * evade_force + math.cos(w_ang) * wander_force
            ru["vy"] += (-ny) * evade_force + math.sin(w_ang) * wander_force

            # integrate physics for both
            for b in balls:
                b["vx"] *= friction
                b["vy"] *= friction

                sp = math.hypot(b["vx"], b["vy"])
                if sp > speed_limit:
                    s = speed_limit / sp
                    b["vx"] *= s
                    b["vy"] *= s

                b["x"] += b["vx"]
                b["y"] += b["vy"]

                _resolve_shape_collision(b, shape, cx, cy, cr, bounce, angle_offset, audio=audio if audio.enabled else None, t=frame / fps)

            # catch -> swap roles
            if cooldown > 0:
                cooldown -= 1
            else:
                catch_dist = (ch["r"] + ru["r"]) * catch_multiplier
                if dist <= catch_dist:
                    chaser_idx = runner_idx
                    cooldown = max(0, int(swap_cooldown_frames))
                    # quick shove to separate (prevents jitter / immediate swap back)
                    balls[chaser_idx]["vx"] += nx * 3.0
                    balls[chaser_idx]["vy"] += ny * 3.0
                    balls[1 - chaser_idx]["vx"] -= nx * 3.0
                    balls[1 - chaser_idx]["vy"] -= ny * 3.0

            # draw trails + balls
            for i, b in enumerate(balls):
                col = c_chaser if i == chaser_idx else c_runner
                pos = (int(b["x"]), int(b["y"]))

                if ball_trail:
                    b["trail"].append((b["x"], b["y"], b["r"]))
                    if len(b["trail"]) > trail_length:
                        b["trail"].pop(0)
                    ntr = len(b["trail"])
                    for ti, (tx, ty, tr) in enumerate(b["trail"]):
                        alpha = int(160 * (ti / max(1, ntr)))
                        rad = max(2, int(tr * 0.55 * (ti / max(1, ntr))))
                        _with_alpha_circle(surface, col, (int(tx), int(ty)), rad, alpha)

                if ball_glow:
                    _draw_glow(surface, col, pos, b["r"], layers=glow_layers, strength=glow_strength)
                pygame.draw.circle(surface, col, pos, b["r"])

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-framerate",
                str(fps),
                "-i",
                str(frames_dir / "frame_%06d.png"),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "fast",
                "-crf",
                "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)

