"""
Wormhole Ball — Two Portals Teleport
-------------------------------------
A ball bounces inside a boundary shape.
Two portals are placed inside the arena; entering one exits from the other.

PORTALS:
    portal_radius         : int   = 70
    portal_a_color        : str   = "#00ffff"
    portal_b_color        : str   = "#ff00ff"
    portal_glow           : bool  = True
    portal_swirl          : bool  = True
    portal_spin_speed     : float = 1.5
    portal_separation     : float = 0.55    — fraction of arena radius
    teleport_cooldown     : int   = 16      — frames after teleport before next teleport
    exit_boost            : float = 1.03    — speed multiplier on exit

BALL:
    ball_radius           : int   = 24
    ball_color            : str   = "#ffffff"
    ball_glow             : bool  = True
    ball_trail            : bool  = True
    trail_length          : int   = 20
    glow_layers           : int   = 5
    ball_speed_min        : float = 4.0
    ball_speed_max        : float = 8.0

PHYSICS:
    gravity               : float = 0.12
    bounce                : float = 0.985
    friction              : float = 0.998
    speed_limit           : float = 14.0

SHAPE:
    shape                 : str   = "circle" — "circle","square","triangle","pentagon","hexagon","diamond"
    circle_radius         : int   = None
    ring_color            : str   = "#ffffff"
    ring_width            : int   = 4
    ring_glow             : bool  = False
    ring_dash             : bool  = False
    ring_spin             : bool  = False
    ring_spin_speed       : float = 0.5

BACKGROUND:
    bg_color              : str   = "#0d0d0d"
    bg_color2             : str   = None
    bg_gradient_dir       : str   = "vertical"

OUTPUT:
    fps                   : int   = 60
    width                 : int   = 1080
    height                : int   = 1920
    duration              : int   = 16
"""

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


def _hex(h):
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _with_alpha_circle(surf, color, pos, r, alpha):
    import pygame

    if r <= 0 or alpha <= 0:
        return
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0] - r, pos[1] - r))


def _draw_glow(surf, color, pos, r, layers=5):
    for i in range(layers, 0, -1):
        _with_alpha_circle(surf, color, pos, r + i * 7, int(60 / i))


def _gradient_surface(w, h, c1, c2, direction="vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (x, 0), (x, h))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_d = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max_d)
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                surf.set_at((x, y), (r, g, b))
    else:
        for y in range(h):
            t = y / max(1, h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (0, y), (w, y))
    return surf


_SHAPE_SIDES = {"triangle": 3, "diamond": 4, "pentagon": 5, "hexagon": 6}


def _shape_vertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [
        (
            cx + size * math.cos(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
            cy + size * math.sin(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
        )
        for i in range(sides)
    ]


def _closest_point_on_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-9)
    t = max(0.0, min(1.0, t))
    cx2 = ax + t * dx
    cy2 = ay + t * dy
    nx = px - cx2
    ny = py - cy2
    dist = math.hypot(nx, ny)
    if dist < 1e-6:
        nx, ny = -dy, dx
        dist = math.hypot(nx, ny)
    return cx2, cy2, nx / dist, ny / dist, dist


def _resolve_shape_collision(ball, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx, by, br = ball["x"], ball["y"], ball["r"]
    hit = False
    if shape == "circle":
        dx, dy = bx - cx, by - cy
        dist = math.hypot(dx, dy)
        md = size - br
        if dist > md and dist > 0:
            nx, ny = dx / dist, dy / dist
            ball["x"] = cx + nx * md
            ball["y"] = cy + ny * md
            dot = ball["vx"] * nx + ball["vy"] * ny
            ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
            ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
            hit = True
    elif shape == "square":
        half = size - br
        if bx < cx - half:
            ball["x"] = cx - half
            ball["vx"] = abs(ball["vx"]) * bounce
            hit = True
        elif bx > cx + half:
            ball["x"] = cx + half
            ball["vx"] = -abs(ball["vx"]) * bounce
            hit = True
        if by < cy - half:
            ball["y"] = cy - half
            ball["vy"] = abs(ball["vy"]) * bounce
            hit = True
        elif by > cy + half:
            ball["y"] = cy + half
            ball["vy"] = -abs(ball["vy"]) * bounce
            hit = True
    else:
        verts = _shape_vertices(shape, cx, cy, size, angle_offset)
        for i in range(len(verts)):
            ax, ay = verts[i]
            bx2, by2 = verts[(i + 1) % len(verts)]
            cpx, cpy, nx, ny, dist = _closest_point_on_segment(bx, by, ax, ay, bx2, by2)
            to_center_x = cx - cpx
            to_center_y = cy - cpy
            if nx * to_center_x + ny * to_center_y < 0:
                nx, ny = -nx, -ny
            if dist < br:
                overlap = br - dist
                ball["x"] += nx * overlap
                ball["y"] += ny * overlap
                dot = ball["vx"] * nx + ball["vy"] * ny
                if dot < 0:
                    ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
                    ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
                hit = True
    if hit and audio is not None:
        from Games.collision_audio import log_wall_from_ball
        log_wall_from_ball(audio, t, ball)
    return hit


def _draw_shape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame

    if shape == "circle":
        if dash:
            n = max(1, int(math.pi * size / 20))
            for i in range(n):
                a0 = (2 * math.pi / n) * i
                a1 = a0 + math.pi / n
                pts = []
                for s in range(11):
                    a = a0 + (a1 - a0) * s / 10
                    pts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
                if len(pts) > 1:
                    pygame.draw.lines(surf, color, False, pts, width)
        else:
            pygame.draw.circle(surf, color, (cx, cy), size, width)
        return
    if shape == "square":
        half = size
        pygame.draw.rect(surf, color, pygame.Rect(cx - half, cy - half, half * 2, half * 2), width)
        return
    verts = _shape_vertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x), int(y)) for x, y in verts], width)


def run(
    duration=16,
    output=None,
    fps=60,
    width=1080,
    height=1920,
    portal_radius=70,
    portal_a_color="#00ffff",
    portal_b_color="#ff00ff",
    portal_glow=True,
    portal_swirl=True,
    portal_spin_speed=1.5,
    portal_separation=0.55,
    teleport_cooldown=16,
    exit_boost=1.03,
    ball_radius=24,
    ball_color="#ffffff",
    ball_glow=True,
    ball_trail=True,
    trail_length=20,
    glow_layers=5,
    ball_speed_min=4.0,
    ball_speed_max=8.0,
    gravity=0.12,
    bounce=0.985,
    friction=0.998,
    speed_limit=14.0,
    shape="circle",
    circle_radius=None,
    ring_color="#ffffff",
    ring_width=4,
    ring_glow=False,
    ring_dash=False,
    ring_spin=False,
    ring_spin_speed=0.5,
    bg_color="#0d0d0d",
    bg_color2=None,
    bg_gradient_dir="vertical",
    collision_audio: dict | None = None,
    **kwargs,
):
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = (shape or "circle").lower().strip()
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"wormholeBall_{shape}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    total_frames = max(1, int(duration * fps))
    cx, cy = width // 2, height // 2
    cr = circle_radius or (min(width, height) // 2 - 80)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    rc = _hex(ring_color)
    c_ball = _hex(ball_color)
    c_pa = _hex(portal_a_color)
    c_pb = _hex(portal_b_color)
    grad_surf = _gradient_surface(width, height, bg1, bg2, bg_gradient_dir) if bg2 else None

    sep = max(0.2, min(0.85, float(portal_separation))) * cr
    p1 = {"x": cx - sep * 0.5, "y": cy}
    p2 = {"x": cx + sep * 0.5, "y": cy}

    # Keep portals inside arena by clamping roughly to safe area.
    safe = cr - portal_radius - ball_radius - 8
    p1["x"] = max(cx - safe, min(cx + safe, p1["x"]))
    p2["x"] = max(cx - safe, min(cx + safe, p2["x"]))

    ball = {
        "x": cx + random.uniform(-cr * 0.4, cr * 0.4),
        "y": cy + random.uniform(-cr * 0.4, cr * 0.4),
        "vx": random.choice([-1, 1]) * random.uniform(ball_speed_min, ball_speed_max),
        "vy": random.choice([-1, 1]) * random.uniform(ball_speed_min, ball_speed_max),
        "r": ball_radius,
        "trail": [],
        "tp_cd": 0,
    }

    angle_offset = 0.0
    swirl = 0.0

    def draw_portal(px, py, col, spin):
        # layered ring + optional swirl spokes
        if portal_glow:
            _draw_glow(surface, col, (int(px), int(py)), portal_radius, layers=4)
        pygame.draw.circle(surface, col, (int(px), int(py)), int(portal_radius), 3)
        pygame.draw.circle(surface, col, (int(px), int(py)), int(portal_radius * 0.66), 2)
        if portal_swirl:
            ps = pygame.Surface((width, height), pygame.SRCALPHA)
            for i in range(6):
                a = spin + i * (2 * math.pi / 6)
                x2 = px + math.cos(a) * portal_radius * 0.7
                y2 = py + math.sin(a) * portal_radius * 0.7
                pygame.draw.line(ps, (*col, 90), (int(px), int(py)), (int(x2), int(y2)), 2)
            surface.blit(ps, (0, 0))

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg1, 255))

            if ring_glow:
                _draw_glow(surface, rc, (cx, cy), cr, layers=3)
            _draw_shape(surface, shape, rc, cx, cy, cr, ring_width, angle_offset, dash=ring_dash)

            draw_portal(p1["x"], p1["y"], c_pa, swirl)
            draw_portal(p2["x"], p2["y"], c_pb, -swirl * 1.07)

            # ball physics
            ball["vy"] += gravity
            ball["vx"] *= friction
            ball["vy"] *= friction
            sp = math.hypot(ball["vx"], ball["vy"])
            if sp > speed_limit:
                s = speed_limit / sp
                ball["vx"] *= s
                ball["vy"] *= s

            ball["x"] += ball["vx"]
            ball["y"] += ball["vy"]
            _resolve_shape_collision(ball, shape, cx, cy, cr, bounce, angle_offset, audio=audio if audio.enabled else None, t=frame / fps)

            if ball["tp_cd"] > 0:
                ball["tp_cd"] -= 1
            else:
                d1 = math.hypot(ball["x"] - p1["x"], ball["y"] - p1["y"])
                d2 = math.hypot(ball["x"] - p2["x"], ball["y"] - p2["y"])
                enter_r = max(4, portal_radius - ball["r"] * 0.35)
                if d1 <= enter_r:
                    # preserve offset + direction, place at portal 2
                    ox = ball["x"] - p1["x"]
                    oy = ball["y"] - p1["y"]
                    ball["x"] = p2["x"] + ox
                    ball["y"] = p2["y"] + oy
                    ball["vx"] *= exit_boost
                    ball["vy"] *= exit_boost
                    ball["tp_cd"] = max(1, int(teleport_cooldown))
                elif d2 <= enter_r:
                    ox = ball["x"] - p2["x"]
                    oy = ball["y"] - p2["y"]
                    ball["x"] = p1["x"] + ox
                    ball["y"] = p1["y"] + oy
                    ball["vx"] *= exit_boost
                    ball["vy"] *= exit_boost
                    ball["tp_cd"] = max(1, int(teleport_cooldown))

            if ball_trail:
                ball["trail"].append((ball["x"], ball["y"], ball["r"]))
                if len(ball["trail"]) > trail_length:
                    ball["trail"].pop(0)
                n = len(ball["trail"])
                for i, (tx, ty, tr) in enumerate(ball["trail"]):
                    alpha = int(160 * (i / max(1, n)))
                    rad = max(2, int(tr * 0.6 * (i / max(1, n))))
                    _with_alpha_circle(surface, c_ball, (int(tx), int(ty)), rad, alpha)

            pos = (int(ball["x"]), int(ball["y"]))
            if ball_glow:
                _draw_glow(surface, c_ball, pos, ball["r"], layers=glow_layers)
            pygame.draw.circle(surface, c_ball, pos, ball["r"])
            pygame.draw.circle(surface, (255, 255, 255), (pos[0] - ball["r"] // 4, pos[1] - ball["r"] // 4), max(1, ball["r"] // 5))

            if ring_spin:
                angle_offset += math.radians(ring_spin_speed)
            swirl += math.radians(portal_spin_speed)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-framerate",
                str(fps),
                "-i",
                str(frames_dir / "frame_%06d.png"),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "fast",
                "-crf",
                "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)

