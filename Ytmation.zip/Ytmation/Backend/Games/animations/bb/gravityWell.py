"""
Gravity Well — Full Customization
------------------------------------
Multiple balls orbit a central gravity point, accelerate, slingshot and collide.

CORE:
    end_behavior         : str   = "loop"    — "stop" | "loop" (reset when all absorbed)
    loop_count           : int   = 0         — max loops (0 = infinite)

WELL:
    well_count           : int   = 1         — number of gravity wells (1-3)
    well_strength        : float = 0.15      — gravitational pull per frame
    well_radius          : int   = 30        — absorb ball if closer than this
    well_color           : str   = "#ffffff"
    show_well            : bool  = True      — draw the well visually
    well_pulse           : bool  = True      — well pulses/breathes
    well_glow            : bool  = True
    well_glow_layers     : int   = 6
    multi_well_layout    : str   = "triangle" — "line"|"triangle"|"random" (if well_count>1)
    multi_well_distance  : int   = 300        — distance between wells

BALLS:
    ball_count           : int   = 8
    ball_colors          : list  = None      — hex list, random if None
    ball_radius          : int   = 18
    ball_glow            : bool  = True
    ball_trail           : bool  = True
    trail_length         : int   = 30
    ball_shine           : bool  = True
    ball_opacity         : int   = 255
    ball_collision       : bool  = True
    spawn_mode           : str   = "ring"    — "ring"|"scatter"|"random"
    spawn_radius         : int   = None      — auto if None

PHYSICS:
    speed_limit          : float = 20.0      — max ball speed
    bounce               : float = 0.8       — ball-ball collision bounce
    escape_velocity      : float = 18.0      — above this speed ball escapes screen
    slingshot            : bool  = True      — balls can slingshot around the well

HIT EFFECTS:
    on_collision_flash   : bool  = True
    on_collision_particles: bool = False
    on_absorb_particles  : bool  = True      — burst when ball is absorbed
    particle_count       : int   = 12
    particle_speed       : float = 1.5
    particle_colors      : list  = None

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"
    bg_image             : str   = None
    bg_image_alpha       : int   = 255

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 20
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*8, int(60/i))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i, (tx, ty, tr) in enumerate(trail):
        alpha = int(180*(i/n))
        rad   = max(2, int(tr*0.8*(i/n)))
        _withAlpha(surf, color, (int(tx),int(ty)), rad, alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255*(p["life"]/p["max_life"]))
        r     = max(1, int(p["r"]*(p["life"]/p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]),int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=12, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0,2*math.pi)
        speed = random.uniform(2,9)*speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({"x":x,"y":y,
                    "vx":math.cos(angle)*speed,"vy":math.sin(angle)*speed,
                    "r":random.randint(3,9),"color":c,
                    "life":random.randint(12,28),"max_life":28})
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w,h))
    if direction=="horizontal":
        for x in range(w):
            t=x/w
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(x,0),(x,h))
    elif direction=="radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img = pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img, size)


# ── well helpers ───────────────────────────────────────────────────────────────

def _buildWells(well_count, layout, cx, cy, dist, well_radius, well_color):
    wc = _hex(well_color)
    wells = []
    if well_count == 1:
        wells = [{"x":float(cx),"y":float(cy),"r":well_radius,"color":wc}]
    elif well_count == 2:
        wells = [
            {"x":float(cx-dist//2),"y":float(cy),"r":well_radius,"color":wc},
            {"x":float(cx+dist//2),"y":float(cy),"r":well_radius,"color":wc},
        ]
    else:
        if layout == "line":
            step = dist // max(1, well_count-1)
            for i in range(well_count):
                wells.append({"x":float(cx - dist//2 + i*step),
                               "y":float(cy),"r":well_radius,"color":wc})
        elif layout == "random":
            for _ in range(well_count):
                wells.append({"x":float(cx+random.randint(-dist//2,dist//2)),
                               "y":float(cy+random.randint(-dist//2,dist//2)),
                               "r":well_radius,"color":wc})
        else:  # triangle / polygon
            for i in range(well_count):
                a = 2*math.pi*i/well_count - math.pi/2
                wells.append({"x":float(cx+dist//2*math.cos(a)),
                               "y":float(cy+dist//2*math.sin(a)),
                               "r":well_radius,"color":wc})
    return wells

def _drawWell(surf, well, show_well, well_glow, well_glow_layers, pulse_r):
    import pygame
    pos = (int(well["x"]), int(well["y"]))
    r   = int(pulse_r)
    if well_glow:
        _drawGlow(surf, well["color"], pos, r, layers=well_glow_layers)
    if show_well:
        pygame.draw.circle(surf, well["color"], pos, r)
        # inner dark hole
        inner = max(2, r-4)
        pygame.draw.circle(surf, (0,0,0), pos, inner)
        # ring
        pygame.draw.circle(surf, well["color"], pos, r, 3)


# ── ball helpers ───────────────────────────────────────────────────────────────

def _buildBalls(ball_count, spawn_mode, spawn_radius,
                cx, cy, ball_radius, palette, speed_limit):
    balls = []
    for i in range(ball_count):
        color = _hex(random.choice(palette)) if palette else (
            random.randint(80,255), random.randint(80,255), random.randint(80,255))

        if spawn_mode == "ring":
            angle = 2*math.pi*i/ball_count
            dist  = spawn_radius
        elif spawn_mode == "scatter":
            angle = 2*math.pi*i/ball_count + random.uniform(-0.3,0.3)
            dist  = spawn_radius * random.uniform(0.6, 1.0)
        else:  # random
            angle = random.uniform(0,2*math.pi)
            dist  = random.uniform(spawn_radius*0.4, spawn_radius)

        x = cx + dist*math.cos(angle)
        y = cy + dist*math.sin(angle)

        # initial tangential velocity for orbit
        orb_speed = math.sqrt(max(0.1, dist*0.0005)) * 3.5
        tang = angle + math.pi/2
        vx = math.cos(tang)*orb_speed
        vy = math.sin(tang)*orb_speed

        balls.append({
            "x":float(x),"y":float(y),
            "vx":float(vx),"vy":float(vy),
            "r":ball_radius,"color":color,
            "flash":0,"trail":[],
            "active":True,
        })
    return balls


def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):
    n = len(balls)
    for i in range(n):
        for j in range(i+1,n):
            a,b = balls[i],balls[j]
            if not a["active"] or not b["active"]: continue
            dx=b["x"]-a["x"]; dy=b["y"]-a["y"]
            dist=math.hypot(dx,dy); md=a["r"]+b["r"]
            if dist<md and dist>0:
                overlap=(md-dist)/2; nx=dx/dist; ny=dy/dist
                a["x"]-=nx*overlap; a["y"]-=ny*overlap
                b["x"]+=nx*overlap; b["y"]+=ny*overlap
                dvx=a["vx"]-b["vx"]; dvy=a["vy"]-b["vy"]
                dot=dvx*nx+dvy*ny
                if dot>0:
                    a["vx"]=(a["vx"]-dot*nx)*bounce; a["vy"]=(a["vy"]-dot*ny)*bounce
                    b["vx"]=(b["vx"]+dot*nx)*bounce; b["vy"]=(b["vy"]+dot*ny)*bounce
                a["flash"]=4; b["flash"]=4
                if audio is not None:
                    from Games.collision_audio import log_ball_pair
                    log_ball_pair(audio, t, dvx, dvy)
                return True  # one collision per frame
    return False


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    duration: int               = 20,
    output: Path                = None,
    fps: int                    = 60,
    width: int                  = 1080,
    height: int                 = 1920,
    # core
    end_behavior: str           = "loop",
    loop_count: int             = 0,
    # well
    well_count: int             = 1,
    well_strength: float        = 0.15,
    well_radius: int            = 30,
    well_color: str             = "#ffffff",
    show_well: bool             = True,
    well_pulse: bool            = True,
    well_glow: bool             = True,
    well_glow_layers: int       = 6,
    multi_well_layout: str      = "triangle",
    multi_well_distance: int    = 300,
    # balls
    ball_count: int             = 8,
    ball_colors: list           = None,
    ball_radius: int            = 18,
    ball_glow: bool             = True,
    ball_trail: bool            = True,
    trail_length: int           = 30,
    ball_shine: bool            = True,
    ball_opacity: int           = 255,
    ball_collision: bool        = True,
    spawn_mode: str             = "ring",
    spawn_radius: int           = None,
    # physics
    speed_limit: float          = 20.0,
    bounce: float               = 0.8,
    escape_velocity: float      = 18.0,
    slingshot: bool             = True,
    # hit effects
    on_collision_flash: bool    = True,
    on_collision_particles: bool= False,
    on_absorb_particles: bool   = True,
    particle_count: int         = 12,
    particle_speed: float       = 1.5,
    particle_colors: list       = None,
    # background
    bg_color: str               = "#0d0d0d",
    bg_color2: str              = None,
    bg_gradient_dir: str        = "vertical",
    bg_image: str               = None,
    bg_image_alpha: int         = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER","dummy")
    os.environ.setdefault("SDL_AUDIODRIVER","dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"gravityWell_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width,height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    sr = spawn_radius or min(width,height)//3

    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image,(width,height))
        if bg_image_alpha<255: raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    def _reset():
        wells = _buildWells(well_count, multi_well_layout, cx, cy,
                            multi_well_distance, well_radius, well_color)
        balls = _buildBalls(ball_count, spawn_mode, sr,
                            cx, cy, ball_radius, ball_colors, speed_limit)
        return wells, balls

    wells, balls = _reset()
    particles    = []
    pulse_t      = 0.0
    loops_done   = 0
    done         = False

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))
                continue

            pulse_t += 0.05

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255)); surface.blit(bg_img_surf,(0,0))
            elif grad_surf:
                surface.blit(grad_surf,(0,0))
            else:
                surface.fill((*bg,255))

            # ── draw distortion rings around wells ────────────────────────
            for well in wells:
                wpos = (int(well["x"]),int(well["y"]))
                for ring in range(1,5):
                    ring_r  = well["r"] + ring*40 + int(math.sin(pulse_t+ring)*8)
                    ring_alpha = max(0, 60 - ring*12)
                    s = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
                    pygame.draw.circle(s, (*well["color"],ring_alpha), wpos, ring_r, 1)
                    surface.blit(s,(0,0))

            # ── draw wells ────────────────────────────────────────────────
            for well in wells:
                pr = well["r"] + (int(math.sin(pulse_t)*5) if well_pulse else 0)
                _drawWell(surface, well, show_well, well_glow, well_glow_layers, pr)

            # ── particles ─────────────────────────────────────────────────
            _drawParticles(surface, particles)
            for p in particles:
                p["x"]+=p["vx"]; p["y"]+=p["vy"]
                p["vy"]+=0.1;    p["life"]-=1
            particles=[p for p in particles if p["life"]>0]

            # ── gravity + physics ─────────────────────────────────────────
            active_balls = [b for b in balls if b["active"]]

            for b in active_balls:
                # apply gravity from each well
                for well in wells:
                    dx = well["x"]-b["x"]
                    dy = well["y"]-b["y"]
                    dist = math.hypot(dx,dy)

                    if dist < well["r"]:
                        # absorbed by well
                        b["active"] = False
                        if on_absorb_particles:
                            particles+=_spawnParticles(
                                b["x"],b["y"],b["color"],pcolors,
                                count=particle_count*2,speed_mult=particle_speed*1.5)
                        break

                    # gravitational acceleration — inverse square law
                    # with softening to prevent singularity
                    softened = max(dist, well["r"]*1.5)
                    force    = well_strength * 1000.0 / (softened*softened)
                    force    = min(force, 2.0)  # cap force
                    b["vx"] += (dx/dist)*force
                    b["vy"] += (dy/dist)*force

                if not b["active"]: continue

                # speed limit
                spd = math.hypot(b["vx"],b["vy"])
                if spd > speed_limit:
                    b["vx"] = b["vx"]/spd*speed_limit
                    b["vy"] = b["vy"]/spd*speed_limit

                b["x"] += b["vx"]
                b["y"] += b["vy"]

                # trail
                if ball_trail:
                    b["trail"].append((b["x"],b["y"],b["r"]))
                    if len(b["trail"])>trail_length: b["trail"].pop(0)

                # escape — ball too far off screen
                if (abs(b["x"]-cx) > width or abs(b["y"]-cy) > height*0.8):
                    b["active"] = False
                    if on_absorb_particles:
                        particles+=_spawnParticles(
                            b["x"],b["y"],b["color"],pcolors,
                            count=particle_count,speed_mult=particle_speed)

            # ── ball-ball collision ────────────────────────────────────────
            if ball_collision:
                col = _resolveBallCollisions(active_balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)
                if col and on_collision_particles:
                    # find the pair that collided (approximate — just use first active)
                    if active_balls:
                        b0=active_balls[0]
                        particles+=_spawnParticles(
                            b0["x"],b0["y"],b0["color"],pcolors,
                            count=particle_count//2,speed_mult=particle_speed)

            # ── draw trails + balls ───────────────────────────────────────
            for b in balls:
                if not b["active"]: continue
                if ball_trail:
                    _drawTrail(surface,b["trail"],b["color"])

            for b in balls:
                if not b["active"]: continue
                pos        = (int(b["x"]),int(b["y"]))
                r_int      = max(1,b["r"])
                draw_color = _lighten(b["color"],180) if b["flash"]>0 else b["color"]

                if ball_glow: _drawGlow(surface,draw_color,pos,r_int,layers=3)

                if ball_opacity<255:
                    _withAlpha(surface,draw_color,pos,r_int,ball_opacity)
                else:
                    pygame.draw.circle(surface,draw_color,pos,r_int)

                if ball_shine and r_int>6:
                    pygame.draw.circle(surface,(255,255,255),
                        (pos[0]-r_int//4,pos[1]-r_int//4),max(1,r_int//5))

                if b["flash"]>0: b["flash"]-=1

            # ── check all absorbed ────────────────────────────────────────
            if all(not b["active"] for b in balls):
                loops_done+=1
                print(f"   All balls absorbed/escaped. Loop {loops_done} at frame {frame}")
                if end_behavior=="loop" and (loop_count==0 or loops_done<loop_count):
                    wells,balls=_reset()
                    particles=[]
                else:
                    done=True

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))

            if frame%(fps*2)==0:
                alive=sum(1 for b in balls if b["active"])
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| balls: {alive}/{ball_count} | loops: {loops_done}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg","-y","-framerate",str(fps),
            "-i",str(frames_dir/"frame_%06d.png"),
            "-c:v","libx264","-pix_fmt","yuv420p",
            "-preset","fast","-crf","18",str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration)
    return output