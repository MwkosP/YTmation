"""
Paint Ball — Full Customization
---------------------------------
A ball bounces inside a shape, painting the interior as it moves.
The surface fills up over time until the shape is completely covered.

CORE:
    end_on_full          : bool  = True    — stop/loop when shape is fully painted
    coverage_threshold   : float = 0.95    — 0.0-1.0, what counts as "full"
    show_coverage        : bool  = False   — show coverage % on screen

PAINT:
    paint_style          : str   = "solid" — "solid" | "glow" | "rainbow"
    paint_color          : str   = None    — hex, random if None
    paint_radius_mult    : float = 1.0     — multiplier on ball radius for paint width
    paint_fade           : bool  = False   — old paint slowly fades (harder to fill)
    paint_fade_speed     : int   = 1       — alpha lost per frame (1=very slow, 5=fast)
    paint_opacity        : int   = 220     — opacity of paint strokes (0-255)
    rainbow_speed        : float = 1.0     — how fast rainbow cycles

SHAPE:
    shape                : str   = "circle" — "circle"|"square"|"triangle"|"pentagon"|"hexagon"|"diamond"
    shape_radius         : int   = None
    ring_color           : str   = "#ffffff"
    ring_width           : int   = 4
    ring_glow            : bool  = False
    ring_flash_on_hit    : bool  = False
    ring_spin            : bool  = False
    ring_spin_speed      : float = 0.5
    ring_double          : bool  = False
    ring_double_gap      : int   = 20
    ring_dash            : bool  = False

BALL:
    ball_color           : str   = None    — hex, random if None
    ball_radius          : int   = 20
    ball_glow            : bool  = False
    ball_shine           : bool  = True
    ball_visible         : bool  = True    — hide ball, only show paint
    ball_opacity         : int   = 255
    ball_image           : str   = None

HIT EFFECTS:
    on_hit_flash         : bool  = False
    on_hit_particles     : bool  = False
    on_hit_ring_pulse    : bool  = False
    particle_count       : int   = 10
    particle_speed       : float = 1.0
    particle_colors      : list  = None
    bg_pulse_on_hit      : bool  = False

PHYSICS:
    gravity              : float = 0.0
    speed                : float = 7.0
    bounce               : float = 1.0
    friction             : float = 1.0

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"
    bg_image             : str   = None
    bg_image_alpha       : int   = 255

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 20
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _hsvToRgb(h, s, v):
    h = h % 1.0
    i = int(h*6); f = h*6-i
    p,q,t = v*(1-s), v*(1-f*s), v*(1-(1-f)*s)
    r,g,b = [(v,t,p),(q,v,p),(p,v,t),(p,q,v),(t,p,v),(v,p,q)][i%6]
    return (int(r*255), int(g*255), int(b*255))

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlowCircle(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*7, int(50/i))

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255 * (p["life"] / p["max_life"]))
        r     = max(1, int(p["r"] * (p["life"] / p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]), int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=10, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(2, 8) * speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({
            "x": x, "y": y,
            "vx": math.cos(angle)*speed,
            "vy": math.sin(angle)*speed,
            "r":  random.randint(3, 8),
            "color": c,
            "life": random.randint(10, 25),
            "max_life": 25,
        })
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x/w
            pygame.draw.line(surf, tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)), (x,0),(x,h))
    elif direction == "radial":
        cx2,cy2 = w//2,h//2
        md = math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y), tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t = y/h
            pygame.draw.line(surf, tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)), (0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img = pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img, size)


# ── shape helpers ──────────────────────────────────────────────────────────────

_SHAPE_SIDES = {"triangle":3, "diamond":4, "pentagon":5, "hexagon":6}

def _shapeVertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [(cx + size*math.cos(angle_offset + 2*math.pi*i/sides - math.pi/2),
             cy + size*math.sin(angle_offset + 2*math.pi*i/sides - math.pi/2))
            for i in range(sides)]

def _drawShape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame
    if shape == "circle":
        if dash:
            _dashedCircle(surf, color, (cx,cy), size, width)
        else:
            pygame.draw.circle(surf, color, (cx,cy), size, width)
        return
    if shape == "square":
        pygame.draw.rect(surf, color, pygame.Rect(cx-size,cy-size,size*2,size*2), width)
        return
    verts = _shapeVertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x),int(y)) for x,y in verts], width)

def _fillShape(surf, shape, color, cx, cy, size, angle_offset=0.0):
    """Fill entire shape interior with a solid color — used for clipping mask."""
    import pygame
    if shape == "circle":
        pygame.draw.circle(surf, color, (cx,cy), size)
    elif shape == "square":
        pygame.draw.rect(surf, color, pygame.Rect(cx-size,cy-size,size*2,size*2))
    else:
        verts = _shapeVertices(shape, cx, cy, size, angle_offset)
        pygame.draw.polygon(surf, color, [(int(x),int(y)) for x,y in verts])

def _dashedCircle(surf, color, center, radius, width, dash=20):
    import pygame
    n = max(1, int(math.pi*radius/dash))
    for i in range(n):
        a0 = (2*math.pi/n)*i; a1 = a0+math.pi/n
        pts = [(center[0]+radius*math.cos(a0+(a1-a0)*s/10),
                center[1]+radius*math.sin(a0+(a1-a0)*s/10)) for s in range(11)]
        if len(pts)>1: pygame.draw.lines(surf, color, False, pts, width)

def _closestPointOnSegment(px,py,ax,ay,bx,by):
    dx,dy = bx-ax,by-ay
    t = max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2,cy2 = ax+t*dx,ay+t*dy
    nx,ny = px-cx2,py-cy2
    dist = math.hypot(nx,ny)
    if dist<1e-6: nx,ny,dist=-dy,dx,math.hypot(-dy,dx)
    return cx2,cy2,nx/dist,ny/dist,dist

def _resolveShapeCollision(ball, r, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx, by = ball["x"], ball["y"]
    hit = False
    if shape == "circle":
        dx,dy = bx-cx,by-cy
        dist = math.hypot(dx,dy)
        md = size-r
        if dist > md:
            nx,ny = dx/dist,dy/dist
            ball["x"] = cx+nx*md; ball["y"] = cy+ny*md
            dot = ball["vx"]*nx+ball["vy"]*ny
            ball["vx"] = (ball["vx"]-2*dot*nx)*bounce
            ball["vy"] = (ball["vy"]-2*dot*ny)*bounce
            hit = True
    elif shape == "square":
        half = size-r
        if bx < cx-half: ball["x"]=cx-half; ball["vx"]=abs(ball["vx"])*bounce; hit=True
        elif bx > cx+half: ball["x"]=cx+half; ball["vx"]=-abs(ball["vx"])*bounce; hit=True
        if by < cy-half: ball["y"]=cy-half; ball["vy"]=abs(ball["vy"])*bounce; hit=True
        elif by > cy+half: ball["y"]=cy+half; ball["vy"]=-abs(ball["vy"])*bounce; hit=True
    else:
        verts = _shapeVertices(shape,cx,cy,size,angle_offset)
        for i in range(len(verts)):
            ax,ay = verts[i]; bvx,bvy = verts[(i+1)%len(verts)]
            cpx,cpy,nx,ny,dist = _closestPointOnSegment(bx,by,ax,ay,bvx,bvy)
            tcx,tcy = cx-cpx,cy-cpy
            if nx*tcx+ny*tcy<0: nx,ny=-nx,-ny
            if dist<r:
                ball["x"]+=nx*(r-dist); ball["y"]+=ny*(r-dist)
                dot=ball["vx"]*nx+ball["vy"]*ny
                if dot<0:
                    ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
                    ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
                hit=True
    return hit

def _buildShapeMask(width, height, shape, cx, cy, cr, angle_offset=0.0):
    """
    Returns a boolean mask surface and the total number of pixels inside the shape.
    We use a small-scale mask (1/4 res) for fast coverage estimation.
    """
    import pygame
    scale = 4
    sw, sh = width//scale, height//scale
    mask_surf = pygame.Surface((sw, sh))
    mask_surf.fill((0,0,0))
    # draw filled shape in white at scaled coords
    scx, scy, scr = cx//scale, cy//scale, cr//scale
    if shape == "circle":
        pygame.draw.circle(mask_surf, (255,255,255), (scx,scy), scr)
    elif shape == "square":
        pygame.draw.rect(mask_surf, (255,255,255), pygame.Rect(scx-scr,scy-scr,scr*2,scr*2))
    else:
        verts = _shapeVertices(shape, scx, scy, scr, angle_offset)
        pygame.draw.polygon(mask_surf, (255,255,255), [(int(x),int(y)) for x,y in verts])
    # count white pixels
    pa = pygame.surfarray.array3d(mask_surf)
    total = int((pa[:,:,0] > 128).sum())
    return mask_surf, total, scale

def _estimateCoverage(paint_surf, mask_surf, scale, total_pixels):
    """Estimate what fraction of the shape interior has been painted."""
    import pygame
    sw = paint_surf.get_width()//scale
    sh = paint_surf.get_height()//scale
    # downscale paint surface
    small = pygame.transform.scale(paint_surf, (sw, sh))
    pa_paint = pygame.surfarray.array_alpha(small)
    pa_mask  = pygame.surfarray.array3d(mask_surf)[:,:,0]
    inside_painted = int(((pa_paint > 30) & (pa_mask > 128)).sum())
    if total_pixels == 0: return 0.0
    return min(1.0, inside_painted / total_pixels)

def _drawShapeGlow(surf, color, cx, cy, size, shape, angle_offset, layers=3):
    import pygame
    for i in range(layers, 0, -1):
        gs = size + i*8
        alpha = int(50/i)
        s = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        gc = (*color[:3], alpha)
        gw = max(2, i*3)
        if shape == "circle":
            pygame.draw.circle(s, gc, (cx,cy), gs, gw)
        elif shape == "square":
            pygame.draw.rect(s, gc, pygame.Rect(cx-gs,cy-gs,gs*2,gs*2), gw)
        else:
            verts = _shapeVertices(shape, cx, cy, gs, angle_offset)
            pygame.draw.polygon(s, gc, [(int(x),int(y)) for x,y in verts], gw)
        surf.blit(s, (0,0))


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    # output
    duration: int               = 20,
    output: Path                = None,
    fps: int                    = 60,
    width: int                  = 1080,
    height: int                 = 1920,
    # core
    end_on_full: bool           = True,
    coverage_threshold: float   = 0.95,
    show_coverage: bool         = False,
    # paint
    paint_style: str            = "solid",   # solid | glow | rainbow
    paint_color: str            = None,
    paint_radius_mult: float    = 1.0,
    paint_fade: bool            = False,
    paint_fade_speed: int       = 1,
    paint_opacity: int          = 220,
    rainbow_speed: float        = 1.0,
    # shape
    shape: str                  = "circle",
    shape_radius: int           = None,
    ring_color: str             = "#ffffff",
    ring_width: int             = 4,
    ring_glow: bool             = False,
    ring_flash_on_hit: bool     = False,
    ring_spin: bool             = False,
    ring_spin_speed: float      = 0.5,
    ring_double: bool           = False,
    ring_double_gap: int        = 20,
    ring_dash: bool             = False,
    # ball
    ball_color: str             = None,
    ball_radius: int            = 20,
    ball_glow: bool             = False,
    ball_shine: bool            = True,
    ball_visible: bool          = True,
    ball_opacity: int           = 255,
    ball_image: str             = None,
    # hit effects
    on_hit_flash: bool          = False,
    on_hit_particles: bool      = False,
    on_hit_ring_pulse: bool     = False,
    particle_count: int         = 10,
    particle_speed: float       = 1.0,
    particle_colors: list       = None,
    bg_pulse_on_hit: bool       = False,
    # physics
    gravity: float              = 0.0,
    speed: float                = 7.0,
    bounce: float               = 1.0,
    friction: float             = 1.0,
    # background
    bg_color: str               = "#0d0d0d",
    bg_color2: str              = None,
    bg_gradient_dir: str        = "vertical",
    bg_image: str               = None,
    bg_image_alpha: int         = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = shape.lower().strip()
    paint_style = paint_style.lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"paintBall_{stamp}.mp4"

    pygame.init()
    surface   = pygame.Surface((width, height), pygame.SRCALPHA)
    bg        = _hex(bg_color)
    bg2       = _hex(bg_color2) if bg_color2 else None
    rc        = _hex(ring_color)
    pcolors   = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    cr = shape_radius or (min(width, height) // 2 - 80)

    # colors
    bc = _hex(ball_color)  if ball_color  else (
        random.randint(80,255), random.randint(80,255), random.randint(80,255))
    pc = _hex(paint_color) if paint_color else bc

    # ── paint surface — SRCALPHA so we can track coverage ─────────────────────
    paint_surf = pygame.Surface((width, height), pygame.SRCALPHA)
    paint_surf.fill((0,0,0,0))

    # ── clip mask — only show paint INSIDE the shape ──────────────────────────
    # We'll use a mask surface: white inside shape, black outside
    clip_mask = pygame.Surface((width, height), pygame.SRCALPHA)
    clip_mask.fill((0,0,0,0))
    _fillShape(clip_mask, shape, (255,255,255,255), cx, cy, cr)

    # ── coverage estimation setup ──────────────────────────────────────────────
    mask_surf_small, total_pixels, scale = _buildShapeMask(width, height, shape, cx, cy, cr)
    coverage = 0.0
    check_interval = 30  # check coverage every N frames

    # ── pre-load assets ───────────────────────────────────────────────────────
    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image, (width, height))
        if bg_image_alpha < 255: raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    ball_img = None
    if ball_image and Path(ball_image).exists():
        ball_img = _loadImage(ball_image, (ball_radius*2, ball_radius*2))

    # ── font for coverage display ──────────────────────────────────────────────
    font = None
    if show_coverage:
        try:
            font = pygame.font.SysFont("monospace", 60, bold=True)
        except Exception:
            pass

    # ── ball state ────────────────────────────────────────────────────────────
    angle0 = random.uniform(0, 2*math.pi)
    ball = {
        "x":  float(cx + random.randint(-cr//3, cr//3)),
        "y":  float(cy + random.randint(-cr//3, cr//3)),
        "vx": math.cos(angle0) * speed,
        "vy": math.sin(angle0) * speed,
    }

    particles     = []
    ring_flash    = 0
    ring_pulse    = 0
    bg_flash      = 0
    shape_angle   = 0.0
    flash_timer   = 0
    rainbow_hue   = 0.0
    done          = False
    paint_r       = max(1, int(ball_radius * paint_radius_mult))

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255))
                surface.blit(bg_img_surf, (0,0))
            elif grad_surf:
                surface.blit(grad_surf, (0,0))
            else:
                flash_amt = min(bg_flash*8, 40)
                surface.fill((
                    min(255,bg[0]+flash_amt),
                    min(255,bg[1]+flash_amt),
                    min(255,bg[2]+flash_amt), 255))
            if bg_flash > 0: bg_flash -= 1

            # ── physics ───────────────────────────────────────────────────
            if not done:
                ball["vy"] += gravity
                ball["vx"] *= friction
                ball["vy"] *= friction
                ball["x"]  += ball["vx"]
                ball["y"]  += ball["vy"]

                # maintain speed
                spd = math.hypot(ball["vx"], ball["vy"])
                if spd > 0 and abs(spd - speed) > 0.5:
                    ball["vx"] = ball["vx"]/spd * speed
                    ball["vy"] = ball["vy"]/spd * speed

                hit = _resolveShapeCollision(ball, ball_radius, shape, cx, cy, cr, bounce, shape_angle)
                if hit:
                    log_wall_from_ball(audio, frame / fps, ball)

                if hit:
                    if on_hit_flash:      flash_timer = 6
                    if ring_flash_on_hit: ring_flash  = 6
                    if on_hit_ring_pulse: ring_pulse  = 18
                    if bg_pulse_on_hit:   bg_flash    = 4
                    if on_hit_particles:
                        particles += _spawnParticles(
                            ball["x"], ball["y"], bc, pcolors,
                            count=particle_count, speed_mult=particle_speed)

            # ── paint ─────────────────────────────────────────────────────
            if not done:
                # pick paint color
                if paint_style == "rainbow":
                    rainbow_hue = (rainbow_hue + 0.002 * rainbow_speed) % 1.0
                    cur_paint_c = _hsvToRgb(rainbow_hue, 1.0, 1.0)
                else:
                    cur_paint_c = pc

                # paint a filled circle at ball position on the paint surface
                pos = (int(ball["x"]), int(ball["y"]))

                if paint_style == "glow":
                    for i in range(4, 0, -1):
                        pr = paint_r + i*6
                        alpha = int((paint_opacity * 0.4) / i)
                        _withAlpha(paint_surf, cur_paint_c, pos, pr, alpha)
                    _withAlpha(paint_surf, cur_paint_c, pos, paint_r, paint_opacity)
                else:
                    _withAlpha(paint_surf, cur_paint_c, pos, paint_r, paint_opacity)

                # paint fade
                if paint_fade and frame % 2 == 0:
                    # subtract alpha from paint surface gradually
                    fade_surf = pygame.Surface((width, height), pygame.SRCALPHA)
                    fade_surf.fill((0,0,0, paint_fade_speed))
                    paint_surf.blit(fade_surf, (0,0), special_flags=pygame.BLEND_RGBA_SUB)

            # ── coverage check ────────────────────────────────────────────
            if frame % check_interval == 0 and not done:
                coverage = _estimateCoverage(paint_surf, mask_surf_small, scale, total_pixels)
                if end_on_full and coverage >= coverage_threshold:
                    done = True
                    print(f"   Shape fully painted at frame {frame} ({coverage*100:.1f}%)")

            # ── blit paint clipped to shape ────────────────────────────────
            # Method: create a temp surface, blit paint, then multiply by mask
            clipped = pygame.Surface((width, height), pygame.SRCALPHA)
            clipped.fill((0,0,0,0))
            clipped.blit(paint_surf, (0,0))
            # mask out outside shape using BLEND_RGBA_MULT
            clipped.blit(clip_mask, (0,0), special_flags=pygame.BLEND_RGBA_MULT)
            surface.blit(clipped, (0,0))

            # ── ring ──────────────────────────────────────────────────────
            cur_rc  = _lighten(rc, min(ring_flash*15,120)) if ring_flash > 0 else rc
            pulse_r = cr + int(ring_pulse)

            if ring_glow:
                _drawShapeGlow(surface, cur_rc, cx, cy, pulse_r, shape, shape_angle)

            _drawShape(surface, shape, cur_rc, cx, cy, pulse_r,
                       ring_width, shape_angle, dash=ring_dash)

            if ring_double:
                inner = max(10, pulse_r - ring_double_gap)
                _drawShape(surface, shape, (*cur_rc,90), cx, cy, inner,
                           max(1,ring_width-1), shape_angle)

            if ring_spin:
                shape_angle += math.radians(ring_spin_speed)

            if ring_flash > 0: ring_flash -= 1
            if ring_pulse > 0: ring_pulse  = max(0, ring_pulse - 2)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface, particles)
                for p in particles:
                    p["x"]+=p["vx"]; p["y"]+=p["vy"]
                    p["vy"]+=0.2;    p["life"]-=1
                particles = [p for p in particles if p["life"]>0]

            # ── ball ──────────────────────────────────────────────────────
            if ball_visible:
                pos        = (int(ball["x"]), int(ball["y"]))
                draw_color = _lighten(bc, 180) if flash_timer > 0 else bc

                if ball_glow:
                    _drawGlowCircle(surface, draw_color, pos, ball_radius)

                if ball_img:
                    scaled = pygame.transform.smoothscale(ball_img, (ball_radius*2, ball_radius*2))
                    if ball_opacity < 255: scaled.set_alpha(ball_opacity)
                    surface.blit(scaled, (pos[0]-ball_radius, pos[1]-ball_radius))
                else:
                    if ball_opacity < 255:
                        _withAlpha(surface, draw_color, pos, ball_radius, ball_opacity)
                    else:
                        pygame.draw.circle(surface, draw_color, pos, ball_radius)
                    if ball_shine and ball_radius > 6:
                        pygame.draw.circle(surface, (255,255,255),
                            (pos[0]-ball_radius//4, pos[1]-ball_radius//4),
                            max(1, ball_radius//5))

            if flash_timer > 0: flash_timer -= 1

            # ── coverage text ─────────────────────────────────────────────
            if show_coverage and font:
                txt = font.render(f"{coverage*100:.0f}%", True, (255,255,255))
                surface.blit(txt, (cx - txt.get_width()//2, height - 120))

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))

            if frame % (fps*2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| coverage: {coverage*100:.1f}%")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", str(fps),
            "-i", str(frames_dir/"frame_%06d.png"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "fast", "-crf", "18",
            str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)