"""
Sizing Platform — Full Customization
--------------------------------------
A ball bounces inside a shape that grows or shrinks over time.
Ball escapes when shape gets too small, or shape fills the screen.

CORE:
    mode             : str   = "shrink"   — "shrink" | "grow" | "shrink_grow" | "grow_shrink"
    size_multiplier  : float = 0.998      — per-frame factor (0.998=slow shrink, 1.002=slow grow)
    end_behavior     : str   = "loop"     — "stop" | "loop" (respawn ball, reset size)
    loop_count       : int   = 0          — max loops (0 = infinite)

SIZE LIMITS:
    min_size         : int   = 40         — shape collapses below this (ball escapes)
    max_size         : int   = None       — shape too big above this (auto = near screen edge)
    start_size       : int   = None       — starting shape size (auto if None)

SHAPE:
    shape            : str   = "circle"   — "circle"|"square"|"triangle"|"pentagon"|"hexagon"|"diamond"
    ring_color       : str   = "#ffffff"
    ring_width       : int   = 5
    ring_glow        : bool  = False
    ring_flash_on_hit: bool  = False
    ring_spin        : bool  = False
    ring_spin_speed  : float = 0.5
    ring_double      : bool  = False
    ring_double_gap  : int   = 20
    ring_dash        : bool  = False

BALL:
    ball_color       : str   = None
    ball_radius      : int   = 20
    ball_glow        : bool  = True
    ball_trail       : bool  = True
    trail_length     : int   = 18
    ball_shine       : bool  = True
    ball_opacity     : int   = 255
    ball_image       : str   = None
    ball_speed       : float = 7.0

HIT EFFECTS:
    on_hit_flash     : bool  = False
    on_hit_particles : bool  = False
    on_hit_ring_pulse: bool  = False
    particle_count   : int   = 10
    particle_speed   : float = 1.2
    particle_colors  : list  = None
    bg_pulse_on_hit  : bool  = False

PHYSICS:
    gravity          : float = 0.0
    bounce           : float = 1.0
    friction         : float = 1.0

BACKGROUND:
    bg_color         : str   = "#0d0d0d"
    bg_color2        : str   = None
    bg_gradient_dir  : str   = "vertical"
    bg_image         : str   = None
    bg_image_alpha   : int   = 255

OUTPUT:
    fps              : int   = 60
    width            : int   = 1080
    height           : int   = 1920
    duration         : int   = 15
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=5):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*7, int(55/i))

def _drawShapeGlow(surf, color, cx, cy, size, shape, angle_offset, layers=3):
    import pygame
    for i in range(layers, 0, -1):
        gs = size + i*8; alpha = int(50/i); gw = max(2, i*3)
        s  = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        gc = (*color[:3], alpha)
        if shape == "circle":
            pygame.draw.circle(s, gc, (cx,cy), gs, gw)
        elif shape == "square":
            pygame.draw.rect(s, gc, pygame.Rect(cx-gs,cy-gs,gs*2,gs*2), gw)
        else:
            verts = _shapeVertices(shape, cx, cy, gs, angle_offset)
            pygame.draw.polygon(s, gc, [(int(x),int(y)) for x,y in verts], gw)
        surf.blit(s, (0,0))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i, (tx, ty, tr) in enumerate(trail):
        alpha = int(180 * (i / n))
        rad   = max(2, int(tr * 0.85 * (i / n)))
        _withAlpha(surf, color, (int(tx), int(ty)), rad, alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255 * (p["life"] / p["max_life"]))
        r     = max(1, int(p["r"] * (p["life"] / p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]), int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=10, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(2, 9) * speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({
            "x": x, "y": y,
            "vx": math.cos(angle)*speed,
            "vy": math.sin(angle)*speed,
            "r":  random.randint(3, 9),
            "color": c,
            "life": random.randint(12, 28),
            "max_life": 28,
        })
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x/w
            pygame.draw.line(surf, tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)), (x,0),(x,h))
    elif direction == "radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img = pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img, size)


# ── shape helpers ──────────────────────────────────────────────────────────────

_SHAPE_SIDES = {"triangle":3, "diamond":4, "pentagon":5, "hexagon":6}

def _shapeVertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [(cx + size*math.cos(angle_offset + 2*math.pi*i/sides - math.pi/2),
             cy + size*math.sin(angle_offset + 2*math.pi*i/sides - math.pi/2))
            for i in range(sides)]

def _drawShape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame
    if size <= 0: return
    if shape == "circle":
        pygame.draw.circle(surf, color, (cx,cy), int(size), width)
    elif shape == "square":
        s = int(size)
        pygame.draw.rect(surf, color, pygame.Rect(cx-s,cy-s,s*2,s*2), width)
    else:
        verts = _shapeVertices(shape, cx, cy, size, angle_offset)
        pygame.draw.polygon(surf, color, [(int(x),int(y)) for x,y in verts], width)

def _dashedCircle(surf, color, center, radius, width, dash=20):
    import pygame
    n = max(1, int(math.pi*radius/dash))
    for i in range(n):
        a0=(2*math.pi/n)*i; a1=a0+math.pi/n
        pts=[(center[0]+radius*math.cos(a0+(a1-a0)*s/10),
              center[1]+radius*math.sin(a0+(a1-a0)*s/10)) for s in range(11)]
        if len(pts)>1: pygame.draw.lines(surf,color,False,pts,width)

def _closestPointOnSegment(px,py,ax,ay,bx,by):
    dx,dy=bx-ax,by-ay
    t=max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2,cy2=ax+t*dx,ay+t*dy
    nx,ny=px-cx2,py-cy2
    dist=math.hypot(nx,ny)
    if dist<1e-6: nx,ny,dist=-dy,dx,math.hypot(-dy,dx)
    return cx2,cy2,nx/dist,ny/dist,dist

def _resolveShapeCollision(ball, br, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    """Returns True if bounced, 'escape' if outside shape."""
    bx,by = ball["x"],ball["y"]

    if shape == "circle":
        dx,dy = bx-cx,by-cy
        dist  = math.hypot(dx,dy)
        md    = size - br
        if dist > md:
            if dist > size + br*2:   # way outside — escaped
                return "escape"
            nx,ny = dx/dist,dy/dist
            ball["x"]=cx+nx*md; ball["y"]=cy+ny*md
            dot=ball["vx"]*nx+ball["vy"]*ny
            ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
            ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True
        return False

    elif shape == "square":
        half = size - br
        hit  = False
        if bx < cx-half: ball["x"]=cx-half; ball["vx"]=abs(ball["vx"])*bounce; hit=True
        elif bx > cx+half: ball["x"]=cx+half; ball["vx"]=-abs(ball["vx"])*bounce; hit=True
        if by < cy-half: ball["y"]=cy-half; ball["vy"]=abs(ball["vy"])*bounce; hit=True
        elif by > cy+half: ball["y"]=cy+half; ball["vy"]=-abs(ball["vy"])*bounce; hit=True
        # escape check — ball far outside
        if abs(bx-cx) > size+br*3 or abs(by-cy) > size+br*3:
            return "escape"
        return hit

    else:
        verts = _shapeVertices(shape, cx, cy, size, angle_offset)
        n     = len(verts)
        hit   = False
        for i in range(n):
            ax,ay=verts[i]; bvx,bvy=verts[(i+1)%n]
            cpx,cpy,nx,ny,dist=_closestPointOnSegment(bx,by,ax,ay,bvx,bvy)
            tcx,tcy=cx-cpx,cy-cpy
            if nx*tcx+ny*tcy<0: nx,ny=-nx,-ny
            if dist<br:
                ball["x"]+=nx*(br-dist); ball["y"]+=ny*(br-dist)
                dot=ball["vx"]*nx+ball["vy"]*ny
                if dot<0:
                    ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
                    ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
                hit=True
        # escape: ball far from center relative to shape size
        if math.hypot(bx-cx,by-cy) > size * 1.8:
            return "escape"
        return hit


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    duration: int           = 15,
    output: Path            = None,
    fps: int                = 60,
    width: int              = 1080,
    height: int             = 1920,
    # core
    mode: str               = "shrink",      # shrink | grow | shrink_grow | grow_shrink
    size_multiplier: float  = 0.998,
    end_behavior: str       = "loop",
    loop_count: int         = 0,
    # size limits
    min_size: int           = 40,
    max_size: int           = None,
    start_size: int         = None,
    # shape
    shape: str              = "circle",
    ring_color: str         = "#ffffff",
    ring_width: int         = 5,
    ring_glow: bool         = False,
    ring_flash_on_hit: bool = False,
    ring_spin: bool         = False,
    ring_spin_speed: float  = 0.5,
    ring_double: bool       = False,
    ring_double_gap: int    = 20,
    ring_dash: bool         = False,
    # ball
    ball_color: str         = None,
    ball_radius: int        = 20,
    ball_glow: bool         = True,
    ball_trail: bool        = True,
    trail_length: int       = 18,
    ball_shine: bool        = True,
    ball_opacity: int       = 255,
    ball_image: str         = None,
    ball_speed: float       = 7.0,
    # hit effects
    on_hit_flash: bool      = False,
    on_hit_particles: bool  = False,
    on_hit_ring_pulse: bool = False,
    particle_count: int     = 10,
    particle_speed: float   = 1.2,
    particle_colors: list   = None,
    bg_pulse_on_hit: bool   = False,
    # physics
    gravity: float          = 0.0,
    bounce: float           = 1.0,
    friction: float         = 1.0,
    # background
    bg_color: str           = "#0d0d0d",
    bg_color2: str          = None,
    bg_gradient_dir: str    = "vertical",
    bg_image: str           = None,
    bg_image_alpha: int     = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = shape.lower().strip()
    mode  = mode.lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"sizingPlatform_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width, height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    rc           = _hex(ring_color)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2

    # size limits
    _max_size = max_size or (min(width, height) // 2 - 40)
    _min_size = max(min_size, ball_radius + 5)

    # starting size & direction based on mode
    if start_size:
        cur_size = float(start_size)
    elif mode in ("shrink", "grow_shrink"):
        cur_size = float(_max_size)
    else:
        cur_size = float(_min_size + 10)

    direction = -1 if mode in ("shrink", "grow_shrink") else 1
    # multiplier: shrink = <1, grow = >1
    # we store a single mult and flip it for direction
    shrink_mult = min(size_multiplier, 1.0/size_multiplier)  # always <1
    grow_mult   = max(size_multiplier, 1.0/size_multiplier)  # always >1

    # pre-load assets
    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image, (width, height))
        if bg_image_alpha < 255: raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    ball_img = None
    if ball_image and Path(ball_image).exists():
        ball_img = _loadImage(ball_image, (ball_radius*2, ball_radius*2))

    bc = _hex(ball_color) if ball_color else (
        random.randint(80,255), random.randint(80,255), random.randint(80,255))

    def _spawnBall(size):
        spd   = ball_speed
        angle = random.uniform(0, 2*math.pi)
        safe  = max(ball_radius+5, size*0.4)
        dist  = random.uniform(0, safe)
        return {
            "x":  float(cx + dist*math.cos(angle)),
            "y":  float(cy + dist*math.sin(angle)),
            "vx": math.cos(angle + math.pi/2) * spd,
            "vy": math.sin(angle + math.pi/2) * spd,
            "trail": [],
            "escaped": False,
        }

    ball        = _spawnBall(cur_size)
    shape_angle = 0.0
    particles   = []
    ring_flash  = 0
    ring_pulse  = 0
    bg_flash    = 0
    flash_timer = 0
    loops_done  = 0
    done        = False

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
                continue

            # ── size update ───────────────────────────────────────────────
            if not ball["escaped"]:
                if direction == -1:
                    cur_size *= shrink_mult
                else:
                    cur_size *= grow_mult

                # clamp & handle limits
                hit_limit = False
                if cur_size <= _min_size:
                    cur_size  = float(_min_size)
                    hit_limit = True
                elif cur_size >= _max_size:
                    cur_size  = float(_max_size)
                    hit_limit = True

                if hit_limit:
                    if mode in ("shrink_grow", "grow_shrink"):
                        direction *= -1   # reverse
                    # else just clamp — ball will escape naturally

            # ── ring spin ─────────────────────────────────────────────────
            if ring_spin:
                shape_angle += math.radians(ring_spin_speed)

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255)); surface.blit(bg_img_surf,(0,0))
            elif grad_surf:
                surface.blit(grad_surf,(0,0))
            else:
                fa = min(bg_flash*8,40)
                surface.fill((min(255,bg[0]+fa),min(255,bg[1]+fa),min(255,bg[2]+fa),255))
            if bg_flash > 0: bg_flash -= 1

            # ── ring ──────────────────────────────────────────────────────
            cur_rc  = _lighten(rc, min(ring_flash*15,120)) if ring_flash > 0 else rc
            pulse_r = cur_size + int(ring_pulse)

            if ring_glow:
                _drawShapeGlow(surface, cur_rc, cx, cy, pulse_r, shape, shape_angle)

            _drawShape(surface, shape, cur_rc, cx, cy, pulse_r,
                       ring_width, shape_angle, dash=ring_dash)

            if ring_double:
                inner = max(10, pulse_r - ring_double_gap)
                _drawShape(surface, shape, (*cur_rc,90), cx, cy, inner,
                           max(1,ring_width-1), shape_angle)

            if ring_flash > 0: ring_flash -= 1
            if ring_pulse > 0: ring_pulse  = max(0, ring_pulse-2)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface, particles)
                for p in particles:
                    p["x"]+=p["vx"]; p["y"]+=p["vy"]
                    p["vy"]+=0.2;    p["life"]-=1
                particles = [p for p in particles if p["life"]>0]

            # ── physics ───────────────────────────────────────────────────
            if not ball["escaped"]:
                ball["vy"] += gravity
                ball["vx"] *= friction
                ball["vy"] *= friction
                ball["x"]  += ball["vx"]
                ball["y"]  += ball["vy"]

                # maintain speed
                spd = math.hypot(ball["vx"], ball["vy"])
                if spd > 0:
                    ball["vx"] = ball["vx"]/spd * ball_speed
                    ball["vy"] = ball["vy"]/spd * ball_speed

                result = _resolveShapeCollision(
                    ball, ball_radius, shape, cx, cy, cur_size, bounce, shape_angle)

                if result == "escape":
                    ball["escaped"] = True
                    print(f"   Ball escaped at frame {frame} | size: {cur_size:.1f}")
                    if on_hit_particles:
                        particles += _spawnParticles(
                            ball["x"], ball["y"], bc, pcolors,
                            count=particle_count*2, speed_mult=particle_speed*1.5)

                elif result is True:
                    log_wall_from_ball(audio, frame / fps, ball)
                    if on_hit_flash:      flash_timer = 6
                    if ring_flash_on_hit: ring_flash  = 6
                    if on_hit_ring_pulse: ring_pulse  = 18
                    if bg_pulse_on_hit:   bg_flash    = 4
                    if on_hit_particles:
                        particles += _spawnParticles(
                            ball["x"], ball["y"], bc, pcolors,
                            count=particle_count, speed_mult=particle_speed)

                # trail
                if ball_trail:
                    ball["trail"].append((ball["x"], ball["y"], ball_radius))
                    if len(ball["trail"]) > trail_length:
                        ball["trail"].pop(0)

            else:
                # escaped — fly off screen then loop/stop
                ball["x"] += ball["vx"]
                ball["y"] += ball["vy"]
                off = max(width, height) + 100
                if abs(ball["x"]-cx) > off or abs(ball["y"]-cy) > off:
                    loops_done += 1
                    if end_behavior == "loop" and (loop_count == 0 or loops_done < loop_count):
                        # reset size and ball
                        if start_size:
                            cur_size = float(start_size)
                        elif mode in ("shrink", "grow_shrink"):
                            cur_size = float(_max_size)
                        else:
                            cur_size = float(_min_size + 10)
                        direction = -1 if mode in ("shrink", "grow_shrink") else 1
                        ball = _spawnBall(cur_size)
                    else:
                        done = True

            # ── draw trail ────────────────────────────────────────────────
            if ball_trail:
                _drawTrail(surface, ball["trail"], bc)

            # ── draw ball ─────────────────────────────────────────────────
            pos        = (int(ball["x"]), int(ball["y"]))
            draw_color = _lighten(bc, 180) if flash_timer > 0 else bc

            if ball_glow:
                _drawGlow(surface, draw_color, pos, ball_radius)

            if ball_img:
                scaled = pygame.transform.smoothscale(ball_img, (ball_radius*2, ball_radius*2))
                if ball_opacity < 255: scaled.set_alpha(ball_opacity)
                surface.blit(scaled, (pos[0]-ball_radius, pos[1]-ball_radius))
            else:
                if ball_opacity < 255:
                    _withAlpha(surface, draw_color, pos, ball_radius, ball_opacity)
                else:
                    pygame.draw.circle(surface, draw_color, pos, ball_radius)
                if ball_shine and ball_radius > 6:
                    pygame.draw.circle(surface, (255,255,255),
                        (pos[0]-ball_radius//4, pos[1]-ball_radius//4),
                        max(1,ball_radius//5))

            if flash_timer > 0: flash_timer -= 1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))

            if frame % (fps*2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| size: {cur_size:.1f} | dir: {'shrink' if direction==-1 else 'grow'}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", str(fps),
            "-i", str(frames_dir/"frame_%06d.png"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "fast", "-crf", "18",
            str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)