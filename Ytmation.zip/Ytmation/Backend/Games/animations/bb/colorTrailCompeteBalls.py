"""
Color Trail Compete Balls — Full Customization
-----------------------------------------------
Multiple balls bounce inside a shape, each painting the surface they travel over.
If a ball crosses another ball's paint, it repaints it its own color.
Winner is the ball with the most territory at the end.

CORE:
    end_behavior         : str   = "loop"    — "stop" | "loop"
    loop_count           : int   = 0
    show_score           : bool  = True      — show territory % per ball
    show_winner          : bool  = True      — flash winner at end
    coverage_check_every : int   = 30        — frames between score recalculation

SHAPE:
    shape                : str   = "circle"
    shape_radius         : int   = None
    ring_color           : str   = "#ffffff"
    ring_width           : int   = 5
    ring_glow            : bool  = False
    ring_flash_on_hit    : bool  = False
    ring_spin            : bool  = False
    ring_spin_speed      : float = 0.5
    ring_double          : bool  = False
    ring_double_gap      : int   = 20
    ring_dash            : bool  = False

BALLS:
    ball_count           : int   = 3
    ball_colors          : list  = None      — hex list, auto if None
    ball_radius          : int   = 20
    ball_glow            : bool  = True
    ball_trail           : bool  = False     — motion trail (separate from paint)
    trail_length         : int   = 10
    ball_shine           : bool  = True
    ball_opacity         : int   = 255
    ball_collision       : bool  = True
    ball_speed           : float = 6.0

PAINT:
    paint_radius_mult    : float = 1.2       — paint stroke size relative to ball
    paint_opacity        : int   = 200
    paint_style          : str   = "solid"   — "solid" | "glow"

HIT EFFECTS:
    on_hit_flash         : bool  = False
    on_hit_particles     : bool  = False
    on_hit_ring_pulse    : bool  = False
    particle_count       : int   = 8
    particle_speed       : float = 1.2
    particle_colors      : list  = None
    bg_pulse_on_hit      : bool  = False

PHYSICS:
    gravity              : float = 0.0
    bounce               : float = 1.0
    friction             : float = 1.0

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"
    bg_image             : str   = None
    bg_image_alpha       : int   = 255

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 20
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"

# ── default ball colors ────────────────────────────────────────────────────────

DEFAULT_COLORS = [
    "#ff4444", "#44aaff", "#44ff88",
    "#ffcc00", "#ff44cc", "#cc44ff",
    "#ff8800", "#00ffcc",
]

# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*7, int(55/i))

def _drawShapeGlow(surf, color, cx, cy, size, shape, angle_offset, layers=3):
    import pygame
    for i in range(layers, 0, -1):
        gs=size+i*8; alpha=int(50/i); gw=max(2,i*3)
        s=pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        gc=(*color[:3], alpha)
        if shape=="circle": pygame.draw.circle(s,gc,(cx,cy),gs,gw)
        elif shape=="square": pygame.draw.rect(s,gc,pygame.Rect(cx-gs,cy-gs,gs*2,gs*2),gw)
        else:
            verts=_shapeVertices(shape,cx,cy,gs,angle_offset)
            pygame.draw.polygon(s,gc,[(int(x),int(y)) for x,y in verts],gw)
        surf.blit(s,(0,0))

def _drawTrail(surf, trail, color):
    n=len(trail)
    if n==0: return
    for i,(tx,ty,tr) in enumerate(trail):
        alpha=int(140*(i/n)); rad=max(2,int(tr*0.7*(i/n)))
        _withAlpha(surf,color,(int(tx),int(ty)),rad,alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha=int(255*(p["life"]/p["max_life"]))
        r=max(1,int(p["r"]*(p["life"]/p["max_life"])))
        _withAlpha(surf,p["color"],(int(p["x"]),int(p["y"])),r,alpha)

def _spawnParticles(x, y, color, pcolors, count=8, speed_mult=1.0):
    out=[]
    for _ in range(count):
        angle=random.uniform(0,2*math.pi); speed=random.uniform(2,8)*speed_mult
        c=_hex(random.choice(pcolors)) if pcolors else color
        out.append({"x":x,"y":y,"vx":math.cos(angle)*speed,"vy":math.sin(angle)*speed,
                    "r":random.randint(3,8),"color":c,"life":random.randint(10,25),"max_life":25})
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf=pygame.Surface((w,h))
    if direction=="horizontal":
        for x in range(w):
            t=x/w
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(x,0),(x,h))
    elif direction=="radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img=pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img,size)


# ── shape helpers ──────────────────────────────────────────────────────────────

_SHAPE_SIDES={"triangle":3,"diamond":4,"pentagon":5,"hexagon":6,"heptagon":7,"octagon":8}

def _shapeVertices(shape, cx, cy, size, angle_offset=0.0):
    sides=_SHAPE_SIDES.get(shape,6)
    return [(cx+size*math.cos(angle_offset+2*math.pi*i/sides-math.pi/2),
             cy+size*math.sin(angle_offset+2*math.pi*i/sides-math.pi/2))
            for i in range(sides)]

def _drawShape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame
    if size<=0: return
    if shape=="circle": pygame.draw.circle(surf,color,(cx,cy),int(size),width)
    elif shape=="square":
        s=int(size); pygame.draw.rect(surf,color,pygame.Rect(cx-s,cy-s,s*2,s*2),width)
    else:
        verts=_shapeVertices(shape,cx,cy,size,angle_offset)
        pygame.draw.polygon(surf,color,[(int(x),int(y)) for x,y in verts],width)

def _fillShape(surf, shape, color, cx, cy, size, angle_offset=0.0):
    import pygame
    if shape=="circle": pygame.draw.circle(surf,color,(cx,cy),int(size))
    elif shape=="square":
        s=int(size); pygame.draw.rect(surf,color,pygame.Rect(cx-s,cy-s,s*2,s*2))
    else:
        verts=_shapeVertices(shape,cx,cy,size,angle_offset)
        pygame.draw.polygon(surf,color,[(int(x),int(y)) for x,y in verts])

def _closestPointOnSegment(px,py,ax,ay,bx,by):
    dx,dy=bx-ax,by-ay
    t=max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2,cy2=ax+t*dx,ay+t*dy; nx,ny=px-cx2,py-cy2
    dist=math.hypot(nx,ny)
    if dist<1e-6: nx,ny,dist=-dy,dx,math.hypot(-dy,dx)
    return cx2,cy2,nx/dist,ny/dist,dist

def _resolveShapeCollision(ball, br, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx,by=ball["x"],ball["y"]
    if shape=="circle":
        dx,dy=bx-cx,by-cy; dist=math.hypot(dx,dy); md=size-br
        if dist>md:
            nx,ny=dx/dist,dy/dist
            ball["x"]=cx+nx*md; ball["y"]=cy+ny*md
            dot=ball["vx"]*nx+ball["vy"]*ny
            ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
            ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True
        return False
    elif shape=="square":
        half=size-br; hit=False
        if bx<cx-half: ball["x"]=cx-half; ball["vx"]=abs(ball["vx"])*bounce; hit=True
        elif bx>cx+half: ball["x"]=cx+half; ball["vx"]=-abs(ball["vx"])*bounce; hit=True
        if by<cy-half: ball["y"]=cy-half; ball["vy"]=abs(ball["vy"])*bounce; hit=True
        elif by>cy+half: ball["y"]=cy+half; ball["vy"]=-abs(ball["vy"])*bounce; hit=True
        return hit
    else:
        verts=_shapeVertices(shape,cx,cy,size,angle_offset)
        n=len(verts); hit=False
        for i in range(n):
            ax,ay=verts[i]; bvx,bvy=verts[(i+1)%n]
            cpx,cpy,enx,eny,dist=_closestPointOnSegment(bx,by,ax,ay,bvx,bvy)
            tcx,tcy=cx-cpx,cy-cpy
            if enx*tcx+eny*tcy<0: enx,eny=-enx,-eny
            if dist<br:
                ball["x"]+=enx*(br-dist); ball["y"]+=eny*(br-dist)
                dot=ball["vx"]*enx+ball["vy"]*eny
                if dot<0:
                    ball["vx"]=(ball["vx"]-2*dot*enx)*bounce
                    ball["vy"]=(ball["vy"]-2*dot*eny)*bounce
                hit=True
        return hit


# ── ball-ball collision ────────────────────────────────────────────────────────

def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):
    n=len(balls)
    for i in range(n):
        for j in range(i+1,n):
            a,b=balls[i],balls[j]
            dx=b["x"]-a["x"]; dy=b["y"]-a["y"]
            dist=math.hypot(dx,dy); md=a["r"]+b["r"]
            if dist<md and dist>0:
                overlap=(md-dist)/2; nx=dx/dist; ny=dy/dist
                a["x"]-=nx*overlap; a["y"]-=ny*overlap
                b["x"]+=nx*overlap; b["y"]+=ny*overlap
                dvx=a["vx"]-b["vx"]; dvy=a["vy"]-b["vy"]
                dot=dvx*nx+dvy*ny
                if dot>0:
                    a["vx"]=(a["vx"]-dot*nx)*bounce; a["vy"]=(a["vy"]-dot*ny)*bounce
                    b["vx"]=(b["vx"]+dot*nx)*bounce; b["vy"]=(b["vy"]+dot*ny)*bounce


# ── score calculation ──────────────────────────────────────────────────────────

def _calcScores(paint_surf, colors, width, height, scale=4):
    """Downsample paint surface and count pixels per color."""
    import pygame
    sw,sh = width//scale, height//scale
    small = pygame.transform.scale(paint_surf,(sw,sh))
    arr   = pygame.surfarray.array3d(small)
    scores = {}
    total  = 0
    for i,color in enumerate(colors):
        cr,cg,cb = color[:3]
        # count pixels close to this color
        match = (
            (abs(arr[:,:,0].astype(int)-cr) < 40) &
            (abs(arr[:,:,1].astype(int)-cg) < 40) &
            (abs(arr[:,:,2].astype(int)-cb) < 40)
        )
        count = int(match.sum())
        scores[i] = count
        total += count
    return scores, total


def _drawScorebar(surf, scores, total, colors, width, height, font, ball_count):
    """Draw a score bar at the bottom of the screen."""
    import pygame
    if total == 0: return
    bar_h  = 18
    bar_y  = height - 55
    bar_x  = 60
    bar_w  = width - 120
    x      = bar_x

    for i in range(ball_count):
        frac  = scores.get(i,0) / max(1,total)
        seg_w = int(bar_w * frac)
        if seg_w > 0:
            pygame.draw.rect(surf, colors[i],
                pygame.Rect(x, bar_y, seg_w, bar_h))
        x += seg_w

    pygame.draw.rect(surf, (200,200,200),
        pygame.Rect(bar_x, bar_y, bar_w, bar_h), 2)

    # labels
    if font:
        x = bar_x
        for i in range(ball_count):
            frac = scores.get(i,0) / max(1,total)
            pct  = f"{frac*100:.0f}%"
            txt  = font.render(pct, True, colors[i])
            surf.blit(txt,(x, bar_y - 28))
            x += bar_w // ball_count


def _drawWinner(surf, winner_idx, colors, width, height, font_big):
    """Flash winner label in center."""
    import pygame
    if font_big is None: return
    color = colors[winner_idx]
    label = f"BALL {winner_idx+1} WINS!"
    txt   = font_big.render(label, True, color)
    x     = width//2  - txt.get_width()//2
    y     = height//2 - txt.get_height()//2
    # dark background
    bg = pygame.Surface((txt.get_width()+40, txt.get_height()+20), pygame.SRCALPHA)
    bg.fill((0,0,0,180))
    surf.blit(bg,(x-20, y-10))
    surf.blit(txt,(x,y))


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    duration: int               = 20,
    output: Path                = None,
    fps: int                    = 60,
    width: int                  = 1080,
    height: int                 = 1920,
    # core
    end_behavior: str           = "loop",
    loop_count: int             = 0,
    show_score: bool            = True,
    show_winner: bool           = True,
    coverage_check_every: int   = 30,
    # shape
    shape: str                  = "circle",
    shape_radius: int           = None,
    ring_color: str             = "#ffffff",
    ring_width: int             = 5,
    ring_glow: bool             = False,
    ring_flash_on_hit: bool     = False,
    ring_spin: bool             = False,
    ring_spin_speed: float      = 0.5,
    ring_double: bool           = False,
    ring_double_gap: int        = 20,
    ring_dash: bool             = False,
    # balls
    ball_count: int             = 3,
    ball_colors: list           = None,
    ball_radius: int            = 20,
    ball_glow: bool             = True,
    ball_trail: bool            = False,
    trail_length: int           = 10,
    ball_shine: bool            = True,
    ball_opacity: int           = 255,
    ball_collision: bool        = True,
    ball_speed: float           = 6.0,
    # paint
    paint_radius_mult: float    = 1.2,
    paint_opacity: int          = 200,
    paint_style: str            = "solid",
    # hit effects
    on_hit_flash: bool          = False,
    on_hit_particles: bool      = False,
    on_hit_ring_pulse: bool     = False,
    particle_count: int         = 8,
    particle_speed: float       = 1.2,
    particle_colors: list       = None,
    bg_pulse_on_hit: bool       = False,
    # physics
    gravity: float              = 0.0,
    bounce: float               = 1.0,
    friction: float             = 1.0,
    # background
    bg_color: str               = "#0d0d0d",
    bg_color2: str              = None,
    bg_gradient_dir: str        = "vertical",
    bg_image: str               = None,
    bg_image_alpha: int         = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER","dummy")
    os.environ.setdefault("SDL_AUDIODRIVER","dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape      = shape.lower().strip()
    paint_style = paint_style.lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"colorTrailCompeteBalls_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width,height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    rc           = _hex(ring_color)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    cr = shape_radius or (min(width,height)//2 - 80)

    # resolve ball colors
    palette = []
    if ball_colors:
        for c in ball_colors[:ball_count]:
            palette.append(_hex(c))
    while len(palette) < ball_count:
        idx = len(palette) % len(DEFAULT_COLORS)
        palette.append(_hex(DEFAULT_COLORS[idx]))

    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image,(width,height))
        if bg_image_alpha<255: raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    # fonts
    font_score = None
    font_big   = None
    try:
        font_score = pygame.font.SysFont("monospace", 26, bold=True)
        font_big   = pygame.font.SysFont("monospace", 72, bold=True)
    except Exception:
        pass

    # clip mask — shape interior only
    clip_mask = pygame.Surface((width,height), pygame.SRCALPHA)
    clip_mask.fill((0,0,0,0))
    _fillShape(clip_mask, shape, (255,255,255,255), cx, cy, cr)

    paint_r = max(1, int(ball_radius * paint_radius_mult))

    def _resetScene():
        # paint surface — RGBA, accumulates color
        ps = pygame.Surface((width,height), pygame.SRCALPHA)
        ps.fill((0,0,0,0))

        # spawn balls evenly around inner ring
        bs = []
        for i in range(ball_count):
            angle = 2*math.pi*i/ball_count
            dist  = cr * 0.5
            x     = cx + dist*math.cos(angle)
            y     = cy + dist*math.sin(angle)
            tang  = angle + math.pi/2 + random.uniform(-0.3,0.3)
            bs.append({
                "x": float(x), "y": float(y),
                "vx": math.cos(tang)*ball_speed,
                "vy": math.sin(tang)*ball_speed,
                "r": ball_radius,
                "color": palette[i],
                "idx": i,
                "flash": 0, "trail": [],
            })
        return ps, bs

    paint_surf, balls = _resetScene()
    particles    = []
    shape_angle  = 0.0
    ring_flash   = 0
    ring_pulse   = 0
    bg_flash     = 0
    scores       = {i:0 for i in range(ball_count)}
    total_painted = 1
    winner_idx   = 0
    loops_done   = 0
    done         = False
    winner_frames = 0   # countdown to show winner

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))
                continue

            if ring_spin:
                shape_angle += math.radians(ring_spin_speed)

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255)); surface.blit(bg_img_surf,(0,0))
            elif grad_surf:
                surface.blit(grad_surf,(0,0))
            else:
                fa=min(bg_flash*8,40)
                surface.fill((min(255,bg[0]+fa),min(255,bg[1]+fa),min(255,bg[2]+fa),255))
            if bg_flash>0: bg_flash-=1

            # ── paint each ball's position ─────────────────────────────────
            for b in balls:
                pos = (int(b["x"]),int(b["y"]))
                color = b["color"]
                if paint_style=="glow":
                    for gi in range(3,0,-1):
                        _withAlpha(paint_surf,color,pos,
                                   paint_r+gi*5,int(paint_opacity*0.3/gi))
                # solid fill — overwrites whatever was there
                pygame.draw.circle(paint_surf, (*color[:3], paint_opacity), pos, paint_r)

            # ── blit paint clipped to shape ────────────────────────────────
            clipped = pygame.Surface((width,height), pygame.SRCALPHA)
            clipped.fill((0,0,0,0))
            clipped.blit(paint_surf,(0,0))
            clipped.blit(clip_mask,(0,0), special_flags=pygame.BLEND_RGBA_MULT)
            surface.blit(clipped,(0,0))

            # ── ring ──────────────────────────────────────────────────────
            cur_rc  = _lighten(rc,min(ring_flash*15,120)) if ring_flash>0 else rc
            pulse_r = cr+int(ring_pulse)
            if ring_glow:
                _drawShapeGlow(surface,cur_rc,cx,cy,pulse_r,shape,shape_angle)
            _drawShape(surface,shape,cur_rc,cx,cy,pulse_r,ring_width,shape_angle,dash=ring_dash)
            if ring_double:
                inner=max(10,pulse_r-ring_double_gap)
                _drawShape(surface,shape,(*cur_rc,90),cx,cy,inner,max(1,ring_width-1),shape_angle)
            if ring_flash>0: ring_flash-=1
            if ring_pulse>0: ring_pulse=max(0,ring_pulse-2)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface,particles)
                for p in particles:
                    p["x"]+=p["vx"]; p["y"]+=p["vy"]; p["vy"]+=0.2; p["life"]-=1
                particles=[p for p in particles if p["life"]>0]

            # ── ball-ball collision ────────────────────────────────────────
            if ball_collision:
                _resolveBallCollisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)

            # ── physics ───────────────────────────────────────────────────
            for b in balls:
                b["vy"]+=gravity; b["vx"]*=friction; b["vy"]*=friction
                b["x"]+=b["vx"]; b["y"]+=b["vy"]

                spd=math.hypot(b["vx"],b["vy"])
                if spd>0:
                    b["vx"]=b["vx"]/spd*ball_speed
                    b["vy"]=b["vy"]/spd*ball_speed

                if ball_trail:
                    b["trail"].append((b["x"],b["y"],b["r"]))
                    if len(b["trail"])>trail_length: b["trail"].pop(0)

                hit=_resolveShapeCollision(b,b["r"],shape,cx,cy,cr,bounce,shape_angle)
                if hit:
                    log_wall_from_ball(audio, frame / fps, ball)
                if hit:
                    if on_hit_flash:      b["flash"]  = 6
                    if ring_flash_on_hit: ring_flash  = 6
                    if on_hit_ring_pulse: ring_pulse  = 18
                    if bg_pulse_on_hit:   bg_flash    = 4
                    if on_hit_particles:
                        particles+=_spawnParticles(b["x"],b["y"],b["color"],pcolors,
                                                   count=particle_count,speed_mult=particle_speed)

            # ── score recalc ───────────────────────────────────────────────
            if frame % coverage_check_every == 0:
                scores, total_painted = _calcScores(
                    paint_surf, palette, width, height, scale=4)
                if total_painted > 0:
                    winner_idx = max(scores, key=lambda i: scores.get(i,0))

            # ── draw trails + balls ───────────────────────────────────────
            for b in balls:
                if ball_trail: _drawTrail(surface,b["trail"],b["color"])

            for b in balls:
                pos=(int(b["x"]),int(b["y"])); r_int=max(1,b["r"])
                draw_color=_lighten(b["color"],180) if b["flash"]>0 else b["color"]
                if ball_glow: _drawGlow(surface,draw_color,pos,r_int)
                if ball_opacity<255:
                    _withAlpha(surface,draw_color,pos,r_int,ball_opacity)
                else:
                    pygame.draw.circle(surface,draw_color,pos,r_int)
                if ball_shine and r_int>6:
                    pygame.draw.circle(surface,(255,255,255),
                        (pos[0]-r_int//4,pos[1]-r_int//4),max(1,r_int//5))
                if b["flash"]>0: b["flash"]-=1

            # ── scorebar ───────────────────────────────────────────────────
            if show_score:
                _drawScorebar(surface,scores,total_painted,palette,
                              width,height,font_score,ball_count)

            # ── winner flash in last 3 seconds ────────────────────────────
            if show_winner and frame >= total_frames - fps*3:
                if (frame//15) % 2 == 0:
                    _drawWinner(surface,winner_idx,palette,width,height,font_big)

            # ── end check — loop at end of duration ───────────────────────
            if frame == total_frames - 1:
                loops_done += 1
                if end_behavior=="loop" and (loop_count==0 or loops_done<loop_count):
                    paint_surf, balls = _resetScene()
                    particles=[]; scores={i:0 for i in range(ball_count)}
                else:
                    done = True

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))

            if frame%(fps*2)==0:
                pcts=[f"B{i+1}:{scores.get(i,0)/max(1,total_painted)*100:.0f}%"
                      for i in range(ball_count)]
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| {' '.join(pcts)}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg","-y","-framerate",str(fps),
            "-i",str(frames_dir/"frame_%06d.png"),
            "-c:v","libx264","-pix_fmt","yuv420p",
            "-preset","fast","-crf","18",str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration)
    return output