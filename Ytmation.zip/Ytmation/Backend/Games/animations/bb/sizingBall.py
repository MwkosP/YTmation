"""
Growing / Shrinking Ball — Full Customization
----------------------------------------------
A single ball bounces inside a shape, growing or shrinking on every wall hit.

CORE:
    mode             : str   = "grow"     — "grow" | "shrink" | "grow_shrink" | "shrink_grow"
    size_multiplier  : float = 1.06       — factor applied per bounce (e.g. 1.06 = +6%)
    end_behavior     : str   = "reverse"  — "stop" | "reverse" | "loop" (what happens at min/max)
    start_radius     : int   = None       — starting ball size, auto if None

SIZE LIMITS:
    min_radius       : int   = 5          — ball vanishes below this (shrink mode)
    max_radius       : int   = None       — auto: 90% of shape size

SHAPE:
    shape            : str   = "circle"   — "circle"|"square"|"triangle"|"pentagon"|"hexagon"|"diamond"
    shape_radius     : int   = None       — auto if None
    ring_color       : str   = "#ffffff"
    ring_width       : int   = 4
    ring_glow        : bool  = False
    ring_flash_on_hit: bool  = False
    ring_spin        : bool  = False
    ring_spin_speed  : float = 0.5
    ring_double      : bool  = False
    ring_double_gap  : int   = 20
    ring_dash        : bool  = False

BALL:
    ball_color       : str   = None       — hex, random if None
    ball_glow        : bool  = True
    ball_shine       : bool  = True
    ball_trail       : bool  = True
    trail_length     : int   = 18
    ball_opacity     : int   = 255
    ball_image       : str   = None       — path to PNG

COLOR TRANSITION:
    color_start      : str   = None       — interpolate ball color from this...
    color_end        : str   = None       — ...to this as ball grows/shrinks
    color_by_size    : bool  = False      — enable color transition based on size

HIT EFFECTS:
    on_hit_flash     : bool  = True
    on_hit_particles : bool  = False
    on_hit_ring_pulse: bool  = False
    particle_count   : int   = 12
    particle_speed   : float = 1.2
    particle_colors  : list  = None
    bg_pulse_on_hit  : bool  = False

PHYSICS:
    gravity          : float = 0.0        — 0 = weightless, floaty feel
    speed            : float = 6.0        — initial ball speed
    bounce           : float = 1.0        — energy kept on wall hit (1.0 = no loss)
    friction         : float = 1.0

BACKGROUND:
    bg_color         : str   = "#0d0d0d"
    bg_color2        : str   = None
    bg_gradient_dir  : str   = "vertical"
    bg_image         : str   = None
    bg_image_alpha   : int   = 255
    bg_pulse_on_hit  : bool  = False

OUTPUT:
    fps              : int   = 60
    width            : int   = 1080
    height           : int   = 1920
    duration         : int   = 15
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _lerpColor(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(c1[i] + (c2[i]-c1[i])*t) for i in range(3))

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=5):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*8, int(60/i))

def _drawShapeGlow(surf, color, cx, cy, size, shape, angle_offset, layers=3):
    import pygame
    for i in range(layers, 0, -1):
        glow_size = size + i * 8
        alpha     = int(50 / i)
        gs        = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        gc        = (*color[:3], alpha)
        gw        = max(2, i*3)
        if shape == "circle":
            pygame.draw.circle(gs, gc, (cx, cy), glow_size, gw)
        elif shape == "square":
            half = glow_size
            pygame.draw.rect(gs, gc, pygame.Rect(cx-half, cy-half, half*2, half*2), gw)
        else:
            verts = _shapeVertices(shape, cx, cy, glow_size, angle_offset)
            pygame.draw.polygon(gs, gc, [(int(x),int(y)) for x,y in verts], gw)
        surf.blit(gs, (0,0))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i, (tx, ty, tr) in enumerate(trail):
        alpha = int(180 * (i / n))
        rad   = max(2, int(tr * 0.8 * (i / n)))
        _withAlpha(surf, color, (int(tx), int(ty)), rad, alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255 * (p["life"] / p["max_life"]))
        r     = max(1, int(p["r"] * (p["life"] / p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]), int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=12, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(2, 8) * speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({
            "x": x, "y": y,
            "vx": math.cos(angle)*speed,
            "vy": math.sin(angle)*speed,
            "r":  random.randint(3, 8),
            "color": c,
            "life": random.randint(10, 25),
            "max_life": 25,
        })
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x/w
            pygame.draw.line(surf, tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)), (x,0),(x,h))
    elif direction == "radial":
        cx2,cy2 = w//2,h//2
        md = math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y), tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t = y/h
            pygame.draw.line(surf, tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)), (0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img = pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img, size)


# ── shape helpers ──────────────────────────────────────────────────────────────

_SHAPE_SIDES = {"triangle":3, "diamond":4, "pentagon":5, "hexagon":6}

def _shapeVertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [(cx + size*math.cos(angle_offset + 2*math.pi*i/sides - math.pi/2),
             cy + size*math.sin(angle_offset + 2*math.pi*i/sides - math.pi/2))
            for i in range(sides)]

def _drawShape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame
    if shape == "circle":
        if dash:
            _dashedCircle(surf, color, (cx,cy), size, width)
        else:
            pygame.draw.circle(surf, color, (cx,cy), size, width)
        return
    if shape == "square":
        half = size
        pygame.draw.rect(surf, color, pygame.Rect(cx-half,cy-half,half*2,half*2), width)
        return
    verts = _shapeVertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x),int(y)) for x,y in verts], width)

def _dashedCircle(surf, color, center, radius, width, dash=20):
    import pygame
    n = max(1, int(math.pi*radius/dash))
    for i in range(n):
        a0 = (2*math.pi/n)*i
        a1 = a0 + math.pi/n
        pts = [(center[0]+radius*math.cos(a0+(a1-a0)*s/10),
                center[1]+radius*math.sin(a0+(a1-a0)*s/10)) for s in range(11)]
        if len(pts) > 1:
            pygame.draw.lines(surf, color, False, pts, width)

def _closestPointOnSegment(px, py, ax, ay, bx, by):
    dx, dy = bx-ax, by-ay
    t = max(0.0, min(1.0, ((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2, cy2 = ax+t*dx, ay+t*dy
    nx, ny = px-cx2, py-cy2
    dist = math.hypot(nx, ny)
    if dist < 1e-6: nx,ny,dist = -dy,dx,math.hypot(-dy,dx)
    return cx2, cy2, nx/dist, ny/dist, dist

def _resolveShapeCollision(b, r, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    """Returns True if collision happened. Modifies b dict in place."""
    bx, by = b["x"], b["y"]
    hit = False

    if shape == "circle":
        dx, dy = bx-cx, by-cy
        dist = math.hypot(dx, dy)
        md = size - r
        if dist > md:
            nx, ny = dx/dist, dy/dist
            b["x"] = cx + nx*md
            b["y"] = cy + ny*md
            dot = b["vx"]*nx + b["vy"]*ny
            b["vx"] = (b["vx"] - 2*dot*nx) * bounce
            b["vy"] = (b["vy"] - 2*dot*ny) * bounce
            hit = True

    elif shape == "square":
        half = size - r
        if bx < cx-half: b["x"]=cx-half; b["vx"]=abs(b["vx"])*bounce; hit=True
        elif bx > cx+half: b["x"]=cx+half; b["vx"]=-abs(b["vx"])*bounce; hit=True
        if by < cy-half: b["y"]=cy-half; b["vy"]=abs(b["vy"])*bounce; hit=True
        elif by > cy+half: b["y"]=cy+half; b["vy"]=-abs(b["vy"])*bounce; hit=True

    else:
        verts = _shapeVertices(shape, cx, cy, size, angle_offset)
        n = len(verts)
        for i in range(n):
            ax, ay = verts[i]
            bvx, bvy = verts[(i+1)%n]
            cpx, cpy, nx, ny, dist = _closestPointOnSegment(bx, by, ax, ay, bvx, bvy)
            tcx, tcy = cx-cpx, cy-cpy
            if nx*tcx + ny*tcy < 0: nx,ny = -nx,-ny
            if dist < r:
                overlap = r - dist
                b["x"] += nx*overlap
                b["y"] += ny*overlap
                dot = b["vx"]*nx + b["vy"]*ny
                if dot < 0:
                    b["vx"] = (b["vx"] - 2*dot*nx) * bounce
                    b["vy"] = (b["vy"] - 2*dot*ny) * bounce
                hit = True

    return hit


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    # output
    duration: int           = 15,
    output: Path            = None,
    fps: int                = 60,
    width: int              = 1080,
    height: int             = 1920,
    # core
    mode: str               = "grow",        # grow | shrink | grow_shrink | shrink_grow
    size_multiplier: float  = 1.06,
    end_behavior: str       = "reverse",     # stop | reverse | loop
    start_radius: int       = None,
    # size limits
    min_radius: int         = 5,
    max_radius: int         = None,
    # shape
    shape: str              = "circle",
    shape_radius: int       = None,
    ring_color: str         = "#ffffff",
    ring_width: int         = 4,
    ring_glow: bool         = False,
    ring_flash_on_hit: bool = False,
    ring_spin: bool         = False,
    ring_spin_speed: float  = 0.5,
    ring_double: bool       = False,
    ring_double_gap: int    = 20,
    ring_dash: bool         = False,
    # ball
    ball_color: str         = None,
    ball_glow: bool         = True,
    ball_shine: bool        = True,
    ball_trail: bool        = True,
    trail_length: int       = 18,
    ball_opacity: int       = 255,
    ball_image: str         = None,
    # color transition
    color_start: str        = None,
    color_end: str          = None,
    color_by_size: bool     = False,
    # hit effects
    on_hit_flash: bool      = True,
    on_hit_particles: bool  = False,
    on_hit_ring_pulse: bool = False,
    particle_count: int     = 12,
    particle_speed: float   = 1.2,
    particle_colors: list   = None,
    bg_pulse_on_hit: bool   = False,
    # physics
    gravity: float          = 0.0,
    speed: float            = 6.0,
    bounce: float           = 1.0,
    friction: float         = 1.0,
    # background
    bg_color: str           = "#0d0d0d",
    bg_color2: str          = None,
    bg_gradient_dir: str    = "vertical",
    bg_image: str           = None,
    bg_image_alpha: int     = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = shape.lower().strip()
    mode  = mode.lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"growingBall_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width, height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    rc           = _hex(ring_color)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    cr = shape_radius or (min(width, height) // 2 - 80)

    # size limits
    max_r = max_radius or int(cr * 0.90)
    min_r = max(2, min_radius)

    # starting radius based on mode
    if start_radius:
        ball_r = float(start_radius)
    elif mode in ("grow", "grow_shrink"):
        ball_r = float(min_r + 5)
    else:
        ball_r = float(max_r - 5)

    # ball color
    if color_by_size and color_start and color_end:
        cs = _hex(color_start)
        ce = _hex(color_end)
        ball_c = cs
    else:
        ball_c = _hex(ball_color) if ball_color else (
            random.randint(80,255), random.randint(80,255), random.randint(80,255))
        cs = ce = ball_c

    # direction: +1 = growing, -1 = shrinking
    direction = 1 if mode in ("grow", "grow_shrink") else -1

    # initial velocity — random angle, fixed speed
    angle0 = random.uniform(0, 2*math.pi)
    ball = {
        "x":  float(cx),
        "y":  float(cy),
        "vx": math.cos(angle0) * speed,
        "vy": math.sin(angle0) * speed,
    }

    # pre-load assets
    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image, (width, height))
        if bg_image_alpha < 255: raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    ball_img = None
    if ball_image and Path(ball_image).exists():
        ball_img = pygame.image.load(str(ball_image)).convert_alpha()

    particles     = []
    ring_flash    = 0
    ring_pulse    = 0
    bg_flash      = 0
    shape_angle   = 0.0   # radians
    ring_angle_d  = 0.0   # degrees for image rotation
    flash_timer   = 0
    done          = False

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255))
                surface.blit(bg_img_surf, (0,0))
            elif grad_surf:
                surface.blit(grad_surf, (0,0))
            else:
                flash_amt = min(bg_flash*8, 40)
                surface.fill((
                    min(255,bg[0]+flash_amt),
                    min(255,bg[1]+flash_amt),
                    min(255,bg[2]+flash_amt),
                    255))
            if bg_flash > 0: bg_flash -= 1

            # ── color by size ──────────────────────────────────────────────
            if color_by_size and color_start and color_end:
                t = (ball_r - min_r) / max(1, max_r - min_r)
                ball_c = _lerpColor(cs, ce, t)

            # ── ring ──────────────────────────────────────────────────────
            cur_rc  = _lighten(rc, min(ring_flash*15,120)) if ring_flash > 0 else rc
            pulse_r = cr + int(ring_pulse)

            if ring_glow:
                _drawShapeGlow(surface, cur_rc, cx, cy, pulse_r, shape, shape_angle)

            _drawShape(surface, shape, cur_rc, cx, cy, pulse_r,
                       ring_width, shape_angle, dash=ring_dash)

            if ring_double:
                inner = max(10, pulse_r - ring_double_gap)
                _drawShape(surface, shape, (*cur_rc,90), cx, cy, inner,
                           max(1,ring_width-1), shape_angle)

            if ring_spin:
                shape_angle  += math.radians(ring_spin_speed)
                ring_angle_d += ring_spin_speed

            if ring_flash > 0: ring_flash -= 1
            if ring_pulse > 0: ring_pulse  = max(0, ring_pulse - 2)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface, particles)
                for p in particles:
                    p["x"] += p["vx"]; p["y"] += p["vy"]
                    p["vy"] += 0.2;    p["life"] -= 1
                particles = [p for p in particles if p["life"] > 0]

            # ── physics ───────────────────────────────────────────────────
            if not done:
                ball["vy"] += gravity
                ball["vx"] *= friction
                ball["vy"] *= friction
                ball["x"]  += ball["vx"]
                ball["y"]  += ball["vy"]

                # shape collision — use current ball_r
                r_int = max(1, int(ball_r))
                hit   = _resolveShapeCollision(ball, r_int, shape, cx, cy, cr, bounce, shape_angle)
                if hit:
                    log_wall_from_ball(audio, frame / fps, ball)

                if hit:
                    # resize on bounce
                    if direction == 1:
                        ball_r *= size_multiplier
                    else:
                        ball_r /= size_multiplier

                    # clamp & handle end behavior
                    if ball_r >= max_r or ball_r <= min_r:
                        ball_r = max(min_r, min(ball_r, float(max_r)))
                        if end_behavior == "stop":
                            done = True
                        elif end_behavior == "reverse":
                            direction *= -1
                        elif end_behavior == "loop":
                            if direction == 1:
                                ball_r = float(min_r + 5)
                            else:
                                ball_r = float(max_r - 5)

                    # maintain constant speed after bounce
                    spd = math.hypot(ball["vx"], ball["vy"])
                    if spd > 0:
                        ball["vx"] = ball["vx"] / spd * speed
                        ball["vy"] = ball["vy"] / spd * speed

                    if on_hit_flash:      flash_timer     = 6
                    if ring_flash_on_hit: ring_flash      = 6
                    if on_hit_ring_pulse: ring_pulse      = 18
                    if bg_pulse_on_hit:   bg_flash        = 4
                    if on_hit_particles:
                        particles += _spawnParticles(
                            ball["x"], ball["y"], ball_c, pcolors,
                            count=particle_count, speed_mult=particle_speed)

            # ── draw ball ─────────────────────────────────────────────────
            r_int      = max(1, int(ball_r))
            draw_color = _lighten(ball_c, 180) if flash_timer > 0 else ball_c
            pos        = (int(ball["x"]), int(ball["y"]))

            if ball_trail:
                # draw trail as circles fading back
                trail_r = r_int
                for i in range(min(trail_length, frame)):
                    frac = i / trail_length
                    tx = int(ball["x"] - ball["vx"] * i * 0.8)
                    ty = int(ball["y"] - ball["vy"] * i * 0.8)
                    tr = max(2, int(trail_r * (1 - frac * 0.5)))
                    _withAlpha(surface, ball_c, (tx,ty), tr, int(120*(1-frac)))

            if ball_glow:
                _drawGlow(surface, draw_color, pos, r_int, layers=5)

            if ball_img:
                scaled = pygame.transform.smoothscale(ball_img, (r_int*2, r_int*2))
                if ball_opacity < 255: scaled.set_alpha(ball_opacity)
                surface.blit(scaled, (pos[0]-r_int, pos[1]-r_int))
            else:
                if ball_opacity < 255:
                    _withAlpha(surface, draw_color, pos, r_int, ball_opacity)
                else:
                    pygame.draw.circle(surface, draw_color, pos, r_int)

                if ball_shine and r_int > 6:
                    pygame.draw.circle(surface, (255,255,255),
                        (pos[0]-r_int//4, pos[1]-r_int//4), max(1, r_int//5))

            if flash_timer > 0: flash_timer -= 1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))

            if frame % (fps*2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| ball_r: {ball_r:.1f} | dir: {'grow' if direction==1 else 'shrink'}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", str(fps),
            "-i", str(frames_dir/"frame_%06d.png"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "fast", "-crf", "18",
            str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)