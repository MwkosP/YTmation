"""
Breakout Ball — Full Customization
------------------------------------
A ball bounces inside a boundary, breaking destructible blocks on contact.
Simulation ends when all blocks are cleared or the ball escapes.

CORE:
    end_behavior         : str   = "loop"   — "stop" | "loop" (reset when done)
    loop_count           : int   = 0        — max loops (0 = infinite)
    win_condition        : str   = "clear"  — "clear" (all blocks gone) | "escape" | "either"

BLOCKS:
    block_shape          : str   = "square" — "square"|"hexagon"|"triangle"|"circle"
    block_rows           : int   = 6        — rows of blocks
    block_cols           : int   = 6        — cols of blocks
    block_size           : int   = None     — auto if None
    block_padding        : int   = 4        — gap between blocks
    block_health         : int   = 1        — hits to destroy (1-3)
    block_colors         : list  = None     — list of colors per health level (health 3,2,1)
    block_glow           : bool  = False
    block_flash_on_hit   : bool  = True

BOUNDARY:
    boundary_shape       : str   = "circle" — outer container: "circle"|"square"|"triangle"|"hexagon"|"pentagon"|"diamond"
    boundary_radius      : int   = None
    boundary_color       : str   = "#ffffff"
    boundary_width       : int   = 5
    boundary_glow        : bool  = False
    boundary_spin        : bool  = False
    boundary_spin_speed  : float = 0.0

BALL:
    ball_color           : str   = None
    ball_radius          : int   = 18
    ball_glow            : bool  = True
    ball_trail           : bool  = True
    trail_length         : int   = 16
    ball_shine           : bool  = True
    ball_opacity         : int   = 255
    ball_speed           : float = 8.0

HIT EFFECTS:
    on_hit_flash         : bool  = True
    on_hit_particles     : bool  = True
    particle_count       : int   = 8
    particle_speed       : float = 1.2
    particle_colors      : list  = None
    on_hit_boundary_pulse: bool  = False
    bg_pulse_on_hit      : bool  = False

PHYSICS:
    gravity              : float = 0.0
    bounce               : float = 1.0
    friction             : float = 1.0

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"
    bg_image             : str   = None
    bg_image_alpha       : int   = 255

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 20
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"

# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*6, int(55/i))

def _drawShapeGlow(surf, color, cx, cy, size, shape, angle_offset, layers=3):
    import pygame
    for i in range(layers, 0, -1):
        gs=size+i*8; alpha=int(50/i); gw=max(2,i*3)
        s=pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        gc=(*color[:3], alpha)
        if shape=="circle": pygame.draw.circle(s,gc,(cx,cy),gs,gw)
        elif shape=="square": pygame.draw.rect(s,gc,pygame.Rect(cx-gs,cy-gs,gs*2,gs*2),gw)
        else:
            verts=_boundaryVertices(shape,cx,cy,gs,angle_offset)
            pygame.draw.polygon(s,gc,[(int(x),int(y)) for x,y in verts],gw)
        surf.blit(s,(0,0))

def _drawTrail(surf, trail, color):
    n=len(trail)
    if n==0: return
    for i,(tx,ty,tr) in enumerate(trail):
        alpha=int(160*(i/n)); rad=max(2,int(tr*0.7*(i/n)))
        _withAlpha(surf,color,(int(tx),int(ty)),rad,alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha=int(255*(p["life"]/p["max_life"]))
        r=max(1,int(p["r"]*(p["life"]/p["max_life"])))
        _withAlpha(surf,p["color"],(int(p["x"]),int(p["y"])),r,alpha)

def _spawnParticles(x, y, color, pcolors, count=8, speed_mult=1.0):
    out=[]
    for _ in range(count):
        angle=random.uniform(0,2*math.pi); speed=random.uniform(2,8)*speed_mult
        c=_hex(random.choice(pcolors)) if pcolors else color
        out.append({"x":x,"y":y,"vx":math.cos(angle)*speed,"vy":math.sin(angle)*speed,
                    "r":random.randint(3,8),"color":c,"life":random.randint(10,25),"max_life":25})
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf=pygame.Surface((w,h))
    if direction=="horizontal":
        for x in range(w):
            t=x/w; pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(x,0),(x,h))
    elif direction=="radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h; pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img=pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img,size)


# ── boundary shape helpers ─────────────────────────────────────────────────────

_BOUNDARY_SIDES={"triangle":3,"diamond":4,"pentagon":5,"hexagon":6,
                 "heptagon":7,"octagon":8,"dodecagon":12}

def _boundaryVertices(shape, cx, cy, size, angle_offset=0.0):
    sides=_BOUNDARY_SIDES.get(shape,6)
    return [(cx+size*math.cos(angle_offset+2*math.pi*i/sides-math.pi/2),
             cy+size*math.sin(angle_offset+2*math.pi*i/sides-math.pi/2))
            for i in range(sides)]

def _drawBoundary(surf, shape, color, cx, cy, size, width, angle_offset=0.0):
    import pygame
    if shape=="circle": pygame.draw.circle(surf,color,(cx,cy),int(size),width)
    elif shape=="square":
        s=int(size); pygame.draw.rect(surf,color,pygame.Rect(cx-s,cy-s,s*2,s*2),width)
    else:
        verts=_boundaryVertices(shape,cx,cy,size,angle_offset)
        pygame.draw.polygon(surf,color,[(int(x),int(y)) for x,y in verts],width)

def _closestPointOnSegment(px,py,ax,ay,bx,by):
    dx,dy=bx-ax,by-ay
    t=max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2,cy2=ax+t*dx,ay+t*dy; nx,ny=px-cx2,py-cy2
    dist=math.hypot(nx,ny)
    if dist<1e-6: nx,ny,dist=-dy,dx,math.hypot(-dy,dx)
    return cx2,cy2,nx/dist,ny/dist,dist

def _resolveBoundaryCollision(ball, br, shape, cx, cy, size, bounce, angle_offset=0.0):
    """Returns True if bounced, 'escape' if outside."""
    bx,by=ball["x"],ball["y"]
    if shape=="circle":
        dx,dy=bx-cx,by-cy; dist=math.hypot(dx,dy); md=size-br
        if dist>md:
            if dist>size+br*2: return "escape"
            nx,ny=dx/dist,dy/dist
            ball["x"]=cx+nx*md; ball["y"]=cy+ny*md
            dot=ball["vx"]*nx+ball["vy"]*ny
            ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
            ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True
        return False
    elif shape=="square":
        half=size-br; hit=False
        if bx<cx-half: ball["x"]=cx-half; ball["vx"]=abs(ball["vx"])*bounce; hit=True
        elif bx>cx+half: ball["x"]=cx+half; ball["vx"]=-abs(ball["vx"])*bounce; hit=True
        if by<cy-half: ball["y"]=cy-half; ball["vy"]=abs(ball["vy"])*bounce; hit=True
        elif by>cy+half: ball["y"]=cy+half; ball["vy"]=-abs(ball["vy"])*bounce; hit=True
        if abs(bx-cx)>size+br*3 or abs(by-cy)>size+br*3: return "escape"
        return hit
    else:
        verts=_boundaryVertices(shape,cx,cy,size,angle_offset)
        n=len(verts); hit=False
        for i in range(n):
            ax,ay=verts[i]; bvx2,bvy2=verts[(i+1)%n]
            cpx,cpy,enx,eny,dist=_closestPointOnSegment(bx,by,ax,ay,bvx2,bvy2)
            tcx,tcy=cx-cpx,cy-cpy
            if enx*tcx+eny*tcy<0: enx,eny=-enx,-eny
            if dist<br:
                ball["x"]+=enx*(br-dist); ball["y"]+=eny*(br-dist)
                dot=ball["vx"]*enx+ball["vy"]*eny
                if dot<0:
                    ball["vx"]=(ball["vx"]-2*dot*enx)*bounce
                    ball["vy"]=(ball["vy"]-2*dot*eny)*bounce
                hit=True
        if math.hypot(bx-cx,by-cy)>size*1.8: return "escape"
        return hit


# ── block building & collision ─────────────────────────────────────────────────

DEFAULT_HEALTH_COLORS = [
    _hex("#e74c3c"),   # health 3 — red
    _hex("#f39c12"),   # health 2 — orange
    _hex("#2ecc71"),   # health 1 — green
]

def _buildBlocks(block_shape, block_rows, block_cols, block_size,
                 block_padding, block_health, block_colors,
                 cx, cy, boundary_r):
    """Build a grid of blocks centered inside the boundary."""
    blocks = []
    colors = [_hex(c) for c in block_colors] if block_colors else DEFAULT_HEALTH_COLORS
    # ensure we have enough colors for all health levels
    while len(colors) < block_health:
        colors.append(colors[-1])

    bs = block_size  # half-size of each block cell

    if block_shape == "hexagon":
        # honeycomb layout
        hex_w = bs * 2
        hex_h = bs * math.sqrt(3)
        col_step = hex_w * 0.75 + block_padding
        row_step = hex_h + block_padding

        total_w = col_step * (block_cols - 1) + hex_w
        total_h = row_step * (block_rows - 1) + hex_h
        ox = cx - total_w/2 + hex_w/2
        oy = cy - total_h/2 + hex_h/2

        for row in range(block_rows):
            for col in range(block_cols):
                x = ox + col * col_step
                y = oy + row * row_step + (col % 2) * (row_step / 2)
                # only include if inside boundary
                if math.hypot(x-cx, y-cy) < boundary_r - bs*1.5:
                    blocks.append(_makeBlock(x, y, bs, block_shape, block_health, colors))

    elif block_shape == "triangle":
        tri_w = bs * 2 + block_padding
        tri_h = bs * math.sqrt(3) + block_padding
        total_w = tri_w * block_cols
        total_h = tri_h * block_rows
        ox = cx - total_w/2 + bs
        oy = cy - total_h/2 + bs

        for row in range(block_rows):
            for col in range(block_cols * 2):
                # alternate upward/downward triangles
                x = ox + col * bs + (row % 2) * bs/2
                y = oy + row * tri_h
                if math.hypot(x-cx, y-cy) < boundary_r - bs*1.5:
                    flipped = (col + row) % 2 == 1
                    blocks.append(_makeBlock(x, y, bs, block_shape, block_health, colors,
                                             extra={"flipped": flipped}))

    else:
        # square or circle — plain grid
        cell = bs * 2 + block_padding
        total_w = cell * block_cols
        total_h = cell * block_rows
        ox = cx - total_w/2 + bs
        oy = cy - total_h/2 + bs

        for row in range(block_rows):
            for col in range(block_cols):
                x = ox + col * cell
                y = oy + row * cell
                if math.hypot(x-cx, y-cy) < boundary_r - bs*1.5:
                    blocks.append(_makeBlock(x, y, bs, block_shape, block_health, colors))

    return blocks


def _makeBlock(x, y, size, shape, health, colors, extra=None):
    return {
        "x": x, "y": y, "size": size,
        "shape": shape,
        "health": health,
        "max_health": health,
        "colors": colors,
        "flash": 0,
        "alive": True,
        **(extra or {}),
    }


def _blockColor(block):
    idx = block["max_health"] - block["health"]  # 0=full, 1=damaged, 2=critical
    idx = min(idx, len(block["colors"])-1)
    return block["colors"][idx]


def _drawBlock(surf, block, glow=False):
    import pygame
    if not block["alive"]: return
    color = _lighten(_blockColor(block), 80) if block["flash"]>0 else _blockColor(block)
    x,y,s = int(block["x"]),int(block["y"]),block["size"]
    pos = (x,y)

    if block["shape"]=="square":
        rect = pygame.Rect(x-s, y-s, s*2, s*2)
        if glow:
            gs=pygame.Surface((s*2+20,s*2+20), pygame.SRCALPHA)
            pygame.draw.rect(gs,(*color,40),(0,0,s*2+20,s*2+20))
            surf.blit(gs,(x-s-10,y-s-10))
        pygame.draw.rect(surf, color, rect)
        pygame.draw.rect(surf, _lighten(color,60), rect, 2)

    elif block["shape"]=="circle":
        if glow: _drawGlow(surf,color,pos,s,layers=2)
        pygame.draw.circle(surf,color,pos,s)
        pygame.draw.circle(surf,_lighten(color,60),pos,s,2)

    elif block["shape"]=="hexagon":
        verts=[(x+s*math.cos(math.pi/6+math.pi/3*i),
                y+s*math.sin(math.pi/6+math.pi/3*i)) for i in range(6)]
        iverts=[(int(vx),int(vy)) for vx,vy in verts]
        if glow:
            gs=pygame.Surface(surf.get_size(),pygame.SRCALPHA)
            pygame.draw.polygon(gs,(*color,40),[(int(vx),int(vy))
                for vx,vy in [(x+( s+6)*math.cos(math.pi/6+math.pi/3*i),
                               y+(s+6)*math.sin(math.pi/6+math.pi/3*i)) for i in range(6)]])
            surf.blit(gs,(0,0))
        pygame.draw.polygon(surf,color,iverts)
        pygame.draw.polygon(surf,_lighten(color,60),iverts,2)

    elif block["shape"]=="triangle":
        flipped = block.get("flipped",False)
        if flipped:
            verts=[(x,y+s),(x-s,y-s),(x+s,y-s)]
        else:
            verts=[(x,y-s),(x-s,y+s),(x+s,y+s)]
        iverts=[(int(vx),int(vy)) for vx,vy in verts]
        pygame.draw.polygon(surf,color,iverts)
        pygame.draw.polygon(surf,_lighten(color,60),iverts,2)

    if block["flash"]>0: block["flash"]-=1


def _blockCollision(ball, br, block, bounce):
    """
    AABB-style collision for all block shapes using circle-vs-rect/circle approach.
    Returns True if collision happened.
    """
    if not block["alive"]: return False
    bx,by = ball["x"],ball["y"]
    bsize  = block["size"]
    dx,dy  = bx-block["x"], by-block["y"]

    if block["shape"]=="circle":
        dist=math.hypot(dx,dy)
        md=br+bsize
        if dist<md and dist>0:
            nx,ny=dx/dist,dy/dist
            ball["x"]=block["x"]+nx*md; ball["y"]=block["y"]+ny*md
            dot=ball["vx"]*nx+ball["vy"]*ny
            if dot<0:
                ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
                ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True
        return False

    elif block["shape"]=="square":
        # clamp to square
        cx2=max(block["x"]-bsize,min(bx,block["x"]+bsize))
        cy2=max(block["y"]-bsize,min(by,block["y"]+bsize))
        dist=math.hypot(bx-cx2,by-cy2)
        if dist<br:
            if dist>0:
                nx=(bx-cx2)/dist; ny=(by-cy2)/dist
            else:
                nx,ny=1,0
            overlap=br-dist
            ball["x"]+=nx*overlap; ball["y"]+=ny*overlap
            dot=ball["vx"]*nx+ball["vy"]*ny
            if dot<0:
                ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
                ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True
        return False

    else:
        # hexagon/triangle — use circle-vs-circle approximation (good enough)
        dist=math.hypot(dx,dy)
        md=br+bsize*0.85
        if dist<md and dist>0:
            nx,ny=dx/dist,dy/dist
            ball["x"]=block["x"]+nx*md; ball["y"]=block["y"]+ny*md
            dot=ball["vx"]*nx+ball["vy"]*ny
            if dot<0:
                ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
                ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True
        return False


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    duration: int               = 20,
    output: Path                = None,
    fps: int                    = 60,
    width: int                  = 1080,
    height: int                 = 1920,
    # core
    end_behavior: str           = "loop",
    loop_count: int             = 0,
    win_condition: str          = "clear",   # clear | escape | either
    # blocks
    block_shape: str            = "square",  # square|hexagon|triangle|circle
    block_rows: int             = 6,
    block_cols: int             = 6,
    block_size: int             = None,
    block_padding: int          = 4,
    block_health: int           = 1,
    block_colors: list          = None,
    block_glow: bool            = False,
    block_flash_on_hit: bool    = True,
    # boundary
    boundary_shape: str         = "circle",
    boundary_radius: int        = None,
    boundary_color: str         = "#ffffff",
    boundary_width: int         = 5,
    boundary_glow: bool         = False,
    boundary_spin: bool         = False,
    boundary_spin_speed: float  = 0.0,
    # ball
    ball_color: str             = None,
    ball_radius: int            = 18,
    ball_glow: bool             = True,
    ball_trail: bool            = True,
    trail_length: int           = 16,
    ball_shine: bool            = True,
    ball_opacity: int           = 255,
    ball_speed: float           = 8.0,
    # hit effects
    on_hit_flash: bool          = True,
    on_hit_particles: bool      = True,
    particle_count: int         = 8,
    particle_speed: float       = 1.2,
    particle_colors: list       = None,
    on_hit_boundary_pulse: bool = False,
    bg_pulse_on_hit: bool       = False,
    # physics
    gravity: float              = 0.0,
    bounce: float               = 1.0,
    friction: float             = 1.0,
    # background
    bg_color: str               = "#0d0d0d",
    bg_color2: str              = None,
    bg_gradient_dir: str        = "vertical",
    bg_image: str               = None,
    bg_image_alpha: int         = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER","dummy")
    os.environ.setdefault("SDL_AUDIODRIVER","dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    block_shape    = block_shape.lower().strip()
    boundary_shape = boundary_shape.lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"breakoutBall_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width,height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    bc_color     = _hex(boundary_color)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    br = boundary_radius or (min(width,height)//2 - 60)

    # auto block size based on grid and boundary
    if block_size is None:
        play_area = br * 0.85
        bs = max(10, int(min(play_area/block_cols, play_area/block_rows) * 0.9) - block_padding)
    else:
        bs = block_size

    # ball color
    bc = _hex(ball_color) if ball_color else (
        random.randint(80,255), random.randint(80,255), random.randint(80,255))

    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw=_loadImage(bg_image,(width,height))
        if bg_image_alpha<255: raw.set_alpha(bg_image_alpha)
        bg_img_surf=raw

    def _resetScene():
        blocks = _buildBlocks(block_shape, block_rows, block_cols, bs,
                               block_padding, block_health, block_colors,
                               cx, cy, br)
        angle  = random.uniform(0, 2*math.pi)
        ball   = {
            "x": float(cx), "y": float(cy),
            "vx": math.cos(angle)*ball_speed,
            "vy": math.sin(angle)*ball_speed,
            "flash": 0, "trail": [],
        }
        return blocks, ball

    blocks, ball = _resetScene()
    particles    = []
    boundary_angle = 0.0
    boundary_pulse = 0
    bg_flash     = 0
    flash_timer  = 0
    loops_done   = 0
    done         = False

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))
                continue

            if boundary_spin:
                boundary_angle += math.radians(boundary_spin_speed)

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255)); surface.blit(bg_img_surf,(0,0))
            elif grad_surf:
                surface.blit(grad_surf,(0,0))
            else:
                fa=min(bg_flash*8,40)
                surface.fill((min(255,bg[0]+fa),min(255,bg[1]+fa),min(255,bg[2]+fa),255))
            if bg_flash>0: bg_flash-=1

            # ── draw blocks ───────────────────────────────────────────────
            for blk in blocks:
                _drawBlock(surface, blk, glow=block_glow)

            # ── boundary ──────────────────────────────────────────────────
            pulse_r = br + int(boundary_pulse)
            cur_bc  = bc_color

            if boundary_glow:
                _drawShapeGlow(surface,cur_bc,cx,cy,pulse_r,boundary_shape,boundary_angle)
            _drawBoundary(surface,boundary_shape,cur_bc,cx,cy,pulse_r,
                          boundary_width,boundary_angle)

            if boundary_pulse>0: boundary_pulse=max(0,boundary_pulse-2)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface,particles)
                for p in particles:
                    p["x"]+=p["vx"]; p["y"]+=p["vy"]; p["vy"]+=0.2; p["life"]-=1
                particles=[p for p in particles if p["life"]>0]

            # ── physics ───────────────────────────────────────────────────
            ball["vy"]+=gravity; ball["vx"]*=friction; ball["vy"]*=friction
            ball["x"]+=ball["vx"]; ball["y"]+=ball["vy"]

            # maintain speed
            spd=math.hypot(ball["vx"],ball["vy"])
            if spd>0:
                ball["vx"]=ball["vx"]/spd*ball_speed
                ball["vy"]=ball["vy"]/spd*ball_speed

            # trail
            if ball_trail:
                ball["trail"].append((ball["x"],ball["y"],ball_radius))
                if len(ball["trail"])>trail_length: ball["trail"].pop(0)

            # ── block collisions ──────────────────────────────────────────
            alive_blocks = [b for b in blocks if b["alive"]]
            for blk in alive_blocks:
                if _blockCollision(ball, ball_radius, blk, bounce):
                    log_wall_from_ball(audio, frame / fps, ball)
                    blk["health"] -= 1
                    if blk["health"] <= 0:
                        blk["alive"] = False
                    else:
                        if block_flash_on_hit: blk["flash"] = 6
                    if on_hit_flash:   flash_timer     = 5
                    if bg_pulse_on_hit: bg_flash        = 4
                    if on_hit_particles:
                        particles+=_spawnParticles(
                            ball["x"],ball["y"],_blockColor(blk),pcolors,
                            count=particle_count,speed_mult=particle_speed)
                    break  # one block per frame

            # ── boundary collision ────────────────────────────────────────
            b_result = _resolveBoundaryCollision(
                ball, ball_radius, boundary_shape, cx, cy, br, bounce, boundary_angle)

            if b_result=="escape":
                escaped = True
            else:
                escaped = False
                if b_result is True:
                    log_wall_from_ball(audio, frame / fps, ball)
                if b_result is True and on_hit_boundary_pulse:
                    boundary_pulse = 15

            # ── win check ─────────────────────────────────────────────────
            all_clear   = all(not b["alive"] for b in blocks)
            trigger_end = False
            if win_condition=="clear"  and all_clear:  trigger_end=True
            if win_condition=="escape" and escaped:     trigger_end=True
            if win_condition=="either" and (all_clear or escaped): trigger_end=True

            if trigger_end:
                loops_done+=1
                reason = "cleared" if all_clear else "escaped"
                print(f"   Round {loops_done} ended ({reason}) at frame {frame}")
                if end_behavior=="loop" and (loop_count==0 or loops_done<loop_count):
                    blocks,ball=_resetScene()
                    particles=[]; flash_timer=0
                else:
                    done=True

            # ── draw trail + ball ──────────────────────────────────────────
            if ball_trail:
                _drawTrail(surface,ball["trail"],bc)

            pos=(int(ball["x"]),int(ball["y"]))
            draw_color=_lighten(bc,180) if flash_timer>0 else bc

            if ball_glow: _drawGlow(surface,draw_color,pos,ball_radius)

            if ball_opacity<255:
                _withAlpha(surface,draw_color,pos,ball_radius,ball_opacity)
            else:
                pygame.draw.circle(surface,draw_color,pos,ball_radius)

            if ball_shine and ball_radius>6:
                pygame.draw.circle(surface,(255,255,255),
                    (pos[0]-ball_radius//4,pos[1]-ball_radius//4),max(1,ball_radius//5))

            if flash_timer>0: flash_timer-=1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))

            if frame%(fps*2)==0:
                alive=sum(1 for b in blocks if b["alive"])
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| blocks: {alive}/{len(blocks)} | loops: {loops_done}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg","-y","-framerate",str(fps),
            "-i",str(frames_dir/"frame_%06d.png"),
            "-c:v","libx264","-pix_fmt","yuv420p",
            "-preset","fast","-crf","18",str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration)
    return output