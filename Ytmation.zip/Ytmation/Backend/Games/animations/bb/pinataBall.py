"""
Piñata Ball — Full Customization
----------------------------------
A ball hits a shape repeatedly. The shape wobbles and shakes with increasing
intensity. At the breaking point it BURSTS open — dozens of colorful balls
explode outward, fall with gravity, bounce off each other and the floor.

PHASES:
    Phase 1 — Build up: ball bounces inside, shape wobbles more each hit
    Phase 2 — BURST: shape explodes, inner balls flood out
    Phase 3 — Cascade: balls fall, bounce, settle at the bottom

CORE:
    hits_to_break        : int   = 10      — hits before piñata bursts
    end_behavior         : str   = "loop"  — "stop" | "loop"
    loop_count           : int   = 0
    settle_frames        : int   = 180     — frames to show cascade before loop

PIÑATA SHAPE:
    shape                : str   = "circle"
    shape_radius         : int   = None
    shape_color          : str   = "#ff6644"   — main piñata color
    shape_color2         : str   = "#ffcc00"   — secondary stripe color
    shape_stripe         : bool  = True        — draw colorful stripes on shape
    ring_width           : int   = 6
    shape_glow           : bool  = True

WOBBLE:
    wobble_max_angle     : float = 18.0    — max wobble degrees at full damage
    wobble_speed         : float = 8.0     — wobble oscillation speed
    wobble_decay         : float = 0.85    — how fast wobble dies down per frame
    screen_shake_max     : int   = 12      — max screen shake on hit

INNER BALLS:
    inner_ball_count     : int   = 40      — balls that explode out
    inner_ball_colors    : list  = None    — hex list, rainbow if None
    inner_ball_min_r     : int   = 12
    inner_ball_max_r     : int   = 32
    inner_ball_speed_min : float = 8.0
    inner_ball_speed_max : float = 22.0
    ball_collision       : bool  = True

PHYSICS (cascade):
    gravity              : float = 0.6
    bounce_floor         : float = 0.45
    bounce_wall          : float = 0.55
    friction             : float = 0.98
    floor_y              : int   = None    — auto (near bottom of screen)

STRIKER BALL:
    striker_color        : str   = None
    striker_radius       : int   = 22
    striker_glow         : bool  = True
    striker_trail        : bool  = True
    trail_length         : int   = 20
    striker_speed        : float = 7.0

HIT EFFECTS:
    on_hit_particles     : bool  = True
    particle_count       : int   = 12
    particle_speed       : float = 1.8
    particle_colors      : list  = None
    confetti_burst       : bool  = True    — confetti on final burst

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 25
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"

# ── rainbow palette ────────────────────────────────────────────────────────────

RAINBOW = ["#ff4444","#ff8800","#ffcc00","#44ff88",
           "#44aaff","#aa44ff","#ff44aa","#ffffff",
           "#ff6644","#44ffcc","#ffff44","#ff44ff"]

# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _lerpColor(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(c1[i]+(c2[i]-c1[i])*t) for i in range(3))

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=5):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*8, int(60/i))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i,(tx,ty,tr) in enumerate(trail):
        alpha = int(160*(i/n))
        rad   = max(2, int(tr*0.75*(i/n)))
        _withAlpha(surf, color, (int(tx),int(ty)), rad, alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255*(p["life"]/p["max_life"]))
        r     = max(1, int(p["r"]*(p["life"]/p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]),int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=12, speed_mult=1.0, big=False):
    out = []
    for _ in range(count):
        angle = random.uniform(0,2*math.pi)
        speed = random.uniform(3,12)*speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        r     = random.randint(5,14) if big else random.randint(3,8)
        life  = random.randint(20,45) if big else random.randint(12,28)
        out.append({"x":x,"y":y,
                    "vx":math.cos(angle)*speed,"vy":math.sin(angle)*speed,
                    "r":r,"color":c,"life":life,"max_life":life,
                    "gravity": 0.3 if big else 0.2})
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w,h))
    if direction=="horizontal":
        for x in range(w):
            t=x/w
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(x,0),(x,h))
    elif direction=="radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf


# ── shape helpers ──────────────────────────────────────────────────────────────

_SHAPE_SIDES = {"triangle":3,"diamond":4,"pentagon":5,"hexagon":6,"heptagon":7,"octagon":8}

def _shapeVertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape,6)
    return [(cx+size*math.cos(angle_offset+2*math.pi*i/sides-math.pi/2),
             cy+size*math.sin(angle_offset+2*math.pi*i/sides-math.pi/2))
            for i in range(sides)]

def _drawPinata(surf, shape, cx, cy, cr, angle_offset,
                color1, color2, stripe, ring_width, glow, damage):
    """Draw the piñata shape with optional stripes and damage tinting."""
    import pygame

    # glow
    if glow:
        _drawGlow(surf, color1, (cx,cy), cr, layers=4)

    # filled shape
    if shape=="circle":
        pygame.draw.circle(surf, color1, (cx,cy), int(cr))
        if stripe:
            # draw alternating stripe arcs
            n_stripes = 8
            for i in range(n_stripes):
                a0 = 2*math.pi*i/n_stripes + angle_offset
                a1 = a0 + math.pi/n_stripes
                pts = [(cx+cr*0.95*math.cos(a0+(a1-a0)*t/10),
                        cy+cr*0.95*math.sin(a0+(a1-a0)*t/10)) for t in range(11)]
                if len(pts)>1:
                    pygame.draw.lines(surf,color2,False,
                        [(int(x),int(y)) for x,y in pts], ring_width+2)
        pygame.draw.circle(surf, _lighten(color1,40), (cx,cy), int(cr), ring_width)

    elif shape=="square":
        s=int(cr)
        pygame.draw.rect(surf,color1,pygame.Rect(cx-s,cy-s,s*2,s*2))
        if stripe:
            stripe_w=s//4
            for i in range(-2,3):
                x0=cx+i*stripe_w-stripe_w//2
                pygame.draw.rect(surf,color2,pygame.Rect(x0,cy-s,stripe_w//2,s*2))
        pygame.draw.rect(surf,_lighten(color1,40),
            pygame.Rect(cx-s,cy-s,s*2,s*2),ring_width)

    else:
        verts=_shapeVertices(shape,cx,cy,cr,angle_offset)
        iverts=[(int(x),int(y)) for x,y in verts]
        pygame.draw.polygon(surf,color1,iverts)
        if stripe:
            n=len(verts)
            for i in range(0,n,2):
                a,b2=verts[i],verts[(i+1)%n]
                mx,my=(a[0]+b2[0])/2,(a[1]+b2[1])/2
                pygame.draw.line(surf,color2,(cx,cy),(int(mx),int(my)),ring_width+3)
        pygame.draw.polygon(surf,_lighten(color1,40),iverts,ring_width)

    # crack overlay based on damage
    if damage > 0.3:
        crack_alpha = int(180*(damage-0.3)/0.7)
        s2 = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        # draw X crack
        pygame.draw.line(s2,(0,0,0,crack_alpha),
            (cx-int(cr*0.6),cy-int(cr*0.6)),(cx+int(cr*0.6),cy+int(cr*0.6)),
            max(1,int(3*damage)))
        pygame.draw.line(s2,(0,0,0,crack_alpha),
            (cx+int(cr*0.6),cy-int(cr*0.6)),(cx-int(cr*0.6),cy+int(cr*0.6)),
            max(1,int(3*damage)))
        if damage>0.6:
            pygame.draw.line(s2,(0,0,0,crack_alpha),
                (cx,cy-int(cr*0.8)),(cx+int(cr*0.3),cy+int(cr*0.6)),
                max(1,int(2*damage)))
        surf.blit(s2,(0,0))


def _closestPointOnSegment(px,py,ax,ay,bx,by):
    dx,dy=bx-ax,by-ay
    t=max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2,cy2=ax+t*dx,ay+t*dy; nx,ny=px-cx2,py-cy2
    dist=math.hypot(nx,ny)
    if dist<1e-6: nx,ny,dist=-dy,dx,math.hypot(-dy,dx)
    return cx2,cy2,nx/dist,ny/dist,dist

def _resolveShapeCollision(ball, br, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx,by=ball["x"],ball["y"]
    if shape=="circle":
        dx,dy=bx-cx,by-cy; dist=math.hypot(dx,dy); md=size-br
        if dist>md:
            nx,ny=dx/dist,dy/dist
            ball["x"]=cx+nx*md; ball["y"]=cy+ny*md
            dot=ball["vx"]*nx+ball["vy"]*ny
            ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
            ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True
        return False
    elif shape=="square":
        half=size-br; hit=False
        if bx<cx-half: ball["x"]=cx-half; ball["vx"]=abs(ball["vx"])*bounce; hit=True
        elif bx>cx+half: ball["x"]=cx+half; ball["vx"]=-abs(ball["vx"])*bounce; hit=True
        if by<cy-half: ball["y"]=cy-half; ball["vy"]=abs(ball["vy"])*bounce; hit=True
        elif by>cy+half: ball["y"]=cy+half; ball["vy"]=-abs(ball["vy"])*bounce; hit=True
        return hit
    else:
        verts=_shapeVertices(shape,cx,cy,size,angle_offset); n=len(verts); hit=False
        for i in range(n):
            ax,ay=verts[i]; bvx2,bvy2=verts[(i+1)%n]
            _,__,enx,eny,dist=_closestPointOnSegment(bx,by,ax,ay,bvx2,bvy2)
            tcx,tcy=cx-ball["x"],cy-ball["y"]
            if enx*tcx+eny*tcy<0: enx,eny=-enx,-eny
            if dist<br:
                ball["x"]+=enx*(br-dist); ball["y"]+=eny*(br-dist)
                dot=ball["vx"]*enx+ball["vy"]*eny
                if dot<0:
                    ball["vx"]=(ball["vx"]-2*dot*enx)*bounce
                    ball["vy"]=(ball["vy"]-2*dot*eny)*bounce
                hit=True
        return hit


# ── inner ball physics ─────────────────────────────────────────────────────────

def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):
    n=len(balls)
    for i in range(n):
        for j in range(i+1,n):
            a,b=balls[i],balls[j]
            dx=b["x"]-a["x"]; dy=b["y"]-a["y"]
            dist=math.hypot(dx,dy); md=a["r"]+b["r"]
            if dist<md and dist>0:
                overlap=(md-dist)/2; nx=dx/dist; ny=dy/dist
                a["x"]-=nx*overlap; a["y"]-=ny*overlap
                b["x"]+=nx*overlap; b["y"]+=ny*overlap
                dvx=a["vx"]-b["vx"]; dvy=a["vy"]-b["vy"]
                dot=dvx*nx+dvy*ny
                if dot>0:
                    a["vx"]=(a["vx"]-dot*nx)*bounce; a["vy"]=(a["vy"]-dot*ny)*bounce
                    b["vx"]=(b["vx"]+dot*nx)*bounce; b["vy"]=(b["vy"]+dot*ny)*bounce


def _spawnInnerBalls(count, cx, cy, colors,
                     min_r, max_r, spd_min, spd_max):
    """Create inner balls that explode outward from center."""
    balls = []
    palette = [_hex(c) for c in colors] if colors else [_hex(c) for c in RAINBOW]
    for i in range(count):
        r     = random.randint(min_r, max_r)
        color = random.choice(palette)
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(spd_min, spd_max)
        # start near center with slight random offset
        ox    = random.uniform(-20,20)
        oy    = random.uniform(-20,20)
        balls.append({
            "x": float(cx+ox), "y": float(cy+oy),
            "vx": math.cos(angle)*speed,
            "vy": math.sin(angle)*speed - random.uniform(0,4),  # slight upward bias
            "r": r, "color": color,
            "settled": False, "settle_timer": 0,
            "trail": [],
        })
    return balls


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    duration: int               = 25,
    output: Path                = None,
    fps: int                    = 60,
    width: int                  = 1080,
    height: int                 = 1920,
    # core
    hits_to_break: int          = 10,
    end_behavior: str           = "loop",
    loop_count: int             = 0,
    settle_frames: int          = 180,
    # piñata shape
    shape: str                  = "circle",
    shape_radius: int           = None,
    shape_color: str            = "#ff6644",
    shape_color2: str           = "#ffcc00",
    shape_stripe: bool          = True,
    ring_width: int             = 6,
    shape_glow: bool            = True,
    # wobble
    wobble_max_angle: float     = 18.0,
    wobble_speed: float         = 8.0,
    wobble_decay: float         = 0.85,
    screen_shake_max: int       = 12,
    # inner balls
    inner_ball_count: int       = 40,
    inner_ball_colors: list     = None,
    inner_ball_min_r: int       = 12,
    inner_ball_max_r: int       = 32,
    inner_ball_speed_min: float = 8.0,
    inner_ball_speed_max: float = 22.0,
    ball_collision: bool        = True,
    # physics cascade
    gravity: float              = 0.6,
    bounce_floor: float         = 0.45,
    bounce_wall: float          = 0.55,
    friction: float             = 0.98,
    floor_y: int                = None,
    # striker ball
    striker_color: str          = None,
    striker_radius: int         = 22,
    striker_glow: bool          = True,
    striker_trail: bool         = True,
    trail_length: int           = 20,
    striker_speed: float        = 7.0,
    # hit effects
    on_hit_particles: bool      = True,
    particle_count: int         = 12,
    particle_speed: float       = 1.8,
    particle_colors: list       = None,
    confetti_burst: bool        = True,
    # background
    bg_color: str               = "#0d0d0d",
    bg_color2: str              = None,
    bg_gradient_dir: str        = "vertical",
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER","dummy")
    os.environ.setdefault("SDL_AUDIODRIVER","dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = shape.lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"pinataBall_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width,height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    c1           = _hex(shape_color)
    c2           = _hex(shape_color2)
    sc           = _hex(striker_color) if striker_color else (
        random.randint(150,255), random.randint(150,255), random.randint(150,255))
    pcolors      = particle_colors or RAINBOW
    total_frames = max(1, int(duration * fps))

    cx   = width  // 2
    cy   = height // 2 - 100   # piñata hangs slightly above center
    cr   = shape_radius or (min(width,height)//2 - 120)
    fy   = floor_y or (height - 80)

    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width,height,bg,bg2,bg_gradient_dir)

    def _reset():
        angle   = random.uniform(0,2*math.pi)
        striker = {
            "x": float(cx), "y": float(cy),
            "vx": math.cos(angle)*striker_speed,
            "vy": math.sin(angle)*striker_speed,
            "flash": 0, "trail": [],
        }
        return striker

    striker      = _reset()
    inner_balls  = []
    particles    = []
    hits         = 0
    wobble_angle = 0.0
    wobble_vel   = 0.0
    shape_offset = 0.0   # current wobble rotation offset
    shake_x = shake_y = 0
    shake_timer      = 0
    burst            = False
    settle_timer     = 0
    loops_done       = 0
    done             = False

    # "string" visual at top
    string_y = oy = cy - cr - 40

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))
                continue

            damage = hits / max(1, hits_to_break)

            # ── wobble physics ────────────────────────────────────────────
            if not burst:
                wobble_vel  *= wobble_decay
                wobble_angle+= wobble_vel
                wobble_angle *= 0.92   # spring back to 0
                shape_offset  = math.radians(wobble_angle)

            # ── screen shake ──────────────────────────────────────────────
            if shake_timer > 0:
                intensity = int(screen_shake_max * damage)
                shake_x   = random.randint(-intensity, intensity)
                shake_y   = random.randint(-intensity, intensity)
                shake_timer -= 1
            else:
                shake_x = shake_y = 0

            # ── background ────────────────────────────────────────────────
            if grad_surf:
                surface.blit(grad_surf,(shake_x,shake_y))
            else:
                surface.fill((*bg,255))

            # ── string ────────────────────────────────────────────────────
            if not burst:
                import pygame
                sx = cx + shake_x + int(math.sin(shape_offset)*20)
                pygame.draw.line(surface,(160,140,100),
                    (cx+shake_x, 0),(sx, cy-cr+shake_y), 3)

            # ── draw inner balls (cascade phase) ──────────────────────────
            if burst:
                # physics
                if ball_collision:
                    _resolveBallCollisions(inner_balls, bounce_floor, t=frame / fps, audio=audio if audio.enabled else None)

                for b in inner_balls:
                    if b["settled"]: continue
                    b["vy"] += gravity
                    b["vx"] *= friction
                    b["vy"] *= friction
                    b["x"]  += b["vx"]
                    b["y"]  += b["vy"]

                    # trail
                    b["trail"].append((b["x"],b["y"],b["r"]))
                    if len(b["trail"])>8: b["trail"].pop(0)

                    # floor
                    if b["y"]+b["r"] >= fy:
                        b["y"]=fy-b["r"]
                        b["vy"]=-abs(b["vy"])*bounce_floor
                        b["vx"]*=0.85
                        if abs(b["vy"])<1.0 and abs(b["vx"])<0.5:
                            b["settle_timer"]+=1
                            if b["settle_timer"]>10:
                                b["vy"]=0; b["vx"]=0; b["settled"]=True
                        else:
                            b["settle_timer"]=0

                    # walls
                    if b["x"]-b["r"] < 0:
                        b["x"]=b["r"]; b["vx"]=abs(b["vx"])*bounce_wall
                    elif b["x"]+b["r"] > width:
                        b["x"]=width-b["r"]; b["vx"]=-abs(b["vx"])*bounce_wall

                # draw trails then balls
                for b in inner_balls:
                    _drawTrail(surface, b["trail"], b["color"])
                for b in inner_balls:
                    pos=(int(b["x"]),int(b["y"]))
                    _withAlpha(surface,b["color"],pos,b["r"],230)
                    if b["r"]>8:
                        pygame.draw.circle(surface,(255,255,255),
                            (pos[0]-b["r"]//4,pos[1]-b["r"]//4),max(1,b["r"]//5))

                # floor line
                pygame.draw.line(surface,(80,80,80),(0,fy),(width,fy),4)

                settle_timer += 1
                all_settled = all(b["settled"] for b in inner_balls)
                if all_settled or settle_timer >= settle_frames:
                    loops_done += 1
                    print(f"   Cascade complete. Loop {loops_done}")
                    if end_behavior=="loop" and (loop_count==0 or loops_done<loop_count):
                        striker=_reset(); inner_balls=[]; particles=[]
                        hits=0; burst=False; settle_timer=0
                        wobble_angle=0.0; wobble_vel=0.0
                    else:
                        done=True

            else:
                # ── draw piñata ────────────────────────────────────────────
                pcx = cx + shake_x + int(math.sin(shape_offset)*cr*0.15)
                pcy = cy + shake_y + int((1-math.cos(shape_offset))*cr*0.08)
                _drawPinata(surface, shape, pcx, pcy, cr,
                            shape_offset, c1, c2, shape_stripe,
                            ring_width, shape_glow, damage)

                # ── striker physics ────────────────────────────────────────
                striker["vy"] += 0.0  # no gravity for striker
                striker["x"]  += striker["vx"]
                striker["y"]  += striker["vy"]

                spd=math.hypot(striker["vx"],striker["vy"])
                if spd>0:
                    striker["vx"]=striker["vx"]/spd*striker_speed
                    striker["vy"]=striker["vy"]/spd*striker_speed

                if striker_trail:
                    striker["trail"].append((striker["x"],striker["y"],striker_radius))
                    if len(striker["trail"])>trail_length: striker["trail"].pop(0)

                hit=_resolveShapeCollision(
                    striker, striker_radius, shape,
                    pcx, pcy, cr, 1.0, shape_offset)
                if hit:
                    log_wall_from_ball(audio, frame / fps, ball)

                if hit:
                    hits += 1
                    print(f"   Hit {hits}/{hits_to_break}")

                    # wobble kick — gets harder each hit
                    kick = wobble_max_angle * (hits/hits_to_break)
                    wobble_vel += random.choice([-1,1]) * kick * wobble_speed * 0.1

                    shake_timer = max(4, int(8*damage))
                    striker["flash"] = 6

                    if on_hit_particles:
                        particles+=_spawnParticles(
                            striker["x"],striker["y"],c1,
                            pcolors,
                            count=particle_count,speed_mult=particle_speed)

                    if hits >= hits_to_break:
                        # BURST!
                        burst = True
                        settle_timer = 0
                        print(f"   PIÑATA BURST at frame {frame}!")
                        inner_balls = _spawnInnerBalls(
                            inner_ball_count, pcx, pcy,
                            inner_ball_colors,
                            inner_ball_min_r, inner_ball_max_r,
                            inner_ball_speed_min, inner_ball_speed_max)
                        if confetti_burst:
                            for _ in range(5):
                                particles+=_spawnParticles(
                                    pcx,pcy,c1,
                                    RAINBOW,
                                    count=30,speed_mult=3.0,big=True)

            # ── particles ─────────────────────────────────────────────────
            _drawParticles(surface, particles)
            for p in particles:
                p["x"]+=p["vx"]; p["y"]+=p["vy"]
                p["vy"]+=p.get("gravity",0.2); p["life"]-=1
            particles=[p for p in particles if p["life"]>0]

            # ── draw striker ───────────────────────────────────────────────
            if not burst:
                if striker_trail:
                    _drawTrail(surface, striker["trail"], sc)
                pos=(int(striker["x"])+shake_x, int(striker["y"])+shake_y)
                draw_color=_lighten(sc,180) if striker["flash"]>0 else sc
                if striker_glow: _drawGlow(surface,draw_color,pos,striker_radius)
                pygame.draw.circle(surface,draw_color,pos,striker_radius)
                pygame.draw.circle(surface,(255,255,255),
                    (pos[0]-striker_radius//4,pos[1]-striker_radius//4),
                    max(1,striker_radius//5))
                if striker["flash"]>0: striker["flash"]-=1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))

            if frame%(fps*2)==0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| hits:{hits}/{hits_to_break} | burst:{burst} "
                      f"| inner_balls:{len(inner_balls)}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg","-y","-framerate",str(fps),
            "-i",str(frames_dir/"frame_%06d.png"),
            "-c:v","libx264","-pix_fmt","yuv420p",
            "-preset","fast","-crf","18",str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration)
    return output