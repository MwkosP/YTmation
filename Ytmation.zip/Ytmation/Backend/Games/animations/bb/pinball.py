"""
Pinball / Pachinko — Full Customization
----------------------------------------
Balls fall from the top through a staggered peg grid and collect at the bottom.

SPAWN:
    spawn_mode       : str   = "continuous" — "continuous" (stream forever) or "fixed" (N balls total)
    ball_count       : int   = 30           — total balls if spawn_mode="fixed", pool size if "continuous"
    spawn_rate       : int   = 12           — frames between each ball spawn
    spawn_x          : str   = "random"     — "random", "center", or "spread" (evenly spaced)
    spawn_y          : int   = None         — y position to spawn from, auto if None

BOTTOM:
    bottom_mode      : str   = "slots"      — "slots" (collect in buckets) or "open" (fall off screen)
    slot_count       : int   = 7            — number of collection slots at bottom
    slot_color       : str   = "#333333"    — slot divider color
    slot_label       : bool  = False        — show ball count per slot

PEGS:
    peg_rows         : int   = 9            — number of peg rows
    peg_cols         : int   = 7            — pegs per row (alternating rows get peg_cols-1)
    peg_radius       : int   = 12           — peg size
    peg_color        : str   = "#ffffff"    — peg color
    peg_glow         : bool  = False        — glow around pegs
    peg_flash_on_hit : bool  = False        — peg flashes when hit
    peg_shape        : str   = "circle"     — "circle" or "diamond"
    peg_colors       : list  = None         — per-peg random colors if provided

BALLS:
    ball_radius      : int   = 14           — ball size
    ball_colors      : list  = None         — hex list, random if None
    ball_glow        : bool  = False
    ball_trail       : bool  = False
    trail_length     : int   = 10
    ball_shine       : bool  = True
    ball_opacity     : int   = 255

PHYSICS:
    gravity          : float = 0.4
    bounce           : float = 0.55         — lower than bouncingBalls feels more realistic
    friction         : float = 0.99
    ball_collision   : bool  = True         — balls collide with each other
    speed_limit      : float = 18.0         — cap max velocity

HIT EFFECTS:
    on_hit_flash     : bool  = False
    on_hit_particles : bool  = False
    particle_count   : int   = 6
    particle_speed   : float = 1.0
    particle_colors  : list  = None

BACKGROUND:
    bg_color         : str   = "#0d0d0d"
    bg_color2        : str   = None
    bg_gradient_dir  : str   = "vertical"

OUTPUT:
    fps              : int   = 60
    width            : int   = 1080
    height           : int   = 1920
    duration         : int   = 15
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*6, int(50/i))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i, (tx, ty, tr) in enumerate(trail):
        alpha = int(160 * (i / n))
        rad   = max(2, int(tr * 0.6 * (i / n)))
        _withAlpha(surf, color, (int(tx), int(ty)), rad, alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255 * (p["life"] / p["max_life"]))
        r     = max(1, int(p["r"] * (p["life"] / p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]), int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=6, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(1, 5) * speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({
            "x": x, "y": y,
            "vx": math.cos(angle)*speed,
            "vy": math.sin(angle)*speed,
            "r":  random.randint(2, 6),
            "color": c,
            "life": random.randint(8, 20),
            "max_life": 20,
        })
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / w
            r = int(c1[0] + (c2[0]-c1[0])*t)
            g = int(c1[1] + (c2[1]-c1[1])*t)
            b = int(c1[2] + (c2[2]-c1[2])*t)
            pygame.draw.line(surf, (r,g,b), (x,0), (x,h))
    elif direction == "radial":
        cx2, cy2 = w//2, h//2
        max_d = math.hypot(cx2, cy2)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x-cx2, y-cy2) / max_d)
                r = int(c1[0] + (c2[0]-c1[0])*t)
                g = int(c1[1] + (c2[1]-c1[1])*t)
                b = int(c1[2] + (c2[2]-c1[2])*t)
                surf.set_at((x,y), (r,g,b))
    else:
        for y in range(h):
            t = y / h
            r = int(c1[0] + (c2[0]-c1[0])*t)
            g = int(c1[1] + (c2[1]-c1[1])*t)
            b = int(c1[2] + (c2[2]-c1[2])*t)
            pygame.draw.line(surf, (r,g,b), (0,y), (w,y))
    return surf


# ── peg helpers ────────────────────────────────────────────────────────────────

def _drawPeg(surf, peg, peg_shape, peg_glow):
    import pygame
    color = peg["flash_color"] if peg["flash"] > 0 else peg["color"]
    pos   = (int(peg["x"]), int(peg["y"]))
    r     = peg["r"]

    if peg_glow or peg["flash"] > 0:
        _drawGlow(surf, color, pos, r, layers=3)

    if peg_shape == "diamond":
        pts = [
            (pos[0],     pos[1] - r),
            (pos[0] + r, pos[1]    ),
            (pos[0],     pos[1] + r),
            (pos[0] - r, pos[1]    ),
        ]
        pygame.draw.polygon(surf, color, pts)
    else:
        pygame.draw.circle(surf, color, pos, r)

    if peg["flash"] > 0:
        peg["flash"] -= 1


def _buildPegs(width, height, peg_rows, peg_cols, peg_radius,
               peg_color, peg_colors, wall_pad, top_pad, bottom_pad):
    """Build staggered peg grid. Returns list of peg dicts."""
    pegs      = []
    rc        = _hex(peg_color)
    play_w    = width  - wall_pad * 2
    play_h    = height - top_pad - bottom_pad
    row_gap   = play_h / (peg_rows + 1)
    col_gap   = play_w / peg_cols

    for row in range(peg_rows):
        stagger    = col_gap / 2 if row % 2 == 1 else 0
        cols_this  = peg_cols - 1 if row % 2 == 1 else peg_cols
        for col in range(cols_this):
            x = wall_pad + stagger + col * col_gap + col_gap / 2
            y = top_pad  + (row + 1) * row_gap
            color = _hex(random.choice(peg_colors)) if peg_colors else rc
            pegs.append({
                "x": x, "y": y, "r": peg_radius,
                "color": color,
                "flash": 0,
                "flash_color": (255, 255, 255),
            })
    return pegs


def _buildSlots(width, height, slot_count, wall_pad, bottom_pad):
    """Build slot dividers and return list of slot x-ranges."""
    slot_w = (width - wall_pad * 2) / slot_count
    slots  = []
    for i in range(slot_count):
        x0 = wall_pad + i * slot_w
        x1 = x0 + slot_w
        slots.append({"x0": x0, "x1": x1, "count": 0})
    return slots


# ── ball-ball collision ────────────────────────────────────────────────────────

def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):
    n = len(balls)
    for i in range(n):
        for j in range(i+1, n):
            a, b  = balls[i], balls[j]
            if not a["active"] or not b["active"]: continue
            dx   = b["x"] - a["x"]
            dy   = b["y"] - a["y"]
            dist = math.hypot(dx, dy)
            md   = a["r"] + b["r"]
            if dist < md and dist > 0:
                overlap = (md - dist) / 2
                nx = dx / dist; ny = dy / dist
                a["x"] -= nx * overlap; a["y"] -= ny * overlap
                b["x"] += nx * overlap; b["y"] += ny * overlap
                dvx = a["vx"] - b["vx"]; dvy = a["vy"] - b["vy"]
                dot = dvx*nx + dvy*ny
                if dot > 0:
                    a["vx"] = (a["vx"] - dot*nx) * bounce
                    a["vy"] = (a["vy"] - dot*ny) * bounce
                    b["vx"] = (b["vx"] + dot*nx) * bounce
                    b["vy"] = (b["vy"] + dot*ny) * bounce
                if audio is not None:
                    from Games.collision_audio import log_ball_pair
                    log_ball_pair(audio, t, dvx, dvy)


def _makeBall(x, y, ball_radius, palette, speed_limit):
    color = _hex(random.choice(palette)) if palette else (
        random.randint(80,255), random.randint(80,255), random.randint(80,255))
    return {
        "x": x, "y": y,
        "vx": random.uniform(-1.5, 1.5),
        "vy": random.uniform(0, 2),
        "r":  ball_radius,
        "color": color,
        "flash": 0,
        "trail": [],
        "active": True,
        "settled": False,
    }


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    # output
    duration: int           = 15,
    output: Path            = None,
    fps: int                = 60,
    width: int              = 1080,
    height: int             = 1920,
    # spawn
    spawn_mode: str         = "continuous",  # "continuous" | "fixed"
    ball_count: int         = 30,
    spawn_rate: int         = 12,            # frames between spawns
    spawn_x: str            = "random",      # "random" | "center" | "spread"
    spawn_y: int            = None,
    # bottom
    bottom_mode: str        = "slots",       # "slots" | "open"
    slot_count: int         = 7,
    slot_color: str         = "#333333",
    slot_label: bool        = False,
    # pegs
    peg_rows: int           = 9,
    peg_cols: int           = 7,
    peg_radius: int         = 12,
    peg_color: str          = "#ffffff",
    peg_glow: bool          = False,
    peg_flash_on_hit: bool  = False,
    peg_shape: str          = "circle",      # "circle" | "diamond"
    peg_colors: list        = None,
    # balls
    ball_radius: int        = 14,
    ball_colors: list       = None,
    ball_glow: bool         = False,
    ball_trail: bool        = False,
    trail_length: int       = 10,
    ball_shine: bool        = True,
    ball_opacity: int       = 255,
    # physics
    gravity: float          = 0.4,
    bounce: float           = 0.55,
    friction: float         = 0.99,
    ball_collision: bool    = True,
    speed_limit: float      = 18.0,
    # hit effects
    on_hit_flash: bool      = False,
    on_hit_particles: bool  = False,
    particle_count: int     = 6,
    particle_speed: float   = 1.0,
    particle_colors: list   = None,
    # background
    bg_color: str           = "#0d0d0d",
    bg_color2: str          = None,
    bg_gradient_dir: str    = "vertical",
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"pinball_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width, height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    sc           = _hex(slot_color)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    # layout constants
    wall_pad    = 40
    top_pad     = int(height * 0.08)
    bottom_pad  = int(height * 0.15)
    floor_y     = height - bottom_pad

    # ── pre-build scene ───────────────────────────────────────────────────────
    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    pegs  = _buildPegs(width, height, peg_rows, peg_cols, peg_radius,
                       peg_color, peg_colors, wall_pad, top_pad, bottom_pad)
    slots = _buildSlots(width, height, slot_count, wall_pad, bottom_pad) \
            if bottom_mode == "slots" else []

    # spawn x positions
    _spawn_y = spawn_y or (top_pad // 2)
    if spawn_x == "center":
        _spawn_xs = [width // 2]
    elif spawn_x == "spread":
        _spawn_xs = [int(wall_pad + (i+1) * (width - wall_pad*2) / (ball_count+1))
                     for i in range(ball_count)]
    else:
        _spawn_xs = list(range(wall_pad + ball_radius, width - wall_pad - ball_radius))

    balls      = []
    particles  = []
    spawned    = 0
    frame_ctr  = 0

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            # ── background ────────────────────────────────────────────────
            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg, 255))

            # ── spawn balls ───────────────────────────────────────────────
            should_spawn = (frame % max(1, spawn_rate) == 0)
            if spawn_mode == "continuous" and should_spawn:
                sx = random.choice(_spawn_xs) if spawn_x == "random" else \
                     _spawn_xs[spawned % len(_spawn_xs)]
                balls.append(_makeBall(sx, _spawn_y, ball_radius, ball_colors, speed_limit))
                spawned += 1
            elif spawn_mode == "fixed" and spawned < ball_count and should_spawn:
                sx = random.choice(_spawn_xs) if spawn_x == "random" else \
                     _spawn_xs[spawned % len(_spawn_xs)]
                balls.append(_makeBall(sx, _spawn_y, ball_radius, ball_colors, speed_limit))
                spawned += 1

            # ── walls ─────────────────────────────────────────────────────
            # draw side walls
            pygame.draw.line(surface, (80,80,80), (wall_pad, top_pad), (wall_pad, height), 3)
            pygame.draw.line(surface, (80,80,80), (width-wall_pad, top_pad), (width-wall_pad, height), 3)

            # ── slots ─────────────────────────────────────────────────────
            if bottom_mode == "slots":
                # slot divider walls — balls fall BETWEEN these, not blocked by a floor
                for i in range(1, slot_count):
                    sx2 = int(wall_pad + i * (width - wall_pad*2) / slot_count)
                    pygame.draw.line(surface, sc, (sx2, floor_y), (sx2, height - 10), 4)
                # slot entry indicators (small triangles/caps at top of each divider)
                for i in range(1, slot_count):
                    sx2 = int(wall_pad + i * (width - wall_pad*2) / slot_count)
                    pygame.draw.circle(surface, sc, (sx2, floor_y), 6)
                # actual floor at very bottom
                pygame.draw.line(surface, sc, (wall_pad, height - 10), (width - wall_pad, height - 10), 4)

                if slot_label:
                    try:
                        font = pygame.font.SysFont("monospace", 28, bold=True)
                        for i, sl in enumerate(slots):
                            mx = int((sl["x0"] + sl["x1"]) / 2)
                            txt = font.render(str(sl["count"]), True, (200,200,200))
                            surface.blit(txt, (mx - txt.get_width()//2, floor_y + 10))
                    except Exception:
                        pass

            # ── pegs ──────────────────────────────────────────────────────
            for peg in pegs:
                _drawPeg(surface, peg, peg_shape, peg_glow)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface, particles)
                for p in particles:
                    p["x"] += p["vx"]; p["y"] += p["vy"]
                    p["vy"] += 0.15;   p["life"] -= 1
                particles = [p for p in particles if p["life"] > 0]

            # ── ball-ball collision ────────────────────────────────────────
            if ball_collision:
                _resolveBallCollisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)

            # ── physics + draw balls ───────────────────────────────────────
            for b in balls:
                if not b["active"]: continue

                # trail
                if ball_trail:
                    b["trail"].append((b["x"], b["y"], b["r"]))
                    if len(b["trail"]) > trail_length:
                        b["trail"].pop(0)
                    _drawTrail(surface, b["trail"], b["color"])

                # physics
                b["vy"] += gravity
                b["vx"] *= friction
                b["vy"] *= friction

                # speed cap
                spd = math.hypot(b["vx"], b["vy"])
                if spd > speed_limit:
                    b["vx"] = b["vx"] / spd * speed_limit
                    b["vy"] = b["vy"] / spd * speed_limit

                b["x"] += b["vx"]
                b["y"] += b["vy"]

                # wall bounce
                if b["x"] - b["r"] < wall_pad:
                    b["x"] = wall_pad + b["r"]
                    b["vx"] = abs(b["vx"]) * bounce
                    log_wall_from_ball(audio, frame / fps, b)
                elif b["x"] + b["r"] > width - wall_pad:
                    b["x"] = width - wall_pad - b["r"]
                    b["vx"] = -abs(b["vx"]) * bounce
                    log_wall_from_ball(audio, frame / fps, b)

                # floor / slots
                if bottom_mode == "slots":
                    actual_floor = height - 10
                    # ball hits the actual bottom floor
                    if b["y"] + b["r"] >= actual_floor:
                        if abs(b["vy"]) < 1.5 and abs(b["vx"]) < 1.5:
                            b["y"] = actual_floor - b["r"]
                            b["vy"] = 0; b["vx"] = 0
                            b["settled"] = True
                            # count in slot
                            for sl in slots:
                                if sl["x0"] <= b["x"] <= sl["x1"]:
                                    sl["count"] += 1
                                    break
                        else:
                            b["y"] = actual_floor - b["r"]
                            b["vy"] = -abs(b["vy"]) * bounce
                            log_wall_from_ball(audio, frame / fps, b)
                    # ball bounces off slot divider walls (only below floor_y)
                    if b["y"] > floor_y:
                        for i in range(1, slot_count):
                            div_x = wall_pad + i * (width - wall_pad*2) / slot_count
                            if abs(b["x"] - div_x) < b["r"]:
                                if b["x"] < div_x:
                                    b["x"] = div_x - b["r"]
                                    b["vx"] = -abs(b["vx"]) * bounce
                                else:
                                    b["x"] = div_x + b["r"]
                                    b["vx"] = abs(b["vx"]) * bounce
                                log_wall_from_ball(audio, frame / fps, b)
                elif bottom_mode == "open":
                    if b["y"] - b["r"] > height + 50:
                        b["active"] = False
                        continue

                # peg collision
                hit_peg = False
                for peg in pegs:
                    dx   = b["x"] - peg["x"]
                    dy   = b["y"] - peg["y"]
                    dist = math.hypot(dx, dy)
                    md   = b["r"] + peg["r"]
                    if dist < md and dist > 0:
                        nx = dx / dist; ny = dy / dist
                        # push out
                        b["x"] = peg["x"] + nx * md
                        b["y"] = peg["y"] + ny * md
                        # reflect
                        dot = b["vx"]*nx + b["vy"]*ny
                        b["vx"] = (b["vx"] - 2*dot*nx) * bounce
                        b["vy"] = (b["vy"] - 2*dot*ny) * bounce
                        # small random nudge so balls don't get stuck
                        b["vx"] += random.uniform(-0.3, 0.3)

                        if peg_flash_on_hit:
                            peg["flash"] = 5
                        if on_hit_flash:
                            b["flash"] = 5
                        if on_hit_particles:
                            particles += _spawnParticles(
                                b["x"], b["y"], b["color"], pcolors,
                                count=particle_count, speed_mult=particle_speed)
                        hit_peg = True
                        log_wall_from_ball(audio, frame / fps, b)
                        break  # one peg per frame

                # draw ball
                if ball_glow:
                    _drawGlow(surface, b["color"], (int(b["x"]), int(b["y"])), b["r"])

                pos        = (int(b["x"]), int(b["y"]))
                draw_color = _lighten(b["color"], 180) if b["flash"] > 0 else b["color"]

                if ball_opacity < 255:
                    _withAlpha(surface, draw_color, pos, b["r"], ball_opacity)
                else:
                    pygame.draw.circle(surface, draw_color, pos, b["r"])

                if ball_shine:
                    pygame.draw.circle(surface, (255,255,255),
                        (pos[0]-b["r"]//4, pos[1]-b["r"]//4), max(1, b["r"]//5))

                if b["flash"] > 0: b["flash"] -= 1

            # remove inactive balls in open mode
            if bottom_mode == "open":
                balls = [b for b in balls if b["active"]]

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))

            if frame % (fps*2) == 0:
                pct = frame*100//total_frames
                print(f"   Frame {frame}/{total_frames} ({pct}%) | balls: {len(balls)}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", str(fps),
            "-i", str(frames_dir/"frame_%06d.png"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "fast", "-crf", "18",
            str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)