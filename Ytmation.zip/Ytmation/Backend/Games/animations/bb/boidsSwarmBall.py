"""
Boids Swarm Ball — Flock + Predator
-------------------------------------
Many balls flock with cohesion, separation, and alignment inside a boundary.
A predator occasionally enters, chases the swarm, and removes boids on contact.

BOIDS:
    boid_count            : int   = 28
    perception_radius     : float = 90.0
    separation_radius     : float = 34.0
    max_speed             : float = 6.5
    max_force             : float = 0.18
    cohesion_weight       : float = 1.0
    separation_weight     : float = 1.4
    alignment_weight      : float = 1.0

PREDATOR:
    predator_enabled      : bool  = True
    predator_spawn_every  : int   = 240      — frames between predator spawns
    predator_duration     : int   = 180      — frames predator stays active
    predator_radius       : int   = 28
    predator_color        : str   = "#ff2222"
    predator_speed        : float = 9.0
    predator_chase_force  : float = 0.30
    eat_radius_mult       : float = 1.05

LOOK:
    boid_color            : str   = "#44ccff"
    boid_radius           : int   = 14
    boid_glow             : bool  = True
    boid_trail            : bool  = True
    trail_length          : int   = 12
    glow_layers           : int   = 3
    show_counts           : bool  = True

PHYSICS:
    bounce                : float = 0.98
    friction              : float = 0.995

SHAPE:
    shape                 : str   = "circle"
    circle_radius         : int   = None
    ring_color            : str   = "#ffffff"
    ring_width            : int   = 4
    ring_glow             : bool  = False
    ring_dash             : bool  = False
    ring_spin             : bool  = False
    ring_spin_speed       : float = 0.5

BACKGROUND:
    bg_color              : str   = "#0d0d0d"
    bg_color2             : str   = None
    bg_gradient_dir       : str   = "vertical"

OUTPUT:
    fps                   : int   = 60
    width                 : int   = 1080
    height                : int   = 1920
    duration              : int   = 22
"""

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


def _hex(h):
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _clamp_mag(vx, vy, limit):
    sp = math.hypot(vx, vy)
    if sp > limit and sp > 0:
        s = limit / sp
        return vx * s, vy * s
    return vx, vy


def _with_alpha_circle(surf, color, pos, r, alpha):
    import pygame

    if r <= 0 or alpha <= 0:
        return
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0] - r, pos[1] - r))


def _draw_glow(surf, color, pos, r, layers=3, strength=45):
    for i in range(layers, 0, -1):
        _with_alpha_circle(surf, color, pos, r + i * 5, int(strength / i))


def _gradient_surface(w, h, c1, c2, direction="vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (x, 0), (x, h))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_d = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max_d)
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                surf.set_at((x, y), (r, g, b))
    else:
        for y in range(h):
            t = y / max(1, h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (0, y), (w, y))
    return surf


_SHAPE_SIDES = {"triangle": 3, "diamond": 4, "pentagon": 5, "hexagon": 6}


def _shape_vertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [
        (
            cx + size * math.cos(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
            cy + size * math.sin(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
        )
        for i in range(sides)
    ]


def _closest_point_on_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-9)
    t = max(0.0, min(1.0, t))
    cx2 = ax + t * dx
    cy2 = ay + t * dy
    nx = px - cx2
    ny = py - cy2
    dist = math.hypot(nx, ny)
    if dist < 1e-6:
        nx, ny = -dy, dx
        dist = math.hypot(nx, ny)
    return cx2, cy2, nx / dist, ny / dist, dist


def _resolve_shape_collision(ball, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx, by, br = ball["x"], ball["y"], ball["r"]
    hit = False
    if shape == "circle":
        dx, dy = bx - cx, by - cy
        dist = math.hypot(dx, dy)
        md = size - br
        if dist > md and dist > 0:
            nx, ny = dx / dist, dy / dist
            ball["x"] = cx + nx * md
            ball["y"] = cy + ny * md
            dot = ball["vx"] * nx + ball["vy"] * ny
            ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
            ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
            hit = True
    elif shape == "square":
        half = size - br
        if bx < cx - half:
            ball["x"] = cx - half
            ball["vx"] = abs(ball["vx"]) * bounce
            hit = True
        elif bx > cx + half:
            ball["x"] = cx + half
            ball["vx"] = -abs(ball["vx"]) * bounce
            hit = True
        if by < cy - half:
            ball["y"] = cy - half
            ball["vy"] = abs(ball["vy"]) * bounce
            hit = True
        elif by > cy + half:
            ball["y"] = cy + half
            ball["vy"] = -abs(ball["vy"]) * bounce
            hit = True
    else:
        verts = _shape_vertices(shape, cx, cy, size, angle_offset)
        for i in range(len(verts)):
            ax, ay = verts[i]
            bx2, by2 = verts[(i + 1) % len(verts)]
            cpx, cpy, nx, ny, dist = _closest_point_on_segment(bx, by, ax, ay, bx2, by2)
            to_center_x = cx - cpx
            to_center_y = cy - cpy
            if nx * to_center_x + ny * to_center_y < 0:
                nx, ny = -nx, -ny
            if dist < br:
                overlap = br - dist
                ball["x"] += nx * overlap
                ball["y"] += ny * overlap
                dot = ball["vx"] * nx + ball["vy"] * ny
                if dot < 0:
                    ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
                    ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
                hit = True
    if hit and audio is not None:
        from Games.collision_audio import log_wall_from_ball
        log_wall_from_ball(audio, t, ball)
    return hit


def _draw_shape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame

    if shape == "circle":
        if dash:
            n = max(1, int(math.pi * size / 20))
            for i in range(n):
                a0 = (2 * math.pi / n) * i
                a1 = a0 + math.pi / n
                pts = []
                for s in range(11):
                    a = a0 + (a1 - a0) * s / 10
                    pts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
                if len(pts) > 1:
                    pygame.draw.lines(surf, color, False, pts, width)
        else:
            pygame.draw.circle(surf, color, (cx, cy), size, width)
        return
    if shape == "square":
        half = size
        pygame.draw.rect(surf, color, pygame.Rect(cx - half, cy - half, half * 2, half * 2), width)
        return
    verts = _shape_vertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x), int(y)) for x, y in verts], width)


def _limit_force(fx, fy, max_force):
    mag = math.hypot(fx, fy)
    if mag > max_force and mag > 0:
        s = max_force / mag
        return fx * s, fy * s
    return fx, fy


def _boids_forces(boid, neighbors, cx, cy, perception, sep_radius, coh_w, sep_w, ali_w, max_force):
    sep_x = sep_y = 0.0
    ali_x = ali_y = 0.0
    coh_x = coh_y = 0.0
    sep_n = ali_n = coh_n = 0

    for other in neighbors:
        if other is boid:
            continue
        dx = other["x"] - boid["x"]
        dy = other["y"] - boid["y"]
        d = math.hypot(dx, dy)
        if d <= 0 or d > perception:
            continue
        if d < sep_radius:
            sep_x -= dx / d
            sep_y -= dy / d
            sep_n += 1
        ali_x += other["vx"]
        ali_y += other["vy"]
        ali_n += 1
        coh_x += other["x"]
        coh_y += other["y"]
        coh_n += 1

    fx = fy = 0.0

    if sep_n > 0:
        fx += (sep_x / sep_n) * sep_w
        fy += (sep_y / sep_n) * sep_w

    if ali_n > 0:
        ali_x /= ali_n
        ali_y /= ali_n
        ali_x -= boid["vx"]
        ali_y -= boid["vy"]
        fx += ali_x * ali_w
        fy += ali_y * ali_w

    if coh_n > 0:
        coh_x = coh_x / coh_n - boid["x"]
        coh_y = coh_y / coh_n - boid["y"]
        fx += coh_x * 0.001 * coh_w
        fy += coh_y * 0.001 * coh_w

    # mild center bias keeps swarm in arena
    fx += (cx - boid["x"]) * 0.00015
    fy += (cy - boid["y"]) * 0.00015

    return _limit_force(fx, fy, max_force)


def _spawn_predator(cx, cy, cr, radius):
    ang = random.uniform(0, 2 * math.pi)
    dist = cr + radius + 20
    return {
        "x": cx + math.cos(ang) * dist * 0.95,
        "y": cy + math.sin(ang) * dist * 0.95,
        "vx": 0.0,
        "vy": 0.0,
        "r": radius,
        "life": 0,
    }


def run(
    duration=22,
    output=None,
    fps=60,
    width=1080,
    height=1920,
    boid_count=28,
    perception_radius=90.0,
    separation_radius=34.0,
    max_speed=6.5,
    max_force=0.18,
    cohesion_weight=1.0,
    separation_weight=1.4,
    alignment_weight=1.0,
    predator_enabled=True,
    predator_spawn_every=240,
    predator_duration=180,
    predator_radius=28,
    predator_color="#ff2222",
    predator_speed=9.0,
    predator_chase_force=0.30,
    eat_radius_mult=1.05,
    boid_color="#44ccff",
    boid_radius=14,
    boid_glow=True,
    boid_trail=True,
    trail_length=12,
    glow_layers=3,
    show_counts=True,
    bounce=0.98,
    friction=0.995,
    shape="circle",
    circle_radius=None,
    ring_color="#ffffff",
    ring_width=4,
    ring_glow=False,
    ring_dash=False,
    ring_spin=False,
    ring_spin_speed=0.5,
    bg_color="#0d0d0d",
    bg_color2=None,
    bg_gradient_dir="vertical",
    collision_audio: dict | None = None,
    **kwargs,
):
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = (shape or "circle").lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"boidsSwarmBall_{shape}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    total_frames = max(1, int(duration * fps))
    cx, cy = width // 2, height // 2
    cr = circle_radius or (min(width, height) // 2 - 80)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    rc = _hex(ring_color)
    c_boid = _hex(boid_color)
    c_pred = _hex(predator_color)
    grad_surf = _gradient_surface(width, height, bg1, bg2, bg_gradient_dir) if bg2 else None

    font = None
    if show_counts:
        try:
            font = pygame.font.SysFont("DejaVu Sans", 30)
        except Exception:
            font = None

    def spawn_boid():
        ang = random.uniform(0, 2 * math.pi)
        dist = random.uniform(0, cr * 0.7)
        return {
            "x": cx + math.cos(ang) * dist,
            "y": cy + math.sin(ang) * dist,
            "vx": random.uniform(-2, 2),
            "vy": random.uniform(-2, 2),
            "r": boid_radius,
            "trail": [],
        }

    boids = [spawn_boid() for _ in range(max(3, int(boid_count)))]
    predator = None
    spawn_timer = max(30, int(predator_spawn_every))
    angle_offset = 0.0
    eaten_total = 0

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg1, 255))

            if ring_glow:
                _draw_glow(surface, rc, (cx, cy), cr, layers=3)
            _draw_shape(surface, shape, rc, cx, cy, cr, ring_width, angle_offset, dash=ring_dash)

            # spawn predator occasionally
            if predator_enabled:
                if predator is None:
                    spawn_timer -= 1
                    if spawn_timer <= 0:
                        predator = _spawn_predator(cx, cy, cr, predator_radius)
                        predator["life"] = max(1, int(predator_duration))
                        spawn_timer = max(30, int(predator_spawn_every))
                else:
                    predator["life"] -= 1
                    if predator["life"] <= 0:
                        predator = None

            # boids flocking
            for b in boids:
                fx, fy = _boids_forces(
                    b,
                    boids,
                    cx,
                    cy,
                    perception_radius,
                    separation_radius,
                    cohesion_weight,
                    separation_weight,
                    alignment_weight,
                    max_force,
                )
                # flee from predator
                if predator is not None:
                    dx = b["x"] - predator["x"]
                    dy = b["y"] - predator["y"]
                    d = math.hypot(dx, dy) + 1e-9
                    if d < perception_radius * 1.4:
                        flee = (1.0 - d / (perception_radius * 1.4)) * max_force * 2.2
                        fx += (dx / d) * flee
                        fy += (dy / d) * flee

                b["vx"] += fx
                b["vy"] += fy
                b["vx"] *= friction
                b["vy"] *= friction
                b["vx"], b["vy"] = _clamp_mag(b["vx"], b["vy"], max_speed)
                b["x"] += b["vx"]
                b["y"] += b["vy"]
                _resolve_shape_collision(b, shape, cx, cy, cr, bounce, angle_offset, audio=audio if audio.enabled else None, t=frame / fps)

            # predator chase nearest boid
            if predator is not None and boids:
                best = None
                best_d2 = 1e18
                for b in boids:
                    dx = b["x"] - predator["x"]
                    dy = b["y"] - predator["y"]
                    d2 = dx * dx + dy * dy
                    if d2 < best_d2:
                        best_d2 = d2
                        best = b
                if best is not None:
                    d = math.sqrt(best_d2) + 1e-9
                    predator["vx"] += ((best["x"] - predator["x"]) / d) * predator_chase_force
                    predator["vy"] += ((best["y"] - predator["y"]) / d) * predator_chase_force
                predator["vx"] *= friction
                predator["vy"] *= friction
                predator["vx"], predator["vy"] = _clamp_mag(predator["vx"], predator["vy"], predator_speed)
                predator["x"] += predator["vx"]
                predator["y"] += predator["vy"]
                _resolve_shape_collision(predator, shape, cx, cy, cr, bounce, angle_offset, audio=audio if audio.enabled else None, t=frame / fps)

                # eat boids
                eat_r = (predator["r"] + boid_radius) * eat_radius_mult
                eat_r2 = eat_r * eat_r
                alive = []
                for b in boids:
                    dx = b["x"] - predator["x"]
                    dy = b["y"] - predator["y"]
                    if dx * dx + dy * dy <= eat_r2:
                        eaten_total += 1
                        continue
                    alive.append(b)
                boids = alive

            # draw boids
            for b in boids:
                pos = (int(b["x"]), int(b["y"]))
                if boid_trail:
                    b["trail"].append((b["x"], b["y"], b["r"]))
                    if len(b["trail"]) > trail_length:
                        b["trail"].pop(0)
                    ntr = len(b["trail"])
                    for ti, (tx, ty, tr) in enumerate(b["trail"]):
                        alpha = int(130 * (ti / max(1, ntr)))
                        rad = max(2, int(tr * 0.5 * (ti / max(1, ntr))))
                        _with_alpha_circle(surface, c_boid, (int(tx), int(ty)), rad, alpha)
                if boid_glow:
                    _draw_glow(surface, c_boid, pos, b["r"], layers=glow_layers)
                pygame.draw.circle(surface, c_boid, pos, b["r"])

            if predator is not None:
                ppos = (int(predator["x"]), int(predator["y"]))
                _draw_glow(surface, c_pred, ppos, predator["r"], layers=5, strength=70)
                pygame.draw.circle(surface, c_pred, ppos, predator["r"])
                pygame.draw.circle(surface, (255, 80, 80), ppos, max(2, predator["r"] // 3), 2)

            if show_counts and font:
                pred_txt = "ON" if predator is not None else "off"
                hud = f"Boids:{len(boids)}  Eaten:{eaten_total}  Pred:{pred_txt}"
                s = font.render(hud, True, (235, 235, 235))
                surface.blit(s, (30, 25))

            if ring_spin:
                angle_offset += math.radians(ring_spin_speed)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%) | boids:{len(boids)}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-framerate",
                str(fps),
                "-i",
                str(frames_dir / "frame_%06d.png"),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "fast",
                "-crf",
                "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)
