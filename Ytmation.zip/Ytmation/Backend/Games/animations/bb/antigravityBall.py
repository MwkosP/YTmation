"""
Antigravity Ball — Gravity Flip on Bounce Count
-------------------------------------------------
A ball bounces inside a boundary shape.
Gravity direction reverses every N wall bounces.

CORE:
    flips_every_bounces   : int   = 5        — reverse gravity after this many collisions
    start_gravity_sign    : int   = 1        — 1 or -1

BALL:
    ball_radius           : int   = 26
    ball_color            : str   = "#00ffff"
    ball_glow             : bool  = True
    ball_trail            : bool  = True
    trail_length          : int   = 22
    glow_layers           : int   = 5
    ball_speed_min        : float = 3.0
    ball_speed_max        : float = 7.0

PHYSICS:
    gravity               : float = 0.30
    bounce                : float = 0.985
    friction              : float = 0.998
    speed_limit           : float = 14.0
    center_pull           : float = 0.0

LOOK:
    show_flip_indicator   : bool  = True
    indicator_color       : str   = "#ffffff"
    indicator_alpha       : int   = 150

SHAPE:
    shape                 : str   = "circle" — "circle","square","triangle","pentagon","hexagon","diamond"
    circle_radius         : int   = None
    ring_color            : str   = "#ffffff"
    ring_width            : int   = 4
    ring_glow             : bool  = False
    ring_dash             : bool  = False
    ring_spin             : bool  = False
    ring_spin_speed       : float = 0.5

BACKGROUND:
    bg_color              : str   = "#0d0d0d"
    bg_color2             : str   = None
    bg_gradient_dir       : str   = "vertical"

OUTPUT:
    fps                   : int   = 60
    width                 : int   = 1080
    height                : int   = 1920
    duration              : int   = 16
"""

import math
import random
import tempfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


def _hex(h):
    h = (h or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _with_alpha_circle(surf, color, pos, r, alpha):
    import pygame

    if r <= 0 or alpha <= 0:
        return
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0] - r, pos[1] - r))


def _draw_glow(surf, color, pos, r, layers=5):
    for i in range(layers, 0, -1):
        _with_alpha_circle(surf, color, pos, r + i * 7, int(60 / i))


def _gradient_surface(w, h, c1, c2, direction="vertical"):
    import pygame

    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / max(1, w - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (x, 0), (x, h))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_d = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x - cx, y - cy) / max_d)
                r = int(c1[0] + (c2[0] - c1[0]) * t)
                g = int(c1[1] + (c2[1] - c1[1]) * t)
                b = int(c1[2] + (c2[2] - c1[2]) * t)
                surf.set_at((x, y), (r, g, b))
    else:
        for y in range(h):
            t = y / max(1, h - 1)
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            pygame.draw.line(surf, (r, g, b), (0, y), (w, y))
    return surf


_SHAPE_SIDES = {"triangle": 3, "diamond": 4, "pentagon": 5, "hexagon": 6}


def _shape_vertices(shape, cx, cy, size, angle_offset=0.0):
    sides = _SHAPE_SIDES.get(shape, 6)
    return [
        (
            cx + size * math.cos(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
            cy + size * math.sin(angle_offset + 2 * math.pi * i / sides - math.pi / 2),
        )
        for i in range(sides)
    ]


def _closest_point_on_segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-9)
    t = max(0.0, min(1.0, t))
    cx2 = ax + t * dx
    cy2 = ay + t * dy
    nx = px - cx2
    ny = py - cy2
    dist = math.hypot(nx, ny)
    if dist < 1e-6:
        nx, ny = -dy, dx
        dist = math.hypot(nx, ny)
    return cx2, cy2, nx / dist, ny / dist, dist


def _resolve_shape_collision(ball, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    bx, by, br = ball["x"], ball["y"], ball["r"]
    hit = False
    if shape == "circle":
        dx, dy = bx - cx, by - cy
        dist = math.hypot(dx, dy)
        md = size - br
        if dist > md and dist > 0:
            nx, ny = dx / dist, dy / dist
            ball["x"] = cx + nx * md
            ball["y"] = cy + ny * md
            dot = ball["vx"] * nx + ball["vy"] * ny
            ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
            ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
            hit = True
    elif shape == "square":
        half = size - br
        if bx < cx - half:
            ball["x"] = cx - half
            ball["vx"] = abs(ball["vx"]) * bounce
            hit = True
        elif bx > cx + half:
            ball["x"] = cx + half
            ball["vx"] = -abs(ball["vx"]) * bounce
            hit = True
        if by < cy - half:
            ball["y"] = cy - half
            ball["vy"] = abs(ball["vy"]) * bounce
            hit = True
        elif by > cy + half:
            ball["y"] = cy + half
            ball["vy"] = -abs(ball["vy"]) * bounce
            hit = True
    else:
        verts = _shape_vertices(shape, cx, cy, size, angle_offset)
        for i in range(len(verts)):
            ax, ay = verts[i]
            bx2, by2 = verts[(i + 1) % len(verts)]
            cpx, cpy, nx, ny, dist = _closest_point_on_segment(bx, by, ax, ay, bx2, by2)
            to_center_x = cx - cpx
            to_center_y = cy - cpy
            if nx * to_center_x + ny * to_center_y < 0:
                nx, ny = -nx, -ny
            if dist < br:
                overlap = br - dist
                ball["x"] += nx * overlap
                ball["y"] += ny * overlap
                dot = ball["vx"] * nx + ball["vy"] * ny
                if dot < 0:
                    ball["vx"] = (ball["vx"] - 2 * dot * nx) * bounce
                    ball["vy"] = (ball["vy"] - 2 * dot * ny) * bounce
                hit = True
    if hit and audio is not None:
        from Games.collision_audio import log_wall_from_ball
        log_wall_from_ball(audio, t, ball)
    return hit


def _draw_shape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame

    if shape == "circle":
        if dash:
            n = max(1, int(math.pi * size / 20))
            for i in range(n):
                a0 = (2 * math.pi / n) * i
                a1 = a0 + math.pi / n
                pts = []
                for s in range(11):
                    a = a0 + (a1 - a0) * s / 10
                    pts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
                if len(pts) > 1:
                    pygame.draw.lines(surf, color, False, pts, width)
        else:
            pygame.draw.circle(surf, color, (cx, cy), size, width)
        return
    if shape == "square":
        half = size
        pygame.draw.rect(surf, color, pygame.Rect(cx - half, cy - half, half * 2, half * 2), width)
        return
    verts = _shape_vertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x), int(y)) for x, y in verts], width)


def run(
    duration=16,
    output=None,
    fps=60,
    width=1080,
    height=1920,
    flips_every_bounces=5,
    start_gravity_sign=1,
    ball_radius=26,
    ball_color="#00ffff",
    ball_glow=True,
    ball_trail=True,
    trail_length=22,
    glow_layers=5,
    ball_speed_min=3.0,
    ball_speed_max=7.0,
    gravity=0.30,
    bounce=0.985,
    friction=0.998,
    speed_limit=14.0,
    center_pull=0.0,
    show_flip_indicator=True,
    indicator_color="#ffffff",
    indicator_alpha=150,
    shape="circle",
    circle_radius=None,
    ring_color="#ffffff",
    ring_width=4,
    ring_glow=False,
    ring_dash=False,
    ring_spin=False,
    ring_spin_speed=0.5,
    bg_color="#0d0d0d",
    bg_color2=None,
    bg_gradient_dir="vertical",
    collision_audio: dict | None = None,
    **kwargs,
):
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape = (shape or "circle").lower().strip()
    flips_every_bounces = max(1, int(flips_every_bounces))
    g_sign = 1 if int(start_gravity_sign) >= 0 else -1

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"antigravityBall_{shape}_{stamp}.mp4"

    pygame.init()
    surface = pygame.Surface((width, height), pygame.SRCALPHA)
    total_frames = max(1, int(duration * fps))
    cx, cy = width // 2, height // 2
    cr = circle_radius or (min(width, height) // 2 - 80)

    bg1 = _hex(bg_color)
    bg2 = _hex(bg_color2) if bg_color2 else None
    rc = _hex(ring_color)
    bc = _hex(ball_color)
    ic = _hex(indicator_color)
    grad_surf = _gradient_surface(width, height, bg1, bg2, bg_gradient_dir) if bg2 else None

    ball = {
        "x": cx + random.uniform(-cr * 0.45, cr * 0.45),
        "y": cy + random.uniform(-cr * 0.45, cr * 0.45),
        "vx": random.choice([-1, 1]) * random.uniform(ball_speed_min, ball_speed_max),
        "vy": random.choice([-1, 1]) * random.uniform(ball_speed_min, ball_speed_max),
        "r": ball_radius,
        "trail": [],
    }

    angle_offset = 0.0
    bounce_count = 0

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            if grad_surf:
                surface.blit(grad_surf, (0, 0))
            else:
                surface.fill((*bg1, 255))

            if ring_glow:
                _draw_glow(surface, rc, (cx, cy), cr, layers=3)
            _draw_shape(surface, shape, rc, cx, cy, cr, ring_width, angle_offset, dash=ring_dash)

            if show_flip_indicator:
                isurf = pygame.Surface((width, height), pygame.SRCALPHA)
                # up arrow if gravity negative (pull up), down arrow if positive
                d = -1 if g_sign < 0 else 1
                y0 = cy - int(cr * 0.78 * d)
                y1 = cy - int(cr * 0.52 * d)
                pygame.draw.line(isurf, (*ic, max(0, min(255, int(indicator_alpha)))), (cx, y0), (cx, y1), 4)
                head = 16
                if d > 0:
                    pts = [(cx, y1 + head), (cx - head // 2, y1), (cx + head // 2, y1)]
                else:
                    pts = [(cx, y1 - head), (cx - head // 2, y1), (cx + head // 2, y1)]
                pygame.draw.polygon(isurf, (*ic, max(0, min(255, int(indicator_alpha)))), pts)
                surface.blit(isurf, (0, 0))

            if center_pull > 0:
                ball["vx"] += (cx - ball["x"]) * center_pull * 0.001
                ball["vy"] += (cy - ball["y"]) * center_pull * 0.001

            ball["vy"] += gravity * g_sign
            ball["vx"] *= friction
            ball["vy"] *= friction

            sp = math.hypot(ball["vx"], ball["vy"])
            if sp > speed_limit:
                s = speed_limit / sp
                ball["vx"] *= s
                ball["vy"] *= s

            ball["x"] += ball["vx"]
            ball["y"] += ball["vy"]

            hit = _resolve_shape_collision(ball, shape, cx, cy, cr, bounce, angle_offset, audio=audio if audio.enabled else None, t=frame / fps)
            if hit:
                bounce_count += 1
                if bounce_count % flips_every_bounces == 0:
                    g_sign *= -1

            if ball_trail:
                ball["trail"].append((ball["x"], ball["y"], ball["r"]))
                if len(ball["trail"]) > trail_length:
                    ball["trail"].pop(0)
                n = len(ball["trail"])
                for i, (tx, ty, tr) in enumerate(ball["trail"]):
                    alpha = int(160 * (i / max(1, n)))
                    rad = max(2, int(tr * 0.62 * (i / max(1, n))))
                    _with_alpha_circle(surface, bc, (int(tx), int(ty)), rad, alpha)

            pos = (int(ball["x"]), int(ball["y"]))
            if ball_glow:
                _draw_glow(surface, bc, pos, ball["r"], layers=glow_layers)
            pygame.draw.circle(surface, bc, pos, ball["r"])
            pygame.draw.circle(surface, (255, 255, 255), (pos[0] - ball["r"] // 4, pos[1] - ball["r"] // 4), max(1, ball["r"] // 5))

            if ring_spin:
                angle_offset += math.radians(ring_spin_speed)

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(
                    f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%) "
                    f"| bounces:{bounce_count} g:{'down' if g_sign>0 else 'up'}"
                )

        print(f"   Encoding {total_frames} frames...")
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-framerate",
                str(fps),
                "-i",
                str(frames_dir / "frame_%06d.png"),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-preset",
                "fast",
                "-crf",
                "18",
                str(output),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)

