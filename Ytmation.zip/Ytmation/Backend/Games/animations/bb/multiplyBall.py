"""
Multiply Ball — Full Customization
------------------------------------
A ball bounces inside a shape. Every time any ball touches the wall,
it spawns N new balls. Original always survives. Ball-ball collision included.

CORE:
    multiply_count       : int   = 1       — new balls spawned per wall hit
    max_balls            : int   = 50      — cap before end_behavior triggers
    end_behavior         : str   = "loop"  — "stop" | "loop"
    loop_count           : int   = 0       — max loops (0 = infinite)

SPAWN STYLE:
    spawn_style          : str   = "reflect" — how new balls are born:
                                   "reflect"  — mirrors the hitting ball's velocity
                                   "random"   — random direction
                                   "burst"    — evenly spread in all directions
    spawn_speed_mult     : float = 1.0     — speed of new balls relative to parent

SHAPE:
    shape                : str   = "circle"
    shape_radius         : int   = None
    ring_color           : str   = "#ffffff"
    ring_width           : int   = 5
    ring_glow            : bool  = False
    ring_flash_on_hit    : bool  = False
    ring_spin            : bool  = False
    ring_spin_speed      : float = 0.5
    ring_double          : bool  = False
    ring_double_gap      : int   = 20
    ring_dash            : bool  = False

BALLS:
    ball_radius          : int   = 28
    ball_color           : str   = None
    randomize_color      : bool  = True    — each new ball gets a random color
    ball_glow            : bool  = True
    ball_trail           : bool  = False
    trail_length         : int   = 10
    ball_shine           : bool  = True
    ball_opacity         : int   = 255
    ball_speed           : float = 7.0

HIT EFFECTS:
    on_hit_flash         : bool  = True
    on_hit_particles     : bool  = False
    on_hit_ring_pulse    : bool  = False
    particle_count       : int   = 8
    particle_speed       : float = 1.2
    particle_colors      : list  = None
    bg_pulse_on_hit      : bool  = False

PHYSICS:
    gravity              : float = 0.0
    bounce               : float = 1.0
    friction             : float = 1.0

BACKGROUND:
    bg_color             : str   = "#0d0d0d"
    bg_color2            : str   = None
    bg_gradient_dir      : str   = "vertical"
    bg_image             : str   = None
    bg_image_alpha       : int   = 255

OUTPUT:
    fps                  : int   = 60
    width                : int   = 1080
    height               : int   = 1920
    duration             : int   = 15
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*6, int(55/i))

def _drawShapeGlow(surf, color, cx, cy, size, shape, angle_offset, layers=3):
    import pygame
    for i in range(layers, 0, -1):
        gs=size+i*8; alpha=int(50/i); gw=max(2,i*3)
        s=pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        gc=(*color[:3], alpha)
        if shape=="circle": pygame.draw.circle(s,gc,(cx,cy),gs,gw)
        elif shape=="square": pygame.draw.rect(s,gc,pygame.Rect(cx-gs,cy-gs,gs*2,gs*2),gw)
        else:
            verts=_shapeVertices(shape,cx,cy,gs,angle_offset)
            pygame.draw.polygon(s,gc,[(int(x),int(y)) for x,y in verts],gw)
        surf.blit(s,(0,0))

def _drawTrail(surf, trail, color):
    n=len(trail)
    if n==0: return
    for i,(tx,ty,tr) in enumerate(trail):
        alpha=int(160*(i/n)); rad=max(2,int(tr*0.7*(i/n)))
        _withAlpha(surf,color,(int(tx),int(ty)),rad,alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha=int(255*(p["life"]/p["max_life"]))
        r=max(1,int(p["r"]*(p["life"]/p["max_life"])))
        _withAlpha(surf,p["color"],(int(p["x"]),int(p["y"])),r,alpha)

def _spawnParticles(x, y, color, pcolors, count=8, speed_mult=1.0):
    out=[]
    for _ in range(count):
        angle=random.uniform(0,2*math.pi); speed=random.uniform(2,8)*speed_mult
        c=_hex(random.choice(pcolors)) if pcolors else color
        out.append({"x":x,"y":y,"vx":math.cos(angle)*speed,"vy":math.sin(angle)*speed,
                    "r":random.randint(3,8),"color":c,"life":random.randint(10,25),"max_life":25})
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf=pygame.Surface((w,h))
    if direction=="horizontal":
        for x in range(w):
            t=x/w
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(x,0),(x,h))
    elif direction=="radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf

def _loadImage(path, size):
    import pygame
    img=pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img,size)


# ── shape helpers ──────────────────────────────────────────────────────────────

_SHAPE_SIDES={"triangle":3,"diamond":4,"pentagon":5,"hexagon":6}

def _shapeVertices(shape, cx, cy, size, angle_offset=0.0):
    sides=_SHAPE_SIDES.get(shape,6)
    return [(cx+size*math.cos(angle_offset+2*math.pi*i/sides-math.pi/2),
             cy+size*math.sin(angle_offset+2*math.pi*i/sides-math.pi/2))
            for i in range(sides)]

def _drawShape(surf, shape, color, cx, cy, size, width, angle_offset=0.0, dash=False):
    import pygame
    if size<=0: return
    if shape=="circle": pygame.draw.circle(surf,color,(cx,cy),int(size),width)
    elif shape=="square":
        s=int(size); pygame.draw.rect(surf,color,pygame.Rect(cx-s,cy-s,s*2,s*2),width)
    else:
        verts=_shapeVertices(shape,cx,cy,size,angle_offset)
        pygame.draw.polygon(surf,color,[(int(x),int(y)) for x,y in verts],width)

def _closestPointOnSegment(px,py,ax,ay,bx,by):
    dx,dy=bx-ax,by-ay
    t=max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy+1e-9)))
    cx2,cy2=ax+t*dx,ay+t*dy; nx,ny=px-cx2,py-cy2
    dist=math.hypot(nx,ny)
    if dist<1e-6: nx,ny,dist=-dy,dx,math.hypot(-dy,dx)
    return cx2,cy2,nx/dist,ny/dist,dist

def _resolveShapeCollision(ball, br, shape, cx, cy, size, bounce, angle_offset=0.0, audio=None, t: float = 0.0):
    """Returns (hit: bool, wall_normal: (nx,ny))"""
    bx,by=ball["x"],ball["y"]
    if shape=="circle":
        dx,dy=bx-cx,by-cy; dist=math.hypot(dx,dy); md=size-br
        if dist>md:
            nx,ny=dx/dist,dy/dist
            ball["x"]=cx+nx*md; ball["y"]=cy+ny*md
            dot=ball["vx"]*nx+ball["vy"]*ny
            ball["vx"]=(ball["vx"]-2*dot*nx)*bounce
            ball["vy"]=(ball["vy"]-2*dot*ny)*bounce
            return True,(nx,ny)
        return False,(0,0)
    elif shape=="square":
        half=size-br; hit=False; nx,ny=0.0,0.0
        if bx<cx-half:   ball["x"]=cx-half; ball["vx"]=abs(ball["vx"])*bounce;  nx=-1; hit=True
        elif bx>cx+half: ball["x"]=cx+half; ball["vx"]=-abs(ball["vx"])*bounce; nx=1;  hit=True
        if by<cy-half:   ball["y"]=cy-half; ball["vy"]=abs(ball["vy"])*bounce;  ny=-1; hit=True
        elif by>cy+half: ball["y"]=cy+half; ball["vy"]=-abs(ball["vy"])*bounce; ny=1;  hit=True
        return hit,(nx,ny)
    else:
        verts=_shapeVertices(shape,cx,cy,size,angle_offset)
        n=len(verts); hit=False; best_nx,best_ny=0.0,0.0; best_dist=1e9
        for i in range(n):
            ax,ay=verts[i]; bvx,bvy=verts[(i+1)%n]
            cpx,cpy,enx,eny,dist=_closestPointOnSegment(bx,by,ax,ay,bvx,bvy)
            tcx,tcy=cx-cpx,cy-cpy
            if enx*tcx+eny*tcy<0: enx,eny=-enx,-eny
            if dist<br:
                ball["x"]+=enx*(br-dist); ball["y"]+=eny*(br-dist)
                dot=ball["vx"]*enx+ball["vy"]*eny
                if dot<0:
                    ball["vx"]=(ball["vx"]-2*dot*enx)*bounce
                    ball["vy"]=(ball["vy"]-2*dot*eny)*bounce
                if dist<best_dist: best_dist=dist; best_nx,best_ny=enx,eny
                hit=True
        return hit,(best_nx,best_ny)


# ── ball-ball collision ────────────────────────────────────────────────────────

def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):
    n=len(balls)
    for i in range(n):
        for j in range(i+1,n):
            a,b=balls[i],balls[j]
            dx=b["x"]-a["x"]; dy=b["y"]-a["y"]
            dist=math.hypot(dx,dy); md=a["r"]+b["r"]
            if dist<md and dist>0:
                overlap=(md-dist)/2; nx=dx/dist; ny=dy/dist
                a["x"]-=nx*overlap; a["y"]-=ny*overlap
                b["x"]+=nx*overlap; b["y"]+=ny*overlap
                dvx=a["vx"]-b["vx"]; dvy=a["vy"]-b["vy"]
                dot=dvx*nx+dvy*ny
                if dot>0:
                    a["vx"]=(a["vx"]-dot*nx)*bounce; a["vy"]=(a["vy"]-dot*ny)*bounce
                    b["vx"]=(b["vx"]+dot*nx)*bounce; b["vy"]=(b["vy"]+dot*ny)*bounce


def _makeBall(x, y, vx, vy, r, color):
    return {"x":float(x),"y":float(y),"vx":float(vx),"vy":float(vy),
            "r":r,"color":color,"flash":0,"trail":[]}

def _randomColor():
    return (random.randint(80,255),random.randint(80,255),random.randint(80,255))


# ── spawn helpers ──────────────────────────────────────────────────────────────

def _spawnNewBalls(parent, count, style, speed, randomize_color, cx, cy):
    """Generate `count` new balls based on spawn_style."""
    new = []
    px,py = parent["x"],parent["y"]
    pcolor = parent["color"]

    for i in range(count):
        color = _randomColor() if randomize_color else pcolor

        if style == "reflect":
            # mirror parent velocity with small random nudge
            angle = math.atan2(parent["vy"], parent["vx"])
            angle += random.uniform(-math.pi/4, math.pi/4)
            vx = math.cos(angle)*speed
            vy = math.sin(angle)*speed

        elif style == "burst":
            # evenly spread around full circle
            angle = (2*math.pi*i/count) + random.uniform(-0.1,0.1)
            vx = math.cos(angle)*speed
            vy = math.sin(angle)*speed

        else:  # random
            angle = random.uniform(0, 2*math.pi)
            vx = math.cos(angle)*speed
            vy = math.sin(angle)*speed

        new.append(_makeBall(px, py, vx, vy, parent["r"], color))
    return new


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    duration: int               = 15,
    output: Path                = None,
    fps: int                    = 60,
    width: int                  = 1080,
    height: int                 = 1920,
    # core
    multiply_count: int         = 1,
    max_balls: int              = 50,
    end_behavior: str           = "loop",
    loop_count: int             = 0,
    # spawn style
    spawn_style: str            = "random",   # reflect | random | burst
    spawn_speed_mult: float     = 1.0,
    # shape
    shape: str                  = "circle",
    shape_radius: int           = None,
    ring_color: str             = "#ffffff",
    ring_width: int             = 5,
    ring_glow: bool             = False,
    ring_flash_on_hit: bool     = False,
    ring_spin: bool             = False,
    ring_spin_speed: float      = 0.5,
    ring_double: bool           = False,
    ring_double_gap: int        = 20,
    ring_dash: bool             = False,
    # balls
    ball_radius: int            = 28,
    ball_color: str             = None,
    randomize_color: bool       = True,
    ball_glow: bool             = True,
    ball_trail: bool            = False,
    trail_length: int           = 10,
    ball_shine: bool            = True,
    ball_opacity: int           = 255,
    ball_speed: float           = 7.0,
    # hit effects
    on_hit_flash: bool          = True,
    on_hit_particles: bool      = False,
    on_hit_ring_pulse: bool     = False,
    particle_count: int         = 8,
    particle_speed: float       = 1.2,
    particle_colors: list       = None,
    bg_pulse_on_hit: bool       = False,
    # physics
    gravity: float              = 0.0,
    bounce: float               = 1.0,
    friction: float             = 1.0,
    # background
    bg_color: str               = "#0d0d0d",
    bg_color2: str              = None,
    bg_gradient_dir: str        = "vertical",
    bg_image: str               = None,
    bg_image_alpha: int         = 255,
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER","dummy")
    os.environ.setdefault("SDL_AUDIODRIVER","dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    shape       = shape.lower().strip()
    spawn_style = spawn_style.lower().strip()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"multiplyBall_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width,height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    rc           = _hex(ring_color)
    pcolors      = particle_colors or None
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    cr = shape_radius or (min(width,height)//2 - 80)

    start_color = _hex(ball_color) if ball_color else _randomColor()
    child_speed = ball_speed * spawn_speed_mult

    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image,(width,height))
        if bg_image_alpha<255: raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    def _resetBalls():
        angle = random.uniform(0, 2*math.pi)
        return [_makeBall(cx, cy,
                          math.cos(angle)*ball_speed,
                          math.sin(angle)*ball_speed,
                          ball_radius, start_color)]

    balls       = _resetBalls()
    particles   = []
    ring_flash  = 0
    ring_pulse  = 0
    bg_flash    = 0
    shape_angle = 0.0
    loops_done  = 0
    done        = False

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                pygame.image.save(surface, str(frames_dir/f"frame_{frame:06d}.png"))
                continue

            if ring_spin:
                shape_angle += math.radians(ring_spin_speed)

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255)); surface.blit(bg_img_surf,(0,0))
            elif grad_surf:
                surface.blit(grad_surf,(0,0))
            else:
                fa=min(bg_flash*8,40)
                surface.fill((min(255,bg[0]+fa),min(255,bg[1]+fa),min(255,bg[2]+fa),255))
            if bg_flash>0: bg_flash-=1

            # ── ring ──────────────────────────────────────────────────────
            cur_rc  = _lighten(rc,min(ring_flash*15,120)) if ring_flash>0 else rc
            pulse_r = cr+int(ring_pulse)

            if ring_glow:
                _drawShapeGlow(surface,cur_rc,cx,cy,pulse_r,shape,shape_angle)
            _drawShape(surface,shape,cur_rc,cx,cy,pulse_r,ring_width,shape_angle,dash=ring_dash)
            if ring_double:
                inner=max(10,pulse_r-ring_double_gap)
                _drawShape(surface,shape,(*cur_rc,90),cx,cy,inner,max(1,ring_width-1),shape_angle)

            if ring_flash>0: ring_flash-=1
            if ring_pulse>0: ring_pulse=max(0,ring_pulse-2)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface,particles)
                for p in particles:
                    p["x"]+=p["vx"]; p["y"]+=p["vy"]; p["vy"]+=0.2; p["life"]-=1
                particles=[p for p in particles if p["life"]>0]

            # ── ball-ball collision ────────────────────────────────────────
            _resolveBallCollisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)

            # ── physics + multiply ────────────────────────────────────────
            new_balls = []
            for b in balls:
                b["vy"]+=gravity; b["vx"]*=friction; b["vy"]*=friction
                b["x"]+=b["vx"]; b["y"]+=b["vy"]

                # maintain speed
                spd=math.hypot(b["vx"],b["vy"])
                if spd>0:
                    b["vx"]=b["vx"]/spd*ball_speed
                    b["vy"]=b["vy"]/spd*ball_speed

                if ball_trail:
                    b["trail"].append((b["x"],b["y"],b["r"]))
                    if len(b["trail"])>trail_length: b["trail"].pop(0)

                hit,(nx,ny) = _resolveShapeCollision(
                    b, b["r"], shape, cx, cy, cr, bounce, shape_angle)
                if hit:
                    log_wall_from_ball(audio, frame / fps, ball)

                if hit and len(balls)+len(new_balls) < max_balls:
                    # spawn new balls — parent survives
                    spawnable = min(multiply_count,
                                    max_balls - len(balls) - len(new_balls))
                    if spawnable > 0:
                        new_balls += _spawnNewBalls(
                            b, spawnable, spawn_style,
                            child_speed, randomize_color, cx, cy)

                    if on_hit_flash:      b["flash"]  = 6
                    if ring_flash_on_hit: ring_flash  = 6
                    if on_hit_ring_pulse: ring_pulse  = 18
                    if bg_pulse_on_hit:   bg_flash    = 4
                    if on_hit_particles:
                        particles += _spawnParticles(
                            b["x"],b["y"],b["color"],pcolors,
                            count=particle_count,speed_mult=particle_speed)

            balls += new_balls

            # ── check max_balls ───────────────────────────────────────────
            if len(balls) >= max_balls:
                loops_done += 1
                print(f"   Max balls ({max_balls}) reached at frame {frame}!")
                if end_behavior=="loop" and (loop_count==0 or loops_done<loop_count):
                    balls = _resetBalls()
                else:
                    done = True

            # ── draw ──────────────────────────────────────────────────────
            for b in balls:
                pos=(int(b["x"]),int(b["y"])); r_int=max(1,int(b["r"]))
                draw_color=_lighten(b["color"],180) if b["flash"]>0 else b["color"]

                if ball_trail: _drawTrail(surface,b["trail"],b["color"])
                if ball_glow:  _drawGlow(surface,draw_color,pos,r_int)

                if ball_opacity<255:
                    _withAlpha(surface,draw_color,pos,r_int,ball_opacity)
                else:
                    pygame.draw.circle(surface,draw_color,pos,r_int)

                if ball_shine and r_int>6:
                    pygame.draw.circle(surface,(255,255,255),
                        (pos[0]-r_int//4,pos[1]-r_int//4),max(1,r_int//5))

                if b["flash"]>0: b["flash"]-=1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))

            if frame%(fps*2)==0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| balls: {len(balls)} | loops: {loops_done}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg","-y","-framerate",str(fps),
            "-i",str(frames_dir/"frame_%06d.png"),
            "-c:v","libx264","-pix_fmt","yuv420p",
            "-preset","fast","-crf","18",str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration)
    return output