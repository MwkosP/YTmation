"""
Bouncing Balls Inside Shape — Full Customization
-------------------------------------------------
Every visual, physics, and asset parameter is exposed.

SHAPE:
    shape            : str   = "circle"  — "circle", "square", "triangle", "hexagon", "pentagon", "diamond"

PHYSICS:
    gravity          : float = 0.4       — downward pull per frame
    bounce           : float = 0.92      — energy kept on wall hit (0-1)
    friction         : float = 1.0       — air resistance (0.99=heavy, 1.0=none)
    magnetic_center  : float = 0.0       — pull toward center (0=none, 0.1=strong)
    ball_collision   : bool  = False     — balls bounce off each other (auto-on if collision_audio set)
    ball_speed_min   : float = 3.0       — initial speed range min
    ball_speed_max   : float = 7.0       — initial speed range max

BALLS:
    ball_count       : int   = 10
    ball_colors      : list  = None      — hex list, random if None
    ball_image       : str   = None      — path to PNG (replaces drawn circle)
    ball_images      : list  = None      — list of paths, one per ball randomly
    ball_opacity     : int   = 255       — 0-255
    ball_glow        : bool  = False
    ball_trail       : bool  = False
    trail_length     : int   = 12
    ball_shine       : bool  = True
    ball_spin        : bool  = False     — visually rotate ball
    glow_layers      : int   = 4
    min_radius       : int   = 20
    max_radius       : int   = 60

RING:
    circle_radius    : int   = None      — auto if None (used as half-size for all shapes)
    ring_color       : str   = "#ffffff"
    ring_width       : int   = 4
    ring_glow        : bool  = False
    ring_flash_on_hit: bool  = False
    ring_double      : bool  = False     — second inner ring
    ring_double_gap  : int   = 20        — gap between rings
    ring_dash        : bool  = False     — dashed style
    ring_image       : str   = None      — PNG overlay on ring (tiled/stretched)
    ring_spin        : bool  = False     — ring slowly rotates
    ring_spin_speed  : float = 0.5       — degrees per frame

HIT EFFECTS:
    on_hit_flash     : bool  = False
    on_hit_particles : bool  = False
    on_hit_ring_pulse: bool  = False
    bg_pulse_on_hit  : bool  = False
    particle_count   : int   = 12
    particle_speed   : float = 1.0
    particle_colors  : list  = None      — hex list, uses ball color if None

BACKGROUND:
    bg_color         : str   = "#0d0d0d"
    bg_color2        : str   = None      — gradient end color
    bg_gradient_dir  : str   = "vertical"  — "vertical" or "horizontal" or "radial"
    bg_image         : str   = None      — path to PNG background
    bg_image_alpha   : int   = 255       — opacity of bg image (0-255)
    bg_pulse_on_hit  : bool  = False

OUTPUT:
    fps              : int   = 60
    width            : int   = 1080
    height           : int   = 1920
    duration         : int   = 10
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4, shape="circle", cx=None, cy=None, angle_offset=0.0):
    """Draw glow effect. For non-circle shapes, draws glow along the shape outline."""
    import pygame
    if shape == "circle" or cx is None:
        for i in range(layers, 0, -1):
            _withAlpha(surf, color, pos, r + i*7, int(50/i))
    else:
        # shape-aware glow — draw progressively larger/fainter outlines
        for i in range(layers, 0, -1):
            glow_size = r + i * 7
            alpha     = int(50 / i)
            glow_surf = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
            glow_color = (*color[:3], alpha)
            glow_width = max(2, i * 3)
            if shape == "square":
                half = glow_size
                pygame.draw.rect(glow_surf, glow_color,
                    pygame.Rect(cx - half, cy - half, half*2, half*2), glow_width)
            else:
                verts = _shapeVertices(shape, cx, cy, glow_size, angle_offset)
                pygame.draw.polygon(glow_surf, glow_color,
                    [(int(x), int(y)) for x, y in verts], glow_width)
            surf.blit(glow_surf, (0, 0))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i, (tx, ty, tr) in enumerate(trail):
        alpha = int(160 * (i / n))
        rad   = max(2, int(tr * 0.6 * (i / n)))
        _withAlpha(surf, color, (int(tx), int(ty)), rad, alpha)

def _drawParticles(surf, particles):
    for p in particles:
        alpha = int(255 * (p["life"] / p["max_life"]))
        r     = max(1, int(p["r"] * (p["life"] / p["max_life"])))
        _withAlpha(surf, p["color"], (int(p["x"]), int(p["y"])), r, alpha)

def _spawnParticles(x, y, color, pcolors, count=12, speed_mult=1.0):
    out = []
    for _ in range(count):
        angle = random.uniform(0, 2*math.pi)
        speed = random.uniform(2, 8) * speed_mult
        c     = _hex(random.choice(pcolors)) if pcolors else color
        out.append({
            "x": x, "y": y,
            "vx": math.cos(angle)*speed,
            "vy": math.sin(angle)*speed,
            "r":  random.randint(3, 8),
            "color": c,
            "life": random.randint(10, 25),
            "max_life": 25,
        })
    return out

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w, h))
    if direction == "horizontal":
        for x in range(w):
            t = x / w
            r = int(c1[0] + (c2[0]-c1[0])*t)
            g = int(c1[1] + (c2[1]-c1[1])*t)
            b = int(c1[2] + (c2[2]-c1[2])*t)
            pygame.draw.line(surf, (r,g,b), (x,0), (x,h))
    elif direction == "radial":
        cx, cy = w//2, h//2
        max_d  = math.hypot(cx, cy)
        for y in range(h):
            for x in range(w):
                t = min(1.0, math.hypot(x-cx, y-cy) / max_d)
                r = int(c1[0] + (c2[0]-c1[0])*t)
                g = int(c1[1] + (c2[1]-c1[1])*t)
                b = int(c1[2] + (c2[2]-c1[2])*t)
                surf.set_at((x,y), (r,g,b))
    else:  # vertical
        for y in range(h):
            t = y / h
            r = int(c1[0] + (c2[0]-c1[0])*t)
            g = int(c1[1] + (c2[1]-c1[1])*t)
            b = int(c1[2] + (c2[2]-c1[2])*t)
            pygame.draw.line(surf, (r,g,b), (0,y), (w,y))
    return surf

def _dashedCircle(surf, color, center, radius, width, dash=20):
    import pygame
    n = max(1, int(math.pi * radius / dash))
    for i in range(n):
        a0 = (2*math.pi/n)*i
        a1 = a0 + math.pi/n
        pts = []
        for s in range(11):
            a = a0 + (a1-a0)*s/10
            pts.append((center[0]+radius*math.cos(a), center[1]+radius*math.sin(a)))
        if len(pts) > 1:
            pygame.draw.lines(surf, color, False, pts, width)

def _loadImage(path, size):
    import pygame
    img = pygame.image.load(str(path)).convert_alpha()
    return pygame.transform.smoothscale(img, size)


# ── shape helpers ──────────────────────────────────────────────────────────────

# Number of sides for polygon shapes
_SHAPE_SIDES = {
    "triangle": 3,
    "diamond":  4,
    "pentagon": 5,
    "hexagon":  6,
}

def _shapeVertices(shape: str, cx: int, cy: int, size: int, angle_offset: float = 0.0):
    """Return list of (x,y) vertices for a polygon shape centered at (cx,cy)."""
    sides = _SHAPE_SIDES.get(shape, 6)
    verts = []
    for i in range(sides):
        a = angle_offset + (2 * math.pi * i / sides) - math.pi / 2
        verts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
    return verts

def _drawShape(surf, shape: str, color, cx: int, cy: int, size: int,
               width: int, angle_offset: float = 0.0, dash: bool = False):
    """Draw the boundary shape (ring) on the surface."""
    import pygame
    if shape == "circle":
        if dash:
            _dashedCircle(surf, color, (cx, cy), size, width)
        else:
            pygame.draw.circle(surf, color, (cx, cy), size, width)
        return

    if shape == "square":
        half = size
        rect = pygame.Rect(cx - half, cy - half, half * 2, half * 2)
        pygame.draw.rect(surf, color, rect, width)
        return

    verts = _shapeVertices(shape, cx, cy, size, angle_offset)
    pygame.draw.polygon(surf, color, [(int(x), int(y)) for x, y in verts], width)


def _pointInShape(shape: str, px: float, py: float,
                  cx: int, cy: int, size: int, angle_offset: float = 0.0) -> bool:
    """Return True if point (px,py) is inside the boundary shape."""
    if shape == "circle":
        return math.hypot(px - cx, py - cy) <= size

    if shape == "square":
        return abs(px - cx) <= size and abs(py - cy) <= size

    # polygon — ray casting
    verts = _shapeVertices(shape, cx, cy, size, angle_offset)
    n = len(verts)
    inside = False
    j = n - 1
    for i in range(n):
        xi, yi = verts[i]
        xj, yj = verts[j]
        if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi + 1e-9) + xi):
            inside = not inside
        j = i
    return inside


def _closestPointOnSegment(px, py, ax, ay, bx, by):
    """Closest point on segment AB to point P, plus the normal pointing inward."""
    dx, dy = bx - ax, by - ay
    t = ((px - ax)*dx + (py - ay)*dy) / (dx*dx + dy*dy + 1e-9)
    t = max(0.0, min(1.0, t))
    cx2 = ax + t*dx
    cy2 = ay + t*dy
    nx = px - cx2
    ny = py - cy2
    dist = math.hypot(nx, ny)
    if dist < 1e-6:
        # degenerate — use outward normal of segment
        nx, ny = -dy, dx
        dist = math.hypot(nx, ny)
    return cx2, cy2, nx/dist, ny/dist, dist


def _resolveShapeCollision(b: dict, shape: str, cx: int, cy: int, size: int,
                            bounce: float, angle_offset: float = 0.0) -> bool:
    """
    Push ball back inside boundary and reflect velocity.
    Returns True if a collision happened.
    """
    bx, by, br = b["x"], b["y"], b["r"]
    hit = False

    if shape == "circle":
        dx   = bx - cx
        dy   = by - cy
        dist = math.hypot(dx, dy)
        md   = size - br
        if dist > md:
            nx = dx / dist
            ny = dy / dist
            b["x"] = cx + nx * md
            b["y"] = cy + ny * md
            dot = b["vx"]*nx + b["vy"]*ny
            b["vx"] = (b["vx"] - 2*dot*nx) * bounce
            b["vy"] = (b["vy"] - 2*dot*ny) * bounce
            hit = True

    elif shape == "square":
        half = size - br
        moved = False
        # clamp and reflect per axis
        if bx < cx - half:
            b["x"] = cx - half; b["vx"] = abs(b["vx"]) * bounce; moved = True
        elif bx > cx + half:
            b["x"] = cx + half; b["vx"] = -abs(b["vx"]) * bounce; moved = True
        if by < cy - half:
            b["y"] = cy - half; b["vy"] = abs(b["vy"]) * bounce; moved = True
        elif by > cy + half:
            b["y"] = cy + half; b["vy"] = -abs(b["vy"]) * bounce; moved = True
        hit = moved

    else:
        # polygon — check distance to each edge
        verts = _shapeVertices(shape, cx, cy, size, angle_offset)
        n = len(verts)
        for i in range(n):
            ax, ay = verts[i]
            bvx, bvy = verts[(i+1) % n]
            cpx, cpy, nx, ny, dist = _closestPointOnSegment(bx, by, ax, ay, bvx, bvy)

            # inward normal points toward center
            # check which side of the edge the ball is on
            to_center_x = cx - cpx
            to_center_y = cy - cpy
            if nx * to_center_x + ny * to_center_y < 0:
                nx, ny = -nx, -ny

            if dist < br:
                # push back
                overlap = br - dist
                b["x"] += nx * overlap
                b["y"] += ny * overlap
                # reflect velocity along inward normal
                dot = b["vx"]*nx + b["vy"]*ny
                if dot < 0:
                    b["vx"] = (b["vx"] - 2*dot*nx) * bounce
                    b["vy"] = (b["vy"] - 2*dot*ny) * bounce
                hit = True

    return hit


# ── ball-ball collision ────────────────────────────────────────────────────────

def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):
    n = len(balls)
    for i in range(n):
        for j in range(i+1, n):
            a, b  = balls[i], balls[j]
            dx    = b["x"] - a["x"]
            dy    = b["y"] - a["y"]
            dist  = math.hypot(dx, dy)
            min_d = a["r"] + b["r"]
            if dist < min_d and dist > 0:
                overlap = (min_d - dist) / 2
                nx = dx / dist
                ny = dy / dist
                a["x"] -= nx * overlap
                a["y"] -= ny * overlap
                b["x"] += nx * overlap
                b["y"] += ny * overlap
                dvx = a["vx"] - b["vx"]
                dvy = a["vy"] - b["vy"]
                dot = dvx*nx + dvy*ny
                if dot > 0:
                    a["vx"] = (a["vx"] - dot*nx) * bounce
                    a["vy"] = (a["vy"] - dot*ny) * bounce
                    b["vx"] = (b["vx"] + dot*nx) * bounce
                    b["vy"] = (b["vy"] + dot*ny) * bounce
                if audio is not None:
                    speed = math.hypot(dvx, dvy)
                    audio.log_ball(t, speed)


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    # output
    duration: int           = 10,
    output: Path            = None,
    fps: int                = 60,
    width: int              = 1080,
    height: int             = 1920,
    # shape
    shape: str              = "circle",   # circle | square | triangle | pentagon | hexagon | diamond
    # physics
    gravity: float          = 0.4,
    bounce: float           = 0.92,
    friction: float         = 1.0,
    magnetic_center: float  = 0.0,
    ball_collision: bool    = False,
    ball_speed_min: float   = 3.0,
    ball_speed_max: float   = 7.0,
    # balls
    ball_count: int         = 10,
    ball_colors: list       = None,
    colors: list            = None,
    ball_image: str         = None,
    ball_images: list       = None,
    ball_opacity: int       = 255,
    ball_glow: bool         = False,
    ball_trail: bool        = False,
    trail_length: int       = 12,
    ball_shine: bool        = True,
    ball_spin: bool         = False,
    glow_layers: int        = 4,
    min_radius: int         = 20,
    max_radius: int         = 60,
    # ring / boundary
    circle_radius: int      = None,
    ring_color: str         = "#ffffff",
    ring_width: int         = 4,
    ring_glow: bool         = False,
    ring_flash_on_hit: bool = False,
    ring_double: bool       = False,
    ring_double_gap: int    = 20,
    ring_dash: bool         = False,
    ring_image: str         = None,
    ring_spin: bool         = False,
    ring_spin_speed: float  = 0.5,
    # hit effects
    on_hit_flash: bool      = False,
    on_hit_particles: bool  = False,
    on_hit_ring_pulse: bool = False,
    bg_pulse_on_hit: bool   = False,
    particle_count: int     = 12,
    particle_speed: float   = 1.0,
    particle_colors: list   = None,
    # background
    bg_color: str           = "#0d0d0d",
    bg_color2: str          = None,
    bg_gradient_dir: str    = "vertical",
    bg_image: str           = None,
    bg_image_alpha: int     = 255,
  # collision audio (see Games/collision_audio.py)
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    from Games.collision_audio import CollisionAudioSession, muxCollisionAudio
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    shape = shape.lower().strip()
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"balls_in_{shape}_{stamp}.mp4"

    palette      = ball_colors or colors or None
    pcolors      = particle_colors or None
    pygame.init()
    surface      = pygame.Surface((width, height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    rc           = _hex(ring_color)
    total_frames = max(1, int(duration * fps))

    cx = width  // 2
    cy = height // 2
    cr = circle_radius or (min(width, height) // 2 - 80)

    # ── pre-load assets ───────────────────────────────────────────────────────
    grad_surf = None
    if bg2 and bg_gradient_dir != "radial":
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)
    elif bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, "radial")

    bg_img_surf = None
    if bg_image and Path(bg_image).exists():
        raw = _loadImage(bg_image, (width, height))
        if bg_image_alpha < 255:
            raw.set_alpha(bg_image_alpha)
        bg_img_surf = raw

    ball_img_list = None
    if ball_images:
        ball_img_list = [p for p in ball_images if Path(p).exists()]
    elif ball_image and Path(ball_image).exists():
        ball_img_list = [ball_image]

    ring_img_surf = None
    if ring_image and Path(ring_image).exists():
        ring_img_surf = _loadImage(ring_image, (cr*2, cr*2))

    # ── spawn balls ───────────────────────────────────────────────────────────
    # spawn radius — for polygons, keep balls well inside
    spawn_size = cr * 0.6

    balls = []
    for i in range(ball_count):
        r      = random.randint(min_radius, max_radius)
        color  = _hex(random.choice(palette)) if palette else (
            random.randint(80,255), random.randint(80,255), random.randint(80,255))
        angle  = random.uniform(0, 2*math.pi)
        dist   = random.uniform(0, spawn_size - r - 10)
        speed  = random.uniform(ball_speed_min, ball_speed_max)
        va     = random.uniform(0, 2*math.pi)

        bimg = None
        if ball_img_list:
            src = random.choice(ball_img_list)
            bimg = _loadImage(src, (r*2, r*2))

        balls.append({
            "x":     cx + dist*math.cos(angle),
            "y":     cy + dist*math.sin(angle),
            "vx":    math.cos(va)*speed,
            "vy":    math.sin(va)*speed,
            "r":     r,
            "color": color,
            "flash": 0,
            "trail": [],
            "angle": 0.0,
            "img":   bimg,
        })

    particles  = []
    ring_flash = 0
    ring_pulse = 0
    bg_flash   = 0
    ring_angle = 0.0   # degrees (pygame rotate) for ring_spin display
    shape_angle_offset = 0.0  # radians, for polygon rotation

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            # ── background ────────────────────────────────────────────────
            if bg_img_surf:
                surface.fill((0,0,0,255))
                surface.blit(bg_img_surf, (0,0))
            elif grad_surf:
                surface.blit(grad_surf, (0,0))
            else:
                flash_amt = min(bg_flash*8, 40)
                surface.fill((
                    min(255, bg[0]+flash_amt),
                    min(255, bg[1]+flash_amt),
                    min(255, bg[2]+flash_amt),
                    255
                ))
            if bg_flash > 0: bg_flash -= 1

            # ── boundary shape ────────────────────────────────────────────
            cur_rc  = _lighten(rc, min(ring_flash*15, 120)) if ring_flash > 0 else rc
            pulse_r = cr + int(ring_pulse)

            if ring_img_surf:
                rsize  = pulse_r * 2
                scaled = pygame.transform.smoothscale(ring_img_surf, (rsize, rsize))
                if ring_spin:
                    scaled = pygame.transform.rotate(scaled, ring_angle)
                surface.blit(scaled, (cx - rsize//2, cy - rsize//2))

            if ring_glow:
                _drawGlow(surface, cur_rc, (cx, cy), pulse_r, layers=3,
                          shape=shape, cx=cx, cy=cy, angle_offset=shape_angle_offset)

            _drawShape(surface, shape, cur_rc, cx, cy, pulse_r,
                       ring_width, shape_angle_offset, dash=ring_dash)

            if ring_double:
                inner = max(10, pulse_r - ring_double_gap)
                _drawShape(surface, shape, (*cur_rc, 90), cx, cy, inner,
                           max(1, ring_width-1), shape_angle_offset)

            if ring_spin:
                ring_angle         += ring_spin_speed          # for image rotate (degrees)
                shape_angle_offset += math.radians(ring_spin_speed)  # for polygon verts (radians)

            if ring_flash > 0: ring_flash -= 1
            if ring_pulse > 0: ring_pulse  = max(0, ring_pulse - 2)

            # ── particles ─────────────────────────────────────────────────
            if on_hit_particles:
                _drawParticles(surface, particles)
                for p in particles:
                    p["x"] += p["vx"]
                    p["y"] += p["vy"]
                    p["vy"] += 0.2
                    p["life"] -= 1
                particles = [p for p in particles if p["life"] > 0]

            # ── ball-ball collision ────────────────────────────────────────
            if ball_collision:
                _resolveBallCollisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)

            # ── balls ─────────────────────────────────────────────────────
            for b in balls:

                if ball_trail:
                    b["trail"].append((b["x"], b["y"], b["r"]))
                    if len(b["trail"]) > trail_length:
                        b["trail"].pop(0)
                    _drawTrail(surface, b["trail"], b["color"])

                if magnetic_center > 0:
                    b["vx"] += (cx - b["x"]) * magnetic_center * 0.001
                    b["vy"] += (cy - b["y"]) * magnetic_center * 0.001

                b["vy"] += gravity
                b["vx"] *= friction
                b["vy"] *= friction
                b["x"]  += b["vx"]
                b["y"]  += b["vy"]

                if ball_spin:
                    b["angle"] += math.hypot(b["vx"], b["vy"]) * 0.05

                # ── shape collision ────────────────────────────────────────
                hit = _resolveShapeCollision(
                    b, shape, cx, cy, cr, bounce, shape_angle_offset)

                if hit:
                    if audio.enabled:
                        speed = math.hypot(b["vx"], b["vy"])
                        audio.log_wall(frame / fps, speed)
                    if on_hit_flash:      b["flash"]  = 6
                    if ring_flash_on_hit: ring_flash  = 6
                    if on_hit_ring_pulse: ring_pulse  = 18
                    if bg_pulse_on_hit:   bg_flash    = 4
                    if on_hit_particles:
                        particles += _spawnParticles(
                            b["x"], b["y"], b["color"], pcolors,
                            count=particle_count, speed_mult=particle_speed)

                if ball_glow:
                    _drawGlow(surface, b["color"], (int(b["x"]), int(b["y"])), b["r"], layers=glow_layers)

                pos        = (int(b["x"]), int(b["y"]))
                draw_color = _lighten(b["color"], 180) if b["flash"] > 0 else b["color"]

                if b["img"]:
                    img = b["img"]
                    if ball_spin:
                        img = pygame.transform.rotate(img, math.degrees(b["angle"]))
                    blit_pos = (pos[0] - img.get_width()//2, pos[1] - img.get_height()//2)
                    if ball_opacity < 255:
                        img = img.copy()
                        img.set_alpha(ball_opacity)
                    surface.blit(img, blit_pos)
                else:
                    if ball_opacity < 255:
                        _withAlpha(surface, draw_color, pos, b["r"], ball_opacity)
                    else:
                        pygame.draw.circle(surface, draw_color, pos, b["r"])

                    if ball_spin:
                        ex = pos[0] + int(b["r"]*0.7*math.cos(b["angle"]))
                        ey = pos[1] + int(b["r"]*0.7*math.sin(b["angle"]))
                        pygame.draw.line(surface, (255,255,255), pos, (ex,ey), 2)

                    if ball_shine:
                        pygame.draw.circle(surface, (255,255,255),
                            (pos[0]-b["r"]//4, pos[1]-b["r"]//4), b["r"]//5)

                if b["flash"] > 0: b["flash"] -= 1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))

            if frame % (fps*2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%)")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", str(fps),
            "-i", str(frames_dir/"frame_%06d.png"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            "-preset", "fast", "-crf", "18",
            str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    output = Path(output)
    if audio.enabled:
        print(f"   Collision audio: {len(audio.events)} hits ({audio.mode})", flush=True)
        output = muxCollisionAudio(output, audio, duration=float(duration))
    print(f"   Done → {output}")
    return output