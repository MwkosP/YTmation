"""
Maze Ball — Full Customization
--------------------------------
A ball bounces inside a procedurally generated maze (top-down view)
until it finds the exit. Pure physics — no AI, just bouncing.

MAZE:
    maze_cols        : int   = 9          — number of columns
    maze_rows        : int   = 14         — number of rows
    seed             : int   = None       — fixed seed for reproducible maze (random if None)
    wall_thickness   : int   = 8          — wall line thickness
    wall_color       : str   = "#ffffff"
    wall_glow        : bool  = False
    show_solution    : bool  = False      — faintly show solution path
    cell_size        : int   = None       — auto if None

MARKERS:
    start_color      : str   = "#00ff88"  — start marker color
    exit_color       : str   = "#ff4444"  — exit marker color
    exit_glow        : bool  = True       — pulsing glow on exit
    show_visited     : bool  = True       — faint trail of visited cells

BALL:
    ball_color       : str   = None       — random if None
    ball_radius      : int   = None       — auto (fits corridor)
    ball_speed       : float = 5.0        — initial speed
    ball_glow        : bool  = True
    ball_trail       : bool  = True
    trail_length     : int   = 30
    ball_shine       : bool  = True
    ball_opacity     : int   = 255

PHYSICS:
    bounce           : float = 0.85       — energy kept on wall hit
    friction         : float = 0.995      — air friction per frame
    random_nudge     : float = 0.3        — small random push each frame (stops ball getting stuck)

CORE:
    end_behavior     : str   = "loop"     — "stop" | "loop" (new maze on exit)
    loop_count       : int   = 0          — max loops (0 = infinite)

BACKGROUND:
    bg_color         : str   = "#0d0d0d"
    bg_color2        : str   = None
    bg_gradient_dir  : str   = "vertical"

OUTPUT:
    fps              : int   = 60
    width            : int   = 1080
    height           : int   = 1920
    duration         : int   = 30
"""

import math
import random
import tempfile
from pathlib import Path
from datetime import datetime

ROOT      = Path(__file__).resolve().parent.parent.parent.parent
CACHE_DIR = ROOT / "Cache" / "games"


# ── colour helpers ─────────────────────────────────────────────────────────────

def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _lighten(c, a=100):
    return tuple(min(255, x + a) for x in c)

def _withAlpha(surf, color, pos, r, alpha):
    import pygame
    if r <= 0 or alpha <= 0: return
    s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
    pygame.draw.circle(s, (*color[:3], int(alpha)), (r, r), r)
    surf.blit(s, (pos[0]-r, pos[1]-r))

def _drawGlow(surf, color, pos, r, layers=4):
    for i in range(layers, 0, -1):
        _withAlpha(surf, color, pos, r + i*7, int(55/i))

def _drawTrail(surf, trail, color):
    n = len(trail)
    if n == 0: return
    for i, (tx, ty, tr) in enumerate(trail):
        alpha = int(160*(i/n))
        rad   = max(2, int(tr*0.75*(i/n)))
        _withAlpha(surf, color, (int(tx),int(ty)), rad, alpha)

def _gradientSurface(w, h, c1, c2, direction="vertical"):
    import pygame
    surf = pygame.Surface((w,h))
    if direction=="horizontal":
        for x in range(w):
            t=x/w
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(x,0),(x,h))
    elif direction=="radial":
        cx2,cy2=w//2,h//2; md=math.hypot(cx2,cy2)
        for y in range(h):
            for x in range(w):
                t=min(1.0,math.hypot(x-cx2,y-cy2)/md)
                surf.set_at((x,y),tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)))
    else:
        for y in range(h):
            t=y/h
            pygame.draw.line(surf,tuple(int(c1[k]+(c2[k]-c1[k])*t) for k in range(3)),(0,y),(w,y))
    return surf


# ── maze generation ────────────────────────────────────────────────────────────

def _generateMaze(cols, rows, seed=None):
    """
    Recursive backtracking maze generation.
    Each cell stores which walls are OPEN (passable).
    N=north S=south E=east W=west — True means wall is REMOVED (open passage).
    """
    import sys
    sys.setrecursionlimit(100000)
    rng = random.Random(seed)

    # all walls closed initially
    grid = [[{"N":False,"S":False,"E":False,"W":False,"visited":False}
              for _ in range(cols)] for _ in range(rows)]

    def carve(r, c):
        grid[r][c]["visited"] = True
        dirs = [("N",-1,0,"S"),("S",1,0,"N"),("E",0,1,"W"),("W",0,-1,"E")]
        rng.shuffle(dirs)
        for wall, dr, dc, opp in dirs:
            nr, nc = r+dr, c+dc
            if 0<=nr<rows and 0<=nc<cols and not grid[nr][nc]["visited"]:
                grid[r][c][wall]     = True   # open wall from this side
                grid[nr][nc][opp]    = True   # open wall from other side
                carve(nr, nc)

    carve(0, 0)
    return grid


def _solveMaze(grid, cols, rows):
    """BFS — returns list of (row,col) from start to exit."""
    from collections import deque
    visited = {(0,0)}
    q = deque([(0,0,[(0,0)])])
    dirs = [("N",-1,0),("S",1,0),("E",0,1),("W",0,-1)]
    while q:
        r,c,path = q.popleft()
        if r==rows-1 and c==cols-1:
            return path
        for wall,dr,dc in dirs:
            if grid[r][c][wall]:
                nr,nc = r+dr,c+dc
                if (nr,nc) not in visited and 0<=nr<rows and 0<=nc<cols:
                    visited.add((nr,nc))
                    q.append((nr,nc,path+[(nr,nc)]))
    return []


# ── maze rendering ─────────────────────────────────────────────────────────────

def _buildWallSegments(grid, cols, rows, ox, oy, cs, wt):
    """
    Pre-compute all wall line segments for fast drawing.
    Returns list of (x0,y0,x1,y1) tuples.
    """
    segs = set()
    hw = wt // 2

    for r in range(rows):
        for c in range(cols):
            cell = grid[r][c]
            x0 = ox + c*cs
            y0 = oy + r*cs
            x1 = x0 + cs
            y1 = y0 + cs

            # North wall
            if not cell["N"]:
                segs.add((x0, y0, x1, y0))
            # South wall
            if not cell["S"]:
                segs.add((x0, y1, x1, y1))
            # West wall
            if not cell["W"]:
                segs.add((x0, y0, x0, y1))
            # East wall
            if not cell["E"]:
                segs.add((x1, y0, x1, y1))

    # always draw outer border
    segs.add((ox,        oy,        ox+cols*cs, oy))
    segs.add((ox,        oy+rows*cs,ox+cols*cs, oy+rows*cs))
    segs.add((ox,        oy,        ox,         oy+rows*cs))
    segs.add((ox+cols*cs,oy,        ox+cols*cs, oy+rows*cs))

    return list(segs)


def _drawMaze(surf, wall_segs, wc, wt, wall_glow):
    """Draw all wall segments."""
    import pygame
    for (x0,y0,x1,y1) in wall_segs:
        pygame.draw.line(surf, wc, (x0,y0), (x1,y1), wt)


def _drawVisited(surf, visited_cells, ox, oy, cs, ball_color):
    """Faint color on cells the ball has visited."""
    import pygame
    for (vr,vc) in visited_cells:
        x0=ox+vc*cs; y0=oy+vr*cs
        s=pygame.Surface((cs,cs),pygame.SRCALPHA)
        s.fill((*ball_color[:3],22))
        surf.blit(s,(x0,y0))


def _drawSolution(surf, solution, ox, oy, cs):
    """Faint yellow path for solution."""
    import pygame
    for (sr,sc) in solution:
        x0=ox+sc*cs; y0=oy+sr*cs
        s=pygame.Surface((cs,cs),pygame.SRCALPHA)
        s.fill((255,230,50,20))
        surf.blit(s,(x0,y0))


def _drawStartExit(surf, ox, oy, cs, rows, cols,
                   start_color, exit_color, exit_glow, pulse):
    """Draw start (green) and exit (red) markers."""
    import pygame
    sc = _hex(start_color)
    ec = _hex(exit_color)
    half = cs//2
    pad  = cs//4

    # start — top-left cell, small filled square
    pygame.draw.rect(surf, sc,
        pygame.Rect(ox+pad, oy+pad, cs-pad*2, cs-pad*2), 3)

    # exit — bottom-right cell, glowing square
    ex0 = ox + (cols-1)*cs + pad
    ey0 = oy + (rows-1)*cs + pad
    esz = cs - pad*2
    if exit_glow:
        for i in range(5,0,-1):
            s=pygame.Surface(surf.get_size(),pygame.SRCALPHA)
            pygame.draw.rect(s,(*ec,int(35/i)),
                pygame.Rect(ex0-i*4,ey0-i*4,esz+i*8,esz+i*8))
            surf.blit(s,(0,0))
    pygame.draw.rect(surf, ec, pygame.Rect(ex0,ey0,esz,esz))
    # pulse ring
    pr = int(pulse*0.3)
    pygame.draw.rect(surf, (*ec,150),
        pygame.Rect(ex0-pr,ey0-pr,esz+pr*2,esz+pr*2), 2)


# ── physics ────────────────────────────────────────────────────────────────────

def _ballCell(ball, ox, oy, cs, cols, rows):
    col = max(0,min(cols-1, int((ball["x"]-ox)/cs)))
    row = max(0,min(rows-1, int((ball["y"]-oy)/cs)))
    return row, col


def _wallCollision(ball, br, grid, cols, rows, ox, oy, cs, bounce, wt):
    """
    Proper wall collision:
    For each wall segment near the ball, check distance and reflect.
    """
    bx,by = ball["x"],ball["y"]
    hit   = False

    # check cells in 2x2 neighborhood of ball
    col = int((bx-ox)/cs)
    row = int((by-oy)/cs)

    for dr in range(-1,2):
        for dc in range(-1,2):
            r,c = row+dr, col+dc
            if not (0<=r<rows and 0<=c<cols): continue
            cell = grid[r][c]
            x0 = ox + c*cs
            y0 = oy + r*cs
            x1 = x0 + cs
            y1 = y0 + cs

            # North wall of this cell
            if not cell["N"] or r==0:
                wy = y0
                if abs(by - wy) < br and x0 <= bx <= x1:
                    if ball["vy"] < 0:
                        ball["y"] = wy + br
                        ball["vy"] = abs(ball["vy"]) * bounce
                        hit = True

            # South wall
            if not cell["S"] or r==rows-1:
                wy = y1
                if abs(by - wy) < br and x0 <= bx <= x1:
                    if ball["vy"] > 0:
                        ball["y"] = wy - br
                        ball["vy"] = -abs(ball["vy"]) * bounce
                        hit = True

            # West wall
            if not cell["W"] or c==0:
                wx = x0
                if abs(bx - wx) < br and y0 <= by <= y1:
                    if ball["vx"] < 0:
                        ball["x"] = wx + br
                        ball["vx"] = abs(ball["vx"]) * bounce
                        hit = True

            # East wall
            if not cell["E"] or c==cols-1:
                wx = x1
                if abs(bx - wx) < br and y0 <= by <= y1:
                    if ball["vx"] > 0:
                        ball["x"] = wx - br
                        ball["vx"] = -abs(ball["vx"]) * bounce
                        hit = True

    return hit


def _atExit(ball, ox, oy, cols, rows, cs, br):
    """Check if ball center is inside exit cell."""
    ex_cx = ox + (cols-1)*cs + cs//2
    ex_cy = oy + (rows-1)*cs + cs//2
    return math.hypot(ball["x"]-ex_cx, ball["y"]-ex_cy) < cs*0.45


# ── main ───────────────────────────────────────────────────────────────────────

def run(
    duration: int           = 30,
    output: Path            = None,
    fps: int                = 60,
    width: int              = 1080,
    height: int             = 1920,
    # maze
    maze_cols: int          = 9,
    maze_rows: int          = 14,
    seed: int               = None,
    wall_thickness: int     = 8,
    wall_color: str         = "#ffffff",
    wall_glow: bool         = False,
    show_solution: bool     = False,
    cell_size: int          = None,
    # markers
    start_color: str        = "#00ff88",
    exit_color: str         = "#ff4444",
    exit_glow: bool         = True,
    show_visited: bool      = True,
    # ball
    ball_color: str         = None,
    ball_radius: int        = None,
    ball_speed: float       = 5.0,
    ball_glow: bool         = True,
    ball_trail: bool        = True,
    trail_length: int       = 30,
    ball_shine: bool        = True,
    ball_opacity: int       = 255,
    # physics
    bounce: float           = 0.85,
    friction: float         = 0.995,
    random_nudge: float     = 0.3,
    # core
    end_behavior: str       = "loop",
    loop_count: int         = 0,
    # background
    bg_color: str           = "#0d0d0d",
    bg_color2: str          = None,
    bg_gradient_dir: str    = "vertical",
    collision_audio: dict | None = None,
    **kwargs,
) -> Path:

    import pygame, os, subprocess
    os.environ.setdefault("SDL_VIDEODRIVER","dummy")
    os.environ.setdefault("SDL_AUDIODRIVER","dummy")

    from Games.collision_audio import (
        CollisionAudioSession,
        finalizeCollisionAudio,
        log_wall_from_ball,
        resolve_ball_collisions,
    )
    collision_audio_cfg = kwargs.pop("collision_audio", collision_audio)
    audio = CollisionAudioSession(collision_audio_cfg)
    if audio.enabled:
        ball_collision = True

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"mazeBall_{stamp}.mp4"

    pygame.init()
    surface      = pygame.Surface((width,height), pygame.SRCALPHA)
    bg           = _hex(bg_color)
    bg2          = _hex(bg_color2) if bg_color2 else None
    wc           = _hex(wall_color)
    total_frames = max(1, int(duration * fps))

    # ── layout ────────────────────────────────────────────────────────────────
    padding = 80
    if cell_size is None:
        cs_w = (width  - padding*2) // maze_cols
        cs_h = (height - padding*2) // maze_rows
        cs   = max(50, min(cs_w, cs_h))
    else:
        cs = cell_size

    maze_w = cs * maze_cols
    maze_h = cs * maze_rows
    ox = (width  - maze_w) // 2
    oy = (height - maze_h) // 2

    # ball fits inside corridor with room to spare
    br = ball_radius or max(8, cs//2 - wall_thickness - 4)

    bc = _hex(ball_color) if ball_color else (
        random.randint(100,255), random.randint(100,255), random.randint(100,255))

    grad_surf = None
    if bg2:
        grad_surf = _gradientSurface(width, height, bg, bg2, bg_gradient_dir)

    rng = random.Random(seed)

    def _reset(cur_seed):
        grid     = _generateMaze(maze_cols, maze_rows, seed=cur_seed)
        solution = _solveMaze(grid, maze_cols, maze_rows)
        wall_segs = _buildWallSegments(grid, maze_cols, maze_rows, ox, oy, cs, wall_thickness)

        # start ball in center of start cell
        sx = float(ox + cs//2)
        sy = float(oy + cs//2)
        # random initial direction, avoid going straight into a wall
        angle = rng.uniform(0, 2*math.pi)
        ball  = {
            "x": sx, "y": sy,
            "vx": math.cos(angle)*ball_speed,
            "vy": math.sin(angle)*ball_speed,
            "flash": 0, "trail": [],
        }
        return grid, solution, wall_segs, ball

    cur_seed          = seed
    grid, solution, wall_segs, ball = _reset(cur_seed)
    visited_cells     = set()
    loops_done        = 0
    done              = False
    pulse_t           = 0.0
    flash_timer       = 0

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)

        for frame in range(total_frames):

            if done:
                pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))
                continue

            pulse_t += 4.0

            # ── background ────────────────────────────────────────────────
            if grad_surf:
                surface.blit(grad_surf,(0,0))
            else:
                surface.fill((*bg,255))

            # ── visited cells ──────────────────────────────────────────────
            rc = _ballCell(ball, ox, oy, cs, maze_cols, maze_rows)
            visited_cells.add(rc)

            if show_visited:
                _drawVisited(surface, visited_cells, ox, oy, cs, bc)

            # ── solution path ──────────────────────────────────────────────
            if show_solution:
                _drawSolution(surface, solution, ox, oy, cs)

            # ── maze walls ────────────────────────────────────────────────
            _drawMaze(surface, wall_segs, wc, wall_thickness, wall_glow)

            # ── start / exit markers ──────────────────────────────────────
            _drawStartExit(surface, ox, oy, cs, maze_rows, maze_cols,
                           start_color, exit_color, exit_glow, pulse_t)

            # ── physics ───────────────────────────────────────────────────
            # random nudge — prevents ball getting stuck in loops
            if random_nudge > 0:
                ball["vx"] += rng.uniform(-random_nudge, random_nudge)
                ball["vy"] += rng.uniform(-random_nudge, random_nudge)

            # friction
            ball["vx"] *= friction
            ball["vy"] *= friction

            # maintain minimum speed so ball never stops
            spd = math.hypot(ball["vx"],ball["vy"])
            if spd < ball_speed * 0.5:
                if spd > 0:
                    ball["vx"] = ball["vx"]/spd * ball_speed * 0.5
                    ball["vy"] = ball["vy"]/spd * ball_speed * 0.5
                else:
                    angle = rng.uniform(0,2*math.pi)
                    ball["vx"] = math.cos(angle)*ball_speed*0.5
                    ball["vy"] = math.sin(angle)*ball_speed*0.5
            # cap max speed
            elif spd > ball_speed * 1.5:
                ball["vx"] = ball["vx"]/spd * ball_speed * 1.5
                ball["vy"] = ball["vy"]/spd * ball_speed * 1.5

            ball["x"] += ball["vx"]
            ball["y"] += ball["vy"]

            # wall collision
            hit = _wallCollision(
                ball, br, grid, maze_cols, maze_rows,
                ox, oy, cs, bounce, wall_thickness)

            if hit:
                log_wall_from_ball(audio, frame / fps, ball)
                flash_timer = 4

            # trail
            if ball_trail:
                ball["trail"].append((ball["x"],ball["y"],br))
                if len(ball["trail"])>trail_length: ball["trail"].pop(0)

            # ── exit check ────────────────────────────────────────────────
            if _atExit(ball, ox, oy, maze_cols, maze_rows, cs, br):
                loops_done += 1
                print(f"   Exit found! Loop {loops_done} at frame {frame} "
                      f"({frame/fps:.1f}s)")
                if end_behavior=="loop" and (loop_count==0 or loops_done<loop_count):
                    # new maze with incremented seed
                    cur_seed = None if seed is None else (cur_seed or 0)+loops_done
                    grid,solution,wall_segs,ball = _reset(cur_seed)
                    visited_cells = set()
                    flash_timer   = 0
                else:
                    done = True

            # ── draw trail ────────────────────────────────────────────────
            if ball_trail:
                _drawTrail(surface, ball["trail"], bc)

            # ── draw ball ─────────────────────────────────────────────────
            pos        = (int(ball["x"]),int(ball["y"]))
            draw_color = _lighten(bc,180) if flash_timer>0 else bc

            if ball_glow:
                _drawGlow(surface, draw_color, pos, br)

            if ball_opacity<255:
                _withAlpha(surface, draw_color, pos, br, ball_opacity)
            else:
                pygame.draw.circle(surface, draw_color, pos, br)

            if ball_shine and br>6:
                pygame.draw.circle(surface,(255,255,255),
                    (pos[0]-br//4,pos[1]-br//4),max(1,br//5))

            if flash_timer>0: flash_timer-=1

            # ── save frame ────────────────────────────────────────────────
            pygame.image.save(surface,str(frames_dir/f"frame_{frame:06d}.png"))

            if frame%(fps*2)==0:
                print(f"   Frame {frame}/{total_frames} ({frame*100//total_frames}%) "
                      f"| cell: {rc} | loops: {loops_done} | visited: {len(visited_cells)}")

        print(f"   Encoding {total_frames} frames...")
        subprocess.run([
            "ffmpeg","-y","-framerate",str(fps),
            "-i",str(frames_dir/"frame_%06d.png"),
            "-c:v","libx264","-pix_fmt","yuv420p",
            "-preset","fast","-crf","18",str(output)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    pygame.quit()
    print(f"   Done → {output}")
    output = Path(output)
    output = finalizeCollisionAudio(output, audio, duration)
    return output