#!/usr/bin/env python3
"""Fix broken local resolve_ball_collisions defs and wire remaining hits."""

from pathlib import Path

BB = Path(__file__).resolve().parent.parent / "Games" / "animations" / "bb"

BROKEN_DEF = 'def resolve_ball_collisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None'
LOG_SNIPPET = (
    "                if audio is not None:\n"
    "                    from Games.collision_audio import log_ball_pair\n"
    "                    log_ball_pair(audio, t, dvx, dvy)\n"
)

FIXES = {
    "pinball.py": ("def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):", None),
    "stackingBalls.py": (
        "def _resolveBallCollisions(balls, bounce, rest_threshold, t: float = 0.0, audio=None):",
        "resolve_ball_collisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None, skip_settled=True)",
        "_resolveBallCollisions(balls, bounce, rest_threshold, t=frame / fps, audio=audio if audio.enabled else None)",
    ),
    "colorTrailCompeteBalls.py": ("def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):",
        "resolve_ball_collisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)",
        "_resolveBallCollisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)"),
    "multiplyBall.py": ("def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):",
        "resolve_ball_collisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)",
        "_resolveBallCollisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)"),
    "splitBall.py": ("def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):",
        "resolve_ball_collisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)",
        "_resolveBallCollisions(balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)"),
    "pinataBall.py": ("def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):",
        "resolve_ball_collisions(inner_balls, bounce_floor, t=frame / fps, audio=audio if audio.enabled else None)",
        "_resolveBallCollisions(inner_balls, bounce_floor, t=frame / fps, audio=audio if audio.enabled else None)"),
    "gravityWell.py": ("def _resolveBallCollisions(balls, bounce, t: float = 0.0, audio=None):",
        "col = _resolveBallCollisions(active_balls, bounce, t=frame / fps, audio=audio if audio.enabled else None)"),
}


def fix_broken_def(path: Path, new_def: str, *call_repls):
    text = path.read_text()
    if BROKEN_DEF not in text and "t=frame / fps" not in text.split("def resolve_ball_collisions", 1)[-1][:80] if "def resolve_ball_collisions" in text else "":
        return False
    # Fix any broken def line
    import re
    text = re.sub(
        r"def resolve_ball_collisions\(balls, bounce,[^\n]+\):",
        new_def,
        text,
        count=1,
    )
    # Add logging before end of collision if-block (pinball style)
    if LOG_SNIPPET.strip() not in text and "def _resolveBallCollisions" in text:
        text = text.replace(
            "                    b[\"vy\"] = (b[\"vy\"] + dot*ny) * bounce\n",
            "                    b[\"vy\"] = (b[\"vy\"] + dot*ny) * bounce\n" + LOG_SNIPPET,
            1,
        )
        if LOG_SNIPPET.strip() not in text:
            text = text.replace(
                "                    b['vy'] = (b['vy'] + dot*ny) * bounce\n",
                "                    b['vy'] = (b['vy'] + dot*ny) * bounce\n" + LOG_SNIPPET,
                1,
            )
    for i in range(0, len(call_repls), 2):
        if i + 1 < len(call_repls):
            text = text.replace(call_repls[i], call_repls[i + 1])
    path.write_text(text)
    return True


def add_escape_roulette_laser_maze_infection():
  # escapeBall
    p = BB / "escapeBall.py"
    t = p.read_text()
    if 'elif result == "bounce":' in t and "log_wall_from_ball(audio" not in t.split("bounce")[1][:200]:
        t = t.replace(
            '                elif result == "bounce":\n',
            '                elif result == "bounce":\n'
            "                    log_wall_from_ball(audio, frame / fps, ball)\n",
            1,
        )
        p.write_text(t)

    # roulette
    p = BB / "rouletteSlotsBall.py"
    t = p.read_text()
    if "hit = True" in t and "log_wall_from_ball(audio, frame / fps, ball)" not in t:
        t = t.replace(
            "                hit = True\n\n            # Slot effect",
            "                hit = True\n"
            "                log_wall_from_ball(audio, frame / fps, ball)\n\n            # Slot effect",
            1,
        )
        p.write_text(t)

    # laser
    p = BB / "laserGridBall.py"
    t = p.read_text()
    if "if laser_hit:" in t and "log_wall_from_ball(audio, frame / fps, ball)" not in t:
        t = t.replace(
            "            if laser_hit:\n",
            "            if laser_hit:\n"
            "                log_wall_from_ball(audio, frame / fps, ball)\n",
            1,
        )
        p.write_text(t)

    # maze
    p = BB / "mazeBall.py"
    t = p.read_text()
    if "if hit:\n                flash_timer = 4" in t:
        t = t.replace(
            "            if hit:\n                flash_timer = 4",
            "            if hit:\n                log_wall_from_ball(audio, frame / fps, ball)\n                flash_timer = 4",
            1,
        )
        p.write_text(t)

    # infection ball-ball
    p = BB / "infectionBall.py"
    t = p.read_text()
    if "touched = _resolve_ball_collision" in t and "log_ball_pair" not in t:
        t = t.replace(
            "                        touched = _resolve_ball_collision(balls[i], balls[j], bounce)\n",
            "                        touched = _resolve_ball_collision(balls[i], balls[j], bounce)\n"
            "                        if touched:\n"
            "                            from Games.collision_audio import log_ball_pair\n"
            "                            log_ball_pair(audio, frame / fps, balls[i][\"vx\"] - balls[j][\"vx\"], balls[i][\"vy\"] - balls[j][\"vy\"])\n",
            1,
        )
        p.write_text(t)

    # pinball peg + walls
    p = BB / "pinball.py"
    t = p.read_text()
    if "hit_peg = True" in t and "log_wall_from_ball(audio, frame / fps, b)" not in t:
        t = t.replace("                        hit_peg = True\n", "                        hit_peg = True\n                        log_wall_from_ball(audio, frame / fps, b)\n", 1)
    if 'b["vx"] = abs(b["vx"]) * bounce' in t and "# peg collision" in t:
        # wall bounce left
        t = t.replace(
            '                    b["vx"] = abs(b["vx"]) * bounce\n',
            '                    b["vx"] = abs(b["vx"]) * bounce\n                    log_wall_from_ball(audio, frame / fps, b)\n',
            1,
        )
    p.write_text(t)

    # stackingBalls wall hits
    p = BB / "stackingBalls.py"
    t = p.read_text()
    if "hit = True" in t and "log_wall_from_ball" not in t:
        # after wall collision block in main loop - find pattern
        if "if hit:" in t and "log_wall_from_ball(audio, frame / fps" not in t:
            t = t.replace(
                "                    hit = True\n",
                "                    hit = True\n                    log_wall_from_ball(audio, frame / fps, b)\n",
                1,
            )
        p.write_text(t)

    # breakObjects/breakout - shape collision call site logging
    for name in ("breakObjectsBall.py", "breakoutBall.py"):
        p = BB / name
        t = p.read_text()
        if "_resolveShapeCollision" in t and "log_wall_from_ball(audio, frame / fps, ball)" not in t:
            if "hit=" in t and "if hit:" not in t:
                pass  # script may have added shape_call_log
        if "finalizeCollisionAudio" in t and "CollisionAudioSession" not in t:
            pass


def main():
    for fname, spec in FIXES.items():
        path = BB / fname
        if path.exists():
            fix_broken_def(path, spec[0], *spec[1:])
            print("fixed def", fname)
    add_escape_roulette_laser_maze_infection()
    print("special cases done")


if __name__ == "__main__":
    main()
