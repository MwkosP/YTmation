import json
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "Cache" / "transitions"

IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff")
VIDEO_EXTENSIONS = (".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v")


TRANSITION_PRESETS = {
    # ─── BASIC ───────────────────────────────────────────
    "cleanCut":       None,
    "crossfade":      "fade",
    "dipBlack":       "fadeblack",
    "dipWhite":       "fadewhite",
    "fadeFast":       "fadefast",
    "fadeGrays":      "fadegrays",
    "fadeSlow":       "fadeslow",
    "dissolve":       "dissolve",
    "distance":       "distance",

    # ─── WIPE ────────────────────────────────────────────
    "wipeLeft":       "wipeleft",
    "wipeRight":      "wiperight",
    "wipeUp":         "wipeup",
    "wipeDown":       "wipedown",
    "wipeTL":         "wipetl",
    "wipeTR":         "wipetr",
    "wipeBL":         "wipebl",
    "wipeBR":         "wipebr",

    # ─── SLIDE / PUSH ────────────────────────────────────
    "pushLeft":       "slideleft",
    "pushRight":      "slideright",
    "pushUp":         "slideup",
    "pushDown":       "slidedown",
    "swipeLeft":      "slideleft",
    "swipeRight":     "slideright",
    "swipeUp":        "slideup",
    "swipeDown":      "slidedown",

    # ─── COVER ───────────────────────────────────────────
    "coverLeft":      "coverleft",
    "coverRight":     "coverright",
    "coverUp":        "coverup",
    "coverDown":      "coverdown",

    # ─── REVEAL ──────────────────────────────────────────
    "revealLeft":     "revealleft",
    "revealRight":    "revealright",
    "revealUp":       "revealup",
    "revealDown":     "revealdown",

    # ─── SMOOTH ──────────────────────────────────────────
    "smoothLeft":     "smoothleft",
    "smoothRight":    "smoothright",
    "smoothUp":       "smoothup",
    "smoothDown":     "smoothdown",

    # ─── DIAGONAL ────────────────────────────────────────
    "diagTL":         "diagtl",
    "diagTR":         "diagtr",
    "diagBL":         "diagbl",
    "diagBR":         "diagbr",

    # ─── SLICE ───────────────────────────────────────────
    "hlSlice":        "hlslice",
    "hrSlice":        "hrslice",
    "vuSlice":        "vuslice",
    "vdSlice":        "vdslice",

    # ─── WIND ────────────────────────────────────────────
    "hlWind":         "hlwind",
    "hrWind":         "hrwind",
    "vuWind":         "vuwind",
    "vdWind":         "vdwind",

    # ─── OPEN / CLOSE ────────────────────────────────────
    "circleOpen":     "circleopen",
    "circleClose":    "circleclose",
    "circleCrop":     "circlecrop",
    "rectCrop":       "rectcrop",
    "horzOpen":       "horzopen",
    "horzClose":      "horzclose",
    "vertOpen":       "vertopen",
    "vertClose":      "vertclose",
    "doorOpen":       "horzopen",
    "doorClose":      "horzclose",
    "irisOpen":       "circleopen",
    "irisClose":      "circleclose",

    # ─── SQUEEZE ─────────────────────────────────────────
    "squeezeH":       "squeezeh",
    "squeezeV":       "squeezev",
    "splitH":         "squeezeh",
    "splitV":         "squeezev",

    # ─── RADIAL ──────────────────────────────────────────
    "radial":         "radial",
    "radialFast":     "radial",

    # ─── MOTION / ENERGY ─────────────────────────────────
    "whipPan":        "hblur",
    "zoomIn":         "zoomin",
    "zoomBlur":       "hblur",
    "glitch":         "pixelize",
    "pixelate":       "pixelize",

    # ─── CINEMATIC ALIASES ───────────────────────────────
    "filmBurn":       "fadeblack",
    "flashWhite":     "fadewhite",
    "crossDissolve":  "dissolve",
    "snapCut":        None,
    "venetian":       "hlslice",
    "barDown":        "vdslice",
    "barUp":          "vuslice",
    "barLeft":        "hlslice",
    "barRight":       "hrslice",

    # ─── LUXURY / HIGH END ───────────────────────────────
    "goldWipe":       "wipeleft",
    "elegantFade":    "fadeslow",
    "velvetDissolve": "dissolve",
    "mirrorLeft":     "horzopen",
    "mirrorRight":    "horzclose",

    # ─── SOCIAL MEDIA ────────────────────────────────────
    "boomerang":      "zoomin",
    "staticNoise":    "pixelize",
    "scanLines":      "fadegrays",
}


def run_command(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def run_json(cmd: list[str]) -> dict:
    raw = subprocess.check_output(cmd)
    return json.loads(raw.decode("utf-8"))


def require_tool(name: str) -> None:
    if shutil.which(name) is None:
        raise RuntimeError(f"Required tool not found: {name}")


def is_image(path: str | Path) -> bool:
    return Path(path).suffix.lower() in IMAGE_EXTENSIONS


def is_video(path: str | Path) -> bool:
    return Path(path).suffix.lower() in VIDEO_EXTENSIONS


def probe_duration(path: str | Path) -> float:
    data = run_json([
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "json",
        str(path),
    ])
    return float(data.get("format", {}).get("duration") or 0)


def has_audio(path: str | Path) -> bool:
    data = run_json([
        "ffprobe",
        "-v", "error",
        "-select_streams", "a",
        "-show_entries", "stream=index",
        "-of", "json",
        str(path),
    ])
    return bool(data.get("streams"))


def fit_filter(width: int, height: int, fps: int) -> str:
    return (
        f"scale={width}:{height}:force_original_aspect_ratio=increase,"
        f"crop={width}:{height},fps={fps},setsar=1,format=yuv420p"
    )


def make_temp_dir() -> tempfile.TemporaryDirectory:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return tempfile.TemporaryDirectory(prefix="work_", dir=str(OUTPUT_DIR))


def resolve_transition(name: str) -> str | None:
    if name not in TRANSITION_PRESETS:
        available = ", ".join(TRANSITION_PRESETS)
        raise ValueError(f"Unknown transition '{name}'. Available: {available}")
    return TRANSITION_PRESETS[name]


def normalize_media(
    source: str | Path,
    output: str | Path,
    *,
    width: int,
    height: int,
    fps: int,
    image_duration: float,
) -> Path:
    source = Path(source)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)

    if not source.exists():
        raise FileNotFoundError(f"Media not found: {source}")

    vf = fit_filter(width, height, fps)
    base = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]

    if is_image(source):
        run_command([
            *base,
            "-loop", "1", "-t", str(image_duration), "-i", str(source),
            "-f", "lavfi", "-t", str(image_duration), "-i", "anullsrc=r=48000:cl=stereo",
            "-vf", vf,
            "-map", "0:v:0", "-map", "1:a:0",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
            "-c:a", "aac", "-shortest",
            str(output),
        ])
        return output

    if has_audio(source):
        run_command([
            *base,
            "-i", str(source),
            "-vf", vf,
            "-af", "aresample=48000",
            "-map", "0:v:0", "-map", "0:a:0",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
            "-c:a", "aac", "-shortest",
            str(output),
        ])
    else:
        run_command([
            *base,
            "-i", str(source),
            "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo",
            "-vf", vf,
            "-map", "0:v:0", "-map", "1:a:0",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
            "-c:a", "aac", "-shortest",
            str(output),
        ])
    return output


def normalize_inputs(
    media: list[str | Path],
    work_dir: str | Path,
    *,
    width: int,
    height: int,
    fps: int,
    image_duration: float,
) -> tuple[list[Path], list[float]]:
    normalized = []
    durations = []
    for index, source in enumerate(media):
        path = normalize_media(
            source,
            Path(work_dir) / f"input_{index:03}.mp4",
            width=width,
            height=height,
            fps=fps,
            image_duration=image_duration,
        )
        normalized.append(path)
        durations.append(probe_duration(path))
    return normalized, durations
