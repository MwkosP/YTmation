#!/usr/bin/env python3
"""Professional transitions between videos and images."""

import argparse
from pathlib import Path

try:
    from .utils import (
        OUTPUT_DIR,
        TRANSITION_PRESETS,
        make_temp_dir,
        normalize_inputs,
        require_tool,
        resolve_transition,
        run_command,
    )
except ImportError:
    from utils import (
        OUTPUT_DIR,
        TRANSITION_PRESETS,
        make_temp_dir,
        normalize_inputs,
        require_tool,
        resolve_transition,
        run_command,
    )


def listTransitions() -> list[str]:
    transitions = sorted(TRANSITION_PRESETS)
    for name in transitions:
        print(name)
    return transitions


def buildTransitionPlan(
    media: list[str | Path],
    *,
    transition: str = "crossfade",
    duration: float = 0.5,
    width: int = 1920,
    height: int = 1080,
    fps: int = 30,
    imageDuration: float = 3.0,
) -> dict:
    if len(media) < 1:
        raise ValueError("Provide at least one image or video")
    if duration < 0:
        raise ValueError("Transition duration must be zero or positive")
    if imageDuration <= 0:
        raise ValueError("Image duration must be greater than zero")
    effect = resolve_transition(transition)
    return {
        "media": [str(item) for item in media],
        "transition": transition,
        "ffmpeg_transition": effect,
        "duration": duration,
        "width": width,
        "height": height,
        "fps": fps,
        "image_duration": imageDuration,
    }


def applyTransition(
    media: list[str | Path],
    output: str | Path,
    *,
    transition: str = "crossfade",
    duration: float = 0.5,
    width: int = 1920,
    height: int = 1080,
    fps: int = 30,
    imageDuration: float = 3.0,
) -> Path:
    return combineMedia(
        media,
        output,
        transition=transition,
        duration=duration,
        width=width,
        height=height,
        fps=fps,
        imageDuration=imageDuration,
    )


def combineMedia(
    media: list[str | Path],
    output: str | Path,
    *,
    transition: str = "crossfade",
    duration: float = 0.5,
    width: int = 1920,
    height: int = 1080,
    fps: int = 30,
    imageDuration: float = 3.0,
) -> Path:
    require_tool("ffmpeg")
    require_tool("ffprobe")

    plan = buildTransitionPlan(
        media,
        transition=transition,
        duration=duration,
        width=width,
        height=height,
        fps=fps,
        imageDuration=imageDuration,
    )
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)

    with make_temp_dir() as workDir:
        normalized, durations = normalize_inputs(
            media,
            workDir,
            width=width,
            height=height,
            fps=fps,
            image_duration=imageDuration,
        )

        if len(normalized) == 1:
            run_command([
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                "-i", str(normalized[0]),
                "-c", "copy",
                str(output),
            ])
            return output

        effect = plan["ffmpeg_transition"]
        if effect is None or duration == 0:
            runConcat(normalized, output)
            return output

        transitionDuration = min(duration, min(durations) * 0.45)
        if transitionDuration <= 0.01:
            runConcat(normalized, output)
            return output
        runXfade(
            normalized,
            durations,
            output,
            transition=effect,
            duration=transitionDuration,
        )
    return output


def runConcat(inputs: list[Path], output: Path) -> None:
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
    for path in inputs:
        cmd.extend(["-i", str(path)])

    streams = "".join(f"[{index}:v][{index}:a]" for index in range(len(inputs)))
    filterComplex = f"{streams}concat=n={len(inputs)}:v=1:a=1[v][a]"
    cmd.extend([
        "-filter_complex", filterComplex,
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "aac",
        str(output),
    ])
    run_command(cmd)


def runXfade(
    inputs: list[Path],
    durations: list[float],
    output: Path,
    *,
    transition: str,
    duration: float,
) -> None:
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
    for path in inputs:
        cmd.extend(["-i", str(path)])

    filters = []
    videoLabel = "0:v"
    audioLabel = "0:a"
    compositeDuration = durations[0]

    for index in range(1, len(inputs)):
        nextVideo = f"{index}:v"
        nextAudio = f"{index}:a"
        outVideo = f"v{index}"
        outAudio = f"a{index}"
        offset = max(0, compositeDuration - duration)
        filters.append(
            f"[{videoLabel}][{nextVideo}]"
            f"xfade=transition={transition}:duration={duration}:offset={offset}"
            f"[{outVideo}]"
        )
        filters.append(
            f"[{audioLabel}][{nextAudio}]"
            f"acrossfade=d={duration}:c1=tri:c2=tri"
            f"[{outAudio}]"
        )
        videoLabel = outVideo
        audioLabel = outAudio
        compositeDuration = compositeDuration + durations[index] - duration

    filterComplex = ";".join(filters)
    cmd.extend([
        "-filter_complex", filterComplex,
        "-map", f"[{videoLabel}]", "-map", f"[{audioLabel}]",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "aac",
        "-movflags", "+faststart",
        str(output),
    ])
    run_command(cmd)


def runCli() -> int:
    parser = argparse.ArgumentParser(description="Combine images/videos with YouTube-ready transitions")
    parser.add_argument("media", nargs="*", help="Images or videos to combine")
    parser.add_argument("-o", "--output", default=str(OUTPUT_DIR / "transitioned.mp4"))
    parser.add_argument("--transition", default="crossfade", help="Transition preset")
    parser.add_argument("-d", "--duration", type=float, default=0.5, help="Transition length in seconds")
    parser.add_argument("--image-duration", type=float, default=3.0, help="Seconds per still image")
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--list", action="store_true", help="List transition presets")
    args = parser.parse_args()

    if args.list:
        listTransitions()
        return 0

    if len(args.media) < 1:
        parser.error("Provide at least one image or video, or use --list")

    output = combineMedia(
        args.media,
        args.output,
        transition=args.transition,
        duration=args.duration,
        width=args.width,
        height=args.height,
        fps=args.fps,
        imageDuration=args.image_duration,
    )
    print(f"Saved: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(runCli())
