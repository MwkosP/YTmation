# Transitions — professional media joins

Combines videos and/or images into one YouTube-ready video with clean transitions.

## Layout

```
Transitions/
├── SKILL.md
├── transitions.py
└── utils.py
```

Outputs default to `Cache/transitions/`.

## Python

```python
from Transitions.transitions import combineMedia, listTransitions

listTransitions()
combineMedia(
    ["clip1.mp4", "image1.png", "clip2.mp4"],
    "Cache/transitions/final.mp4",
    transition="crossfade",
    duration=0.5,
)
```

## CLI

```bash
python Transitions/transitions.py --list
python Transitions/transitions.py clip1.mp4 image1.png clip2.mp4 -o final.mp4 --transition crossfade
python Transitions/transitions.py intro.png render.mp4 -o final.mp4 --transition zoomBlur --image-duration 3
```

## Presets

Use `cleanCut`, `crossfade`, `dipBlack`, `dipWhite`, `fadeFast`, `fadeGrays`, `fadeSlow`, `circleCrop`, `circleClose`, `circleOpen`, `distance`, `dissolve`, `diagBL`, `diagBR`, `diagTL`, `diagTR`, `hlSlice`, `hrSlice`, `vuSlice`, `vdSlice`, `hlWind`, `hrWind`, `vuWind`, `vdWind`, `horzClose`, `horzOpen`, `radial`, `rectCrop`, `squeezeH`, `squeezeV`, `smoothDown`, `smoothLeft`, `smoothRight`, `smoothUp`, `pushLeft`, `pushRight`, `pushUp`, `pushDown`, `coverLeft`, `coverRight`, `coverUp`, `coverDown`, `wipeUp`, `wipeDown`, `wipeTL`, `wipeTR`, `wipeBL`, `wipeBR`, `whipPan`, `zoomBlur`, `glitch`, `wipeLeft`, `wipeRight`, `revealLeft`, `revealRight`, `revealUp`, or `revealDown`.

Images are converted to short motion-safe video segments before transitions are applied.
