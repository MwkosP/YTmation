import json
from datetime import datetime
from pathlib import Path
from Storage.utils import _readJSON, _writeJSON, _appendJSON

ROOT    = Path(__file__).resolve().parent.parent
DB_DIR  = Path(__file__).resolve().parent / "db"

UPLOADS_FILE = DB_DIR / "uploads.json"
CACHE_FILE   = DB_DIR / "cache.json"
HISTORY_FILE = DB_DIR / "history.json"
LOGS_FILE    = DB_DIR / "logs.json"


# ── uploads ────────────────────────────────────────────────────────────────

def logUpload(
    title: str,
    video_id: str,
    channel: str    = None,
    niche: str      = None,
    workflow: str   = None,
    topic: str      = None,
    duration: float = None,
) -> dict:
    """Log a successfully uploaded video."""
    entry = {
        "title":       title,
        "video_id":    video_id,
        "channel":     channel,
        "niche":       niche,
        "workflow":    workflow,
        "topic":       topic,
        "duration":    duration,
        "uploaded_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    _appendJSON(UPLOADS_FILE, entry)
    print(f"📼 Logged upload: {title}")
    return entry


def getUploads(last: int = 10, channel: str = None) -> list[dict]:
    """Get the last N uploaded videos, optionally filtered by channel."""
    data = _readJSON(UPLOADS_FILE, default=[])
    if channel:
        data = [d for d in data if d.get("channel") == channel]
    return data[-last:]


# ── script cache ───────────────────────────────────────────────────────────

def cacheScript(topic: str, data: dict, channel: str = None):
    """Cache a generated script so we don't call Claude again for same topic."""
    cache = _readJSON(CACHE_FILE, default=[])
    if not isinstance(cache, list):
        cache = []

    # remove existing cache for same topic+channel
    cache = [c for c in cache if not (c.get("topic") == topic and c.get("channel") == channel)]

    cache.append({
        "topic":     topic,
        "channel":   channel,
        "cached_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        **data,
    })
    _writeJSON(CACHE_FILE, cache)
    print(f"💾 Cached script for: '{topic}' [{channel}]")


def getCachedScript(topic: str, channel: str = None) -> dict | None:
    """Get a cached script by topic and channel. Returns None if not cached."""
    cache = _readJSON(CACHE_FILE, default=[])
    for entry in reversed(cache):
        if entry.get("topic") == topic and entry.get("channel") == channel:
            return entry
    return None


def clearCache(topic: str = None, channel: str = None):
    """Clear cache for a specific topic/channel or everything."""
    if topic or channel:
        cache = _readJSON(CACHE_FILE, default=[])
        cache = [
            c for c in cache
            if not (
                (topic   is None or c.get("topic")   == topic) and
                (channel is None or c.get("channel") == channel)
            )
        ]
        _writeJSON(CACHE_FILE, cache)
        print(f"🗑️  Cleared cache — topic={topic} channel={channel}")
    else:
        _writeJSON(CACHE_FILE, [])
        print("🗑️  Cleared all cache")


# ── asset usage history ────────────────────────────────────────────────────

def logUsed(asset_type: str, name: str, channel: str = None):
    """
    Log that an asset was used.
    asset_type: 'music', 'sfx', 'footage'
    """
    history = _readJSON(HISTORY_FILE, default=[])
    if not isinstance(history, list):
        history = []
    history.append({
        "asset_type": asset_type,
        "name":       name,
        "channel":    channel,
        "used_at":    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    _writeJSON(HISTORY_FILE, history)


def getRecentlyUsed(asset_type: str, last: int = 5, channel: str = None) -> list[str]:
    """Get recently used asset names to avoid repetition."""
    history = _readJSON(HISTORY_FILE, default=[])
    filtered = [
        h for h in history
        if h.get("asset_type") == asset_type and
        (channel is None or h.get("channel") == channel)
    ]
    return [h["name"] for h in filtered[-last:]]


def wasRecentlyUsed(asset_type: str, name: str, channel: str = None, last: int = 5) -> bool:
    """Check if an asset was used in the last N videos."""
    return name in getRecentlyUsed(asset_type, last=last, channel=channel)


# ── pipeline logs ──────────────────────────────────────────────────────────

def logRun(
    workflow: str,
    status: str,
    channel: str    = None,
    topic: str      = None,
    duration: float = None,
    error: str      = None,
) -> dict:
    """
    Log a pipeline run.
    status: 'success' | 'failed'
    """
    entry = {
        "workflow": workflow,
        "status":   status,
        "channel":  channel,
        "topic":    topic,
        "duration": duration,
        "error":    error,
        "ran_at":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    _appendJSON(LOGS_FILE, entry)

    icon = "✅" if status == "success" else "❌"
    print(f"{icon} Logged run: {workflow} [{status}]")
    return entry


def getLogs(last: int = 10, channel: str = None, status: str = None) -> list[dict]:
    """Get the last N pipeline logs, optionally filtered by channel or status."""
    logs = _readJSON(LOGS_FILE, default=[])
    if channel:
        logs = [l for l in logs if l.get("channel") == channel]
    if status:
        logs = [l for l in logs if l.get("status") == status]
    return logs[-last:]


def getFailedRuns(last: int = 10, channel: str = None) -> list[dict]:
    """Get the last N failed pipeline runs."""
    return getLogs(last=last, channel=channel, status="failed")