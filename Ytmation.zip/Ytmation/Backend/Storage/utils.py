import json
from pathlib import Path

DB_DIR = Path(__file__).resolve().parent / "db"


def _readJSON(path: Path, default=None):
    """Read a JSON file. Returns default if file doesn't exist."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        return default if default is not None else {}
    with open(path, "r") as f:
        return json.load(f)


def _writeJSON(path: Path, data):
    """Write data to a JSON file."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def _appendJSON(path: Path, entry: dict):
    """Append an entry to a JSON list file."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    data = _readJSON(path, default=[])
    if not isinstance(data, list):
        data = []
    data.append(entry)
    _writeJSON(path, data)