# Storage Module

## Purpose
Persistent JSON logging, script caching, asset usage history, and pipeline run tracking.
All data stored in Storage/db/ as JSON files. Every function accepts a channel= param for filtering.

## Location
`Storage/storage.py`

## DB Files
- Storage/db/uploads.json   — uploaded video records
- Storage/db/cache.json     — cached scripts
- Storage/db/history.json   — asset usage history
- Storage/db/logs.json      — pipeline run logs

## Functions

### logUpload(title, video_id, channel, niche, workflow, topic, duration) -> dict
Log a successfully uploaded video.
```python
from Storage.storage import logUpload
logUpload("Brain deletes memories", "xxxxxxxxxxx", channel="MParkour_psychology", topic="memory")
```

### getUploads(last, channel) -> list[dict]
Get last N uploaded videos, filtered by channel.
```python
from Storage.storage import getUploads
getUploads(last=10, channel="MParkour_psychology")
```

### cacheScript(topic, data, channel)
Cache a generated script to avoid duplicate API calls.
```python
from Storage.storage import cacheScript
cacheScript("memory", {"hook": "...", "full_script": "..."}, channel="MParkour_psychology")
```

### getCachedScript(topic, channel) -> dict | None
Get cached script. Returns None if not cached.
```python
from Storage.storage import getCachedScript
cached = getCachedScript("memory", channel="MParkour_psychology")
if cached:
    script = cached
```

### clearCache(topic, channel)
Clear cache for a topic/channel or everything.
```python
from Storage.storage import clearCache
clearCache(topic="memory", channel="MParkour_psychology")
clearCache()  # clears all
```

### logUsed(asset_type, name, channel)
Log that an asset was used. asset_type: 'music' | 'sfx' | 'footage'
```python
from Storage.storage import logUsed
logUsed("music", "chill_beat", channel="MParkour_psychology")
```

### getRecentlyUsed(asset_type, last, channel) -> list[str]
Get recently used asset names to avoid repetition.
```python
from Storage.storage import getRecentlyUsed
getRecentlyUsed("music", last=5, channel="MParkour_psychology")
```

### wasRecentlyUsed(asset_type, name, channel, last) -> bool
Check if an asset was used recently.
```python
from Storage.storage import wasRecentlyUsed
if wasRecentlyUsed("music", "chill_beat", channel="MParkour_psychology"):
    # pick different track
```

### logRun(workflow, status, channel, topic, duration, error) -> dict
Log a pipeline run. status: 'success' | 'failed'
```python
from Storage.storage import logRun
logRun("MParkour_psychology", "success", channel="MParkour_psychology", topic="memory", duration=127)
logRun("MParkour_psychology", "failed",  channel="MParkour_psychology", error="ElevenLabs timeout")
```

### getLogs(last, channel, status) -> list[dict]
Get pipeline logs filtered by channel and/or status.
```python
from Storage.storage import getLogs
getLogs(last=10, channel="MParkour_psychology")
getLogs(channel="MParkour_psychology", status="failed")
```

### getFailedRuns(last, channel) -> list[dict]
Get failed pipeline runs.
```python
from Storage.storage import getFailedRuns
getFailedRuns(channel="MParkour_psychology")
```

## Workflow Pattern
Every workflow must wrap in try/except and call logRun at the end:
```python
import time
from Storage.storage import logRun

def runWorkflow(topic=None):
    start = time.time()
    try:
        # pipeline steps...
        logRun("workflow_name", "success", channel=CHANNEL, topic=topic,
               duration=round(time.time() - start, 1))
    except Exception as e:
        logRun("workflow_name", "failed", channel=CHANNEL, topic=topic,
               duration=round(time.time() - start, 1), error=str(e))
        raise