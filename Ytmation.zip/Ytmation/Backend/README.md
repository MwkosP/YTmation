# YT Automation Pipeline

Python pipeline for generating and uploading faceless YouTube videos automatically.

---

## Structure

```
YT/
├── Footage/        pick and trim video clips
├── Voice/          TTS via generateSpeech(model=...) + Whisper transcription
├── Script/         script generation (Claude API)
├── Stitching/      all video manipulation (ffmpeg)
├── SFX/            sound effects library
├── Music/          music download (yt-dlp) and library
├── Thumbnail/      thumbnail generation (PIL)
├── Templates/      overlay assets (reddit_card, lower_third, etc)
├── Transitions/    xfade transitions between clips
├── Games/          pygame 2D animations
├── Characters/     mascot pose timelines (+ spoken intro planned)
├── Blender/        3D renders
├── Storage/        JSON logging, caching, history
├── Upload/         YouTube API uploader (not built yet)
├── Workflows/      end to end pipelines per channel
├── Cache/          temp files during rendering
└── test.py         scratch pad for testing
```

---

## Rules

- Every module has a main file and `utils.py` (internal helpers only, never called directly from workflows)
- All ffmpeg video manipulation lives in `Stitching/stitching.py`
- Library modules (SFX, Music, Games, Thumbnail) expose get/list/download funcs only
- Every workflow wraps in try/except and calls `logRun` at the end

---

## Module APIs

**Stitching**
```python
overlayAudio(video, audio)
overlayImage(video, image, start, duration, position)
overlayImages(video, images)
overlaySFX(video, sfx, start, volume)
overlayMultipleSFX(video, sfx_list)
overlayMusic(video, music, volume, fade_out)
burnCaptions(video, timestamps)
resizeVideo(video, width, height)
```

**Voice**
```python
generateSpeech(text, model="gtts")           # or model="orpheus:tara"
listSpeechModels()
getAudioDuration(path)
transcribeAudio(path)                        # Whisper word timestamps
```

**Characters**
```python
renderCharacterTimeline(cues, duration, output, **params)   # silent MP4
listPoses()
resolvePose(name)
# planned: renderCharacterIntro(script, model="gtts"), renderSpokenCharacterTimeline(...)
```

**SFX**
```python
getSFX(name)        # returns path from SFX/library/
listSFX()
downloadSFX(url, name)
```

**Music**
```python
getMusic(name)      # returns path from Music/library/
listMusic()
downloadMusic(url, name)
prepareMusic(name, duration, fade_out)
```

**Games**
```python
renderAnimation(name, duration, **params)
previewAnimation(name, **params)   # renders 3 seconds only
listAnimations()
getAnimation(name)
randomAnimation(duration)
```

**Thumbnail**
```python
generateThumbnail(title, style, **params)
previewThumbnail(title, style, **params)
listTemplates()
getThumbnail(name)
```

**Storage**
```python
logUpload(title, video_id, channel, ...)
getUploads(last, channel)
cacheScript(topic, data, channel)
getCachedScript(topic, channel)
clearCache(topic, channel)
logUsed(asset_type, name, channel)
getRecentlyUsed(asset_type, last, channel)
wasRecentlyUsed(asset_type, name, channel)
logRun(workflow, status, channel, topic, duration, error)
getLogs(last, channel, status)
getFailedRuns(last, channel)
```

---

## ffmpeg Rules

- Never use `format=yuva420p` — breaks alpha channel on overlays
- Timed overlays: `enable='between(t,start,end)'`
- SFX delay: `adelay={ms}|{ms},volume=x`
- Music loop: `stream_loop -1` + `afade=t=out`
- GPU (when available): swap `-c:v libx264 -preset veryfast` with `-c:v h264_nvenc -preset p4`

---

## Workflow Pattern

```python
import time
from Storage.storage import logRun, cacheScript, getCachedScript, logUsed

CHANNEL = "MParkour_psychology"

def runWorkflow(topic=None):
    start = time.time()
    try:
        # 1. check cache before calling Claude
        script = getCachedScript(topic, channel=CHANNEL) or generateScript(topic)
        cacheScript(topic, script, channel=CHANNEL)

        # 2. footage, voice, stitching steps...

        # 3. log assets used
        logUsed("music", "chill_beat", channel=CHANNEL)

        logRun("workflow_name", "success", channel=CHANNEL, topic=topic,
               duration=round(time.time() - start, 1))

    except Exception as e:
        logRun("workflow_name", "failed", channel=CHANNEL, topic=topic,
               duration=round(time.time() - start, 1), error=str(e))
        raise
```

---

## Adding New Animations

Drop a `.py` file in `Games/animations/` with a `run()` function:

```python
def run(duration=10, output=None, **params) -> Path:
    ...
```

It will appear automatically in `listAnimations()`.

---

## Adding New Thumbnail Templates

Drop a `.py` file in `Thumbnail/templates/` with a `run()` function:

```python
def run(title, output, width, height, **params) -> Path:
    ...
```

It will appear automatically in `listTemplates()`.