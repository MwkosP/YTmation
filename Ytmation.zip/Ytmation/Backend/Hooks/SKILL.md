# Hooks — first 3 seconds optimizer

Generates multiple opening hook variants so you can pick the best scroll-stopper before filming or editing.

## Layout

```
Hooks/
├── SKILL.md
├── hooks.py
└── utils.py

Prompts/
├── hooks_system.md      ← AI role (always used)
└── Prompts/hooks.md     ← user template
```

Saves to `Cache/hooks/*.json`.

## Python API

```python
from Hooks.hooks import generateHooks, pickHook, loadHooks

hooks = generateHooks("solo leveling episode recap", limit=5)
best = pickHook(hooks, 0)["spoken"]    # #1 hook line

# Pipeline with Trends
from Trends.trends import getTrends, pickTopic
topic = pickTopic(getTrends("manhwa_recap", limit=3))
generateHooks(topic, limit=5)
```

## CLI

```bash
ollama serve

python Hooks/hooks.py "marble run physics compilation" -n 5
python Hooks/hooks.py "true crime cold case" --seconds 3 --style "dark, serious"
python Hooks/hooks.py --list
```

## Output format

Each hook is a dict:

| Field | Meaning |
|-------|---------|
| `spoken` | Exact narrator line (~3 sec) |
| `visual` | What to show on screen |
| `type` | question, shock, promise, contrarian, tease |

## Args

| Param | Default | Description |
|-------|---------|-------------|
| `topic` | required | Video subject |
| `limit` | 5 | How many variants |
| `seconds` | 3 | Target spoken length |
| `style` | punchy | Tone |
| `temperature` | 0.9 | Higher = more variety |
| `rank` | True | Sort by heuristic score (word count, banned phrases) |
| `critic` | False | Second LLM pass picks + tightens best hook |

```python
generateHooks("AI agents", limit=10, critic=True)  # best quality, slower
pickHook(hooks, 0)  # after rank/critic = best candidate
```

Edit `Prompts/Prompts/hooks.md` and `Hooks/patterns.json` to tune scoring.

## Is this ML?

**Not really.** True hook optimization needs **retention/CTR data** (Insights module + A/B tests).
This module is **generative + heuristics + optional critic** — good drafts, not guaranteed winners.
