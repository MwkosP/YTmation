#!/usr/bin/env python3
"""Generate scroll-stopping opening hooks via Ollama."""

import argparse
import sys
from pathlib import Path

try:
    from .utils import (
        DEFAULT_LIMIT,
        DEFAULT_MODEL,
        DEFAULT_SECONDS,
        DEFAULT_TEMPLATE,
        build_hooks_prompt,
        critic_pick,
        fetch_ollama,
        list_saved,
        load_hooks,
        load_hooks_system,
        parse_hooks,
        pick_hook,
        rank_hooks,
        save_hooks,
    )
except ImportError:
    from utils import (
        DEFAULT_LIMIT,
        DEFAULT_MODEL,
        DEFAULT_SECONDS,
        DEFAULT_TEMPLATE,
        build_hooks_prompt,
        critic_pick,
        fetch_ollama,
        list_saved,
        load_hooks,
        load_hooks_system,
        parse_hooks,
        pick_hook,
        rank_hooks,
        save_hooks,
    )


def loadHooks(path: str | Path) -> list[dict]:
    return load_hooks(path)


def pickHook(hooks: list[dict], index: int = 0) -> dict | None:
    return pick_hook(hooks, index=index)


def generateHooks(
    topic: str,
    limit: int = DEFAULT_LIMIT,
    *,
    seconds: int = DEFAULT_SECONDS,
    style: str = "punchy, scroll-stopping",
    template: str = DEFAULT_TEMPLATE,
    model: str = DEFAULT_MODEL,
    temperature: float = 0.9,
    rank: bool = True,
    critic: bool = False,
    save: bool = True,
) -> list[dict]:
    """Generate `limit` opening hook variants for a video topic."""
    userPrompt = build_hooks_prompt(
        topic, limit=limit, seconds=seconds, style=style, template=template
    )
    print(f"Model: {model}  |  hooks: {limit}  |  ~{seconds}s each\n")
    print("Generating...\n")

    raw = fetch_ollama(
        [
            {"role": "system", "content": load_hooks_system(seconds)},
            {"role": "user", "content": userPrompt},
        ],
        model=model,
        temperature=temperature,
    )
    hooks = parse_hooks(raw, limit)
    if rank:
        hooks = rank_hooks(hooks, seconds=seconds)
        for i, hook in enumerate(hooks, 1):
            hook["id"] = i
    if critic and hooks:
        hooks = critic_pick(topic, hooks, model)

    for hook in hooks:
        scoreText = f"  score={hook['score']}" if "score" in hook else ""
        print(f"  {hook['id']}. [{hook['type']}] {hook['spoken']}{scoreText}")
        if hook.get("visual"):
            print(f"     visual: {hook['visual']}")
        if hook.get("critic_note"):
            print(f"     critic: {hook['critic_note']}")
        print()

    if save and hooks:
        path = save_hooks(
            hooks, topic, meta={"seconds": seconds, "style": style, "model": model}
        )
        print(f"Saved: {path}", file=sys.stderr)

    return hooks


def runCli() -> int:
    parser = argparse.ArgumentParser(description="Generate YouTube opening hooks")
    parser.add_argument("topic", nargs="?", help="Video topic or title")
    parser.add_argument("-n", "--limit", type=int, default=DEFAULT_LIMIT)
    parser.add_argument("--seconds", type=int, default=DEFAULT_SECONDS)
    parser.add_argument("-s", "--style", default="punchy, scroll-stopping")
    parser.add_argument("-m", "--model", default=DEFAULT_MODEL)
    parser.add_argument("-t", "--temperature", type=float, default=0.9)
    parser.add_argument("--no-save", action="store_true")
    parser.add_argument("--no-rank", action="store_true", help="Skip heuristic scoring")
    parser.add_argument("--critic", action="store_true", help="Second LLM pass to pick best")
    parser.add_argument("--list", action="store_true", help="List recent saved hook files")
    args = parser.parse_args()

    if args.list:
        for path in list_saved():
            print(path.name)
        return 0

    if not args.topic:
        parser.error("Provide a topic or use --list")

    generateHooks(
        args.topic,
        args.limit,
        seconds=args.seconds,
        style=args.style,
        model=args.model,
        temperature=args.temperature,
        rank=not args.no_rank,
        critic=args.critic,
        save=not args.no_save,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(runCli())
