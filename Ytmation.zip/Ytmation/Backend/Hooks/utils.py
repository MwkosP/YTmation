import json
import re
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

OLLAMA_URL = "http://127.0.0.1:11434"
DEFAULT_MODEL = "qwen2.5-coder:3b"
ROOT = Path(__file__).resolve().parent.parent
PROMPTS_DIR = ROOT / "Prompts"
USER_PROMPTS_DIR = PROMPTS_DIR / "Prompts"
OUTPUT_DIR = ROOT / "Cache" / "hooks"
DEFAULT_TEMPLATE = "hooks"
DEFAULT_LIMIT = 5
DEFAULT_SECONDS = 3
PATTERNS_FILE = Path(__file__).resolve().parent / "patterns.json"
WORDS_PER_SECOND = 2.5


def fetch_ollama(messages: list[dict], model: str, temperature: float) -> str:
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": temperature},
    }
    req = urllib.request.Request(
        f"{OLLAMA_URL}/api/chat",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=600) as resp:
            return json.loads(resp.read())["message"]["content"]
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach Ollama. Run: ollama serve\n{e}") from e


def load_hooks_system(seconds: int = DEFAULT_SECONDS) -> str:
    text = (PROMPTS_DIR / "hooks_system.md").read_text(encoding="utf-8")
    return text.replace("{seconds}", str(seconds)).strip()


def load_patterns() -> dict:
    if PATTERNS_FILE.exists():
        return json.loads(PATTERNS_FILE.read_text(encoding="utf-8"))
    return {"banned_phrases": [], "strong_openers": [], "max_words": 12, "target_words": 10}


def word_count(text: str) -> int:
    return len(text.split())


def score_hook(hook: dict, *, seconds: int = DEFAULT_SECONDS) -> float:
    """Heuristic ranker, not ML, but filters obvious failures."""
    patterns = load_patterns()
    spoken = hook.get("spoken", "")
    lower = spoken.lower()
    score = 100.0

    max_words = patterns.get("max_words", 12)
    target = patterns.get("target_words", 10)
    words = word_count(spoken)
    if words > max_words:
        score -= (words - max_words) * 15
    elif words <= target:
        score += 10
    if words < 4:
        score -= 20

    ideal = int(seconds * WORDS_PER_SECOND)
    score -= abs(words - ideal) * 3

    for phrase in patterns.get("banned_phrases", []):
        if phrase in lower:
            score -= 40

    for opener in patterns.get("strong_openers", []):
        if lower.startswith(opener):
            score += 15
            break

    if "?" in spoken:
        score += 5
    if hook.get("visual"):
        score += 5
    if len(spoken) > 80:
        score -= 30

    return max(score, 0)


def rank_hooks(hooks: list[dict], *, seconds: int = DEFAULT_SECONDS) -> list[dict]:
    for hook in hooks:
        hook["score"] = round(score_hook(hook, seconds=seconds), 1)
    return sorted(hooks, key=lambda x: x["score"], reverse=True)


def critic_pick(topic: str, hooks: list[dict], model: str) -> list[dict]:
    """Second LLM pass: pick and rewrite the single best hook."""
    shortlist = hooks[:5]
    prompt = (
        f"Topic: {topic}\n\n"
        f"Candidates:\n{json.dumps(shortlist, indent=2)}\n\n"
        "Pick the best scroll-stopping hook. Rewrite 'spoken' to max 12 words if needed. "
        "Return JSON: {\"winner\": {{...}}, \"why\": \"one sentence\"}}"
    )
    raw = fetch_ollama(
        [
            {"role": "system", "content": "You are a YouTube retention expert. JSON only."},
            {"role": "user", "content": prompt},
        ],
        model=model,
        temperature=0.3,
    )
    try:
        if "```" in raw:
            match = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
            if match:
                raw = match.group(1)
        data = json.loads(raw.strip())
        winner = data.get("winner")
        if winner:
            winner["critic_note"] = data.get("why", "")
            winner["score"] = 999
            rest = [hook for hook in hooks if hook.get("spoken") != winner.get("spoken")]
            return [winner] + rest
    except (json.JSONDecodeError, TypeError):
        pass
    return hooks


def load_prompt(name: str) -> str:
    path = USER_PROMPTS_DIR / f"{name}.md"
    if not path.exists():
        raise FileNotFoundError(f"Prompt '{name}' not found in Prompts/Prompts/")
    return path.read_text(encoding="utf-8").strip()


def build_hooks_prompt(
    topic: str,
    *,
    limit: int = DEFAULT_LIMIT,
    seconds: int = DEFAULT_SECONDS,
    style: str = "punchy, scroll-stopping",
    template: str = DEFAULT_TEMPLATE,
) -> str:
    return load_prompt(template).format(
        topic=topic,
        limit=limit,
        seconds=seconds,
        style=style,
    )


def parse_hooks(raw: str, limit: int) -> list[dict]:
    raw = raw.strip()
    if "```" in raw:
        match = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
        if match:
            raw = match.group(1).strip()
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            hooks = data
        elif isinstance(data, dict) and "hooks" in data:
            hooks = data["hooks"]
        else:
            hooks = [data]
    except json.JSONDecodeError:
        hooks = []
        for line in raw.splitlines():
            line = re.sub(r"^\d+[\).\s]+", "", line.strip())
            if line:
                hooks.append({"spoken": line, "visual": "", "type": "unknown"})
    out = []
    for i, hook in enumerate(hooks[:limit], 1):
        if isinstance(hook, str):
            hook = {"spoken": hook, "visual": "", "type": "unknown"}
        out.append({
            "id": i,
            "spoken": hook.get("spoken", hook.get("line", "")).strip(),
            "visual": hook.get("visual", "").strip(),
            "type": hook.get("type", "unknown").strip(),
        })
    return out


def save_hooks(hooks: list[dict], topic: str, meta: dict | None = None) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^\w]+", "_", topic.strip())[:40].strip("_") or "hooks"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = OUTPUT_DIR / f"{slug}_{stamp}.json"
    payload = {
        "topic": topic,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "count": len(hooks),
        "hooks": hooks,
        **(meta or {}),
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path


def load_hooks(path: str | Path) -> list[dict]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return data.get("hooks", data if isinstance(data, list) else [])


def pick_hook(hooks: list[dict], index: int = 0) -> dict | None:
    if not hooks or index >= len(hooks):
        return None
    return hooks[index]


def list_saved(limit: int = 10) -> list[Path]:
    if not OUTPUT_DIR.exists():
        return []
    files = sorted(OUTPUT_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[:limit]
