import io
import time
import requests
from datetime import datetime
from pathlib import Path
from PIL import Image, ImageDraw
from ddgs import DDGS
from rembg import remove

ROOT       = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "Cache" / "images" / "keywords"


def _roundCorners(img: Image.Image, radius: int = 30) -> Image.Image:
    mask = Image.new("L", img.size, 0)
    draw = ImageDraw.Draw(mask)
    draw.rounded_rectangle([0, 0, img.size[0], img.size[1]], radius=radius, fill=255)
    img  = img.convert("RGBA")
    img.putalpha(mask)
    return img


def _removeBackground(img: Image.Image) -> Image.Image:
    buf    = io.BytesIO()
    img.save(buf, format="PNG")
    result = remove(buf.getvalue())
    return Image.open(io.BytesIO(result)).convert("RGBA")


def _downloadImage(url: str) -> Image.Image:
    headers = {"User-Agent": "Mozilla/5.0"}
    r       = requests.get(url, headers=headers, timeout=10)
    r.raise_for_status()
    return Image.open(io.BytesIO(r.content)).convert("RGB")


def fetchImage(
    keyword: str,
    width: int = 400,
    height: int = 400,
    remove_bg: bool = True,
    output: str | Path = None,
) -> Path | None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        slug   = keyword.replace(" ", "_")[:20]
        output = OUTPUT_DIR / f"{slug}_{stamp}.png"

    try:
        time.sleep(1)
        with DDGS() as ddgs:
            results = list(ddgs.images(keyword, max_results=5))

        if not results:
            print(f"  ⚠ No images found for '{keyword}'")
            return None

        img = None
        for result in results:
            try:
                img = _downloadImage(result["image"])
                break
            except Exception:
                continue

        if img is None:
            print(f"  ⚠ Failed to download image for '{keyword}'")
            return None

        img = img.resize((width, height), Image.LANCZOS)

        if remove_bg:
            print(f"  🔄 Removing background for '{keyword}'...")
            img = _removeBackground(img)
        else:
            img = _roundCorners(img, radius=24)

        img.save(str(output), "PNG")
        print(f"  ✓ Image : {keyword} → {output}")
        return Path(output)

    except Exception as e:
        print(f"  ⚠ fetchImage failed for '{keyword}': {e}")
        return None