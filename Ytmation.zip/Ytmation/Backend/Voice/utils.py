import subprocess
from pathlib import Path
import whisper


def _saveAudio(tts, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tts.save(str(path))


def _getAudioDuration(path: Path) -> float:
    result = subprocess.check_output([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(path)
    ])
    return float(result.decode().strip())


def _transcribeAudio(path: Path) -> list[dict]:
    model  = whisper.load_model("base")
    result = model.transcribe(
        str(path),
        word_timestamps=True,
        language="en"
    )
    words = []
    for segment in result["segments"]:
        for word in segment.get("words", []):
            words.append({
                "word":  word["word"].strip(),
                "start": round(word["start"], 3),
                "end":   round(word["end"],   3),
            })
    return words