from datetime import datetime
from pathlib import Path

from Voice.utils import _saveAudio, _getAudioDuration, _transcribeAudio

ROOT       = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "Cache" / "voice"


def generateVoice(
    text: str,
    lang: str = "en",
    slow: bool = False,
    output: str | Path = None,
) -> Path:
    from gtts import gTTS

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OUTPUT_DIR / f"voice_{stamp}.mp3"

    tts = gTTS(text, lang=lang, slow=slow)
    _saveAudio(tts, Path(output))
    return Path(output)


def getAudioDuration(path: str | Path) -> float:
    return _getAudioDuration(Path(path))


def transcribeAudio(path: str | Path) -> list[dict]:
    return _transcribeAudio(Path(path))
