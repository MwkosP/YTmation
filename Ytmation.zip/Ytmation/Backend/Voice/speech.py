"""
Unified TTS entry point — route by model string.

Examples:
    generateSpeech("Hello", model="gtts")
    generateSpeech("Hello", model="orpheus:tara")
    generateSpeech("Hello", model="orpheus", voice="leo")
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "Cache" / "voice"

# provider -> human-readable note (for listSpeechModels)
_SPEECH_PROVIDERS: dict[str, str] = {
    "gtts": "Google Translate TTS (online)",
    "orpheus": "Orpheus via Hugging Face Gradio Space",
    "elevenlabs": "ElevenLabs API (not wired yet)",
}


def _parse_speech_model(model: str) -> tuple[str, str | None]:
    """Parse model='orpheus:tara' -> ('orpheus', 'tara')."""
    name = (model or "gtts").strip()
    if not name:
        name = "gtts"
    if ":" in name:
        provider, variant = name.split(":", 1)
        return provider.strip().lower(), (variant.strip() or None)
    return name.lower(), None


def listSpeechModels() -> list[str]:
    """Known model prefixes for generateSpeech(model=...)."""
    models = ["gtts"]
    from Voice.orpheus import VOICES

    models.extend(f"orpheus:{voice}" for voice in VOICES)
    models.append("elevenlabs")
    return models


def generateSpeech(
    text: str,
    output: str | Path | None = None,
    *,
    model: str = "gtts",
    **kwargs,
) -> Path:
    """
    Generate speech audio from text using the requested TTS backend.

    model:
        gtts              — Google TTS (kwargs: lang, slow)
        orpheus           — Orpheus default voice
        orpheus:tara      — Orpheus with voice suffix
        elevenlabs:ID     — reserved (NotImplementedError until wired)

    Returns path to generated audio file (usually .mp3).
    """
    if not (text or "").strip():
        raise ValueError("text must be non-empty")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        provider, _ = _parse_speech_model(model)
        output = OUTPUT_DIR / f"speech_{provider}_{stamp}.mp3"
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)

    provider, variant = _parse_speech_model(model)

    if provider == "gtts":
        from Voice.voice import generateVoice

        lang = kwargs.pop("lang", "en")
        slow = kwargs.pop("slow", False)
        if kwargs:
            unknown = ", ".join(sorted(kwargs))
            raise TypeError(f"Unknown kwargs for gtts: {unknown}")
        return generateVoice(text, lang=lang, slow=slow, output=output)

    if provider == "orpheus":
        from Voice.orpheus import DEFAULT_VOICE, VOICES, generateOrpheusVoice

        voice = kwargs.pop("voice", None) or variant or DEFAULT_VOICE
        if voice not in VOICES:
            raise ValueError(f"Unknown Orpheus voice {voice!r}. Choose from: {', '.join(VOICES)}")

        orpheus_keys = ("temperature", "top_p", "repetition_penalty", "max_new_tokens")
        orpheus_kwargs = {k: kwargs.pop(k) for k in orpheus_keys if k in kwargs}
        if kwargs:
            unknown = ", ".join(sorted(kwargs))
            raise TypeError(f"Unknown kwargs for orpheus: {unknown}")

        if output.suffix.lower() not in (".mp3", ".wav"):
            output = output.with_suffix(".mp3")
        return generateOrpheusVoice(text, output, voice=voice, **orpheus_kwargs)

    if provider == "elevenlabs":
        raise NotImplementedError(
            "ElevenLabs TTS is not wired yet. Use model='gtts' or model='orpheus:tara'. "
            "The elevenlabs package is listed in pyproject.toml for future use."
        )

    known = ", ".join(_SPEECH_PROVIDERS)
    raise ValueError(f"Unknown speech model {model!r}. Known providers: {known}")
