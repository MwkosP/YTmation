"""
Orpheus TTS via the public Hugging Face Space (MohamedRashad/Orpheus-TTS).

Not part of Hugging Face Inference Providers — this calls the community Gradio Space.
Set HF_TOKEN or HUGGINGFACE_HUB_TOKEN for better rate limits (free tier).

Voices: tara, leah, jess, leo, dan, mia, zac, zoe
"""

from __future__ import annotations

import os
import shutil
import subprocess
from functools import lru_cache
from pathlib import Path

ORPHEUS_SPACE = "MohamedRashad/Orpheus-TTS"
DEFAULT_VOICE = "tara"
VOICES = ("tara", "leah", "jess", "leo", "dan", "mia", "zac", "zoe")


def hfToken() -> str | None:
    return os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")


@lru_cache(maxsize=1)
def _client():
    from gradio_client import Client

    token = hfToken()
    if not token:
        return Client(ORPHEUS_SPACE)
    # gradio_client has used both `token` and `hf_token` across versions.
    try:
        return Client(ORPHEUS_SPACE, token=token)
    except TypeError:
        return Client(ORPHEUS_SPACE, hf_token=token)


def _wavToMp3(wav_path: Path, mp3_path: Path) -> Path:
    mp3_path.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-i",
            str(wav_path),
            "-codec:a",
            "libmp3lame",
            "-qscale:a",
            "2",
            str(mp3_path),
        ],
        check=True,
        capture_output=True,
    )
    return mp3_path


def generateOrpheusVoice(
    text: str,
    output: str | Path,
    *,
    voice: str = DEFAULT_VOICE,
    temperature: float = 0.6,
    top_p: float = 0.95,
    repetition_penalty: float = 1.1,
    max_new_tokens: int = 400,
) -> Path:
    """
    Generate speech with Orpheus on HF Spaces. Returns path to mp3 or wav.
    """
    if voice not in VOICES:
        raise ValueError(f"Unknown voice {voice!r}. Choose from: {', '.join(VOICES)}")

    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)

    client = _client()
    wav_path = client.predict(
        text.strip(),
        voice,
        temperature,
        top_p,
        repetition_penalty,
        max_new_tokens,
        api_name="/generate_speech",
    )
    wav_path = Path(wav_path)
    if not wav_path.is_file():
        raise RuntimeError(f"Orpheus returned no audio for: {text[:80]!r}...")

    if output.suffix.lower() == ".mp3":
        return _wavToMp3(wav_path, output)

    if output.suffix.lower() in (".wav", ""):
        dest = output if output.suffix else output.with_suffix(".wav")
        shutil.copy2(wav_path, dest)
        return dest

    # Default: copy wav then convert if another extension requested
    shutil.copy2(wav_path, output.with_suffix(".wav"))
    return output.with_suffix(".wav")
