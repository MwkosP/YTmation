# Voice Module

## Purpose

Text-to-speech and speech utilities. **All new TTS should go through `generateSpeech(..., model=...)`** — one router for gTTS, Orpheus, and future backends.

Low-level helpers (`generateVoice`, `generateOrpheusVoice`) remain for existing callers; prefer `generateSpeech` in new workflows.

## Location

```
Voice/
├── speech.py      ← primary API (generateSpeech)
├── voice.py       ← gTTS + duration + Whisper transcription
├── orpheus.py     ← Orpheus HF Gradio Space
├── utils.py       ← internal ffprobe / Whisper helpers
└── __init__.py
```

Output cache: `Cache/voice/`

---

## Primary API — `generateSpeech`

```python
from Voice import generateSpeech, listSpeechModels

path = generateSpeech("Hey guys, welcome back.", model="gtts")
path = generateSpeech("Hey guys...", model="orpheus:tara")
path = generateSpeech("Hey guys...", model="orpheus", voice="leo", temperature=0.7)
```

### Parameters

| Param | Default | Description |
|-------|---------|-------------|
| `text` | required | Spoken content |
| `output` | auto in `Cache/voice/` | Destination `.mp3` (Orpheus accepts `.wav`) |
| `model` | `"gtts"` | Backend selector (see below) |
| `**kwargs` | — | Passed to the active backend only |

### `model` values

| `model` | Backend | Extra kwargs |
|---------|---------|--------------|
| `"gtts"` | Google Translate TTS (online) | `lang` (default `"en"`), `slow` (default `False`) |
| `"orpheus"` | Orpheus default voice (`tara`) | `voice`, `temperature`, `top_p`, `repetition_penalty`, `max_new_tokens` |
| `"orpheus:tara"` | Orpheus with voice suffix | same as orpheus; suffix overrides default voice |
| `"orpheus:leo"` | … | Voices: `tara`, `leah`, `jess`, `leo`, `dan`, `mia`, `zac`, `zoe` |
| `"elevenlabs:..."` | **Not wired** | Raises `NotImplementedError` |

### List available model strings

```python
from Voice import listSpeechModels
print(listSpeechModels())
# ['gtts', 'orpheus:tara', 'orpheus:leah', ...]
```

### Orpheus env

Set `HF_TOKEN` or `HUGGINGFACE_HUB_TOKEN` for better Hugging Face rate limits.  
Requires optional extra: `pip install -e ".[voice-orpheus]"` (`gradio_client`).

---

## Legacy / specialized APIs

### `generateVoice` — gTTS only

```python
from Voice.voice import generateVoice

generateVoice("Hello", lang="en", slow=False, output=path)
```

### `generateOrpheusVoice` — Orpheus only

```python
from Voice.orpheus import generateOrpheusVoice

generateOrpheusVoice("Hello", output=path, voice="tara")
```

### Duration & transcription

```python
from Voice import getAudioDuration, transcribeAudio

seconds = getAudioDuration(path)
words = transcribeAudio(path)  # Whisper base, word timestamps
```

---

## Adding a new TTS backend

1. Implement backend in `Voice/<backend>.py` (or wire existing package).
2. Add a branch in `Voice/speech.py` → `generateSpeech`.
3. Document the `model=` string in this file and `Artifacts/srcs/SOURCES.md`.

Callers (`renderSpokenCharacterTimeline`, Math helpers, workflows) should **not** change — only pass a new `model=` value.

---

## Typical workflow usage

```python
from Voice import generateSpeech, getAudioDuration
from Stitching.stitching import overlayAudio

audio = generateSpeech(intro_line, model="orpheus:tara")
duration = getAudioDuration(audio)
video_with_voice = overlayAudio(silent_video, audio)
```

---

## Related (planned)

Character spoken segments use **`Characters.renderSpokenCharacterTimeline(script, model=...)`** — see `Characters/SKILL.md`.
