from datetime import datetime
from pathlib import Path
from Stitching.utils import _runFfmpeg
import shutil

ROOT         = Path(__file__).resolve().parent.parent
OUTPUT_DIR   = ROOT / "Cache" / "stitched"
CAPTIONS_DIR = ROOT / "Cache" / "captioned"
OVERLAY_DIR  = ROOT / "Cache" / "overlay"


def overlayAudio(
    video: str | Path,
    audio: str | Path,
    output: str | Path = None,
) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OUTPUT_DIR / f"stitched_{stamp}.mp4"

    _runFfmpeg([
        "-i", str(video),
        "-i", str(audio),
        "-c:v", "copy",
        "-c:a", "aac",
        "-map", "0:v:0",
        "-map", "1:a:0",
        "-shortest",
        str(output)
    ])

    return Path(output)


def overlayImage(
    video: str | Path,
    image: str | Path,
    output: str | Path = None,
    start: float = 0.0,
    duration: float = 7.0,
    position: str = "center",
) -> Path:
    OVERLAY_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OVERLAY_DIR / f"overlay_{stamp}.mp4"

    end = start + duration

    if position == "center":
        x, y = "(W-w)/2", "(H-h)/2"
    elif position == "top":
        x, y = "(W-w)/2", "40"
    else:
        x, y = "(W-w)/2", "H-h-40"

    _runFfmpeg([
        "-i", str(video),
        "-i", str(image),
        "-filter_complex",
        f"[0:v][1:v]overlay={x}:{y}:enable='between(t,{start},{end})'[outv]",
        "-map", "[outv]",
        "-map", "0:a?",
        "-c:v", "libx264", "-preset", "veryfast",
        "-c:a", "copy",
        str(output)
    ])

    return Path(output)




def overlayImages(
    video: str | Path,
    images: list[dict],
    output: str | Path = None,
    img_size: int = 380,
    duration: float = 3.0,
) -> Path:
    OVERLAY_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OVERLAY_DIR / f"keywords_{stamp}.mp4"

    valid = [item for item in images if item.get("path") and Path(item["path"]).exists()]

    if not valid:
        shutil.copy2(str(video), str(output))
        return Path(output)

    sides        = ["left", "right"]
    inputs       = ["-i", str(video)]
    filter_parts = []

    filter_parts.append("[0:v]copy[v0]")

    for i, item in enumerate(valid):
        inputs.extend(["-i", str(item["path"])])
        idx   = i + 1
        start = item["start"]
        end   = start + duration

        filter_parts.append(
            f"[{idx}:v]scale={img_size}:{img_size}:force_original_aspect_ratio=decrease:flags=lanczos,"
            f"pad={img_size}:{img_size}:(ow-iw)/2:(oh-ih)/2:color=0x00000000"
            f"[img{idx}]"
        )

    prev = "v0"
    for i, item in enumerate(valid):
        idx   = i + 1
        side  = sides[i % 2]
        start = item["start"]
        end   = start + duration
        x     = "40" if side == "left" else "W-w-40"
        y     = "(H-h)/2"
        out   = f"v{idx}"

        filter_parts.append(
            f"[{prev}][img{idx}]overlay={x}:{y}:enable='between(t,{start},{end})'[{out}]"
        )
        prev = out

    _runFfmpeg([
        *inputs,
        "-filter_complex", ";".join(filter_parts),
        "-map", f"[{prev}]",
        "-map", "0:a?",
        "-c:v", "libx264", "-preset", "veryfast",
        "-c:a", "copy",
        str(output)
    ])

    return Path(output)


def burnCaptions(
    video: str | Path,
    timestamps: list[dict],
    output: str | Path = None,
    fontsize: int = 72,
    fontcolor: str = "white",
    position: str = "bottom",
    words_per_chunk: int = 3,
) -> Path:
    CAPTIONS_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CAPTIONS_DIR / f"captioned_{stamp}.mp4"

    chunks = []
    for i in range(0, len(timestamps), words_per_chunk):
        group = timestamps[i:i + words_per_chunk]
        chunks.append({
            "text":  " ".join(w["word"] for w in group),
            "start": group[0]["start"],
            "end":   group[-1]["end"],
        })

    y = "h*0.78"

    filters = []
    for chunk in chunks:
        start = chunk["start"]
        end   = chunk["end"]
        text  = (
            chunk["text"]
            .replace("'", "")
            .replace('"', "")
            .replace(":", "")
            .replace("\\", "")
            .upper()
        )

        fade_in  = f"if(between(t,{start},{start+0.08}),(t-{start})/0.08,1)"
        fade_out = f"if(between(t,{end-0.08},{end}),({end}-t)/0.08,1)"
        alpha    = f"if(between(t,{start},{end}),min({fade_in},{fade_out}),0)"

        filters.append(
            f"drawtext=text='{text}'"
            f":fontcolor=black@0.6"
            f":fontsize={fontsize}"
            f":font=Arial"
            f":x=(w-text_w)/2+3:y={y}+3"
            f":alpha='{alpha}'"
        )

        filters.append(
            f"drawtext=text='{text}'"
            f":fontcolor={fontcolor}"
            f":fontsize={fontsize}"
            f":font=Arial"
            f":x=(w-text_w)/2:y={y}"
            f":alpha='{alpha}'"
        )

    _runFfmpeg([
        "-i", str(video),
        "-vf", ",".join(filters),
        "-c:a", "copy",
        str(output)
    ])

    return Path(output)


def resizeVideo(
    video: str | Path,
    output: str | Path = None,
    width: int = 1080,
    height: int = 1920,
) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OUTPUT_DIR / f"vertical_{stamp}.mp4"

    _runFfmpeg([
        "-i", str(video),
        "-vf", f"crop=ih*9/16:ih,scale={width}:{height}",
        "-c:v", "libx264", "-preset", "veryfast",
        "-c:a", "copy",
        str(output)
    ])

    return Path(output)






def overlaySFX(
    video: str | Path,
    sfx: str | Path,
    output: str | Path = None,
    start: float = 0.0,
    volume: float = 1.0,
) -> Path:
    OVERLAY_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OVERLAY_DIR / f"sfx_{stamp}.mp4"

    _runFfmpeg([
        "-i", str(video),
        "-i", str(sfx),
        "-filter_complex",
        f"[1:a]adelay={int(start*1000)}|{int(start*1000)},volume={volume}[sfx];"
        f"[0:a][sfx]amix=inputs=2:duration=first[aout]",
        "-map", "0:v",
        "-map", "[aout]",
        "-c:v", "copy",
        "-c:a", "aac",
        str(output)
    ])

    return Path(output)







 
def overlaySFX(
    video: str | Path,
    sfx: str | Path,
    output: str | Path = None,
    start: float = 0.0,
    volume: float = 1.0,
) -> Path:
    """Overlay a single SFX onto a video at a given timestamp."""
    from Stitching.utils import _runFfmpeg
 
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
 
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OUTPUT_DIR / f"sfx_{stamp}.mp4"
 
    delay_ms = int(start * 1000)
 
    _runFfmpeg([
        "-i", str(video),
        "-i", str(sfx),
        "-filter_complex",
        f"[1:a]adelay={delay_ms}|{delay_ms},volume={volume}[sfx];"
        f"[0:a][sfx]amix=inputs=2:duration=first[aout]",
        "-map", "0:v",
        "-map", "[aout]",
        "-c:v", "copy",
        "-c:a", "aac",
        str(output)
    ])
 
    return Path(output)
 
 
def overlayMultipleSFX(
    video: str | Path,
    sfx_list: list[dict],
    output: str | Path = None,
) -> Path:
    """
    Overlay multiple SFX in a single ffmpeg pass.
 
    sfx_list format:
    [
        {"path": getSFX("whoosh"), "start": 0.0, "volume": 0.8},
        {"path": getSFX("pop"),    "start": 7.0, "volume": 1.0},
    ]
    """
    from Stitching.utils import _runFfmpeg
 
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
 
    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OUTPUT_DIR / f"sfx_{stamp}.mp4"
 
    valid = [s for s in sfx_list if s.get("path") and Path(s["path"]).exists()]
 
    if not valid:
        shutil.copy2(str(video), str(output))
        return Path(output)
 
    inputs       = ["-i", str(video)]
    filter_parts = []
    sfx_labels   = []
 
    for i, sfx in enumerate(valid):
        inputs.extend(["-i", str(sfx["path"])])
        idx      = i + 1
        delay_ms = int(sfx.get("start", 0.0) * 1000)
        volume   = sfx.get("volume", 1.0)
        label    = f"sfx{idx}"
 
        filter_parts.append(
            f"[{idx}:a]adelay={delay_ms}|{delay_ms},volume={volume}[{label}]"
        )
        sfx_labels.append(f"[{label}]")
 
    # mix all sfx + original audio together
    all_inputs = "[0:a]" + "".join(sfx_labels)
    n          = len(valid) + 1
    filter_parts.append(
        f"{all_inputs}amix=inputs={n}:duration=first[aout]"
    )
 
    _runFfmpeg([
        *inputs,
        "-filter_complex", ";".join(filter_parts),
        "-map", "0:v",
        "-map", "[aout]",
        "-c:v", "copy",
        "-c:a", "aac",
        str(output)
    ])
 
    return Path(output)








def overlayMusic(
    video: str | Path,
    music: str | Path,
    output: str | Path = None,
    volume: float      = 0.15,
    fade_out: float    = 2.0,
) -> Path:
    """
    Add background music to a video. Mixes with existing audio.
    Music is lowered to volume level so voiceover stays on top.

    e.g. overlayMusic(video, music=getMusic("chill_beat"), volume=0.15)
    """
    from Music.utils import _getAudioDuration

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OUTPUT_DIR / f"music_{stamp}.mp4"

    # get video duration for fade out timing
    result = subprocess.run([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(video)
    ], capture_output=True, text=True, check=True)
    duration   = float(result.stdout.strip())
    fade_start = max(0, duration - fade_out)

    _runFfmpeg([
        "-i", str(video),
        "-stream_loop", "-1",
        "-i", str(music),
        "-filter_complex",
        f"[1:a]volume={volume},afade=t=out:st={fade_start}:d={fade_out}[mus];"
        f"[0:a][mus]amix=inputs=2:duration=first[aout]",
        "-map", "0:v",
        "-map", "[aout]",
        "-c:v", "copy",
        "-c:a", "aac",
        "-shortest",
        str(output)
    ])

    return Path(output)