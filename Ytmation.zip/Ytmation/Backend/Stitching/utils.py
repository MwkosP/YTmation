import subprocess
from pathlib import Path


def _runFfmpeg(args: list[str]) -> None:
    subprocess.run(
        ["ffmpeg", "-hide_banner", "-y", *args],
        check=True
    )