#!/usr/bin/env python3
"""Shared helpers and ffmpeg wrappers for Branding module."""

import json
import shutil
import subprocess
from pathlib import Path

ROOT         = Path(__file__).resolve().parent.parent
BRANDING_DIR = Path(__file__).resolve().parent
PRESETS_DIR  = BRANDING_DIR / "presets"
OUTPUT_DIR   = ROOT / "Cache" / "branded"


def run_command(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True, capture_output=True)


def require_tool(name: str) -> None:
    if shutil.which(name) is None:
        raise RuntimeError(f"Required tool not found: {name}")


def load_preset(name: str) -> dict:
    path = PRESETS_DIR / f"{name}.json"
    if not path.exists():
        available = [p.stem for p in PRESETS_DIR.glob("*.json")]
        raise FileNotFoundError(
            f"Preset '{name}' not found. Available: {', '.join(available)}"
        )
    return json.loads(path.read_text(encoding="utf-8"))


def list_presets() -> list[str]:
    return sorted(p.stem for p in PRESETS_DIR.glob("*.json"))


def probe_duration(path: str | Path) -> float:
    raw = subprocess.check_output([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "json", str(path)
    ])
    data = json.loads(raw.decode())
    return float(data.get("format", {}).get("duration") or 0)


def probe_resolution(path: str | Path) -> tuple[int, int]:
    raw = subprocess.check_output([
        "ffprobe", "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=width,height",
        "-of", "json", str(path)
    ])
    data = json.loads(raw.decode())
    stream = data.get("streams", [{}])[0]
    return int(stream.get("width", 1920)), int(stream.get("height", 1080))


def has_audio(path: str | Path) -> bool:
    raw = subprocess.check_output([
        "ffprobe", "-v", "error",
        "-select_streams", "a",
        "-show_entries", "stream=index",
        "-of", "json", str(path)
    ])
    data = json.loads(raw.decode())
    return bool(data.get("streams"))


def ensure_output_dir() -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUT_DIR


def resolve_path(relative: str) -> Path:
    """Resolve a path relative to Branding/ folder."""
    return BRANDING_DIR / relative


def prepend_clip(main: Path, clip: Path, output: Path) -> None:
    """Prepend a clip to the beginning of main video."""
    run_command([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(clip),
        "-i", str(main),
        "-filter_complex",
        "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]",
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "aac",
        str(output),
    ])


def append_clip(main: Path, clip: Path, output: Path) -> None:
    """Append a clip to the end of main video."""
    run_command([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(main),
        "-i", str(clip),
        "-filter_complex",
        "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]",
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "aac",
        str(output),
    ])


def add_watermark(
    main: Path,
    logo: Path,
    output: Path,
    *,
    position: str = "topright",
    opacity: float = 0.6,
    scale: float = 0.08,
) -> None:
    """Burn a watermark logo into the video."""
    positions = {
        "topright":    "main_w-overlay_w-20:20",
        "topleft":     "20:20",
        "bottomright": "main_w-overlay_w-20:main_h-overlay_h-20",
        "bottomleft":  "20:main_h-overlay_h-20",
        "center":      "(main_w-overlay_w)/2:(main_h-overlay_h)/2",
    }
    pos = positions.get(position, positions["topright"])
    run_command([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(main),
        "-i", str(logo),
        "-filter_complex",
        f"[1:v]scale=iw*{scale}:-1,format=rgba,colorchannelmixer=aa={opacity}[wm];"
        f"[0:v][wm]overlay={pos}[v]",
        "-map", "[v]", "-map", "0:a?",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "copy",
        str(output),
    ])


def add_lower_third(
    main: Path,
    output: Path,
    *,
    text: str,
    font: str = "",
    color: str = "white",
    bg_color: str = "black@0.5",
    position: str = "bottom",
    start: float = 1.0,
    duration: float = 3.0,
    fontsize: int = 48,
) -> None:
    """Add a text lower third overlay."""
    y_pos = "main_h-th-60" if position == "bottom" else "60"
    font_arg = f":fontfile={font}" if font else ""
    run_command([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(main),
        "-vf",
        f"drawtext=text='{text}'"
        f"{font_arg}"
        f":fontcolor={color}"
        f":fontsize={fontsize}"
        f":box=1:boxcolor={bg_color}"
        f":boxborderw=20"
        f":x=(w-text_w)/2:y={y_pos}"
        f":enable='between(t,{start},{start + duration})'",
        "-map", "0:a?",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "copy",
        str(output),
    ])


def apply_lut(
    main: Path,
    output: Path,
    *,
    lut: Path,
    intensity: float = 1.0,
) -> None:
    """Apply a .cube LUT color grade to video."""
    if not lut.exists():
        print(f"Warning: LUT not found at {lut}, skipping color grade.")
        run_command([
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-i", str(main), "-c", "copy", str(output)
        ])
        return
    run_command([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(main),
        "-vf", f"lut3d={lut}:interp=trilinear",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-c:a", "copy",
        str(output),
    ])