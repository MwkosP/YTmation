import json
from pathlib import Path

ROOT         = Path(__file__).resolve().parent
CHANNELS_DIR = ROOT / "channels"


def loadChannel(channel: str) -> dict:
    """Load channel.json for a channel."""
    path = CHANNELS_DIR / channel / "channel.json"
    if not path.exists():
        raise FileNotFoundError(f"Channel '{channel}' not found at {path}")
    with open(path) as f:
        return json.load(f)


def loadBranding(channel: str) -> dict:
    """Load branding.json for a channel."""
    path = CHANNELS_DIR / channel / "branding.json"
    if not path.exists():
        raise FileNotFoundError(f"Branding for '{channel}' not found at {path}")
    with open(path) as f:
        return json.load(f)


def loadPreset(channel: str, preset: str) -> dict:
    """Load a preset json for a channel."""
    path = CHANNELS_DIR / channel / "presets" / f"{preset}.json"
    if not path.exists():
        available = listPresets(channel)
        raise FileNotFoundError(
            f"Preset '{preset}' not found for '{channel}'. Available: {available}"
        )
    with open(path) as f:
        return json.load(f)


def listPresets(channel: str) -> list[str]:
    """List all presets for a channel."""
    presets_dir = CHANNELS_DIR / channel / "presets"
    if not presets_dir.exists():
        return []
    return [f.stem for f in sorted(presets_dir.glob("*.json"))]


def listChannels() -> list[str]:
    """List all available channels."""
    if not CHANNELS_DIR.exists():
        return []
    return [f.name for f in sorted(CHANNELS_DIR.iterdir()) if f.is_dir()]