#!/usr/bin/env python3
"""YouTube revenue calculator — main entry point."""

try:
    from .utils import _estimate, _print_report
except ImportError:
    from utils import _estimate, _print_report


def calculateUserRevenue(
    views: float,
    *,
    country: str = "global",
    niche: str = "entertainment",
    video_duration: float = 10.0,
    avg_watch: float | None = None,
    is_short: bool = False,
    num_videos: int = 1,
    silent: bool = False,
) -> dict:
    """
    Calculate and display YouTube revenue estimates.

    Args:
        views:          total views (across all videos if num_videos > 1)
        country:        country code e.g. us, gr, uk, de
        niche:          content niche e.g. finance, blender, satisfying
        video_duration: video length in minutes
        avg_watch:      average watch time in minutes (default: 40% of duration)
        is_short:       True if YouTube Short
        num_videos:     split views across this many videos
        silent:         if True returns dict without printing

    Returns:
        dict with low, realistic, high estimates per video and total
    """
    views_per_video = views / num_videos

    result = _estimate(
        views=views_per_video,
        country=country,
        niche=niche,
        video_duration=video_duration,
        avg_watch=avg_watch,
        is_short=is_short,
    )

    result["num_videos"]      = num_videos
    result["views_per_video"] = views_per_video
    result["total_views"]     = views
    result["total_low"]       = round(result["low"]       * num_videos, 2)
    result["total_realistic"] = round(result["realistic"] * num_videos, 2)
    result["total_high"]      = round(result["high"]      * num_videos, 2)

    if not silent:
        _print_report(result, num_videos)

    return result


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Estimate YouTube revenue")
    parser.add_argument("views",           type=float,              help="Total views")
    parser.add_argument("--country", "-c", default="global",        help="Country code e.g. us gr uk")
    parser.add_argument("--niche",   "-n", default="entertainment", help="Niche e.g. finance blender satisfying")
    parser.add_argument("--duration", "-d",type=float, default=10,  help="Video duration in minutes")
    parser.add_argument("--watch",   "-w", type=float, default=None,help="Avg watch time in minutes")
    parser.add_argument("--short",   "-s", action="store_true",     help="YouTube Short")
    parser.add_argument("--videos",  "-v", type=int,   default=1,   help="Number of videos")
    args = parser.parse_args()

    calculateUserRevenue(
        args.views,
        country=args.country,
        niche=args.niche,
        video_duration=args.duration,
        avg_watch=args.watch,
        is_short=args.short,
        num_videos=args.videos,
    )