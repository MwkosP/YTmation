#!/usr/bin/env python3
"""Internal helpers for revenue estimation — not for direct use."""

# ─── RPM BY COUNTRY — real 2026 data ─────────────────────
# USA $3-11, India $0.50-2, Gaming $1-3, Finance $8-20 
# US viewer worth 5-8x more than Southeast Asia viewer 

COUNTRY_RPM = {
    # ── Tier 1 — $6-12 base ──────────────────────────────
    "us":   10.0,   # $3-11 RPM verified — top advertiser market
    "no":    8.0,   # Norway — high CPM
    "ch":    8.0,   # Switzerland
    "dk":    7.5,   # Denmark
    "au":    7.0,   # Australia
    "uk":    7.0,   # United Kingdom
    "ca":    6.5,   # Canada
    "se":    6.5,   # Sweden
    "nl":    6.0,   # Netherlands
    "de":    6.0,   # Germany
    "at":    5.5,   # Austria
    "nz":    5.5,   # New Zealand
    "fi":    5.5,   # Finland
    "ie":    5.5,   # Ireland
    "sg":    5.5,   # Singapore

    # ── Tier 2 — $3-6 base ───────────────────────────────
    "be":    5.0,   # Belgium
    "fr":    5.0,   # France
    "jp":    5.0,   # Japan
    "hk":    4.5,   # Hong Kong
    "kr":    4.0,   # South Korea
    "it":    3.5,   # Italy
    "es":    3.0,   # Spain
    "il":    4.0,   # Israel
    "ae":    4.5,   # UAE
    "sa":    3.5,   # Saudi Arabia

    # ── Tier 3 — $1.5-3 base ─────────────────────────────
    "pt":    2.5,   # Portugal
    "gr":    2.0,   # Greece
    "pl":    2.0,   # Poland
    "cz":    2.0,   # Czech Republic
    "hu":    1.8,   # Hungary
    "ro":    1.5,   # Romania
    "hr":    1.8,   # Croatia
    "bg":    1.5,   # Bulgaria
    "mx":    1.8,   # Mexico
    "br":    1.5,   # Brazil
    "ar":    1.2,   # Argentina
    "cl":    1.5,   # Chile
    "co":    1.2,   # Colombia
    "za":    1.5,   # South Africa
    "tw":    2.5,   # Taiwan
    "my":    1.5,   # Malaysia
    "th":    1.2,   # Thailand

    # ── Tier 4 — $0.5-1.5 base ───────────────────────────
    "tr":    1.2,   # Turkey
    "ru":    1.0,   # Russia
    "ua":    1.0,   # Ukraine
    "in":    0.9,   # India — huge volume, low RPM
    "id":    0.8,   # Indonesia
    "ph":    0.8,   # Philippines
    "vn":    0.7,   # Vietnam
    "ng":    0.6,   # Nigeria
    "pk":    0.5,   # Pakistan
    "bd":    0.5,   # Bangladesh
    "eg":    0.6,   # Egypt

    # ── Special ───────────────────────────────────────────
    "global": 2.5,  # mixed international audience
}


# ─── RPM BY NICHE — real 2026 data ───────────────────────
# Base RPM assumes global mixed audience ($1.8 base)
# Multiplier brings it to realistic niche RPM
# Sources: FluxNote, OutlierKit, TubeBuddy, Epidemic Sound 2025-2026

NICHE_MULTIPLIER = {

    # ── Tier S — $25-50 RPM ──────────────────────────────
    "insurance":              22.0,   # $40-50 RPM — most expensive keywords ever
    "finance_investing":      15.0,   # $25-40 RPM — Graham Stephan territory
    "personal_finance":       12.0,   # $20-30 RPM
    "credit_cards":           13.0,   # $22-35 RPM

    # ── Tier A — $10-25 RPM ──────────────────────────────
    "legal":                  10.0,   # $18-22 RPM
    "tax":                     9.0,   # $16-20 RPM
    "real_estate":             8.0,   # $14-18 RPM
    "b2b_saas":               11.0,   # $20-25 RPM — highest per view after finance
    "business":                7.0,   # $12-18 RPM
    "software_tutorials":      6.5,   # $12-16 RPM
    "crypto":                  7.5,   # $13-18 RPM — volatile
    "mortgage":                9.5,   # $17-22 RPM

    # ── Tier B — $5-12 RPM ───────────────────────────────
    "health_medical":          5.5,   # $9-13 RPM
    "mental_health":           4.5,   # $8-11 RPM
    "senior_health":           4.0,   # $6-8 RPM — 19x growth, low competition
    "weight_loss":             4.5,   # $7-10 RPM
    "tech_reviews":            4.0,   # $6-9 RPM
    "ai_tech":                 4.5,   # $7-10 RPM — growing fast
    "education":               2.5,   # $4-6 RPM
    "animated_storytelling":   5.5,   # $9-13 RPM — faceless friendly
    "true_crime":              4.5,   # $8-12 RPM
    "soundscape_sleep":        6.5,   # $10.92 RPM — verified OutlierKit
    "english_learning":        7.0,   # $11.88 RPM — verified OutlierKit
    "manhwa_recaps":           6.0,   # $10.45 RPM — verified OutlierKit
    "literary_analysis":       5.5,   # $9.15 RPM — verified OutlierKit
    "philosophy":              4.5,   # $7-12 RPM
    "jungian_psychology":      4.0,   # $7.13 RPM — verified OutlierKit
    "veteran_stories":         4.0,   # $7.13 RPM — verified OutlierKit
    "history":                 3.5,   # $5-10 RPM
    "motivational":            3.5,   # $5-9 RPM
    "space_astronomy":         3.0,   # $4-8 RPM
    "cooking_food":            3.0,   # $4-7 RPM
    "fitness":                 3.5,   # $5-8 RPM

    # ── Tier C — $2-5 RPM ────────────────────────────────
    "betrayal_stories":        4.0,   # $12.82 RPM — high but 200K competition
    "parenting":               2.5,   # $3-6 RPM
    "travel":                  2.5,   # $3-6 RPM
    "diy_crafts":              2.0,   # $3-5 RPM
    "beauty_makeup":           2.5,   # $3-6 RPM
    "fashion":                 2.0,   # $3-5 RPM
    "sports":                  2.0,   # $3-5 RPM
    "news_politics":           2.5,   # $3-6 RPM — volatile, demonetization risk
    "geopolitics":             3.0,   # $4-7 RPM
    "comedy":                  1.8,   # $2-5 RPM
    "vlogs":                   1.5,   # $2-4 RPM
    "pets_animals":            1.8,   # $2-4 RPM
    "kids_family":             1.2,   # $1.5-3 RPM — made for kids = low RPM

    # ── Tier D — $0.5-2 RPM ──────────────────────────────
    "gaming":                  1.2,   # $1-3 RPM — young audience, ad blockers
    "gaming_reviews":          3.0,   # $6-10 RPM — adult gamers, exception
    "entertainment":           1.2,   # $2-4 RPM
    "satisfying":              1.0,   # $1.5-3 RPM
    "blender_physics":         1.0,   # $1.5-3 RPM
    "blender":                 1.0,   # $1.5-3 RPM
    "3d_animation":            1.2,   # $2-3 RPM
    "music":                   0.7,   # $1-2 RPM — Content ID eats revenue
    "music_covers":            0.5,   # $0.8-1.5 RPM — worst for monetization
    "memes":                   0.5,   # $0.8-1.5 RPM
    "reaction":                0.8,   # $1-2 RPM — copyright risk
    "asmr":                    1.5,   # $2-4 RPM
    "lofi_music":              1.0,   # $1.5-3 RPM

    # ── Shorts (flat rate regardless of niche) ────────────
    "shorts":                  0.03,  # $0.03-0.08 per 1000 views flat
}


def _ads_per_view(watch_minutes: float) -> float:
    if watch_minutes < 2:    return 0.5
    if watch_minutes < 5:    return 1.0
    if watch_minutes < 10:   return 1.5
    if watch_minutes < 20:   return 2.0
    if watch_minutes < 40:   return 2.5
    return 3.0


def _estimate(
    views: float,
    country: str,
    niche: str,
    video_duration: float,
    avg_watch: float | None,
    is_short: bool,
) -> dict:
    if is_short:
        rpm = 0.05
        earnings = (views / 1000) * rpm
        return {
            "views":       views,
            "format":      "Short",
            "rpm":         rpm,
            "final_rpm":   rpm,
            "low":         round(earnings * 0.7, 2),
            "realistic":   round(earnings, 2),
            "high":        round(earnings * 1.5, 2),
        }

    base_rpm   = COUNTRY_RPM.get(country.lower(), 1.8)
    multiplier = NICHE_MULTIPLIER.get(niche.lower(), 1.0)
    rpm        = base_rpm * multiplier
    watch      = avg_watch if avg_watch else video_duration * 0.4
    ad_factor  = _ads_per_view(watch)
    rpm        = rpm * ad_factor / 2.0
    earnings   = (views / 1000) * rpm

    return {
        "views":        views,
        "format":       "Long form",
        "country":      country.upper(),
        "niche":        niche,
        "base_rpm":     round(base_rpm, 2),
        "niche_mult":   multiplier,
        "final_rpm":    round(rpm, 2),
        "avg_watch":    watch,
        "ads_per_view": ad_factor,
        "low":          round(earnings * 0.7, 2),
        "realistic":    round(earnings, 2),
        "high":         round(earnings * 1.5, 2),
    }


def _print_report(result: dict, num_videos: int) -> None:
    watch = result.get("avg_watch", 0)
    is_short = result["format"] == "Short"

    print(f"\n{'═'*45}")
    print(f"  YouTube Revenue Estimate")
    print(f"{'═'*45}")
    print(f"  Format       : {result['format']:>12}")
    print(f"  Total views  : {result['total_views']:>12,.0f}")
    print(f"  Videos       : {num_videos:>12,}")
    print(f"  Views/video  : {result['views_per_video']:>12,.0f}")
    if not is_short:
        print(f"  Country      : {result['country']:>12}")
        print(f"  Niche        : {result['niche']:>12}")
        print(f"  Avg watch    : {watch:>11.0f}m")
        print(f"  RPM          : ${result['final_rpm']:>10.2f}")
    print(f"{'─'*45}")
    print(f"  Per video:")
    print(f"    Low        : ${result['low']:>10,.2f}")
    print(f"    Realistic  : ${result['realistic']:>10,.2f}")
    print(f"    High       : ${result['high']:>10,.2f}")
    if num_videos > 1:
        print(f"{'─'*45}")
        print(f"  Total ({num_videos} videos):")
        print(f"    Low        : ${result['total_low']:>10,.2f}")
        print(f"    Realistic  : ${result['total_realistic']:>10,.2f}")
        print(f"    High       : ${result['total_high']:>10,.2f}")
    print(f"{'═'*45}\n")