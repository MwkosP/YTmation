#!/usr/bin/env python3
"""Prompt template access for script and hook generation."""

import argparse

try:
    from .utils import (
        HOOKS_SYSTEM_PROMPT,
        SYSTEM_PROMPT,
        ensure_prompt_exists,
        list_prompt_names,
        prompt_path,
        read_prompt_file,
    )
except ImportError:
    from utils import (
        HOOKS_SYSTEM_PROMPT,
        SYSTEM_PROMPT,
        ensure_prompt_exists,
        list_prompt_names,
        prompt_path,
        read_prompt_file,
    )


def listPrompts() -> list[str]:
    return list_prompt_names()


def loadPrompt(name: str) -> str:
    path = prompt_path(name)
    ensure_prompt_exists(path, name)
    return read_prompt_file(path)


def loadSystemPrompt() -> str:
    return read_prompt_file(SYSTEM_PROMPT)


def loadHooksSystemPrompt(seconds: int = 3) -> str:
    return read_prompt_file(HOOKS_SYSTEM_PROMPT).replace("{seconds}", str(seconds)).strip()


def buildPrompt(
    name: str,
    *,
    topic: str,
    durationMin: int | None = 5,
    style: str | None = "educational, conversational",
    limit: int | None = None,
    seconds: int | None = None,
) -> str:
    values = {
        "topic": topic,
        "duration_min": durationMin or 5,
        "style": style or "educational, conversational",
        "limit": limit or 5,
        "seconds": seconds or 3,
    }
    return loadPrompt(name).format(**values)


def runCli() -> int:
    parser = argparse.ArgumentParser(description="List or print prompt templates")
    parser.add_argument("name", nargs="?", help="Prompt template name")
    parser.add_argument("--system", action="store_true", help="Print the main system prompt")
    parser.add_argument("--hooks-system", action="store_true", help="Print the hooks system prompt")
    parser.add_argument("--seconds", type=int, default=3)
    args = parser.parse_args()

    if args.system:
        print(loadSystemPrompt())
        return 0
    if args.hooks_system:
        print(loadHooksSystemPrompt(args.seconds))
        return 0
    if args.name:
        print(loadPrompt(args.name))
        return 0

    for name in listPrompts():
        print(name)
    return 0


if __name__ == "__main__":
    raise SystemExit(runCli())
