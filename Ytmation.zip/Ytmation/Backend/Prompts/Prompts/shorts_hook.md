Write a **YouTube Short** script (under 60 seconds spoken).

Topic: {topic}
Tone: {style}

Structure:
- [HOOK] — first line must stop the scroll (question, shock, or promise)
- [BODY] — one idea only; 3–5 short sentences max
- [CTA] — one line (follow, comment, part 2)

No timestamps. No section labels in the final output except mentally — deliver tight spoken lines only.
