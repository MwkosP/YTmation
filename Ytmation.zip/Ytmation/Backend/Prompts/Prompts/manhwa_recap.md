Write a **manhwa recap** narration script.

Series / episode focus: {topic}
Target length: about {duration_min} minutes.
Tone: {style} — dramatic, fast-paced, cliffhanger energy.

Structure:
- [HOOK] — tease the biggest twist without spoiling the ending
- [BODY] — chronological recap; name characters clearly; build tension each beat
- Pause beats before reveals ("But what he didn't know was...")
- [CTA] — comment favorite moment, subscribe for next episode

Avoid meta commentary. Stay in-story. No "welcome back to the channel" filler.
