Write a script for a **long-form ambient / soundscape** video (1hr+ style, but scaled to requested length).

Theme: {topic}
Target length: about {duration_min} minutes.
Tone: {style} — calm, slow, ASMR-friendly.

Structure:
- [HOOK] — soft welcome; what listener will feel (sleep, focus, relax)
- [BODY] — sparse narration every few minutes only; describe atmosphere, not plot
- Long pauses implied with "..." between lines
- [CTA] — gentle ask to like/subscribe for more soundscapes

Minimal talking. Let silence and sound design dominate.
