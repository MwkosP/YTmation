# Psychology Fact Script Template

## Format
- Duration: 60 seconds
- Facts per video: 1
- Style: engaging, conversational, slightly mind-blowing
- Audience: general, 16-35 year olds
- No jargon — explain like talking to a friend

## Structure (60 seconds = ~150 words)

### Hook (0-5s) — 15 words max
Start with a question or shocking statement that makes them stop scrolling.
Examples:
- "Your brain is literally lying to you right now."
- "Did you know you make 35,000 decisions every single day?"
- "The reason you can't stop scrolling is actually science."

### Fact explanation (5-45s) — 100 words
- State the fact clearly
- Explain WHY it happens (the science behind it)
- Give a real life example they can relate to
- Keep it conversational — no academic language

### Mind blow moment (45-55s) — 20 words
- One sentence that makes them think
- Should feel like a revelation
- Makes them want to share it

### CTA (55-60s) — 10 words max
- "Follow for more mind-blowing psychology facts"
- Or "Comment if this happened to you"

## Tone
- Conversational, not academic
- Slightly dramatic but not clickbaity
- Short sentences — this is spoken word
- No filler words like "basically" or "essentially"

## Example output

Hook:
"Your brain deletes memories every single time you remember them."

Fact:
"Every time you recall a memory, your brain actually reconstructs it from scratch.
And each time it does — it changes slightly.
This is called memory reconsolidation.
It means your oldest memories are actually the least accurate.
The more you remember something, the more distorted it becomes.
Your brain is literally rewriting your past every time you think about it."

Mind blow:
"That embarrassing thing from 10 years ago? You've changed it so many times — it probably never happened the way you remember."

CTA:
"Follow for a new psychology fact every day."

## Variables
- {topic} — the psychology topic e.g. "memory", "anxiety", "dopamine"
- {fact} — the core fact in one sentence
- {explanation} — 3-4 sentence explanation
- {example} — real life relatable example
- {mindblow} — the revelation sentence