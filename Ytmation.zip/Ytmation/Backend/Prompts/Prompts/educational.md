Write an **educational YouTube** script.

Topic: {topic}
Target length: about {duration_min} minutes.
Tone: {style} — clear, friendly expert explaining to a curious beginner.

Structure:
- [HOOK] — state the problem or question viewers searched for
- [BODY] — 3–5 numbered beats; one concept per beat; analogies welcome
- Recap key takeaway in one sentence before CTA
- [CTA] — ask a question in comments, subscribe for part 2 if series

Define jargon when used. No fluff.
