Generate exactly {limit} different opening hooks for a YouTube video about: {topic}

Tone: {style}
Each hook must fit in ~{seconds} seconds spoken.

Return JSON array:
[
  {{
    "spoken": "the exact words the narrator says",
    "visual": "what appears on screen in those 3 seconds",
    "type": "question | shock | promise | contrarian | tease"
  }}
]
