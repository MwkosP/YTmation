Write a YouTube video script about: {topic}

Target length: about {duration_min} minutes of spoken narration.
Tone/style: {style}
