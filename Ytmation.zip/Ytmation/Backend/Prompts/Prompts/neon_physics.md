Write a YouTube script for a **satisfying neon physics compilation** video.

Topic / theme: {topic}
Target length: about {duration_min} minutes.
Tone: {style} — hype, minimal words, maximum impact.

Structure:
- [HOOK] — one wild visual tease in under 10 seconds
- [BODY] — short segments between clips (1–2 sentences each); describe the vibe, not every object
- Use timestamps every 30–60 seconds for edit sync
- [CTA] — subscribe for daily physics satisfaction

Keep narration sparse. The visuals carry the video.
