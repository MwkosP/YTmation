from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PROMPTS_DIR = Path(__file__).resolve().parent
USER_PROMPTS_DIR = PROMPTS_DIR / "Prompts"
SYSTEM_PROMPT = PROMPTS_DIR / "system.md"
HOOKS_SYSTEM_PROMPT = PROMPTS_DIR / "hooks_system.md"


def read_prompt_file(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def prompt_path(name: str) -> Path:
    return USER_PROMPTS_DIR / f"{name}.md"


def ensure_prompt_exists(path: Path, name: str) -> None:
    if not path.exists():
        available = ", ".join(list_prompt_names()) or "(none)"
        raise FileNotFoundError(f"Prompt '{name}' not found. Available: {available}")


def list_prompt_names() -> list[str]:
    return sorted(path.stem for path in USER_PROMPTS_DIR.glob("*.md"))
