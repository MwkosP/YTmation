#from Workflows.channels.MParkour_psychology import runMParkourPsychology



#______________________
#Minecraft Parkour Psychology
#______________________

#runMParkourPsychology()

#==================================================================================================================
'''
from Music.music import downloadMusic
#downloadMusic("https://www.youtube.com/watch?v=jfKfPfyJRdk", "ambient")

from Workflows.channels.Mathmwk import runMathmwk
video, thumb = runMathmwk(quality="low", format="long")
'''
'''
from Workflows.channels.MathmwkGoldenRatio import runMathmwkGoldenRatio

video, thumb = runMathmwkGoldenRatio(quality="low", format="long")
'''

'''
from Workflows.channels.MathmwkInfinity import runMathmwkInfinity

video, thumb = runMathmwkInfinity(quality="low", format="long")
'''
'''
from Workflows.channels.MathmwkEuler import runMathmwkEuler

video, thumb = runMathmwkEuler(quality="low", format="long")
'''
'''
from Workflows.channels.MathmwkMontyHall import runMathmwkMontyHall

video, thumb = runMathmwkMontyHall(quality="high", format="long")
'''
'''
from Workflows.channels.MathmwkGravity import runMathmwkGravity

video, thumb = runMathmwkGravity(quality="low", format="long")
'''

'''
from Workflows.channels.MathmwkBirthday import runMathmwkBirthday

video, thumb = runMathmwkBirthday(quality="low", format="long")
'''







''''

from SFX.sfx import getSFX, listSFX
from Stitching.stitching import overlaySFX

# check what sfx you have
print(listSFX())

# test overlay
whoosh = getSFX("wooshLongCinematic")
result = overlaySFX(
    video="Cache/overlay/overlay_20260523_125420.mp4",
    sfx=whoosh,
    start=0.0,
    volume=0.8,
)
print("Done:", result)
'''





"""
from Games.games import renderAnimation, listAnimations, previewAnimation

print(listAnimations())

# quick 3 second preview first
result = previewAnimation("bouncing_balls", ball_count=8)
print("Done:", result)

result = previewAnimation("bouncingBallsInsideCircle", ball_count=8, circle_radius=450)
print("Done:", result)
"""



'''
from Music.music import downloadMusic, getMusic, listMusic

# download a track
downloadMusic("https://www.youtube.com/watch?v=dMn2MNWjIdo", "chill_beat")

# check library
print(listMusic())
'''





'''
from Script.psychology_fact import generatePsychologyFact
from Storage.storage import logRun, getLogs, cacheScript, getCachedScript, logUsed, wasRecentlyUsed

CHANNEL = "MParkour_psychology"

# cache check before calling Claude
cached = getCachedScript("memory", channel=CHANNEL)
if cached:
    script = cached
else:
    script = generatePsychologyFact("memory")
    cacheScript("memory", script, channel=CHANNEL)

# log asset usage
logUsed("music", "chill_beat", channel=CHANNEL)
logUsed("sfx", "quickWoosh", channel=CHANNEL)

# avoid repeating music
if wasRecentlyUsed("music", "chill_beat", channel=CHANNEL, last=5):
    music = getMusic("lofi_rain")  # pick different one

# log run
logRun("MParkour_psychology", "success", channel=CHANNEL, topic="memory", duration=127)

# check logs per channel
print(getLogs(channel=CHANNEL))
print(getLogs(channel=CHANNEL, status="failed"))
'''





'''
from Transitions.transitions import listTransitions, combineMedia

# see all available transitions
listTransitions()
'''







'''
from Thumbnail.thumbnail import generateThumbnail, listTemplates, previewThumbnail

print(listTemplates())

# test bold text
thumb = previewThumbnail(
    title="Your brain deletes memories every time you remember them",
    style="bold_text",
    accent_color="#FF4500",
)
print("Done:", thumb)


thumb = previewThumbnail(
    title="Your brain deletes memories every time you remember them",
    style="gradient",
    color_top="#FF4500",
    color_bottom="#1a1a2e",
)
print("Done:", thumb)


thumb = previewThumbnail(
    title="Your brain deletes memories every time you remember them",
    style="radial_glow",
    glow_color="#FFD700",   # yellow like MrBeast
    bg_color="#0a0a0a",
    glow_strength=0.85,
    text_position="bottom",
)
'''






'''
from Math.math import listScenes, previewScene

print(listScenes())
# ['bar_chart', 'brain_stats', 'circle_pi', 'comparison', 
#  'fourier_series', 'number_spiral', 'pythagorean', 'sine_wave', 
#  'timeline', 'wave_interference']



result = previewScene("sine_wave", color="#FF4500")
print("Done:", result)

result = previewScene("circle_pi", color="#00C896")
print("Done:", result)

result = previewScene("bar_chart", values=[3,7,2,8,5], labels=["A","B","C","D","E"])
print("Done:", result)

result = previewScene("pythagorean")
print("Done:", result)

result = previewScene("brain_stats", stat="95%", label="of decisions are subconscious")
print("Done:", result)

result = previewScene("comparison", label_a="Sleep 6hrs", label_b="Sleep 8hrs", value_a=30, value_b=70)
print("Done:", result)

result = previewScene("fourier_series", n_circles=6)
print("Done:", result)

result = previewScene("wave_interference", freq_a=1.0, freq_b=2.0)
print("Done:", result)

result = previewScene("timeline", title="History of Psychology")
print("Done:", result)

result = previewScene("number_spiral", size=15)
print("Done:", result)

'''



'''
from Blender.blender import listScenes, previewScene

print(listScenes())

result = previewScene("rigidBody", box_count=15, stack_height=4)
print("Done:", result)
'''




'''
from Branding.branding import loadChannel, loadBranding, loadPreset, listChannels

print(listChannels())
print(loadChannel("mathmwk"))
print(loadPreset("mathmwk", "short_60s"))
'''




#=========================#=========================#=========================#=========================
#Games Bouncing Balls

from Games.games import renderAnimation
#=========================#=========================#=========================#=========================
'''



out = renderAnimation("bouncingBalls",
    shape="triangle",
    template="fire",
    duration=10,
    fps=60,
    width=1080,
    height=1920,
)

print("Output:", out)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
# Neon pachinko
#renderAnimation("pinball", duration=45, spawn_mode="continuous",
#                peg_glow=True, ball_glow=True, on_hit_particles=True)

# Fixed drop into slots
#renderAnimation("pinball", spawn_mode="fixed", ball_count=20,
#                bottom_mode="slots", slot_count=5, slot_label=True, peg_flash_on_hit=True)



#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Classic satisfying tower cam
renderAnimation("stackingBalls", camera_follow=True, spawn_mode="continuous",
                ball_colors=["#ff6b6b","#ffd93d","#6bcb77","#4d96ff"])

# Neon chaos, no walls
renderAnimation("stackingBalls", template="neon_dark", has_walls=False,
                spawn_x="random", ball_glow=True, on_hit_particles=True)

# Fixed count, watch them settle
renderAnimation("stackingBalls", spawn_mode="fixed", ball_count=40,
                spawn_x="alternating", bounce=0.4, camera_follow=True)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Classic grow until it fills the circle, reverse
renderAnimation("sizingBall",duration=60, mode="grow_shrink", size_multiplier=1.05,
                end_behavior="reverse", ball_glow=True, on_hit_particles=True)

# Shrink inside a hexagon with color transition
renderAnimation("sizingBall", duration=30, shape="hexagon", mode="shrink",
                color_by_size=True, color_start="#ff0000", color_end="#0000ff",
                ring_spin=True, size_multiplier=1.08)

# Neon, loop mode — resets endlessly
renderAnimation("sizingBall", template="neon_dark", mode="grow",
                end_behavior="loop", size_multiplier=1.04, on_hit_ring_pulse=True)

'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Rainbow fill inside a hexagon
renderAnimation("paintBall", shape="hexagon", paint_style="rainbow",
                ball_glow=True, show_coverage=True, ring_spin=True)

# Neon glow paint, fading — endless loop feel
renderAnimation("paintBall", template="neon_dark", paint_style="glow",
                paint_fade=True, paint_fade_speed=2, end_on_full=False)

# Hidden ball, just watch the shape fill
renderAnimation("paintBall", ball_visible=False, paint_style="solid",
                paint_color="#ff6b6b", shape="triangle", show_coverage=True)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Classic — circle spinning, ball tries to escape
renderAnimation("escapeBall", shape="circle", spin_speed=2.0,
                spin_accelerate=True, end_behavior="loop", ball_glow=True)

# Hexagon gap, faster spin
renderAnimation("escapeBall", shape="hexagon", spin_speed=3.0,
                gap_side=2, on_hit_particles=True, ring_glow=True)

# Neon, tiny gap, slow spin — very tense
renderAnimation("escapeBall", template="neon_dark", shape="circle",
                gap_size=25.0, spin_speed=1.0, spin_accelerate=True,
                ball_trail=True, on_hit_ring_pulse=True)
'''



#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''# Shrinking hexagon, ball escapes, loops
renderAnimation("sizingPlatform", shape="hexagon", mode="shrink",
                size_multiplier=0.995, end_behavior="loop", ball_glow=True)

# Slow pulse — shrink then grow forever
renderAnimation("sizingPlatform", shape="circle", mode="shrink_grow",
                size_multiplier=0.997, ring_spin=True, on_hit_ring_pulse=True)

# Fast shrink, neon, triangle
renderAnimation("sizingPlatform", template="neon_dark", shape="triangle",
                mode="shrink", size_multiplier=0.988, on_hit_particles=True)                
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''# Classic — circle, balls shrink each gen, loop
renderAnimation("splitBall", shape="circle", max_balls=64,
                shrink_per_gen=0.82, end_behavior="loop", ball_glow=True)

# Hexagon, randomize colors, particles on split
renderAnimation("splitBall", shape="hexagon", randomize_color=True,
                on_hit_particles=True, split_angle_spread=45.0)

# Neon, no shrink, chaos
renderAnimation("splitBall", template="neon_dark", shrink_per_gen=1.0,
                ball_collision=True, max_balls=32, split_angle_spread=20.0)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''# Slow build, random spawn, hexagon
renderAnimation("multiplyBall", shape="hexagon", multiply_count=1,
                max_balls=40, randomize_color=True, ball_glow=True)

# Fast chaos — 2 per hit, burst style
renderAnimation("multiplyBall", shape="circle", multiply_count=2,
                spawn_style="burst", max_balls=30, on_hit_particles=True)

# Neon, reflect style, triangle
renderAnimation("multiplyBall", template="neon_dark", shape="triangle",
                spawn_style="reflect", multiply_count=1, ring_spin=True)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Classic honeycomb inside circle
renderAnimation("breakoutBall", block_shape="hexagon", boundary_shape="circle",
                block_rows=5, block_cols=5, block_health=2, ball_glow=True)

# Square blocks inside octagon, spin boundary
renderAnimation("breakoutBall", block_shape="square", boundary_shape="octagon",
                boundary_spin=True, boundary_spin_speed=0.3, on_hit_particles=True)

# Neon, circle blocks, 3 health, loop forever
renderAnimation("breakoutBall", template="neon_dark", block_shape="circle",
                block_health=3, win_condition="either", end_behavior="loop")
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Top-down, neon, reveal the map
renderAnimation("breakObjectsBall", mode="top_down", maze_cols=8, maze_rows=12,
                trail_visited=True, ball_glow=True, exit_glow=True)

# Side view, gravity platformer feel
renderAnimation("breakObjectsBall", mode="side_view", maze_cols=10, maze_rows=14,
                gravity_sv=0.5, ball_speed_sv=4.0, end_behavior="loop")

# Top-down, show solution path, fixed seed
renderAnimation("breakObjectsBall", mode="top_down", maze_seed=42,
                show_solution=True, maze_cols=12, maze_rows=16)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Classic single well, ring spawn, neon
renderAnimation("gravityWell", well_count=1, ball_count=8,
                spawn_mode="ring", ball_glow=True, ball_trail=True,
                well_glow=True, end_behavior="loop")

# Three wells, chaotic
renderAnimation("gravityWell", well_count=3, multi_well_layout="triangle",
                ball_count=12, spawn_mode="random", well_strength=0.2,
                on_absorb_particles=True, ball_collision=True)

# Binary star system — 2 wells
renderAnimation("gravityWell", well_count=2, multi_well_distance=400,
                ball_count=10, spawn_mode="scatter", trail_length=50,
                well_pulse=True, well_glow_layers=8)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Classic — random maze, watch it find the exit
renderAnimation("mazeBall", maze_cols=9, maze_rows=14,
                seed=42, ball_glow=True, show_visited=True)

# Bigger maze, slower ball, more tension
renderAnimation("mazeBall", maze_cols=13, maze_rows=18,
                seed=7, ball_speed=4.0, trail_length=40,
                end_behavior="loop", duration=40)

# Show solution path so viewers can compare
renderAnimation("mazeBall", maze_cols=8, maze_rows=12,
                show_solution=True, show_visited=True, seed=100)

'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Classic alternate — pairs orbit each other
renderAnimation("magnetBalls", polarity_mode="alternate", ball_count=6,
                attract_force=0.08, repel_force=0.10, ball_glow=True)

# All same polarity — pure chaos repulsion
renderAnimation("magnetBalls", polarity_mode="all_same", ball_count=8,
                repel_force=0.15, shape="hexagon", ring_spin=True)

# Strong attraction, inverse square — balls cluster dramatically
renderAnimation("magnetBalls", polarity_mode="alternate", ball_count=8,
                attract_force=0.15, force_falloff="inverse_sq",
                min_distance=25, ball_trail=True, trail_length=40)
'''


#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
# Classic 3-ball competition inside circle
renderAnimation("colorTrailCompeteBalls", ball_count=3, shape="circle",
                ball_speed=6.0, show_score=True, show_winner=True)

# 4 balls, hexagon, faster
renderAnimation("colorTrailCompeteBalls", ball_count=4, shape="hexagon",
                ball_speed=8.0, paint_radius_mult=1.5, ring_spin=True)

# Neon, 2 balls, simple duel
renderAnimation("colorTrailCompeteBalls", template="neon_dark",
                ball_count=2, ball_colors=["#ff0044","#0044ff"],
                ball_speed=7.0, show_winner=True)

'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''# Classic glass circle, spiderweb cracks
renderAnimation("glassBall", shape="circle", max_hits=10,
                crack_style="spiderweb", ring_glow=True, screen_shake=True)

# Hexagon, lightning cracks, fast
renderAnimation("glassBall", shape="hexagon", max_hits=8,
                crack_style="lightning", ball_speed=9.0, end_behavior="loop")

# Slow build, lots of cracks, radial style
renderAnimation("glassBall", shape="circle", max_hits=20,
                crack_style="radial", crack_count_per_hit=5,
                crack_branch_depth=3, ball_speed=5.0)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''# Classic cinematic — slow build, big burst
renderAnimation("pinataBall", shape="circle", hits_to_break=10,
                inner_ball_count=50, confetti_burst=True,
                shape_stripe=True, wobble_max_angle=20.0)

# Hexagon piñata, fast hits
renderAnimation("pinataBall", shape="hexagon", hits_to_break=6,
                inner_ball_count=35, striker_speed=9.0,
                shape_color="#aa44ff", shape_color2="#ff44aa")

# Slow dramatic build, lots of wobble
renderAnimation("pinataBall", hits_to_break=15, wobble_max_angle=25.0,
                wobble_decay=0.80, inner_ball_count=60,
                settle_frames=240, duration=35)

'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
#renderAnimation("chaseBall", duration=20, shape="circle", template="neon_dark")

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''renderAnimation("predatorPrey", template="neon_dark", duration=20,
                predator_count=6, prey_count=18, max_prey=120,
                reproduction_rate=0.012, chase_force=0.28, flee_force=0.18,
                show_counts=True)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
#renderAnimation("teamBalls", template="neon_dark", team_size=5, duration=20)

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================

'''renderAnimation("kaleidoscopeBall", template="neon_dark",
                segments=12, mirror_mode="alternate", duration=20)

renderAnimation("kaleidoscopeBall", shape="hexagon",
                segments=8, mirror_mode="all", ring_spin=True,
                ring_spin_speed=0.9, ball_trail=True)

renderAnimation("kaleidoscopeBall", segments=6, mirror_mode="none",
                gravity=0.25, center_pull=0.08, show_axes=False)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
#renderAnimation("slinkyBall", template="neon_dark", duration=20)


#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
#renderAnimation("wormholeBall", template="neon_dark", duration=10)

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================

#renderAnimation("antigravityBall", flips_every_bounces=5, duration=20)


#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
#renderAnimation("rouletteSlotsBall", template="neon_dark",
#                slot_count=16, spin_speed=0.8, duration=20)



#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''# Spread until everyone is infected
renderAnimation("infectionBall", goal_mode="infect_all",
                ball_count=16, infected_start=1, fade_rate=1.2, duration=22)

# Race the clock — can healthy survive?
renderAnimation("infectionBall", goal_mode="survive_timer",
                timer_seconds=15, ball_count=18, infected_start=2,
                template="neon_dark", duration=20)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''renderAnimation("boidsSwarmBall", template="neon_dark", duration=22,
                boid_count=30, predator_spawn_every=200)

renderAnimation("boidsSwarmBall", boid_count=40,
                separation_weight=1.8, cohesion_weight=0.8,
                predator_chase_force=0.35, predator_spawn_every=150)
'''


#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''renderAnimation("laserGridBall", template="neon_dark", duration=20,
                beam_count=8, beam_rotation_speed=1.5)

renderAnimation("laserGridBall", beam_count=10, beam_hit_width=12,
                hit_knockback=6.0, beam_rotation_speed=2.0)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''renderAnimation("timeReverseBall", template="neon_dark", duration=22,
                reverse_interval=5.0, reverse_duration=2.0)

renderAnimation("timeReverseBall", reverse_interval=3.0, reverse_duration=2.5,
                history_seconds=15, ball_trail=True)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition1",
    gravity=0.7,
    ball_speed=1.2,
    ball_trail=True,
    ball_trail_length=100,
    ball_trail_color="#ffffff",
    ball_trail_opacity=0.5,
    ball_trail_width=2,
    ball_trail_radius=100,
    ball_trail_angle=0,
    ball_trail_speed=0.5,
    ball_trail_direction="up",



    text="Episode 2",
    text_x=0.5,
    text_y=0.46,
    font_size=72,
    text_color="#ffffff",
    # ramps
    ramp_outer_x=0.035,
    ramp_bowl_y=0.78,
    ramp_color="#888888",
    ramp_glow=True,
    ramp_glow_layers=8,
    ramp_glow_strength=90,
    # background
    bg_color="#0a0a0a",
    bg_color2="#1a1020",
    bg_gradient_dir="radial",
    ripple_color="#333333",



)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition2",
    text="Episode 2",
    text_glow=False,   # default now
    text_box=False,    # default
    text_x=0.5,
    text_y=0.5,
    font_size=72,
    text_color="#ffffff",
    duration=5.0,
    in_duration=1.2,
    out_duration=1.0,
    text_in_effect="pixelize",   # or scale, typewriter, glitch, blur, wipe,pixelize
    text_out_effect="fade",
    bg_color="#0b0c10",
    bg_color2="#15182a",
    bg_gradient_dir="radial",
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition3",
    text="Episode 2",
    text_x=0.5,
    text_y=0.5,
    font_size=72,
    text_color="#ffffff",
    duration=5.0,
    in_duration=2.5,      # time to form letters
    out_duration=1.2,     # time to leave screen
    # boids (each dot = one pixel on the text mask)
    boid_count=3500,
    boid_radius=2,
    boid_shape="line",  # circle, triangle, arrow, diamond, square, line, cross, dot
    boid_rotation="velocity",  # velocity, none, toward_home
    sample_step=2,        # 1 = denser letters, 2 = faster render
    boid_color="#ffffff",
    max_speed=9.0,
    spring_assemble=0.14,
    separation_radius=5.0,
    separation_strength=0.35,
    exit_mode="radial",   # radial, random, up, down, left, right, explode
    seed=42,
    # background (same as transition2)
    bg_color="#0b0c10",
    bg_color2="#15182a",
    bg_gradient_dir="radial",
    vignette=0.35,
    show_ripples=True,
)
'''


#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition4",
    text="Episode 2",
    text_x=0.5,
    text_y=0.5,
    font_size=72,
    duration=5.0,
    space="2d",              # "2d" is clearer for left→right; 3d also works

    # direction
    flow_mode="left",          # left | right | up | down | swirl | angle
    flow_strength=0.12,        # how hard they drift that way
    flow_lane_wobble=0.4,      # 0 ≈ straight bands; 0.3–0.5 = soft curved lanes

    # loose lines, not clusters
    cohesion_strength=0.0,     # 0 = almost no clumping; try 0.01–0.02 max
    separation_strength=3.6,
    separation_radius=50.0,
    anti_cluster_strength=0.7,
    alignment_strength=0.35,
    max_flock_neighbors=6,
    wander_strength=0.1,

    max_speed=5.5,
    min_speed=2.0,
    boundary_mode="wrap",
    boid_count=380,
    boid_shape="triangle",
    boid_rotation="velocity",

    text_in_effect="pixelize",
    text_out_effect="fade",
    in_duration=1.2,
    out_duration=1.0,
)
'''



#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition5",
    text="Episode 2",
    text_x=0.5,
    text_y=0.5,
    font_size=72,
    duration=5.0,

    text_in_effect="scale",   # or pixelize, fade, typewriter, …
    in_duration=1.0,
    crumble_duration=1.4,   # hold = duration - in - crumble

    fragment_size=14,       # smaller = finer crumble
    crumble_burst=4.5,
    crumble_gravity=0.38,
    crumble_wind=0.04,
    crumble_fade=2.8,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition6",
    text="Episode 2",
    text_x=0.5,
    text_y=0.5,
    font_size=72,
    duration=5.0,

    spotlight_path="sweep",    # sweep | circle | pan | settle
    spotlight_radius=480,
    spotlight_softness=0.68,
    ambient_dark=28,           # how dark the frame starts
    hold_ambient=175,          # brightness when lit (0–255)

    text_in_effect="fade",
    text_out_effect="fade",
    in_duration=1.8,
    out_duration=1.0,
    idle_motion=True,          # gentle orbit during hold
    dim_on_out=True,           # light closes on exit
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition7",
    text="Episode 2",
    text_x=0.5,
    text_y=0.5,
    font_size=72,
    duration=5.0,

    # paintball
    paintball_from="left",      # left | right | top | bottom | random
    splash_x=0.5,
    splash_y=0.5,
    paintball_color="#e040fb",
    paint_color="#1e6b8a",        # main splash on background
    paint_inner_bright="#2a9cc4",
    splash_radius=520,

    # timing
    fly_duration=0.55,
    splash_duration=1.35,
    text_reveal_duration=0.9,
    out_duration=0.8,

    text_in_effect="fade",
    text_out_effect="fade",
)
'''


#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition8",
    text="Episode 2",
    text_x=0.5,
    text_y=0.5,
    font_size=72,
    duration=5.0,

    static_duration=0.35,    # opening noise
    decode_duration=1.6,     # scan + materialize
    out_duration=0.9,

    accent_color="#00e5ff",
    chroma_split_max=14.0,
    static_intensity=0.85,
    grid_alpha=22,
    scan_glow=True,
    hold_flicker=True,

    text_out_effect="fade",
    bg_color="#050810",
    bg_color2="#0c1830",
)


'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition9",
    text="Episode 2",
    subtitle="Prime Numbers",
    text_y=0.82,
    bar_accent="#00c8ff",
    slide_in_duration=0.55,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================

'''
renderAnimation("transition10",
    text="Episode 2",
    ink_color="#2a8fa8",
    text_color="#1a1410",
    bleed_duration=2.0,
    paper_color="#e8e4dc",
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition11",
    text="Episode 2",
    warp_duration=1.8,
    star_count=220,
    warp_speed_max=28.0,
    text_glow=False,
)
'''


#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition12",
    text="Episode 2",
    font_size=64,
    text_color="#f2f2f2",
    in_duration=1.4,
    out_duration=1.0,
    blur_amount=0.55,
    rise_px=18,
    orb_color="#8b9cff",
    orb_radius=420,
    grain=0.06,
    bg_color="#0c0c0e",
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition13",
    text="Episode 2",
    subtitle="A study of primes",
    font_size=64,
    reveal_duration=1.1,
    panel_color="#0e0e10",
    line_color="#c8c8cc",
    text_color="#f0f0f0",
)
'''




#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition14",
    text="Episode 2",
    star_count=280,
    layer_speeds=(0.12, 0.28, 0.55),
    nebula_strength=1.0,
    text_glow=True,
    bg_color="#030510",
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition15",
    text="Episode 2",
    text_y=0.42,
    rise_duration=2.2,
    planet_radius=920,
    atmosphere_color="#ff9a6e",
    planet_color="#1a2238",
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition16",
    text="Episode 2",
    subtitle="Prime Numbers",
    reveal_duration=1.1,
    string_count=14,
    string_radius=380,
    string_color="#9ab4d4",
    orbit_speed=1.0,
    panel_color="#0e0e10",
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition17",
    text="Episode 2",
    subtitle="Prime Numbers",
    reveal_duration=1.2,
    string_count=18,
    string_radius=420,
    inner_ring=True,
    inner_ring_radius=200,
    string_color="#8aa8c8",
    orbit_speed=1.0,
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition18",
    text="Episode 2",
    subtitle="Prime Numbers",
    bracket_in_duration=0.9,
    bracket_color="#a8b0bc",
)
'''



#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition19",
    text="Episode 2",
    ring_interval=0.55,
    ring_speed=340,
    pulse_count=4,
    ring_color="#8a96a8",
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition20",
    text="Episode 2",
    subtitle="Prime Numbers",
    helix_separation=200,
    helix_amplitude=120,
    drift_speed=1.0,
    strand_color="#8ea4be",
)
'''

#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition21",
    text="Episode 2",
    duration=4.0,
    impact_duration=0.35,
    slam_duration=0.45,
    shock_color="#ff4d4d",
    flash_strength=200,
    shake_strength=22.0,
    slam_scale=1.75,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition22",
    text="Episode 2",
    duration=4.0,
    rupture_in_duration=0.55,
    rupture_out_duration=0.55,
    glitch_intensity=1.0,
    rgb_split_max=16,
    accent_flash="#ff3366",
    flicker=True,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition23",
    text="Episode 2",
    duration=4.5,
    strike_delay=0.4,       # pause before hit
    strike_from="top",      # top | left | right
    bolt_color="#c8e8ff",
    flash_strength=190,
    bolt_displace=95.0,     # jaggedness
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition24",
    text="Episode 2",
    duration=5.0,
    strike_rate=0.12,       # how often new arcs spawn
    orbit_radius=280,       # how far around text
    bolt_color="#7ec8ff",
    glow_pulse=True,
    flash_on_strike=80,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition25",
    text="Episode 2",
    duration=5.0,
    drop_delay=0.35,
    ripple_speed=280.0,
    water_color="#0a2838",
    ripple_color="#6ec8e8",
    caustics_strength=1.0,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition26",
    text="Episode 2",
    duration=5.0,
    rise_duration=2.2,
    hold_duration=1.2,
    water_deep="#0c3a52",
    water_shallow="#1a6a8a",
    foam_color="#c8f0ff",
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition27",
    text="Episode 2",
    duration=5.0,
    play_hold=1.1,
    play_color="#ff0000",
    play_button_scale=0.22,
    flash_on_click=200,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================

'''
renderAnimation("transition28",
    text="Episode 2",
    duration=5.0,
    text_y=0.38,
    cta_y=0.58,
    show_like=True,
    subscribe_at=0.9,
    bell_at=1.35,
    subscribed_at=1.75,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition29",
    text="Episode 2",
    duration=5.0,
    scan_duration=1.4,
    line_width=3,
    line_color="#ffffff",
    line_glow_color="#88ccff",
    line_height=0.35,       # 0 = point on axis; 1 = full frame
    line_axis_y=0.5,        # vertical anchor (0.5 = screen middle)
    reverse_out=True,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================
'''
renderAnimation("transition30",
    text="Episode 2",
    duration=5.0,
    scan_duration=1.4,
    arrow_size=12.0,
    arrow_color="#e8eef4",
    line_height=0.2,
    line_axis_y=0.5,
    trail_count=5,
    probe_line=False,
    reverse_out=True,
)
'''
#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================




#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================



#=========================#=========================#=========================#=========================
#=========================#=========================#=========================#=========================