# Project Rules

## Holy Rules

1. Every module must have a `utils.py` file.

   Each module's `utils.py` is the only place for utility/helper functions that belong to that module. For example, anything in the `Trends` module that is a utility function must live in `Trends/utils.py`.

2. Non-utility files must contain actual feature functions.

   Files and folders outside of `utils.py` should hold the real module logic that can be imported and used by `main.py`. They should not become dumping grounds for helper functions.

3. Public feature functions must use `camelCase()`.

   Any function intended to be called from `main.py` or by another module must be named in `camelCase()`.

4. Utility function casing is flexible.

   Functions inside `utils.py` can use whatever casing makes sense for that module.
