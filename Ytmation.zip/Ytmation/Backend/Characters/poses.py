"""Resolve character pose names to PNG paths under Templates/characters/."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CHARACTER_DIR = ROOT / "Templates" / "characters"

# Explicit registry; falls back to {name}.png in CHARACTER_DIR.
POSES: dict[str, str] = {
    "serious": "serious.png",
    "seriousB": "seriousB.png",
    "amazed": "amazed.png",
    "amazedB": "amazedB.png",
    "angry": "angry.png",
    "angryB": "angryB.png",
    "scared": "scared.png",
    "scaredB": "scaredB.png",
    "horny": "horny.png",
    "hornyB": "hornyB.png",
    "original": "original.png",
    "originalB": "originalB.png",
}


def listPoses() -> list[str]:
    names = set(POSES)
    if CHARACTER_DIR.is_dir():
        for p in CHARACTER_DIR.glob("*.png"):
            names.add(p.stem)
    return sorted(names)


def resolvePose(name: str) -> Path:
    key = (name or "original").strip()
    if key in POSES:
        path = CHARACTER_DIR / POSES[key]
        if path.is_file():
            return path
    direct = CHARACTER_DIR / f"{key}.png"
    if direct.is_file():
        return direct
    available = ", ".join(listPoses()) or "(none)"
    raise FileNotFoundError(
        f"Character pose '{name}' not found under {CHARACTER_DIR}. Available: {available}"
    )
