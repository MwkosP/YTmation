"""
Spoken character segments — TTS-driven pose timelines with muxed audio.
"""

from __future__ import annotations

import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

from Characters.characters import renderCharacterTimeline
from Stitching.utils import _runFfmpeg
from Voice import generateSpeech, getAudioDuration

ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = ROOT / "Cache" / "characters"

_DEFAULT_CUE = {
    "x": 0.5,
    "y": 0.72,
    "scale": 0.38,
    "fade_in": 0.25,
    "fade_out": 0.2,
    "anchor": "bottom_center",
}

_LAYOUT_KEYS = ("x", "y", "scale", "fade_in", "fade_out", "anchor", "fadeIn", "fadeOut")


def _concat_audio(paths: list[Path], output: Path, *, gap: float = 0.0) -> Path:
    """Join MP3/WAV clips in order; optional silence between clips."""
    if not paths:
        raise ValueError("paths must be non-empty")
    if len(paths) == 1 and gap <= 0:
        return paths[0]

    pieces: list[Path] = []
    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)
        for i, src in enumerate(paths):
            pieces.append(src)
            if gap > 0 and i < len(paths) - 1:
                silence = tmp_dir / f"gap_{i}.mp3"
                _runFfmpeg([
                    "-f", "lavfi",
                    "-i", "anullsrc=r=44100:cl=mono",
                    "-t", str(gap),
                    "-c:a", "libmp3lame", "-q:a", "9",
                    str(silence),
                ])
                pieces.append(silence)

        list_file = tmp_dir / "concat.txt"
        list_file.write_text(
            "\n".join(f"file '{p.resolve()}'" for p in pieces),
            encoding="utf-8",
        )
        _runFfmpeg([
            "-f", "concat", "-safe", "0",
            "-i", str(list_file),
            "-c:a", "libmp3lame", "-q:a", "2",
            str(output),
        ])
    return output


def _line_layout(line: dict, defaults: dict) -> dict:
    merged = {**defaults}
    for key in _LAYOUT_KEYS:
        if key in line:
            merged[key] = line[key]
    if "fadeIn" in merged and "fade_in" not in line:
        merged["fade_in"] = merged.pop("fadeIn")
    if "fadeOut" in merged and "fade_out" not in line:
        merged["fade_out"] = merged.pop("fadeOut")
    merged.pop("fadeIn", None)
    merged.pop("fadeOut", None)
    return merged


def renderSpokenCharacterTimeline(
    script: list[dict],
    *,
    model: str = "gtts",
    output: Path | None = None,
    width: int = 1920,
    height: int = 1080,
    fps: int = 60,
    bg_color: str = "#000000",
    bg_image: str | Path | None = None,
    line_gap: float = 0.0,
    cue_defaults: dict | None = None,
    speech_kwargs: dict | None = None,
) -> Path:
    """
    Render a character segment with voice synced to pose swaps.

    script: list of {"text": "...", "pose": "seriousB", ...}
        Optional per-line layout keys: x, y, scale, fade_in, fade_out, anchor.

    Returns path to MP4 with video + audio.
    """
    if not script:
        raise ValueError("script must be a non-empty list of line dicts")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if output is None:
        output = CACHE_DIR / f"spoken_timeline_{stamp}.mp4"
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)

    defaults = {**_DEFAULT_CUE, **(cue_defaults or {})}
    tts_kwargs = dict(speech_kwargs or {})

    audio_clips: list[Path] = []
    cues: list[dict] = []
    t = 0.0

    print(f"   Spoken character — {len(script)} line(s), model={model!r}", flush=True)

    for i, line in enumerate(script):
        text = (line.get("text") or "").strip()
        pose = line.get("pose") or line.get("name")
        if not text:
            raise ValueError(f"script[{i}] missing non-empty 'text'")
        if not pose:
            raise ValueError(f"script[{i}] missing 'pose'")

        clip_path = CACHE_DIR / f"spoken_line_{stamp}_{i}.mp3"
        audio = generateSpeech(text, output=clip_path, model=model, **tts_kwargs)
        duration = getAudioDuration(audio)
        if duration <= 0:
            raise RuntimeError(f"script[{i}] audio duration is zero: {audio}")

        layout = _line_layout(line, defaults)
        cues.append({
            "pose": pose,
            "start": t,
            "end": t + duration,
            **layout,
        })
        audio_clips.append(audio)
        t += duration
        if line_gap > 0 and i < len(script) - 1:
            t += line_gap

    total_duration = t
    combined_audio_path = CACHE_DIR / f"spoken_audio_{stamp}.mp3"
    combined_audio = _concat_audio(audio_clips, combined_audio_path, gap=line_gap)

    silent_video = CACHE_DIR / f"spoken_silent_{stamp}.mp4"
    renderCharacterTimeline(
        cues=cues,
        duration=total_duration,
        output=silent_video,
        width=width,
        height=height,
        fps=fps,
        bg_color=bg_color,
        bg_image=bg_image,
    )

    from Stitching.stitching import overlayAudio

    final = overlayAudio(silent_video, combined_audio, output=output)
    print(f"   Spoken character done → {final} ({total_duration:.1f}s)", flush=True)
    return Path(final)
