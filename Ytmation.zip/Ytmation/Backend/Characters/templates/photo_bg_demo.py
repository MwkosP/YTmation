from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
BG = ROOT / "Cache" / "characters" / "andrew-a-XNZjueEeLO8-unsplash.jpg"

TEMPLATE = {
    "name": "photo_bg_demo",
    "duration": 10.0,
    "width": 1920,
    "height": 1080,
    "fps": 60,
    "bg_image": str(BG),
    "cues": [
        {
            "pose": "seriousB",
            "start": 0.5,
            "end": 4.5,
            "x": 0.5,
            "y": 0.72,
            "scale": 0.38,
            "fade_in": 0.4,
            "fade_out": 0.35,
            "anchor": "bottom_center",
        },
        {
            "pose": "amazedB",
            "start": 5.0,
            "end": 9.5,
            "x": 0.5,
            "y": 0.68,
            "scale": 0.4,
            "fade_in": 0.3,
            "fade_out": 0.4,
            "anchor": "bottom_center",
        },
    ],
}
