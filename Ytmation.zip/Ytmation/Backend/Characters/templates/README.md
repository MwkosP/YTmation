# Character templates

Preset dicts for `renderCharacterTimeline` / `renderSpokenCharacterTimeline`.

Each file exports `TEMPLATE` with layout, background, and optional fixed `cues`.

```python
from Characters.templates.photo_bg_demo import TEMPLATE

t = dict(TEMPLATE)
cues = t.pop("cues")
duration = t.pop("duration")
t.pop("name", None)
renderCharacterTimeline(cues=cues, duration=duration, **t, output=...)
```

Optional asset prep: `python Characters/cutoutCharacters.py` (rembg batch cutouts).
