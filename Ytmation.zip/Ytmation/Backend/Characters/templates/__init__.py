# Character segment presets (Games/templates-style TEMPLATE dicts)
