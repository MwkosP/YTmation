"""
Characters — timed pose overlays
--------------------------------
Render a timeline of character PNGs on a black (or custom) background.

Public API:
    listPoses()
    renderCharacterTimeline(cues, duration, output, **params) -> Path
"""

from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path

from Characters.poses import listPoses, resolvePose

ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = ROOT / "Cache" / "characters"


def _hex(h: str) -> tuple[int, int, int]:
    h = (h or "#000000").lstrip("#")
    if len(h) != 6:
        return (0, 0, 0)
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def _clamp(t: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, t))


def _cue_alpha(t: float, start: float, end: float, fade_in: float, fade_out: float) -> float:
    if t < start or t > end:
        return 0.0
    local = t - start
    span = max(1e-6, end - start)
    fi = max(0.0, fade_in)
    fo = max(0.0, fade_out)
    a = 1.0
    if fi > 0 and local < fi:
        a = local / fi
    elif fo > 0 and local > span - fo:
        a = max(0.0, (end - t) / fo)
    return _clamp(a, 0.0, 1.0)


def _norm_xy(nx: float, ny: float, w: int, h: int) -> tuple[int, int]:
    return int(_clamp(float(nx), 0.0, 1.0) * w), int(_clamp(float(ny), 0.0, 1.0) * h)


def _place_rect(img_w: int, img_h: int, anchor_x: int, anchor_y: int, anchor: str) -> tuple[int, int]:
    anchor = (anchor or "center").lower().replace("-", "_")
    if anchor in ("bottom_center", "bottom"):
        return anchor_x - img_w // 2, anchor_y - img_h
    if anchor in ("top_center", "top"):
        return anchor_x - img_w // 2, anchor_y
    return anchor_x - img_w // 2, anchor_y - img_h // 2


def _load_scaled_pose(path: Path, target_h: int, cache: dict) -> "object":
    import pygame

    key = ("pose", str(path), target_h)
    if key in cache:
        return cache[key]
    img = pygame.image.load(str(path)).convert_alpha()
    if target_h <= 0:
        return img
    scale = target_h / max(1, img.get_height())
    nw = max(1, int(img.get_width() * scale))
    nh = max(1, int(img.get_height() * scale))
    scaled = pygame.transform.smoothscale(img, (nw, nh))
    cache[key] = scaled
    return scaled


def _load_background(path: Path, width: int, height: int, cache: dict) -> "object":
    """Scale image to cover the frame (center crop)."""
    import pygame

    key = ("bg", str(path), width, height)
    if key in cache:
        return cache[key]
    src = pygame.image.load(str(path)).convert()
    iw, ih = src.get_size()
    scale = max(width / max(1, iw), height / max(1, ih))
    nw = max(1, int(iw * scale))
    nh = max(1, int(ih * scale))
    scaled = pygame.transform.smoothscale(src, (nw, nh))
    surface = pygame.Surface((width, height))
    surface.blit(scaled, ((width - nw) // 2, (height - nh) // 2))
    cache[key] = surface
    return surface


def renderCharacterTimeline(
    cues: list[dict],
    duration: float = 10.0,
    output: Path | None = None,
    width: int = 1920,
    height: int = 1080,
    fps: int = 60,
    bg_color: str = "#000000",
    bg_image: str | Path | None = None,
    **kwargs,
) -> Path:
    """
    Composite character pose cues onto a solid color or image background.

    bg_image : path to JPG/PNG — scaled to cover the frame (center crop).

    Each cue dict supports:
        pose       : str   — e.g. "serious" (Templates/characters/)
        start      : float — seconds visible from
        end        : float — seconds visible until
        x, y       : float — anchor point 0–1 on frame
        scale      : float — height as fraction of frame (0.45 = 45% of height)
        fade_in    : float — fade-in seconds from start (default 0)
        fade_out   : float — fade-out seconds before end (default 0)
        anchor     : str   — center | bottom_center | top_center
    """
    import os
    import subprocess
    import pygame

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"character_timeline_{stamp}.mp4"

    normalized: list[dict] = []
    for raw in cues or []:
        pose = raw.get("pose") or raw.get("name") or "original"
        normalized.append({
            "path": resolvePose(pose),
            "start": float(raw.get("start", 0.0)),
            "end": float(raw.get("end", duration)),
            "x": float(raw.get("x", 0.5)),
            "y": float(raw.get("y", 0.5)),
            "scale": float(raw.get("scale", 0.45)),
            "fade_in": float(raw.get("fade_in", raw.get("fadeIn", 0.0))),
            "fade_out": float(raw.get("fade_out", raw.get("fadeOut", 0.0))),
            "anchor": raw.get("anchor", "center"),
        })

    bg_path: Path | None = None
    if bg_image:
        bg_path = Path(bg_image)
        if not bg_path.is_file():
            raise FileNotFoundError(f"Background image not found: {bg_path}")

    pygame.init()
    pygame.display.set_mode((1, 1), pygame.NOFRAME)
    surface = pygame.Surface((width, height))
    bg = _hex(bg_color)
    total_frames = max(1, int(duration * fps))
    img_cache: dict = {}
    bg_surface = _load_background(bg_path, width, height, img_cache) if bg_path else None

    with tempfile.TemporaryDirectory() as tmp:
        frames_dir = Path(tmp)
        for frame in range(total_frames):
            t = frame / max(fps, 1)
            if bg_surface is not None:
                surface.blit(bg_surface, (0, 0))
            else:
                surface.fill(bg)

            for cue in normalized:
                alpha = _cue_alpha(t, cue["start"], cue["end"], cue["fade_in"], cue["fade_out"])
                if alpha <= 0.001:
                    continue
                target_h = max(1, int(height * cue["scale"]))
                img = _load_scaled_pose(cue["path"], target_h, img_cache)
                ax, ay = _norm_xy(cue["x"], cue["y"], width, height)
                px, py = _place_rect(img.get_width(), img.get_height(), ax, ay, cue["anchor"])
                if alpha >= 0.999:
                    surface.blit(img, (px, py))
                else:
                    layer = img.copy()
                    layer.set_alpha(int(255 * alpha))
                    surface.blit(layer, (px, py))

            pygame.image.save(surface, str(frames_dir / f"frame_{frame:06d}.png"))
            if frame % (fps * 2) == 0:
                print(f"   Frame {frame}/{total_frames} ({frame * 100 // total_frames}%)")

        subprocess.run(
            ["ffmpeg", "-y", "-framerate", str(fps), "-i", str(frames_dir / "frame_%06d.png"),
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "fast", "-crf", "18", str(output)],
            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    pygame.quit()
    print(f"   Done → {output}")
    return Path(output)
