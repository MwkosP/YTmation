# Characters Module

## Purpose

Timed pose overlays for mascot / presenter segments. Renders silent MP4s from transparent PNG cutouts (`Templates/characters/`) on a solid color or photo background.

**Spoken segments (planned):** `renderSpokenCharacterTimeline` and `renderCharacterIntro` will call `Voice.generateSpeech` per script line, build audio-driven cues, then mux with `Stitching.overlayAudio`. See `Voice/SKILL.md`.

## Location

```
Characters/
├── characters.py        ← renderCharacterTimeline (silent)
├── spoken.py            ← renderSpokenCharacterTimeline
├── cutoutCharacters.py  ← optional rembg batch cutout CLI
├── poses.py             ← pose name → PNG path
├── templates/           ← segment preset dicts (photo_bg_demo, …)
└── __init__.py

Templates/characters/    ← PNG pose assets (*B.png)
```

Output cache: `Cache/characters/`

---

## Pose assets

| File pattern | Use |
|--------------|-----|
| `seriousB.png`, `amazedB.png`, … | Manual transparent cutouts (preferred) |
| `*B.png` suffix | Convention for “background-ready” poses |

Register names in `Characters/poses.py`. List with `listPoses()`.

**Cutout tool:** `python Characters/cutoutCharacters.py` uses rembg (`u2net`). Manual PNGs avoid tail clipping / color-key artifacts from auto cutout.

---

## Primary API — `renderCharacterTimeline`

```python
from Characters import renderCharacterTimeline, listPoses

listPoses()  # ['seriousB', 'amazedB', ...]

path = renderCharacterTimeline(
    cues=[
        {
            "pose": "seriousB",
            "start": 0.5,
            "end": 4.5,
            "x": 0.5,
            "y": 0.72,
            "scale": 0.38,
            "fade_in": 0.4,
            "fade_out": 0.35,
            "anchor": "bottom_center",
        },
    ],
    duration=10.0,
    output=Path("Cache/characters/intro.mp4"),
    width=1920,
    height=1080,
    fps=60,
    bg_color="#000000",       # ignored when bg_image set
    bg_image="path/to/photo.jpg",  # optional; cover + center crop
)
```

### Cue fields

| Field | Description |
|-------|-------------|
| `pose` | Name resolved via `poses.py` |
| `start`, `end` | Visible window in seconds |
| `x`, `y` | Normalized anchor (0–1) |
| `scale` | Height as fraction of frame height |
| `fade_in`, `fade_out` | Alpha fade seconds |
| `anchor` | `center`, `bottom_center`, `top_center`, … |

Duration is **fixed** for silent timelines. Spoken workflows will derive duration from TTS instead.

---

## Templates

```python
from Characters.templates.photo_bg_demo import TEMPLATE

photo_t = dict(TEMPLATE)
cues = photo_t.pop("cues")
duration = photo_t.pop("duration")
photo_t.pop("name", None)

renderCharacterTimeline(cues=cues, duration=duration, **photo_t, output=...)
```

Presets live under `Characters/templates/`. See `Characters/templates/README.md`.

---

## Spoken character API — `renderSpokenCharacterTimeline`

```python
from Characters import renderSpokenCharacterTimeline

script = [
    {"text": "Hey guys, welcome back.", "pose": "seriousB"},
    {"text": "Without further ado, enjoy the video.", "pose": "amazedB"},
]

path = renderSpokenCharacterTimeline(
    script,
    model="gtts",              # or "orpheus:tara"
    bg_image="...",            # optional
    line_gap=0.0,              # seconds between lines (audio + cues)
    cue_defaults={"y": 0.72, "scale": 0.38},
    output=Path("Cache/characters/intro.mp4"),
)
```

Returns one **MP4** with poses + muxed voice. Works for intro, middle, or outro — placement is up to the workflow stitch step.

Internally: `generateSpeech` → `getAudioDuration` → cues → `renderCharacterTimeline` → concat audio → `overlayAudio`.

---

## Typical workflow usage

**bouncemwk showcase (current — silent intro):**

```python
from Characters.characters import renderCharacterTimeline
from Characters.templates.photo_bg_demo import TEMPLATE as PHOTO_BG_TEMPLATE
```

See `Workflows/channels/bouncemwk/workflowShowcase.py` and `Workflows/channels/bouncemwk/SKILL.md`.

---

## Dependencies

| Tool | Role |
|------|------|
| **pygame** | Frame compositing |
| **ffmpeg** | PNG sequence → H.264 |
| **Voice** | TTS via `generateSpeech` |
| **Stitching** | `overlayAudio` |

Full inventory: `Artifacts/srcs/SOURCES.md` → Characters.
