#!/usr/bin/env python3
"""Remove backgrounds from Templates/characters/*.png → {name}B.png siblings.

Uses rembg for the main body, then grows the mask along purple trail pixels so
dashed tails stay attached without the flat horizontal band the old cutover caused.
"""

from __future__ import annotations

import io
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CHAR_DIR = ROOT / "Templates" / "characters"


def _color_key_mask(rgb, tol: float = 18.0):
    import numpy as np

    bg = rgb[0, 0].astype(np.int16)
    dist = np.linalg.norm(rgb.astype(np.int16) - bg, axis=2)
    return dist > tol


def _extend_trail_mask(rb, ck, rgb, *, min_bright: int = 38, max_iter: int = 80):
    import numpy as np
    from scipy import ndimage

    mx = np.max(rgb, axis=2)
    mask = rb.copy()
    for _ in range(max_iter):
        grown = ndimage.binary_dilation(mask, iterations=2)
        add = ck & grown & ~mask & (mx >= min_bright)
        if not add.any():
            break
        mask |= add
    return mask


def _compose_alpha(rb_alpha, mask, rb, rgb, *, fringe_floor: int = 15, fringe_scale: float = 5.0):
    import numpy as np

    mx = np.max(rgb, axis=2)
    ext = mask & ~rb
    alpha = rb_alpha.copy()
    alpha[ext] = np.clip((mx[ext].astype(np.float32) - fringe_floor) * fringe_scale, 0, 255).astype(np.uint8)
    alpha[~mask] = 0
    return alpha


def cutout_image(
    src: Path,
    *,
    tol: float = 18.0,
    min_bright: int = 38,
) -> "object":
    """Return RGBA PIL image with transparent background."""
    import numpy as np
    from PIL import Image
    from rembg import remove

    rgb = np.array(Image.open(src).convert("RGB"))
    ck = _color_key_mask(rgb, tol=tol)

    buf = io.BytesIO()
    Image.open(src).save(buf, format="PNG")
    rb_rgba = np.array(Image.open(io.BytesIO(remove(buf.getvalue()))).convert("RGBA"))
    rb_alpha = rb_rgba[:, :, 3]
    rb = rb_alpha > 128

    mask = _extend_trail_mask(rb, ck, rgb, min_bright=min_bright)
    alpha = _compose_alpha(rb_alpha, mask, rb, rgb)
    rgba = np.dstack([rgb, alpha])
    return Image.fromarray(rgba, mode="RGBA")


def cutout_characters(
    char_dir: Path = CHAR_DIR,
    *,
    tol: float = 18.0,
    min_bright: int = 38,
) -> list[Path]:
    if not char_dir.is_dir():
        raise FileNotFoundError(f"Character folder not found: {char_dir}")

    written: list[Path] = []
    for src in sorted(char_dir.glob("*.png")):
        if src.stem.endswith("B"):
            continue
        dst = char_dir / f"{src.stem}B.png"
        print(f"  {src.name} → {dst.name}", flush=True)
        result = cutout_image(src, tol=tol, min_bright=min_bright)
        result.save(dst, format="PNG")
        written.append(dst)
    return written


if __name__ == "__main__":
    paths = cutout_characters()
    print(f"Done — {len(paths)} cutout(s) in {CHAR_DIR}")
