#!/usr/bin/env python3
"""Load and generate video storyboards from board templates."""

import argparse
import copy
import json
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BOARDS_DIR = Path(__file__).resolve().parent / "boards"
OUTPUT_DIR = ROOT / "Cache" / "storyboards"


def load_board(name: str) -> dict:
    path = BOARDS_DIR / f"{name}.json"
    if not path.exists():
        available = ", ".join(list_boards()) or "(none)"
        raise FileNotFoundError(f"Board '{name}' not found. Available: {available}")
    return json.loads(path.read_text(encoding="utf-8"))


def list_boards() -> list[str]:
    return sorted(p.stem for p in BOARDS_DIR.glob("*.json"))


def save_board(board: dict, slug: str | None = None) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = board.get("id") or slug or "board"
    path = OUTPUT_DIR / f"{name}_{stamp}.json"
    path.write_text(json.dumps(board, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path


def apply_topic(board: dict, topic: str) -> dict:
    out = copy.deepcopy(board)
    out["topic"] = topic
    if "title" in out:
        out["title"] = f"{out['title']}: {topic}"
    return out


def generateStoryboard(
    topic: str,
    board: str = "physics_short_60s",
    *,
    save: bool = True,
) -> dict:
    """Load a board template and attach the video topic."""
    data = apply_topic(load_board(board), topic)
    print(json.dumps(data, indent=2))
    if save:
        path = save_board(data, slug=topic[:40].replace(" ", "_"))
        print(f"\nSaved: {path}", file=sys.stderr)
    return data


def main() -> int:
    parser = argparse.ArgumentParser(description="Video storyboard templates")
    parser.add_argument("topic", nargs="?", help="Video topic")
    parser.add_argument("-b", "--board", default="physics_short_60s", help="Board template name")
    parser.add_argument("--list-boards", action="store_true", help="List available boards")
    parser.add_argument("--show", metavar="BOARD", help="Print a board template without topic")
    parser.add_argument("--no-save", action="store_true", help="Print only, do not write to Cache")
    args = parser.parse_args()

    if args.list_boards:
        for name in list_boards():
            print(name)
        return 0

    if args.show:
        print(json.dumps(load_board(args.show), indent=2))
        return 0

    if not args.topic:
        parser.error("Provide a topic, or use --show / --list-boards")

    generateStoryboard(args.topic, board=args.board, save=not args.no_save)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
