# Storyboard — shot-by-shot video plans

Turns a topic into a structured scene list before Script, Blender, Motions, or Stitching run.

## Layout

```
Storyboard/
├── SKILL.md
├── storyboard.py
└── boards/
    ├── physics_short_60s.json
    ├── manhwa_recap_15min.json
    └── soundscape_1hr.json
```

Outputs go to `Cache/storyboards/`.

## Board templates

| Board | Duration | Format | Script template |
|-------|----------|--------|-----------------|
| `physics_short_60s` | 60s | 9:16 Short | `neon_physics` |
| `manhwa_recap_15min` | 15 min | 16:9 recap | `manhwa_recap` |
| `soundscape_1hr` | 1 hr | 16:9 ambient | `soundscape` |

Each scene has: `start_sec`, `end_sec`, `type`, `visual`, `narration`, `sfx`, `module` (which YT folder handles it).

## CLI

```bash
python Storyboard/storyboard.py --list-boards
python Storyboard/storyboard.py --show physics_short_60s
python Storyboard/storyboard.py "marble run compilation" -b physics_short_60s
python Storyboard/storyboard.py "solo leveling ep 45" -b manhwa_recap_15min
```

## Python API

```python
from Storyboard.storyboard import generateStoryboard, load_board

board = load_board("soundscape_1hr")
generateStoryboard("rainy cabin ASMR", board="soundscape_1hr")
```

## Pipeline order

1. **Storyboard** — scene structure + modules
2. **Script** — narration from `script_template` on the board
3. **Blender / Motions / Image** — per-scene visuals
4. **Stitching** — assemble by scene timestamps

Add new formats by dropping a `.json` in `boards/`.
