import importlib
from datetime import datetime
from pathlib import Path
from Thumbnail.utils import _addText, _addBackground, _saveImage

ROOT         = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"
CACHE_DIR    = ROOT / "Cache" / "thumbnails"


def listTemplates() -> list[str]:
    """List all available thumbnail templates."""
    return [
        f.stem for f in sorted(TEMPLATES_DIR.glob("*.py"))
        if not f.stem.startswith("_")
    ]


def generateThumbnail(
    title: str,
    style: str       = "bold_text",
    output: Path     = None,
    width: int       = 1280,
    height: int      = 720,
    **params,
) -> Path:
    """
    Generate a thumbnail using a template.

    e.g. generateThumbnail(
        title="Your brain deletes memories every time you remember them",
        style="bold_text",
        bg_color="#0d0d0d",
        text_color="#ffffff",
        accent_color="#FF4500",
    )
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = CACHE_DIR / f"thumb_{style}_{stamp}.png"

    module = importlib.import_module(f"Thumbnail.templates.{style}")
    return module.run(
        title=title,
        output=Path(output),
        width=width,
        height=height,
        **params,
    )


def previewThumbnail(
    title: str,
    style: str   = "bold_text",
    **params,
) -> Path:
    """Generate a thumbnail and open it for preview."""
    import subprocess
    path = generateThumbnail(title=title, style=style, **params)
    subprocess.Popen(["xdg-open", str(path)])
    return path


def getThumbnail(name: str) -> Path:
    """Get a cached thumbnail by partial name match."""
    matches = sorted(CACHE_DIR.glob(f"*{name}*.png"), reverse=True)
    if not matches:
        raise FileNotFoundError(f"No cached thumbnail matching '{name}'")
    return matches[0]