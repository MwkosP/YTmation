from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import textwrap


def _loadFont(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    """Load a system font at the given size."""
    font_paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
        "/usr/share/fonts/truetype/ubuntu/Ubuntu-B.ttf",
    ] if bold else [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
        "/usr/share/fonts/truetype/ubuntu/Ubuntu-R.ttf",
    ]

    for path in font_paths:
        if Path(path).exists():
            return ImageFont.truetype(path, size)

    return ImageFont.load_default()


def _hexToRgb(hex_color: str) -> tuple:
    """Convert hex color to RGB tuple."""
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


def _addBackground(
    img: Image.Image,
    color: str = "#0d0d0d",
) -> Image.Image:
    """Fill image with a solid background color."""
    img.paste(_hexToRgb(color), [0, 0, img.width, img.height])
    return img


def _addGradientBackground(
    img: Image.Image,
    color_top: str    = "#1a1a2e",
    color_bottom: str = "#0d0d0d",
) -> Image.Image:
    """Add a vertical gradient background."""
    draw  = ImageDraw.Draw(img)
    top   = _hexToRgb(color_top)
    bot   = _hexToRgb(color_bottom)

    for y in range(img.height):
        t = y / img.height
        r = int(top[0] + (bot[0] - top[0]) * t)
        g = int(top[1] + (bot[1] - top[1]) * t)
        b = int(top[2] + (bot[2] - top[2]) * t)
        draw.line([(0, y), (img.width, y)], fill=(r, g, b))

    return img


def _addText(
    img: Image.Image,
    text: str,
    position: str   = "center",
    fontsize: int   = 80,
    color: str      = "#ffffff",
    bold: bool      = True,
    max_width: int  = None,
    shadow: bool    = True,
    padding: int    = 80,
) -> Image.Image:
    """Add text to an image with optional shadow."""
    draw      = ImageDraw.Draw(img)
    font      = _loadFont(fontsize, bold=bold)
    rgb       = _hexToRgb(color)
    max_chars = max_width or (img.width - padding * 2) // (fontsize // 2)

    # wrap text
    lines     = textwrap.wrap(text, width=max_chars)
    line_h    = fontsize + 10
    total_h   = line_h * len(lines)

    if position == "center":
        y_start = (img.height - total_h) // 2
    elif position == "top":
        y_start = padding
    elif position == "bottom":
        y_start = img.height - total_h - padding
    else:
        y_start = (img.height - total_h) // 2

    for i, line in enumerate(lines):
        bbox = draw.textbbox((0, 0), line, font=font)
        w    = bbox[2] - bbox[0]
        x    = (img.width - w) // 2
        y    = y_start + i * line_h

        # shadow
        if shadow:
            draw.text((x + 3, y + 3), line, font=font, fill=(0, 0, 0, 180))

        draw.text((x, y), line, font=font, fill=rgb)

    return img


def _addImageBackground(
    img: Image.Image,
    bg_path: str | Path,
    opacity: float = 0.4,
) -> Image.Image:
    """Add an image as background with optional dimming."""
    from PIL import ImageEnhance
    bg = Image.open(bg_path).convert("RGB").resize((img.width, img.height))
    bg = ImageEnhance.Brightness(bg).enhance(opacity)
    img.paste(bg, (0, 0))
    return img


def _saveImage(img: Image.Image, output: Path) -> Path:
    """Save a PIL image to disk."""
    output.parent.mkdir(parents=True, exist_ok=True)
    img.save(str(output), "PNG")
    return output