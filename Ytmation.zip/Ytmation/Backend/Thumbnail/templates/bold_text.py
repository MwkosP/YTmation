"""
Bold Text Thumbnail
--------------------
Clean dark background with large bold centered text.
Great for psychology facts, educational content.

params:
    bg_color      : str = "#0d0d0d"  — background color
    text_color    : str = "#ffffff"  — main text color
    accent_color  : str = "#FF4500"  — accent/highlight color
    fontsize      : int = 90         — main text size
    show_accent   : bool = True      — show accent bar under text
    gradient      : bool = True      — use gradient background
"""

from pathlib import Path
from PIL import Image
from Thumbnail.utils import (
    _addBackground,
    _addGradientBackground,
    _addText,
    _saveImage,
    _hexToRgb,
)
from PIL import ImageDraw


def run(
    title: str,
    output: Path,
    width: int         = 1280,
    height: int        = 720,
    bg_color: str      = "#0d0d0d",
    text_color: str    = "#ffffff",
    accent_color: str  = "#FF4500",
    fontsize: int      = 90,
    show_accent: bool  = True,
    gradient: bool     = True,
) -> Path:
    img  = Image.new("RGB", (width, height))

    # background
    if gradient:
        _addGradientBackground(img, color_top="#1a1a2e", color_bottom=bg_color)
    else:
        _addBackground(img, bg_color)

    # accent bar on left edge
    if show_accent:
        draw = ImageDraw.Draw(img)
        draw.rectangle([(40, height//4), (52, 3*height//4)], fill=_hexToRgb(accent_color))

    # main text
    _addText(
        img,
        text=title,
        position="center",
        fontsize=fontsize,
        color=text_color,
        bold=True,
        shadow=True,
        padding=100,
    )

    return _saveImage(img, output)