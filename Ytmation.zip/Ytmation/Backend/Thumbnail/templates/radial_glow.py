"""
Radial Glow Thumbnail (MrBeast style)
---------------------------------------
Dramatic radial spotlight glow from center, dark vignette edges.
High energy, high contrast — great for viral content.

params:
    glow_color    : str   = "#FFD700"  — center glow color (yellow/orange)
    bg_color      : str   = "#0a0a0a"  — outer dark color
    glow_strength : float = 0.85       — 0.0 to 1.0, how strong the glow is
    glow_radius   : float = 0.6        — 0.0 to 1.0, how wide the glow spreads
    glow_x        : float = 0.5        — 0.0 to 1.0, horizontal center of glow
    glow_y        : float = 0.5        — 0.0 to 1.0, vertical center of glow
    text_color    : str   = "#ffffff"
    fontsize      : int   = 90
    text_position : str   = "bottom"   — center / top / bottom
"""

import math
from pathlib import Path
from PIL import Image, ImageDraw
from Thumbnail.utils import _addText, _saveImage, _hexToRgb


def run(
    title: str,
    output: Path,
    width: int          = 1280,
    height: int         = 720,
    glow_color: str     = "#FFD700",
    bg_color: str       = "#0a0a0a",
    glow_strength: float = 0.85,
    glow_radius: float  = 0.6,
    glow_x: float       = 0.5,
    glow_y: float       = 0.5,
    text_color: str     = "#ffffff",
    fontsize: int       = 90,
    text_position: str  = "bottom",
) -> Path:
    img  = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(img)

    bg   = _hexToRgb(bg_color)
    glow = _hexToRgb(glow_color)

    # center of glow in pixels
    cx = int(glow_x * width)
    cy = int(glow_y * height)

    # max distance from center to corner
    max_dist = math.sqrt((max(cx, width - cx))**2 + (max(cy, height - cy))**2)
    radius   = max_dist * glow_radius

    # draw radial glow pixel by pixel (row by row for speed)
    pixels = []
    for y in range(height):
        row = []
        for x in range(width):
            dist = math.sqrt((x - cx)**2 + (y - cy)**2)
            # normalized 0 (center) to 1 (edge)
            t = min(dist / radius, 1.0)
            # smooth falloff
            t = t ** (1.5 / max(glow_strength, 0.01))
            t = min(t, 1.0)

            r = int(glow[0] + (bg[0] - glow[0]) * t)
            g = int(glow[1] + (bg[1] - glow[1]) * t)
            b = int(glow[2] + (bg[2] - glow[2]) * t)
            row.append((r, g, b))
        pixels.append(row)

    # apply pixels
    for y, row in enumerate(pixels):
        for x, color in enumerate(row):
            draw.point((x, y), fill=color)

    # text
    _addText(
        img,
        text=title,
        position=text_position,
        fontsize=fontsize,
        color=text_color,
        bold=True,
        shadow=True,
        padding=80,
    )

    return _saveImage(img, output)