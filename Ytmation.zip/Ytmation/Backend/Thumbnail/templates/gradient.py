"""
Gradient Thumbnail
-------------------
Vibrant gradient background with bold text. High contrast, eye-catching.
Great for viral/trending content.

params:
    color_top     : str = "#FF4500"  — gradient top color
    color_bottom  : str = "#1a1a2e"  — gradient bottom color
    text_color    : str = "#ffffff"  — text color
    fontsize      : int = 90         — text size
    text_position : str = "center"   — center / top / bottom
"""

from pathlib import Path
from PIL import Image
from Thumbnail.utils import (
    _addGradientBackground,
    _addText,
    _saveImage,
)


def run(
    title: str,
    output: Path,
    width: int          = 1280,
    height: int         = 720,
    color_top: str      = "#FF4500",
    color_bottom: str   = "#1a1a2e",
    text_color: str     = "#ffffff",
    fontsize: int       = 90,
    text_position: str  = "center",
) -> Path:
    img = Image.new("RGB", (width, height))

    _addGradientBackground(img, color_top=color_top, color_bottom=color_bottom)

    _addText(
        img,
        text=title,
        position=text_position,
        fontsize=fontsize,
        color=text_color,
        bold=True,
        shadow=True,
        padding=80,
    )

    return _saveImage(img, output)