# Thumbnail Module

## Purpose
Generates 1280x720 YouTube thumbnail images using PIL templates.
Thumbnails are uploaded to YouTube — they are NOT overlaid on videos (use Templates/ for overlays).

## Location
`Thumbnail/thumbnail.py`

## Templates
Templates live in `Thumbnail/templates/`. Each is a .py file with a run() function.
Current templates: bold_text, gradient, radial_glow

## Functions

### generateThumbnail(title, style, width, height, **params) -> Path
Generates a thumbnail using a named template.
```python
from Thumbnail.thumbnail import generateThumbnail
thumb = generateThumbnail(
    title="Your brain deletes memories",
    style="bold_text",
    bg_color="#0d0d0d",
    accent_color="#FF4500",
)
```

### previewThumbnail(title, style, **params) -> Path
Generates and opens thumbnail for preview.
```python
from Thumbnail.thumbnail import previewThumbnail
previewThumbnail("Your brain deletes memories", style="radial_glow")
```

### listTemplates() -> list[str]
Lists all available template names.
```python
from Thumbnail.thumbnail import listTemplates
print(listTemplates())  # ['bold_text', 'gradient', 'radial_glow']
```

### getThumbnail(name) -> Path
Gets a cached thumbnail by partial name match.
```python
from Thumbnail.thumbnail import getThumbnail
thumb = getThumbnail("bold_text")
```

## Template Params

### bold_text
- bg_color, text_color, accent_color, fontsize, show_accent, gradient

### gradient
- color_top, color_bottom, text_color, fontsize, text_position

### radial_glow
- glow_color, bg_color, glow_strength, glow_radius, glow_x, glow_y, text_color, fontsize, text_position

## Adding New Templates
Drop a .py file in Thumbnail/templates/ with:
```python
def run(title, output, width=1280, height=720, **params) -> Path:
    ...
```
It appears automatically in listTemplates().