# Script — YouTube script writer

Generates video narration scripts locally via **Ollama** using installed models.

## Models (already on this machine)

| Model | Size | Use |
|-------|------|-----|
| `qwen2.5-coder:3b` | 1.9 GB | **Default** — fast, good for drafts |
| `qwen2.5-coder:7b` | 4.7 GB | Higher quality, slower on CPU |

GPU is not used (ROCm mismatch); inference runs on CPU (~10 GB RAM free).

## Prerequisites

```bash
ollama serve   # if not already running
```

## CLI

```bash
# Basic script from a topic
python Script/script.py "why black holes are terrifying"

# Longer, styled
python Script/script.py "neon physics satisfying compilation" -d 8 -s "hype, short punchy lines"

# Custom prompt
python Script/script.py -p "Write a 60-second hook-only script for a marble run video"

# Use the 7B model
python Script/script.py "manhwa recap episode 12" -m qwen2.5-coder:7b

# Save to a specific path
python Script/script.py "topic" -o /path/to/script.txt --no-save
```

Auto-saved scripts go to `Cache/scripts/`.

## Prompts (`YT/Prompts/` — separate from Script/)

```
Prompts/
├── system.md
└── Prompts/
    ├── user_default.md
    ├── educational.md
    ├── neon_physics.md
    ├── manhwa_recap.md
    ├── soundscape.md
    └── shorts_hook.md
```

Templates use `{topic}`, `{duration_min}`, `{style}` placeholders.

```bash
python Script/script.py "marble run" --template neon_physics
python Script/script.py --list-prompts
```

## Python API

```python
from Script.script import generateScript

generateScript("satisfying dominoes", template="neon_physics", duration_min=8)
```

## Output format

Scripts use section labels: `[HOOK]`, `[BODY]`, `[CTA]`, with optional timestamps for editing and Voice TTS.
