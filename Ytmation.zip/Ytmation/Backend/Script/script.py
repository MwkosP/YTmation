#!/usr/bin/env python3
"""Generate YouTube video scripts via local Ollama."""

import argparse
import sys
from pathlib import Path

try:
    from .utils import (
        DEFAULT_MODEL,
        DEFAULT_USER_PROMPT,
        OUTPUT_DIR,
        build_user_prompt,
        list_prompts,
        load_system_prompt,
        ollama_chat,
        save_script,
    )
except ImportError:
    from utils import (
        DEFAULT_MODEL,
        DEFAULT_USER_PROMPT,
        OUTPUT_DIR,
        build_user_prompt,
        list_prompts,
        load_system_prompt,
        ollama_chat,
        save_script,
    )


def generateText(
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    system: str | None = None,
    temperature: float = 0.7,
) -> str:
    messages = [
        {"role": "system", "content": system or load_system_prompt()},
        {"role": "user", "content": prompt},
    ]
    return ollama_chat(model, messages, temperature=temperature)


def generateScript(
    topic: str,
    *,
    duration_min: int | None = 5,
    style: str = "educational, conversational",
    template: str = DEFAULT_USER_PROMPT,
    model: str = DEFAULT_MODEL,
    temperature: float = 0.7,
    save: bool = True,
) -> str:
    prompt = build_user_prompt(
        topic, duration_min=duration_min, style=style, template=template
    )
    print(f"Model: {model}")
    print("Generating...\n")
    text = generateText(prompt, model=model, temperature=temperature)
    print(text)
    if save:
        path = save_script(text, slug=topic[:40].replace(" ", "_"))
        print(f"\nSaved: {path}")
    return text


def runCli() -> int:
    parser = argparse.ArgumentParser(description="Generate YouTube scripts with Ollama")
    parser.add_argument("topic", nargs="?", help="Video topic or idea")
    parser.add_argument("-p", "--prompt", help="Full custom prompt (overrides topic)")
    parser.add_argument("-m", "--model", default=DEFAULT_MODEL, help=f"Ollama model (default: {DEFAULT_MODEL})")
    parser.add_argument("-d", "--duration", type=int, help="Target duration in minutes")
    parser.add_argument("-s", "--style", help="Tone, e.g. educational, hype, calm ASMR")
    parser.add_argument(
        "--template",
        default=DEFAULT_USER_PROMPT,
        help=f"Prompt template from Prompts/ (default: {DEFAULT_USER_PROMPT})",
    )
    parser.add_argument("--list-prompts", action="store_true", help="List available .md prompts")
    parser.add_argument("-t", "--temperature", type=float, default=0.7)
    parser.add_argument("-o", "--output", type=Path, help="Save to this file path")
    parser.add_argument("--slug", help="Filename slug for auto-saved script")
    parser.add_argument("--no-save", action="store_true", help="Print only, do not write to Cache")
    args = parser.parse_args()

    if args.list_prompts:
        for name in list_prompts():
            print(name)
        return 0

    if args.prompt:
        user_prompt = args.prompt
    elif args.topic:
        user_prompt = build_user_prompt(
            args.topic,
            duration_min=args.duration,
            style=args.style,
            template=args.template,
        )
    else:
        parser.error("Provide a topic or use -p/--prompt")

    if args.prompt:
        script = generateText(args.prompt, model=args.model, temperature=args.temperature)
        print(script)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(script.strip() + "\n", encoding="utf-8")
            print(f"Saved: {args.output}", file=sys.stderr)
        elif not args.no_save:
            save_script(script, slug=args.slug or "custom")
            print(f"Saved: {OUTPUT_DIR}", file=sys.stderr)
    else:
        generateScript(
            args.topic,
            duration_min=args.duration,
            style=args.style or "educational, conversational",
            template=args.template,
            model=args.model,
            temperature=args.temperature,
            save=not args.no_save,
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(runCli())
