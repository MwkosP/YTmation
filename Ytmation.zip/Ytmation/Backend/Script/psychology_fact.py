import json
import re
from datetime import datetime
from pathlib import Path

from Script.script import generateText

ROOT        = Path(__file__).resolve().parent.parent
PROMPT_PATH = ROOT / "Prompts" / "channels" / "MParkour_psychology.md"
OUTPUT_DIR  = ROOT / "Cache" / "scripts"


def generatePsychologyFact(topic: str = None, retries: int = 3) -> dict:
    prompt = PROMPT_PATH.read_text(encoding="utf-8")
    if topic:
        prompt += f"\n\nTopic: {topic}"

    for attempt in range(retries):
        try:
            raw    = generateText(prompt, temperature=0.8)
            raw    = re.sub(r'^```json|^```|```$', '', raw, flags=re.MULTILINE).strip()
            result = json.loads(raw)

            if "full_script" not in result or not result["full_script"]:
                result["full_script"] = " ".join(filter(None, [
                    result.get("hook", ""),
                    result.get("fact", ""),
                    result.get("explanation", ""),
                    result.get("example", ""),
                    result.get("mindblow", ""),
                    result.get("cta", ""),
                ]))

            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            stamp      = datetime.now().strftime("%Y%m%d_%H%M%S")
            topic_slug = result.get("topic", "unknown").replace(" ", "_")[:30]
            out_path   = OUTPUT_DIR / f"psychology_{topic_slug}_{stamp}.json"
            out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")

            print(f"📝 Script : {result.get('topic')}")
            print(f"   Hook   : {result.get('hook')}")
            print(f"   Words  : {len(result['full_script'].split())}")
            print(f"   Saved  : {out_path}")

            return result

        except json.JSONDecodeError as e:
            print(f"  ⚠ Attempt {attempt + 1}/{retries} failed: {e} — retrying...")

    raise ValueError(f"Failed to generate valid JSON after {retries} attempts")