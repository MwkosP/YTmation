import json
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

OLLAMA_URL = "http://127.0.0.1:11434"
DEFAULT_MODEL = "qwen2.5-coder:3b"
ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "Cache" / "scripts"
PROMPTS_DIR = ROOT / "Prompts"
USER_PROMPTS_DIR = PROMPTS_DIR / "Prompts"
DEFAULT_USER_PROMPT = "user_default"


def load_system_prompt() -> str:
    return (PROMPTS_DIR / "system.md").read_text(encoding="utf-8").strip()


def load_prompt(name: str) -> str:
    path = USER_PROMPTS_DIR / f"{name}.md"
    if not path.exists():
        available = ", ".join(list_prompts()) or "(none)"
        raise FileNotFoundError(f"Prompt '{name}' not found. Available: {available}")
    return path.read_text(encoding="utf-8").strip()


def list_prompts() -> list[str]:
    return sorted(p.stem for p in USER_PROMPTS_DIR.glob("*.md"))


def ollama_chat(model: str, messages: list[dict], temperature: float = 0.7) -> str:
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": temperature},
    }
    req = urllib.request.Request(
        f"{OLLAMA_URL}/api/chat",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=600) as resp:
            data = json.loads(resp.read())
    except urllib.error.URLError as e:
        raise RuntimeError(
            f"Cannot reach Ollama at {OLLAMA_URL}. Start it with: ollama serve\n{e}"
        ) from e

    return data["message"]["content"]


def build_user_prompt(
    topic: str,
    *,
    duration_min: int | None = 5,
    style: str | None = "educational, conversational",
    template: str = DEFAULT_USER_PROMPT,
    extra: str | None = None,
) -> str:
    text = load_prompt(template).format(
        topic=topic,
        duration_min=duration_min or 5,
        style=style or "educational, conversational",
    )
    if extra:
        text += f"\n\n{extra}"
    return text


def save_script(text: str, slug: str | None = None) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"{slug}_{stamp}.txt" if slug else f"script_{stamp}.txt"
    path = OUTPUT_DIR / name
    path.write_text(text.strip() + "\n", encoding="utf-8")
    return path
