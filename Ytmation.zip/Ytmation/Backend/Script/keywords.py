import json
import re
from pathlib import Path

from Script.script import generateText

ROOT = Path(__file__).resolve().parent.parent


def extractKeywords(full_script: str, timestamps: list[dict], interval: float = 6.0) -> list[dict]:
    prompt = f"""Given this spoken script, extract 6-8 of the most important and visual keywords.
For each keyword find the approximate time it is spoken based on the word list.

Script: {full_script}

Rules:
- Pick words that have strong visual representation (nouns, concepts, emotions)
- No filler words (the, a, is, are, you, we)
- Space them at least {interval} seconds apart
- Respond ONLY with valid JSON, no markdown

Format:
[
  {{"keyword": "brain", "search_query": "human brain illustration"}},
  {{"keyword": "memory", "search_query": "memory concept mind"}}
]"""

    raw    = generateText(prompt, temperature=0.3)
    raw    = re.sub(r'^```json|^```|```$', '', raw, flags=re.MULTILINE).strip()
    result = json.loads(raw)

    # map keywords to actual timestamps
    words      = [w["word"].lower().strip(".,!?") for w in timestamps]
    total_dur  = timestamps[-1]["end"] if timestamps else 60
    keywords   = []
    last_time  = -interval

    for item in result:
        keyword = item["keyword"].lower()

        # find the word in timestamps
        match_time = None
        for i, w in enumerate(words):
            if keyword in w or w in keyword:
                t = timestamps[i]["start"]
                if t - last_time >= interval:
                    match_time = t
                    last_time  = t
                    break

        # fallback — space evenly
        if match_time is None:
            candidate = last_time + interval
            if candidate < total_dur:
                match_time = candidate
                last_time  = candidate

        if match_time is not None:
            keywords.append({
                "keyword":      item["keyword"],
                "search_query": item.get("search_query", item["keyword"]),
                "start":        match_time,
            })

    return keywords