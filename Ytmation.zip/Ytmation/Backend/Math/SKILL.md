---
name: math
description: Use this skill when creating or editing anything under Math/. Covers the current render APIs in Math/math.py, voiceover integration, and the category layout for the upcoming Math/library blocks.
---

# Math Module — Agent Guide

## Purpose

`Math/` is the reusable animation engine used by workflow files.

- `Workflows/` orchestrates per-video pipelines.
- `Math/` owns render primitives, scene utilities, voiceover helpers, and reusable blocks.

---

## Current Render APIs (`Math/math.py`)

Use these directly from workflow scripts when needed:

| Function | Description |
|---|---|
| `listScenes(category=None)` | Lists builtin/community scene modules discoverable by name |
| `renderScene(name, duration=10, output=None, quality="medium", **params)` | Render a named scene module |
| `previewScene(name, output=None, **params)` | 3-second low-quality preview render |
| `getScene(name)` | Returns latest cached mp4 for a named scene |
| `randomScene(duration=10, **params)` | Pick and render a random scene |
| `renderCustomScene(manim_code, output=None, quality="medium")` | Render inline Manim code with `CustomScene` |
| `renderCustomVoiceoverScene(narration, animation_body, ..., **voice_kwargs)` | Render voice-synced inline Manim segment |

### Quality options

- `low` -> `-ql`
- `medium` -> `-qm`
- `high` -> `-qh`
- `4k` -> `-qk`

---

## Voiceover Layer (`Math/voiceover/`)

`renderCustomVoiceoverScene` builds a `VoiceoverScene` wrapper around `animation_body`.

Typical flow:

1. Generate or reuse an mp3 (`Voice.generateSpeech(..., model=...)` or legacy `Voice.generateVoice`)
2. `with self.voiceover(...) as tracker:`
3. Animate with `run_time=tracker.duration * ...`

Notes:

- `three_d=True` switches the wrapper to `ThreeDScene, VoiceoverScene`.
- `transcription_model=None` is valid and avoids Whisper dependencies.
- If you only need duration sync, do not force Whisper transcription.
- Preferred TTS router: `Voice.generateSpeech(text, model="gtts"|"orpheus:tara", ...)`
- Math helpers (unchanged for now):
  - `pregenerateVoice(...)` (gTTS)
  - `pregenerateOrpheusVoice(...)` (Orpheus HF Space, token/quota dependent)

---

## Library Layout (first-class target)

Reusable blocks should live in:

```text
Math/library/
  math/
    calculus/
    algebra/
    linear_algebra/
    geometry/
    statistics/
    number_theory/
  ml/
  physics/
  chemistry/
  economics/
  space/
  text/
```

Each block should be small and composable.

Recommended style:

```python
def SomeBlock(scene, ...):
    # build mobjects
    # play animations
    return created_mobject_or_group
```

---

## Rules

- Use Manim Community (`from manim import *`), never `manimlib`.
- Keep scenes and blocks isolated (no shared cross-scene state).
- Prefer reusable blocks in `Math/library` over copy-pasting scene code.
- Keep imports local inside scene functions when writing workflow scenes.
- Add new dependencies only when needed and note them in docs.