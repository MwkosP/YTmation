"""
manimAbstractions.py
---------------------
Reusable Manim building blocks for mathmwk videos.
Import this inside any CustomScene manim code string.

Usage inside a scene string:
    from manimAbstractions import stickman, ground, title_text, bar_chart
"""

from manim import *
import numpy as np


# ── CONSTANTS ─────────────────────────────────────────────────────────────

BG       = "#0a0a0a"
ORANGE   = "#FF4500"
YELLOW   = "#FFD700"
DGRAY    = "#222222"
LGRAY    = "#888888"


# ── SCENE SETUP ───────────────────────────────────────────────────────────

def setup(scene, bg=BG):
    """Set background color."""
    scene.camera.background_color = bg


# ── TEXT ──────────────────────────────────────────────────────────────────

def title(text, color=WHITE, size=42):
    """Consistent top-edge title."""
    return Text(text, font_size=size, color=color,
                weight=BOLD).to_edge(UP, buff=0.4)


def subtitle(text, color=LGRAY, size=28):
    """Consistent bottom-edge subtitle."""
    return Text(text, font_size=size, color=color).to_edge(DOWN, buff=0.4)


def big_text(text, color=WHITE, size=72, weight=BOLD):
    """Large centered text."""
    return Text(text, font_size=size, color=color, weight=weight)


def label(text, color=LGRAY, size=26):
    """Small descriptive label."""
    return Text(text, font_size=size, color=color)


def formula(tex, color=ORANGE, size=72):
    """Styled math formula."""
    return MathTex(tex, font_size=size, color=color)


def formula_box(tex, color=ORANGE, size=72, box_color=ORANGE):
    """Formula inside a highlighted rectangle."""
    f = MathTex(tex, font_size=size, color=color)
    box = SurroundingRectangle(f, color=box_color, stroke_width=2, buff=0.3)
    return VGroup(f, box)


def highlight(obj, color=ORANGE):
    """Surrounding rectangle highlight."""
    return SurroundingRectangle(obj, color=color, stroke_width=2, buff=0.2)


def stacked_text(*lines, colors=None, sizes=None, buff=0.35):
    """
    Stack multiple text lines vertically.
    e.g. stacked_text("Line 1", "Line 2", colors=[WHITE, ORANGE])
    """
    colors = colors or [WHITE] * len(lines)
    sizes  = sizes  or [44]    * len(lines)
    group  = VGroup(*[
        Text(line, font_size=s, color=c)
        for line, c, s in zip(lines, colors, sizes)
    ]).arrange(DOWN, buff=buff)
    return group


def counting_number(scene, start, end, pos=ORIGIN, color=ORANGE, size=80, duration=2):
    """Animated number counting up from start to end."""
    tracker = ValueTracker(start)
    num = always_redraw(lambda: Text(
        str(int(tracker.get_value())),
        font_size=size, color=color
    ).move_to(pos))
    scene.add(num)
    scene.play(tracker.animate.set_value(end), run_time=duration)
    return num


# ── LAYOUT ────────────────────────────────────────────────────────────────

def ground(y=-2.5, width=12, color=LGRAY):
    """Horizontal ground line."""
    return Line(LEFT*width/2 + UP*y, RIGHT*width/2 + UP*y,
                color=color, stroke_width=2)


def divider(color=DGRAY):
    """Vertical center divider."""
    return Line(UP*4, DOWN*4, color=color, stroke_width=1, stroke_opacity=0.5)


def grid(rows=5, cols=5, spacing=1.0, color=DGRAY):
    """Background grid."""
    lines = VGroup()
    for i in range(-cols//2, cols//2+1):
        lines.add(Line(UP*rows*spacing/2, DOWN*rows*spacing/2,
                      color=color, stroke_width=0.5, stroke_opacity=0.3
                      ).shift(RIGHT*i*spacing))
    for i in range(-rows//2, rows//2+1):
        lines.add(Line(LEFT*cols*spacing/2, RIGHT*cols*spacing/2,
                      color=color, stroke_width=0.5, stroke_opacity=0.3
                      ).shift(UP*i*spacing))
    return lines


# ── STICKMAN ──────────────────────────────────────────────────────────────

def stickman(pos=ORIGIN, color=WHITE, scale=1.0, arm_angle=0):
    """
    Basic stickman figure.
    arm_angle: 0 = arms down, 1 = arms up (celebration)
    """
    s = scale
    head   = Circle(radius=0.25*s, color=color, stroke_width=2).move_to(pos+UP*0.85*s)
    body   = Line(pos+UP*0.6*s,   pos+DOWN*0.3*s, color=color, stroke_width=2)

    if arm_angle == 1:  # arms up
        arm_l = Line(pos+UP*0.3*s, pos+LEFT*0.5*s+UP*0.6*s,  color=color, stroke_width=2)
        arm_r = Line(pos+UP*0.3*s, pos+RIGHT*0.5*s+UP*0.6*s, color=color, stroke_width=2)
    else:               # arms neutral
        arm_l = Line(pos+UP*0.3*s, pos+LEFT*0.4*s+UP*0.1*s,  color=color, stroke_width=2)
        arm_r = Line(pos+UP*0.3*s, pos+RIGHT*0.4*s+UP*0.1*s, color=color, stroke_width=2)

    leg_l  = Line(pos+DOWN*0.3*s, pos+LEFT*0.3*s+DOWN*0.7*s,  color=color, stroke_width=2)
    leg_r  = Line(pos+DOWN*0.3*s, pos+RIGHT*0.3*s+DOWN*0.7*s, color=color, stroke_width=2)
    return VGroup(head, body, arm_l, arm_r, leg_l, leg_r)


def stickman_sitting(pos=ORIGIN, color=WHITE, scale=1.0):
    """Stickman in sitting position."""
    s = scale
    head  = Circle(radius=0.25*s, color=color, stroke_width=2).move_to(pos+UP*0.6*s)
    body  = Line(pos+UP*0.35*s, pos+DOWN*0.05*s, color=color, stroke_width=2)
    arm_l = Line(pos+UP*0.2*s,  pos+LEFT*0.4*s,  color=color, stroke_width=2)
    arm_r = Line(pos+UP*0.2*s,  pos+RIGHT*0.4*s, color=color, stroke_width=2)
    leg_l = Line(pos+DOWN*0.05*s, pos+LEFT*0.5*s+DOWN*0.05*s,  color=color, stroke_width=2)
    leg_r = Line(pos+DOWN*0.05*s, pos+RIGHT*0.5*s+DOWN*0.05*s, color=color, stroke_width=2)
    shin_l = Line(pos+LEFT*0.5*s+DOWN*0.05*s, pos+LEFT*0.5*s+DOWN*0.4*s, color=color, stroke_width=2)
    shin_r = Line(pos+RIGHT*0.5*s+DOWN*0.05*s, pos+RIGHT*0.5*s+DOWN*0.4*s, color=color, stroke_width=2)
    return VGroup(head, body, arm_l, arm_r, leg_l, leg_r, shin_l, shin_r)


def stickman_running(pos=ORIGIN, color=WHITE, scale=1.0):
    """Stickman in running pose."""
    s = scale
    head  = Circle(radius=0.25*s, color=color, stroke_width=2).move_to(pos+UP*0.85*s)
    body  = Line(pos+UP*0.6*s, pos+DOWN*0.2*s, color=color, stroke_width=2)
    arm_l = Line(pos+UP*0.3*s, pos+LEFT*0.5*s+UP*0.4*s,  color=color, stroke_width=2)
    arm_r = Line(pos+UP*0.3*s, pos+RIGHT*0.3*s+DOWN*0.1*s, color=color, stroke_width=2)
    leg_l = Line(pos+DOWN*0.2*s, pos+LEFT*0.4*s+DOWN*0.7*s,  color=color, stroke_width=2)
    leg_r = Line(pos+DOWN*0.2*s, pos+RIGHT*0.2*s+DOWN*0.1*s, color=color, stroke_width=2)
    return VGroup(head, body, arm_l, arm_r, leg_l, leg_r)


def thought_bubble(pos=ORIGIN, text="?", color=WHITE, size=36):
    """Thought bubble with text above a position."""
    bubble = RoundedRectangle(width=1.5, height=0.9, corner_radius=0.3,
                              color=color, stroke_width=2).move_to(pos+UP*1.5)
    dot1 = Dot(pos+UP*0.9, radius=0.06, color=color)
    dot2 = Dot(pos+UP*1.1, radius=0.09, color=color)
    txt  = Text(text, font_size=size, color=color).move_to(bubble)
    return VGroup(bubble, dot1, dot2, txt)


def speech_bubble(pos=ORIGIN, text="Hello!", color=WHITE, size=28):
    """Speech bubble pointing from pos."""
    bubble = RoundedRectangle(width=2.5, height=0.9, corner_radius=0.25,
                              color=color, stroke_width=2).move_to(pos+UP*1.6+RIGHT*0.8)
    pointer = Triangle(color=color, stroke_width=2).scale(0.2).move_to(pos+UP*1.1+RIGHT*0.2)
    txt = Text(text, font_size=size, color=color).move_to(bubble)
    return VGroup(bubble, pointer, txt)


# ── SHAPES & OBJECTS ──────────────────────────────────────────────────────

def tree(pos=ORIGIN, trunk_color="#8B4513", leaf_color="#2d5a27", scale=1.0):
    """Simple tree."""
    s = scale
    trunk = Rectangle(width=0.3*s, height=1.5*s, color=trunk_color,
                     fill_opacity=1, stroke_width=0).move_to(pos+DOWN*0.25*s)
    leaves = Circle(radius=0.8*s, color=leaf_color,
                   fill_opacity=0.85, stroke_width=0).move_to(pos+UP*0.9*s)
    return VGroup(trunk, leaves)


def apple(pos=ORIGIN, color=ORANGE, scale=1.0):
    """Apple shape."""
    s = scale
    body = Circle(radius=0.2*s, color=color, fill_opacity=0.9).move_to(pos)
    stem = Line(pos+UP*0.2*s, pos+UP*0.35*s, color="#8B4513", stroke_width=2)
    return VGroup(body, stem)


def planet(pos=ORIGIN, radius=0.8, color=BLUE, label_text="", opacity=0.7):
    """Planet/circle with optional label."""
    p = Circle(radius=radius, color=color, fill_opacity=opacity).move_to(pos)
    group = VGroup(p)
    if label_text:
        lbl = Text(label_text, font_size=24, color=WHITE).move_to(pos)
        group.add(lbl)
    return group


def door(pos=ORIGIN, number=1, color=ORANGE, scale=1.0):
    """Door shape with number."""
    s = scale
    rect = Rectangle(width=1.4*s, height=2.2*s, color=color,
                    fill_opacity=0.3, stroke_width=3).move_to(pos)
    num  = Text(str(number), font_size=int(48*s), color=WHITE).move_to(pos)
    knob = Dot(pos+RIGHT*0.4*s, radius=0.06*s, color=color)
    return VGroup(rect, num, knob)


def arrow_between(obj1, obj2, color=WHITE, stroke=3):
    """Arrow from one object to another."""
    return Arrow(obj1.get_right(), obj2.get_left(),
                color=color, stroke_width=stroke)


def double_arrow(obj1, obj2, color=WHITE, stroke=3):
    """Double arrow between two objects."""
    return DoubleArrow(obj1.get_right(), obj2.get_left(),
                      color=color, stroke_width=stroke)


def force_arrow(start, direction=UP, length=1.5, color=ORANGE, label_text="F"):
    """Force arrow with label."""
    end = start + direction * length
    arr = Arrow(start, end, color=color, stroke_width=4)
    lbl = Text(label_text, font_size=28, color=color).next_to(arr, RIGHT, buff=0.1)
    return VGroup(arr, lbl)


# ── CHARTS ────────────────────────────────────────────────────────────────

def single_bar(height, width=1.2, color=ORANGE, label_text="", pct_text="",
               pos=ORIGIN, max_height=4.0):
    """Single bar for a bar chart."""
    h = height / 100 * max_height if height <= 100 else height
    bar = Rectangle(width=width, height=h, color=color,
                   fill_opacity=0.85, stroke_width=2)
    bar.align_to(pos, DOWN)
    group = VGroup(bar)
    if pct_text:
        pct = Text(pct_text, font_size=36, color=WHITE).move_to(bar)
        group.add(pct)
    if label_text:
        lbl = Text(label_text, font_size=28, color=color).next_to(bar, DOWN, buff=0.25)
        group.add(lbl)
    return group


def pie_slice(angle, color=ORANGE, radius=2.0, start_angle=0, label_text=""):
    """Single pie slice."""
    sector = Sector(radius=radius, angle=angle, start_angle=start_angle,
                   color=color, fill_opacity=0.8, stroke_width=2)
    group = VGroup(sector)
    if label_text:
        mid_angle = start_angle + angle / 2
        lbl_pos = sector.get_center() + np.array([
            np.cos(mid_angle) * radius * 0.6,
            np.sin(mid_angle) * radius * 0.6,
            0
        ])
        lbl = Text(label_text, font_size=24, color=WHITE).move_to(lbl_pos)
        group.add(lbl)
    return group


# ── AXES & GRAPHS ─────────────────────────────────────────────────────────

def styled_axes(x_range=(-4,4,1), y_range=(-3,3,1),
                x_len=7, y_len=5, color=LGRAY):
    """Pre-styled 2D axes."""
    return Axes(
        x_range=x_range, y_range=y_range,
        x_length=x_len, y_length=y_len,
        axis_config={"color": color, "stroke_width": 1.5,
                    "include_tip": True},
    )


def number_line_custom(start=-5, end=5, step=1, color=WHITE, include_numbers=True):
    """Styled number line."""
    return NumberLine(
        x_range=[start, end, step],
        color=color,
        include_numbers=include_numbers,
        font_size=24,
    )


# ── ANIMATIONS (scene-level helpers) ─────────────────────────────────────

def reveal_lines(scene, *mobjects, lag=0.35, shift=UP*0.15, duration=0.6):
    """Fade in multiple objects one by one."""
    scene.play(
        LaggedStart(*[FadeIn(m, shift=shift) for m in mobjects if hasattr(m, 'get_center')],
                   lag_ratio=lag),
        run_time=duration * len(mobjects),
    )


def write_sequence(scene, *mobjects, lag=0.3):
    """Write multiple objects sequentially."""
    scene.play(
        LaggedStart(*[Write(m) for m in mobjects], lag_ratio=lag),
        run_time=0.8 * len(mobjects),
    )


def pulse(scene, obj, scale=1.15, duration=0.4):
    """Quick pulse/pop effect on an object."""
    scene.play(obj.animate.scale(scale), run_time=duration/2)
    scene.play(obj.animate.scale(1/scale), run_time=duration/2)


def flash_color(scene, obj, color=ORANGE, duration=0.5):
    """Flash an object to a color and back."""
    orig = obj.color
    scene.play(obj.animate.set_color(color), run_time=duration/2)
    scene.play(obj.animate.set_color(orig),  run_time=duration/2)


def count_up_anim(scene, number_mob, tracker, end_val, duration=2):
    """Animate a number counting up."""
    scene.play(tracker.animate.set_value(end_val), run_time=duration)


def morph(scene, obj1, obj2, duration=1.0):
    """Transform one object into another."""
    scene.play(ReplacementTransform(obj1, obj2), run_time=duration)


# ── PHYSICS ───────────────────────────────────────────────────────────────

def falling_object(scene, obj, distance=3.0, duration=1.2):
    """Animate an object falling with ease_in."""
    scene.play(
        obj.animate.shift(DOWN * distance),
        run_time=duration,
        rate_func=rate_functions.ease_in_cubic,
    )


def bouncing_object(scene, obj, height=1.5, bounces=3, duration=2.0):
    """Animate an object bouncing."""
    for i in range(bounces):
        h = height * (0.6 ** i)
        scene.play(obj.animate.shift(UP*h),   run_time=duration/bounces/2,
                  rate_func=rate_functions.ease_out_quad)
        scene.play(obj.animate.shift(DOWN*h), run_time=duration/bounces/2,
                  rate_func=rate_functions.ease_in_quad)


def orbit(scene, obj, center=ORIGIN, radius=2.0, duration=4.0, angle=TAU):
    """Animate an object orbiting a center point."""
    scene.play(
        MoveAlongPath(obj, Circle(radius=radius).move_to(center)),
        run_time=duration, rate_func=linear,
    )


# ── EMPHASIS ──────────────────────────────────────────────────────────────

def exclamation(pos=ORIGIN, color=ORANGE, size=60):
    """Big exclamation mark."""
    return Text("!", font_size=size, color=color, weight=BOLD).move_to(pos)


def question_marks(pos=ORIGIN, color=WHITE, count=3):
    """Floating question marks."""
    return VGroup(*[
        Text("?", font_size=60-i*10, color=color
            ).shift(pos + UP*(0.5+i*0.4) + RIGHT*(i*0.3-0.3))
        for i in range(count)
    ])


def stars_burst(pos=ORIGIN, color=YELLOW, count=5):
    """Star burst effect."""
    return VGroup(*[
        Text("★", font_size=28, color=color
            ).shift(pos + UP*(0.3+i*0.25) + RIGHT*((i-count//2)*0.4))
        for i in range(count)
    ])


def checkmark(pos=ORIGIN, color="#00ff88", size=80):
    """Green checkmark."""
    return MathTex(r"\checkmark", font_size=size, color=color).move_to(pos)


def crossmark(pos=ORIGIN, color="#ff4444", size=80):
    """Red cross mark."""
    return MathTex(r"\times", font_size=size, color=color).move_to(pos)


# ── TRANSITIONS ───────────────────────────────────────────────────────────

def fade_in_scene(scene, *objects, duration=0.5):
    """Fade in multiple objects at once."""
    scene.play(*[FadeIn(o) for o in objects], run_time=duration)


def fade_out_scene(scene, *objects, duration=0.5):
    """Fade out multiple objects at once."""
    scene.play(*[FadeOut(o) for o in objects], run_time=duration)


def clear_scene(scene, duration=0.4):
    """Fade out everything on screen."""
    scene.play(*[FadeOut(m) for m in scene.mobjects], run_time=duration)