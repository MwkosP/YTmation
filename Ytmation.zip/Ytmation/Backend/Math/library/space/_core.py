"""Shared constants + helpers for space/astronomy scenes."""

from manim import *

SPACE_BG = "#0a0a0a"
SPACE_STAR = YELLOW
SPACE_PLANET = BLUE_B
SPACE_ORBIT = GREY_B
SPACE_ACCENT = TEAL_B
SPACE_ALERT = RED_B


def makePlanet(radius: float = 0.28, color=SPACE_PLANET, label: str | None = None) -> VGroup:
    body = Circle(radius=radius, color=color).set_fill(color, opacity=0.35)
    g = VGroup(body)
    if label:
        g.add(Text(label, font_size=20, color=color).next_to(body, DOWN, buff=0.12))
    return g


def makeStar(radius: float = 0.45, color=SPACE_STAR) -> VGroup:
    core = Circle(radius=radius, color=color).set_fill(color, opacity=0.5)
    glow = Circle(radius=radius * 1.35, color=color, stroke_opacity=0.25).set_fill(color, opacity=0.08)
    return VGroup(glow, core)
