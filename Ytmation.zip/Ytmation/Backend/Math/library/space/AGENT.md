# Space Library — Agent Cookbook

## Where things live

| Layer | Path | Use for |
|------|------|---------|
| Shared layout | `Math/library/common/` | `SceneLayout`, titles, captions |
| Space domain | `Math/library/space/` | make/show/demo astronomy blocks |
| Channel showcase | `Workflows/channels/mathmwk/spaceShowcase.py` | Render + stitch catalog |

## API layers

| Prefix | Plays on scene? | Use when |
|------|-------------------|---------|
| `make*` | No | Build planets, stars |
| `show*` | Yes (one beat) | Compose inside scenes |
| `demo*` | Yes (mini lesson) | Showcase segments |

## Available demos

- `demoSolarSystem`
- `demoKeplerOrbit`
- `demoGravityWell`
- `demoMoonPhases`
- `demoEclipse`
- `demoRocketLaunch`
- `demoOrbitalTransfer`
- `demoStarLifecycle`
- `demoBlackHole`
- `demoGalaxy`
- `demoCosmicExpansion`
- `demoLightYearScale`
- `demoSpaceStationOrbit`
- `demoCometOrbit`

## Quick usage

```python
from Math.library.common.styling import setupScene
from Math.library.space.recipes import demoSolarSystem

setupScene(scene)
demoSolarSystem(scene)
```

## Render full catalog

```bash
python Workflows/channels/mathmwk/spaceShowcase.py
```
