"""Space/astronomy recipes — one topic per call."""

from manim import *

from Math.library.common.layout import SceneLayout, makeTitle, makeCaption
from Math.library.common.styling import setupScene
from Math.library.space.shows import (
    showSolarSystem,
    showKeplerOrbit,
    showGravityWell,
    showMoonPhases,
    showEclipse,
    showRocketLaunch,
    showOrbitalTransfer,
    showStarLifecycle,
    showBlackHole,
    showGalaxy,
    showCosmicExpansion,
    showLightYearScale,
    showSpaceStationOrbit,
    showCometOrbit,
)


def demoSolarSystem(scene: Scene, title_text: str = "Solar System") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=44, layout=layout)), run_time=0.6)
    showSolarSystem(scene, layout=layout)


def demoKeplerOrbit(scene: Scene, title_text: str = "Kepler Orbits") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showKeplerOrbit(scene, layout=layout)


def demoGravityWell(scene: Scene, title_text: str = "Gravity Well") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showGravityWell(scene, layout=layout)


def demoMoonPhases(scene: Scene, title_text: str = "Moon Phases") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showMoonPhases(scene, layout=layout)


def demoEclipse(scene: Scene, title_text: str = "Solar Eclipse") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showEclipse(scene, layout=layout)


def demoRocketLaunch(scene: Scene, title_text: str = "Rocket Launch") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=42, layout=layout)), run_time=0.6)
    showRocketLaunch(scene, layout=layout)


def demoOrbitalTransfer(scene: Scene, title_text: str = "Orbital Transfer") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showOrbitalTransfer(scene, layout=layout)
    scene.play(FadeIn(makeCaption("Hohmann-style transfer between orbits", layout=layout)), run_time=0.5)


def demoStarLifecycle(scene: Scene, title_text: str = "Star Lifecycle") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showStarLifecycle(scene, layout=layout)


def demoBlackHole(scene: Scene, title_text: str = "Black Hole") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=44, layout=layout)), run_time=0.6)
    showBlackHole(scene, layout=layout)


def demoGalaxy(scene: Scene, title_text: str = "Spiral Galaxy") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=44, layout=layout)), run_time=0.6)
    showGalaxy(scene, layout=layout)


def demoCosmicExpansion(scene: Scene, title_text: str = "Cosmic Expansion") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showCosmicExpansion(scene, layout=layout)


def demoLightYearScale(scene: Scene, title_text: str = "Light-Year Scale") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showLightYearScale(scene, layout=layout)


def demoSpaceStationOrbit(scene: Scene, title_text: str = "Low Earth Orbit") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showSpaceStationOrbit(scene, layout=layout)


def demoCometOrbit(scene: Scene, title_text: str = "Comet Orbit") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showCometOrbit(scene, layout=layout)
