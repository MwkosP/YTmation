"""Layout-aware space/astronomy show* beats."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.space._core import makePlanet, makeStar, SPACE_ACCENT, SPACE_ORBIT, SPACE_ALERT


def showSolarSystem(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("hero")
    sun = makeStar(0.5)
    planets = VGroup(
        makePlanet(0.08, BLUE_B, "Mercury"),
        makePlanet(0.1, ORANGE, "Venus"),
        makePlanet(0.12, GREEN_B, "Earth"),
        makePlanet(0.1, RED_B, "Mars"),
    )
    orbits = VGroup(*[Circle(radius=0.8 + i * 0.55, color=SPACE_ORBIT, stroke_opacity=0.35) for i in range(4)])
    for i, p in enumerate(planets):
        p.move_to(orbits[i].point_at_angle(PI / 6))
    system = VGroup(orbits, sun, planets)
    placeInRegion(system, "main", layout=layout, fit=True)
    scene.play(FadeIn(sun), Create(orbits), FadeIn(planets), run_time=run_time)
    return system


def showKeplerOrbit(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.2) -> VGroup:
    layout = layout or SceneLayout("standard")
    ellipse = Ellipse(width=5.5, height=3.2, color=SPACE_ORBIT)
    planet = makePlanet(0.14, GREEN_B)
    planet.move_to(ellipse.get_right())
    label = Text("faster near perihelion", font_size=22, color=SPACE_ACCENT).next_to(ellipse, DOWN, buff=0.2)
    g = VGroup(ellipse, planet, label)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(ellipse), FadeIn(planet), FadeIn(label), run_time=run_time * 0.5)
    scene.play(MoveAlongPath(planet, ellipse), run_time=run_time * 0.5)
    return g


def showGravityWell(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    mass = makeStar(0.35)
    grid = VGroup(*[Arc(radius=0.5 + i * 0.35, angle=TAU, color=GREY_B, stroke_opacity=0.35) for i in range(5)])
    probe = Dot(RIGHT * 2.8 + UP * 0.8, radius=0.08, color=YELLOW)
    g = VGroup(grid, mass, probe)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(mass), Create(grid), FadeIn(probe), run_time=run_time * 0.4)
    scene.play(probe.animate.move_to(DOWN * 0.6 + RIGHT * 0.4), run_time=run_time * 0.6)
    return g


def showMoonPhases(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    earth = makePlanet(0.22, BLUE_B)
    phases = VGroup(*[
        Circle(radius=0.12, color=GREY_B).set_fill(GREY_B, opacity=0.15 + 0.15 * i)
        for i in range(4)
    ]).arrange(RIGHT, buff=0.45)
    g = VGroup(earth, phases)
    g.arrange(DOWN, buff=0.45)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(earth), LaggedStart(*[FadeIn(p) for p in phases], lag_ratio=0.2), run_time=run_time)
    return g


def showEclipse(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    sun = makeStar(0.4)
    moon = Circle(radius=0.18, color=GREY_B).set_fill(GREY_B, opacity=0.8)
    shadow = Circle(radius=0.22, color=BLACK).set_fill(BLACK, opacity=0.85)
    left = VGroup(sun, moon).arrange(RIGHT, buff=0.5)
    right = Text("Moon blocks sunlight\n(solar eclipse)", font_size=24, color=YELLOW)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(sun), FadeIn(moon), moon.animate.shift(LEFT * 0.45), FadeIn(right), run_time=run_time * 0.6)
    scene.play(FadeIn(shadow.move_to(sun[1].get_center())), run_time=run_time * 0.4)
    return VGroup(left, right, shadow)


def showRocketLaunch(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("hero")
    rocket = VGroup(
        Triangle(color=GREY_B).set_fill(GREY_B, opacity=0.5).scale(0.35),
        Rectangle(width=0.25, height=0.7, color=GREY_B).set_fill(GREY_D, opacity=0.5),
    ).arrange(DOWN, buff=0)
    flame = Triangle(color=ORANGE).set_fill(ORANGE, opacity=0.6).scale(0.2).next_to(rocket, DOWN, buff=0.02)
    g = VGroup(rocket, flame)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(g), run_time=run_time * 0.35)
    scene.play(g.animate.shift(UP * 2.2), FadeOut(flame), run_time=run_time * 0.65)
    return g


def showOrbitalTransfer(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    inner = Circle(radius=1.2, color=SPACE_ORBIT)
    outer = Circle(radius=2.0, color=SPACE_ORBIT)
    transfer = Arc(radius=1.6, start_angle=0, angle=PI, color=SPACE_ACCENT)
    sat = Dot(inner.get_right(), radius=0.08, color=YELLOW)
    g = VGroup(inner, outer, transfer, sat)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(inner), Create(outer), Create(transfer), FadeIn(sat), run_time=run_time * 0.5)
    scene.play(MoveAlongPath(sat, transfer), run_time=run_time * 0.5)
    return g


def showStarLifecycle(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    stages = VGroup(
        Text("Nebula", font_size=24, color=BLUE_B),
        Text("Main sequence", font_size=24, color=YELLOW),
        Text("Red giant", font_size=24, color=RED_B),
        Text("White dwarf", font_size=24, color=WHITE),
    ).arrange(RIGHT, buff=0.45)
    arrows = VGroup(*[Arrow(stages[i].get_right(), stages[i + 1].get_left(), buff=0.08, color=GREY_B) for i in range(3)])
    g = VGroup(stages, arrows)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(LaggedStart(*[FadeIn(s) for s in stages], lag_ratio=0.2), run_time=run_time * 0.55)
    scene.play(*[GrowArrow(a) for a in arrows], run_time=run_time * 0.45)
    return g


def showBlackHole(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("hero")
    hole = Circle(radius=0.55, color=BLACK).set_fill(BLACK, opacity=1.0)
    disk = Annulus(inner_radius=0.6, outer_radius=1.1, color=ORANGE).set_fill(ORANGE, opacity=0.25)
    g = VGroup(disk, hole)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(disk), FadeIn(hole), run_time=run_time * 0.5)
    scene.play(Rotate(disk, angle=PI / 2), run_time=run_time * 0.5)
    return g


def showGalaxy(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("hero")
    arms = VGroup(*[Arc(radius=0.6 + i * 0.25, angle=3 * PI / 4, color=PURPLE_B, stroke_width=3) for i in range(4)])
    core = Dot(ORIGIN, radius=0.12, color=YELLOW)
    g = VGroup(arms, core)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(core), LaggedStart(*[Create(a) for a in arms], lag_ratio=0.15), run_time=run_time)
    return g


def showCosmicExpansion(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    dots = VGroup(*[Dot(np.array([np.random.uniform(-2.5, 2.5), np.random.uniform(-1.5, 1.5), 0]), radius=0.05, color=BLUE_B) for _ in range(20)])
    placeInRegion(dots, "main", layout=layout, fit=True)
    scene.play(FadeIn(dots), run_time=run_time * 0.35)
    scene.play(dots.animate.scale(1.6), run_time=run_time * 0.65)
    return dots


def showLightYearScale(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = MathTex(r"\mathrm{1\ ly \approx 9.46 \times 10^{12}\ km}", color=SPACE_ACCENT)
    right = Text("Distance light travels\nin one year", font_size=24, color=YELLOW)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(Write(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)


def showSpaceStationOrbit(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    earth = makePlanet(0.35, BLUE_B)
    orbit = Circle(radius=1.4, color=SPACE_ORBIT)
    iss = Rectangle(width=0.35, height=0.12, color=GREY_B).set_fill(GREY_B, opacity=0.5)
    iss.move_to(orbit.point_at_angle(0))
    g = VGroup(earth, orbit, iss)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(earth), Create(orbit), FadeIn(iss), run_time=run_time * 0.45)
    scene.play(Rotate(iss, angle=TAU, about_point=earth[0].get_center()), run_time=run_time * 0.55)
    return g


def showCometOrbit(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    sun = makeStar(0.25)
    path = Ellipse(width=6.0, height=2.2, color=SPACE_ORBIT)
    comet = Dot(path.get_left(), radius=0.08, color=TEAL_B)
    tail = Line(comet.get_center(), comet.get_center() + LEFT * 0.6, color=TEAL_B, stroke_opacity=0.6)
    g = VGroup(path, sun, comet, tail)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(sun), Create(path), FadeIn(comet), Create(tail), run_time=run_time * 0.45)
    scene.play(MoveAlongPath(comet, path), run_time=run_time * 0.55)
    return g
