"""Stoichiometry visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_ACCENT, CHEM_PRIMARY


def showMoleConcept(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = MathTex(r"\mathrm{n = \frac{m}{M}}", color=CHEM_ACCENT).scale(1.2)
    right = VGroup(
        Text("1 mol = 6.02e23 particles", font_size=24),
        Text("Avogadro's number", font_size=22, color=YELLOW),
    ).arrange(DOWN, buff=0.2)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(Write(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)


def showLimitingReagent(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    eq = MathTex(r"\mathrm{2H_2 + O_2 \rightarrow 2H_2O}", color=GREEN_B)
    bars = VGroup(
        Rectangle(width=2.2, height=0.35, color=BLUE_B).set_fill(BLUE_E, opacity=0.35),
        Rectangle(width=1.0, height=0.35, color=ORANGE).set_fill(ORANGE, opacity=0.35),
    ).arrange(RIGHT, buff=0.3)
    labels = VGroup(Text("H2 (excess)", font_size=22), Text("O2 (limiting)", font_size=22, color=ORANGE)).arrange(DOWN, buff=0.15)
    g = VGroup(eq, bars, labels).arrange(DOWN, buff=0.35)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Write(eq), FadeIn(bars), FadeIn(labels), run_time=run_time)
    return g


def showPercentYield(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    formula = MathTex(r"\mathrm{\%Yield = \frac{actual}{theoretical}\times 100}", color=CHEM_PRIMARY).scale(1.0)
    placeInRegion(formula, "main", layout=layout, fit=True)
    scene.play(Write(formula), run_time=run_time)
    return VGroup(formula)
