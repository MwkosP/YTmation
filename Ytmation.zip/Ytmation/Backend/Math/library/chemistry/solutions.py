"""Solutions visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_PRIMARY, CHEM_ACCENT


def showMolarityDilution(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    m1 = MathTex(r"\mathrm{M_1V_1 = M_2V_2}", color=CHEM_PRIMARY).scale(1.1)
    placeInRegion(m1, "main", layout=layout, fit=True)
    scene.play(Write(m1), run_time=run_time)
    return VGroup(m1)


def showSolubilityCurve(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 100, 20], y_range=[0, 120, 20], x_length=6.5, y_length=3.5)
    axes_labels = VGroup(Text("T (°C)", font_size=22).next_to(axes, DOWN), Text("g solute / 100g", font_size=22).next_to(axes, LEFT).rotate(PI / 2))
    curve = axes.plot(lambda x: 20 + 0.8 * x, color=CHEM_ACCENT)
    g = VGroup(axes, curve, axes_labels)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(curve), FadeIn(axes_labels), run_time=run_time)
    return g


def showColligativeProperties(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = Text("Boiling point elevation", font_size=26, color=ORANGE)
    right = Text("Freezing point depression", font_size=26, color=BLUE_B)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)
