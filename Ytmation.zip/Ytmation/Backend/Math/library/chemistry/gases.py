"""Gas law visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_ACCENT


def showGasLaws(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("split")
    ideal = MathTex(r"\mathrm{PV = nRT}", color=CHEM_ACCENT).scale(1.1)
    boyle = Text("Boyle: P ↑ when V ↓", font_size=26, color=BLUE_B)
    charles = Text("Charles: V ↑ when T ↑", font_size=26, color=ORANGE)
    right = VGroup(boyle, charles).arrange(DOWN, buff=0.25)
    placeInRegion(ideal, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(Write(ideal), FadeIn(right), run_time=run_time)
    return VGroup(ideal, right)


def showParticlePressure(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    box = Rectangle(width=4.5, height=2.5, color=GREY_B)
    dots = VGroup(*[Dot(box.get_center() + np.array([np.random.uniform(-1.8, 1.8), np.random.uniform(-0.9, 0.9), 0]), radius=0.06, color=YELLOW) for _ in range(18)])
    g = VGroup(box, dots)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(box), FadeIn(dots), run_time=run_time * 0.5)
    scene.play(dots.animate.shift(RIGHT * 0.4 + UP * 0.15), run_time=run_time * 0.5)
    return g
