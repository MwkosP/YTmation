"""Chemistry recipes — one topic per call."""

from manim import *

from Math.library.common.layout import SceneLayout, makeTitle, makeCaption
from Math.library.common.styling import setupScene
from Math.library.chemistry.shows import (
    showAtomicStructure,
    showPeriodicTrend,
    showIonicBond,
    showCovalentBond,
    showBalancingEquation,
    showReactionRate,
    showPHScale,
    showTitrationCurve,
    showEquilibriumShift,
    showRedox,
)
from Math.library.chemistry.stoichiometry import showMoleConcept, showLimitingReagent, showPercentYield
from Math.library.chemistry.thermochemistry import showEnthalpyProfile, showEndothermicProfile, showHessLaw
from Math.library.chemistry.gases import showGasLaws, showParticlePressure
from Math.library.chemistry.solutions import showMolarityDilution, showSolubilityCurve, showColligativeProperties
from Math.library.chemistry.acids_bases import showBufferSystem, showConjugatePairs, showStrongWeakAcids
from Math.library.chemistry.kinetics import showActivationEnergy, showCatalystEffect
from Math.library.chemistry.equilibrium_adv import showEquilibriumConstant, showIceTable
from Math.library.chemistry.electrochemistry import showGalvanicCell, showElectrolyticCell
from Math.library.chemistry.organic import showFunctionalGroups, showHydrocarbonChain
from Math.library.chemistry.atomic_adv import showOrbitalDiagram, showElectronConfiguration, showIntermolecularForces


def demoAtomicStructure(scene: Scene, title_text: str = "Atomic Structure") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showAtomicStructure(scene, layout=layout)


def demoPeriodicTrends(scene: Scene, title_text: str = "Periodic Trends") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showPeriodicTrend(scene, layout=layout)


def demoOrbitalDiagram(scene: Scene, title_text: str = "Orbital Diagram") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showOrbitalDiagram(scene, layout=layout)


def demoElectronConfiguration(scene: Scene, title_text: str = "Electron Configuration") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title_text, size=34, layout=layout)), run_time=0.6)
    showElectronConfiguration(scene, layout=layout)


def demoIntermolecularForces(scene: Scene, title_text: str = "Intermolecular Forces") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=36, layout=layout)), run_time=0.6)
    showIntermolecularForces(scene, layout=layout)


def demoIonicBond(scene: Scene, title_text: str = "Ionic Bonding") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showIonicBond(scene, layout=layout)


def demoCovalentBond(scene: Scene, title_text: str = "Covalent Bonding") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showCovalentBond(scene, layout=layout)


def demoBalancing(scene: Scene, title_text: str = "Balancing Equations") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showBalancingEquation(scene, layout=layout)


def demoMoleConcept(scene: Scene, title_text: str = "Mole Concept") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showMoleConcept(scene, layout=layout)


def demoLimitingReagent(scene: Scene, title_text: str = "Limiting Reagent") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showLimitingReagent(scene, layout=layout)


def demoPercentYield(scene: Scene, title_text: str = "Percent Yield") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showPercentYield(scene, layout=layout)


def demoEnthalpyProfile(scene: Scene, title_text: str = "Enthalpy Profile") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showEnthalpyProfile(scene, layout=layout)


def demoEndothermic(scene: Scene, title_text: str = "Endothermic Reaction") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=36, layout=layout)), run_time=0.6)
    showEndothermicProfile(scene, layout=layout)


def demoHessLaw(scene: Scene, title_text: str = "Hess's Law") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showHessLaw(scene, layout=layout)


def demoGasLaws(scene: Scene, title_text: str = "Gas Laws") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showGasLaws(scene, layout=layout)


def demoParticlePressure(scene: Scene, title_text: str = "Particle Model of Pressure") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=34, layout=layout)), run_time=0.6)
    showParticlePressure(scene, layout=layout)


def demoMolarityDilution(scene: Scene, title_text: str = "Molarity & Dilution") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title_text, size=36, layout=layout)), run_time=0.6)
    showMolarityDilution(scene, layout=layout)


def demoSolubility(scene: Scene, title_text: str = "Solubility Curve") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showSolubilityCurve(scene, layout=layout)


def demoColligative(scene: Scene, title_text: str = "Colligative Properties") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=34, layout=layout)), run_time=0.6)
    showColligativeProperties(scene, layout=layout)


def demoReactionRate(scene: Scene, title_text: str = "Reaction Rate") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showReactionRate(scene, layout=layout)
    scene.play(FadeIn(makeCaption("Higher temperature usually increases rate", layout=layout)), run_time=0.5)


def demoActivationEnergy(scene: Scene, title_text: str = "Activation Energy") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showActivationEnergy(scene, layout=layout)


def demoCatalystEffect(scene: Scene, title_text: str = "Catalyst Effect") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showCatalystEffect(scene, layout=layout)


def demoPHScale(scene: Scene, title_text: str = "pH Scale") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showPHScale(scene, layout=layout)


def demoBufferSystem(scene: Scene, title_text: str = "Buffer System") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showBufferSystem(scene, layout=layout)


def demoConjugatePairs(scene: Scene, title_text: str = "Conjugate Acid-Base Pairs") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=34, layout=layout)), run_time=0.6)
    showConjugatePairs(scene, layout=layout)


def demoStrongWeakAcids(scene: Scene, title_text: str = "Strong vs Weak Acids") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=36, layout=layout)), run_time=0.6)
    showStrongWeakAcids(scene, layout=layout)


def demoTitration(scene: Scene, title_text: str = "Titration Curve") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showTitrationCurve(scene, layout=layout)


def demoEquilibrium(scene: Scene, title_text: str = "Le Chatelier Shift") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=36, layout=layout)), run_time=0.6)
    showEquilibriumShift(scene, layout=layout)


def demoEquilibriumConstant(scene: Scene, title_text: str = "Equilibrium Constant Kc") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title_text, size=34, layout=layout)), run_time=0.6)
    showEquilibriumConstant(scene, layout=layout)


def demoIceTable(scene: Scene, title_text: str = "ICE Table") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showIceTable(scene, layout=layout)


def demoRedox(scene: Scene, title_text: str = "Redox Reactions") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showRedox(scene, layout=layout)


def demoGalvanicCell(scene: Scene, title_text: str = "Galvanic Cell") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showGalvanicCell(scene, layout=layout)


def demoElectrolyticCell(scene: Scene, title_text: str = "Electrolytic Cell") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=36, layout=layout)), run_time=0.6)
    showElectrolyticCell(scene, layout=layout)


def demoFunctionalGroups(scene: Scene, title_text: str = "Functional Groups") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showFunctionalGroups(scene, layout=layout)


def demoHydrocarbonChain(scene: Scene, title_text: str = "Hydrocarbon Chain") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showHydrocarbonChain(scene, layout=layout)
