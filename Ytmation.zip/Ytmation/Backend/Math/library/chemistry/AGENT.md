# Chemistry Library — Agent Cookbook

## Where things live

| Layer | Path | Use for |
|------|------|---------|
| Shared layout | `Math/library/common/` | `SceneLayout`, titles, captions |
| Chemistry domain | `Math/library/chemistry/` | make/show/demo chemistry blocks |
| Channel showcase | `Workflows/channels/mathmwk/chemistryShowcase.py` | Render + stitch catalog |

## Module map

| File | Topics |
|------|--------|
| `shows.py` | Core bonding, reactions, pH, titration, equilibrium intro |
| `stoichiometry.py` | Mole, limiting reagent, percent yield |
| `thermochemistry.py` | Enthalpy, endothermic, Hess's law |
| `gases.py` | Ideal gas, particle pressure |
| `solutions.py` | Molarity, solubility, colligative |
| `acids_bases.py` | Buffers, conjugates, strong/weak |
| `kinetics.py` | Activation energy, catalyst |
| `equilibrium_adv.py` | Kc, ICE table |
| `electrochemistry.py` | Galvanic, electrolytic |
| `organic.py` | Functional groups, hydrocarbons |
| `atomic_adv.py` | Orbitals, electron config, IMF |

## API layers

| Prefix | Plays on scene? | Use when |
|------|-------------------|---------|
| `make*` | No | Build reusable mobjects |
| `show*` | Yes (one beat) | Compose inside scenes |
| `demo*` | Yes (mini lesson) | Showcase segments |

## Available demos (v1 + v2)

- `demoAtomicStructure`, `demoPeriodicTrends`, `demoOrbitalDiagram`, `demoElectronConfiguration`, `demoIntermolecularForces`
- `demoIonicBond`, `demoCovalentBond`, `demoBalancing`
- `demoMoleConcept`, `demoLimitingReagent`, `demoPercentYield`
- `demoEnthalpyProfile`, `demoEndothermic`, `demoHessLaw`
- `demoGasLaws`, `demoParticlePressure`
- `demoMolarityDilution`, `demoSolubility`, `demoColligative`
- `demoReactionRate`, `demoActivationEnergy`, `demoCatalystEffect`
- `demoPHScale`, `demoBufferSystem`, `demoConjugatePairs`, `demoStrongWeakAcids`, `demoTitration`
- `demoEquilibrium`, `demoEquilibriumConstant`, `demoIceTable`
- `demoRedox`, `demoGalvanicCell`, `demoElectrolyticCell`
- `demoFunctionalGroups`, `demoHydrocarbonChain`

## Quick usage

```python
from Math.library.common.styling import setupScene
from Math.library.chemistry.recipes import demoMoleConcept

setupScene(scene)
demoMoleConcept(scene)
```

## Render full catalog

```bash
python Workflows/channels/mathmwk/chemistryShowcase.py
```
