"""Acid-base visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_ACCENT, CHEM_ALERT


def showBufferSystem(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    eq = MathTex(r"\mathrm{HA \rightleftharpoons H^+ + A^-}", color=GREEN_B)
    note = Text("Buffer resists pH change", font_size=24, color=CHEM_ACCENT)
    g = VGroup(eq, note).arrange(DOWN, buff=0.3)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Write(eq), FadeIn(note), run_time=run_time)
    return g


def showConjugatePairs(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    acid = MathTex(r"\mathrm{NH_4^+ \rightleftharpoons NH_3}", color=CHEM_ALERT)
    base = Text("acid/base conjugate pair", font_size=24, color=YELLOW)
    placeInRegion(acid, "left", layout=layout, fit=True)
    placeInRegion(base, "right", layout=layout, fit=True)
    scene.play(Write(acid), FadeIn(base), run_time=run_time)
    return VGroup(acid, base)


def showStrongWeakAcids(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    strong = Text("Strong: fully ionizes", font_size=26, color=CHEM_ALERT)
    weak = Text("Weak: partial equilibrium", font_size=26, color=BLUE_B)
    placeInRegion(strong, "left", layout=layout, fit=True)
    placeInRegion(weak, "right", layout=layout, fit=True)
    scene.play(FadeIn(strong), FadeIn(weak), run_time=run_time)
    return VGroup(strong, weak)
