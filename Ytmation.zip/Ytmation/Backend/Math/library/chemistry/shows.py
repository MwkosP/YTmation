"""Layout-aware chemistry show* beats."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import makeAtom, CHEM_ACCENT, CHEM_ALERT


def showAtomicStructure(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("hero")
    nucleus = Dot(ORIGIN, radius=0.12, color=RED_B)
    shell1 = Circle(radius=0.8, color=BLUE_B, stroke_opacity=0.6)
    shell2 = Circle(radius=1.25, color=BLUE_D, stroke_opacity=0.45)
    e1 = Dot(shell1.point_at_angle(PI / 4), radius=0.06, color=YELLOW)
    e2 = Dot(shell1.point_at_angle(PI + PI / 4), radius=0.06, color=YELLOW)
    e3 = Dot(shell2.point_at_angle(PI / 7), radius=0.06, color=YELLOW)
    atom = VGroup(nucleus, shell1, shell2, e1, e2, e3)
    placeInRegion(atom, "main", layout=layout, fit=True)
    scene.play(FadeIn(nucleus), Create(shell1), Create(shell2), run_time=run_time * 0.45)
    scene.play(FadeIn(e1), FadeIn(e2), FadeIn(e3), run_time=run_time * 0.25)
    scene.play(Rotate(VGroup(e1, e2), angle=PI / 2, about_point=ORIGIN), run_time=run_time * 0.3)
    return atom


def showPeriodicTrend(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = Text("Atomic radius\nincreases down", font_size=28, color=BLUE_B)
    right = Text("Electronegativity\nincreases up-right", font_size=28, color=GREEN_B)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)


def showIonicBond(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("split")
    na = makeAtom("Na")
    cl = makeAtom("Cl")
    arrow = Arrow(na.get_right(), cl.get_left(), color=CHEM_ACCENT, buff=0.15)
    e = Dot(na.get_right() + RIGHT * 0.12, radius=0.05, color=YELLOW)
    left = VGroup(Text("Na", font_size=30), na).arrange(DOWN, buff=0.15)
    right = VGroup(Text("Cl", font_size=30), cl).arrange(DOWN, buff=0.15)
    pair = VGroup(left, right)
    pair.arrange(RIGHT, buff=2.0)
    placeInRegion(pair, "main", layout=layout, fit=True)
    arrow.put_start_and_end_on(na.get_right(), cl.get_left())
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time * 0.35)
    scene.play(GrowArrow(arrow), FadeIn(e), e.animate.move_to(cl.get_left() + LEFT * 0.1), run_time=run_time * 0.4)
    ions = Text("Na+   Cl-", font_size=30, color=GREEN_B).next_to(pair, DOWN, buff=0.35)
    scene.play(FadeIn(ions), run_time=run_time * 0.25)
    return VGroup(pair, arrow, e, ions)


def showCovalentBond(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    h1 = makeAtom("H")
    h2 = makeAtom("H")
    bond = Line(LEFT * 0.35, RIGHT * 0.35, color=YELLOW, stroke_width=6)
    mol = VGroup(h1, bond, h2).arrange(RIGHT, buff=0.25)
    placeInRegion(mol, "main", layout=layout, fit=True)
    scene.play(FadeIn(h1), FadeIn(h2), run_time=run_time * 0.45)
    scene.play(Create(bond), run_time=run_time * 0.25)
    scene.play(Indicate(bond, color=CHEM_ACCENT), run_time=run_time * 0.3)
    return mol


def showBalancingEquation(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    unbalanced = MathTex(r"\mathrm{H_2 + O_2 \rightarrow H_2O}", color=RED_B).scale(1.1)
    balanced = MathTex(r"\mathrm{2H_2 + O_2 \rightarrow 2H_2O}", color=GREEN_B).scale(1.1)
    placeInRegion(unbalanced, "main", layout=layout, fit=True)
    scene.play(Write(unbalanced), run_time=run_time * 0.45)
    scene.play(Transform(unbalanced, balanced), run_time=run_time * 0.45)
    return VGroup(unbalanced)


def showReactionRate(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 5, 1], y_range=[0, 1.2, 0.2], x_length=6, y_length=3.5)
    cold = axes.plot(lambda x: 1 - np.exp(-0.4 * x), color=BLUE_B)
    hot = axes.plot(lambda x: 1 - np.exp(-0.9 * x), color=ORANGE)
    labels = VGroup(Text("cold", font_size=22, color=BLUE_B), Text("hot", font_size=22, color=ORANGE)).arrange(DOWN, aligned_edge=LEFT).next_to(axes, RIGHT, buff=0.3)
    g = VGroup(axes, cold, hot, labels)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(cold), Create(hot), FadeIn(labels), run_time=run_time)
    return g


def showPHScale(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    line = NumberLine(x_range=[0, 14, 1], length=9, include_numbers=True, color=GREY_B)
    acid = Text("acidic", font_size=24, color=RED_B).next_to(line.n2p(2), UP, buff=0.2)
    base = Text("basic", font_size=24, color=BLUE_B).next_to(line.n2p(12), UP, buff=0.2)
    neutral = Text("neutral", font_size=24, color=GREEN_B).next_to(line.n2p(7), DOWN, buff=0.2)
    g = VGroup(line, acid, base, neutral)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(line), FadeIn(acid), FadeIn(base), FadeIn(neutral), run_time=run_time)
    return g


def showTitrationCurve(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 10, 2], y_range=[0, 14, 2], x_length=6.8, y_length=3.8)
    curve = axes.plot(lambda x: 2 + 10 / (1 + np.exp(-2.2 * (x - 5))), color=CHEM_ACCENT)
    eq = Dot(axes.c2p(5, 7), color=YELLOW)
    label = Text("equivalence", font_size=22, color=YELLOW).next_to(eq, UR, buff=0.12)
    g = VGroup(axes, curve, eq, label)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(curve), run_time=run_time * 0.7)
    scene.play(FadeIn(eq), FadeIn(label), run_time=run_time * 0.3)
    return g


def showEquilibriumShift(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    eq = MathTex(r"\mathrm{N_2 + 3H_2 \rightleftharpoons 2NH_3}", color=GREEN_B)
    shift = Text("Add pressure -> shift right", font_size=26, color=CHEM_ACCENT)
    placeInRegion(eq, "left", layout=layout, fit=True)
    placeInRegion(shift, "right", layout=layout, fit=True)
    scene.play(Write(eq), FadeIn(shift), run_time=run_time)
    return VGroup(eq, shift)


def showRedox(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    ox = Text("Oxidation: loss e-", font_size=28, color=CHEM_ALERT)
    red = Text("Reduction: gain e-", font_size=28, color=GREEN_B)
    placeInRegion(ox, "left", layout=layout, fit=True)
    placeInRegion(red, "right", layout=layout, fit=True)
    scene.play(FadeIn(ox), FadeIn(red), run_time=run_time)
    return VGroup(ox, red)
