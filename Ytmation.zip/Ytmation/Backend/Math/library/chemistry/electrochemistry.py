"""Electrochemistry visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_ACCENT, CHEM_ALERT


def showGalvanicCell(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("split")
    anode = VGroup(Rectangle(width=1.2, height=1.8, color=CHEM_ALERT).set_fill(CHEM_ALERT, opacity=0.2), Text("Anode (-)", font_size=22))
    cathode = VGroup(Rectangle(width=1.2, height=1.8, color=GREEN_B).set_fill(GREEN_B, opacity=0.2), Text("Cathode (+)", font_size=22))
    wire = CurvedArrow(anode[0].get_top(), cathode[0].get_top() + UP * 0.3, color=YELLOW, angle=-TAU / 4)
    e_flow = Arrow(cathode[0].get_top() + UP * 0.5, anode[0].get_top() + UP * 0.5, color=YELLOW, buff=0.1)
    left = VGroup(anode, wire, e_flow)
    right = Text("Spontaneous\nΔG < 0", font_size=26, color=GREEN_B)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(anode), FadeIn(cathode), Create(wire), GrowArrow(e_flow), FadeIn(right), run_time=run_time)
    return VGroup(left, right)


def showElectrolyticCell(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = Text("External battery\ndrives non-spontaneous reaction", font_size=26, color=CHEM_ACCENT)
    right = MathTex(r"\mathrm{Electrolysis}", color=YELLOW)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), Write(right), run_time=run_time)
    return VGroup(left, right)
