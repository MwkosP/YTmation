"""Advanced equilibrium visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_ACCENT


def showEquilibriumConstant(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    kc = MathTex(r"\mathrm{K_c = \frac{[C]^c[D]^d}{[A]^a[B]^b}}", color=CHEM_ACCENT).scale(1.0)
    placeInRegion(kc, "main", layout=layout, fit=True)
    scene.play(Write(kc), run_time=run_time)
    return VGroup(kc)


def showIceTable(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    header = VGroup(
        Text("Species", font_size=22),
        Text("Initial", font_size=22),
        Text("Change", font_size=22),
        Text("Equil", font_size=22),
    ).arrange(RIGHT, buff=0.8)
    row = VGroup(
        Text("A", font_size=22),
        Text("1.0", font_size=22),
        Text("-x", font_size=22, color=RED_B),
        Text("1.0-x", font_size=22, color=GREEN_B),
    ).arrange(RIGHT, buff=0.8)
    table = VGroup(header, row).arrange(DOWN, buff=0.25, aligned_edge=LEFT)
    placeInRegion(table, "main", layout=layout, fit=True)
    scene.play(FadeIn(header), FadeIn(row), run_time=run_time)
    return table
