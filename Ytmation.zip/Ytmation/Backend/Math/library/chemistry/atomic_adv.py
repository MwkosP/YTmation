"""Atomic / quantum starter visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_ACCENT


def showOrbitalDiagram(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    s = VGroup(Rectangle(width=0.5, height=0.8, color=BLUE_B), Text("1s", font_size=20))
    p = VGroup(*[Rectangle(width=0.35, height=0.8, color=GREEN_B) for _ in range(3)])
    p_labels = Text("2p", font_size=20)
    orbitals = VGroup(s, p).arrange(RIGHT, buff=0.5)
    label = Text("Aufbau filling order", font_size=24, color=CHEM_ACCENT).next_to(orbitals, DOWN, buff=0.3)
    g = VGroup(orbitals, p_labels, label)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(s), FadeIn(p), FadeIn(p_labels), FadeIn(label), run_time=run_time)
    return g


def showElectronConfiguration(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    cfg = MathTex(r"\mathrm{Fe:\ 1s^2\,2s^2\,2p^6\,3s^2\,3p^6\,4s^2\,3d^6}", color=YELLOW).scale(0.9)
    placeInRegion(cfg, "main", layout=layout, fit=True)
    scene.play(Write(cfg), run_time=run_time)
    return VGroup(cfg)


def showIntermolecularForces(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    h_bond = Text("Hydrogen bonding", font_size=26, color=BLUE_B)
    ldf = Text("London dispersion", font_size=26, color=YELLOW)
    dipole = Text("Dipole-dipole", font_size=26, color=GREEN_B)
    left = VGroup(h_bond, dipole).arrange(DOWN, buff=0.2)
    right = ldf
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)
