"""Organic chemistry starter visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_PRIMARY


def showFunctionalGroups(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    groups = VGroup(
        Text("-OH  alcohol", font_size=26, color=BLUE_B),
        Text("-COOH  carboxylic acid", font_size=26, color=GREEN_B),
        Text("-NH2  amine", font_size=26, color=PURPLE_B),
        Text("-CHO  aldehyde", font_size=26, color=ORANGE),
    ).arrange(DOWN, buff=0.22, aligned_edge=LEFT)
    placeInRegion(groups, "main", layout=layout, fit=True)
    scene.play(LaggedStart(*[FadeIn(g, shift=RIGHT * 0.1) for g in groups], lag_ratio=0.15), run_time=run_time)
    return groups


def showHydrocarbonChain(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    carbons = VGroup(*[Circle(radius=0.22, color=CHEM_PRIMARY).set_fill(GREY_E, opacity=0.3) for _ in range(5)]).arrange(RIGHT, buff=0.35)
    bonds = VGroup(*[Line(carbons[i].get_right(), carbons[i + 1].get_left(), color=YELLOW) for i in range(4)])
    label = Text("alkane chain", font_size=24, color=YELLOW).next_to(carbons, DOWN, buff=0.25)
    g = VGroup(carbons, bonds, label)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(carbons), Create(bonds), FadeIn(label), run_time=run_time)
    return g
