"""Chemical kinetics visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_ACCENT


def showActivationEnergy(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 6, 1], y_range=[0, 5, 1], x_length=6.5, y_length=3.5)
    curve = axes.plot(lambda x: 4.2 - 0.35 * (x - 3) ** 2, x_range=[0.5, 5.5], color=YELLOW)
    ea = DoubleArrow(axes.c2p(1.2, 2.0), axes.c2p(1.2, 4.0), color=RED_B, buff=0.05)
    label = Text("Ea", font_size=24, color=RED_B).next_to(ea, LEFT, buff=0.1)
    g = VGroup(axes, curve, ea, label)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(curve), GrowArrow(ea), FadeIn(label), run_time=run_time)
    return g


def showCatalystEffect(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 6, 1], y_range=[0, 5, 1], x_length=6.5, y_length=3.5)
    uncatalyzed = axes.plot(lambda x: 4.0 - 0.4 * (x - 3) ** 2, x_range=[0.8, 5.2], color=RED_B)
    catalyzed = axes.plot(lambda x: 3.2 - 0.25 * (x - 3) ** 2, x_range=[0.8, 5.2], color=GREEN_B)
    labels = VGroup(Text("uncatalyzed", font_size=22, color=RED_B), Text("catalyzed", font_size=22, color=GREEN_B)).arrange(DOWN, aligned_edge=LEFT).next_to(axes, RIGHT, buff=0.25)
    g = VGroup(axes, uncatalyzed, catalyzed, labels)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(uncatalyzed), Create(catalyzed), FadeIn(labels), run_time=run_time)
    return g
