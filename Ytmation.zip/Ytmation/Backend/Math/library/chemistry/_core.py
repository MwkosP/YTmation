"""Shared constants + helpers for chemistry scenes."""

from manim import *

CHEM_BG = "#0a0a0a"
CHEM_PRIMARY = BLUE_B
CHEM_SECONDARY = GREEN_B
CHEM_ACCENT = YELLOW
CHEM_ALERT = RED_B


def elementColor(symbol: str):
    palette = {
        "H": BLUE_B,
        "C": GREY_B,
        "N": PURPLE_B,
        "O": RED_B,
        "Cl": GREEN_B,
        "Na": ORANGE,
    }
    return palette.get(symbol, TEAL_B)


def makeAtom(symbol: str, radius: float = 0.34) -> VGroup:
    color = elementColor(symbol)
    core = Circle(radius=radius, color=color).set_fill(color, opacity=0.22)
    label = Text(symbol, font_size=26, color=color).move_to(core.get_center())
    return VGroup(core, label)
