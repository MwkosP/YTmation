"""Thermochemistry visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.chemistry._core import CHEM_ACCENT, CHEM_ALERT


def showEnthalpyProfile(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 6, 1], y_range=[0, 5, 1], x_length=6.5, y_length=3.5)
    exo = axes.plot(lambda x: 4 - 0.5 * (x - 1) ** 2, x_range=[0.5, 5], color=GREEN_B)
    label = Text("exothermic (ΔH < 0)", font_size=24, color=GREEN_B)
    g = VGroup(axes, exo, label)
    label.next_to(exo, UP, buff=0.2)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(exo), FadeIn(label), run_time=run_time)
    return g


def showEndothermicProfile(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 6, 1], y_range=[0, 5, 1], x_length=6.5, y_length=3.5)
    endo = axes.plot(lambda x: 1 + 0.5 * (x - 1) ** 2, x_range=[0.5, 5], color=CHEM_ALERT)
    label = Text("endothermic (ΔH > 0)", font_size=24, color=CHEM_ALERT)
    g = VGroup(axes, endo, label)
    label.next_to(endo, UP, buff=0.2)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(endo), FadeIn(label), run_time=run_time)
    return g


def showHessLaw(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    path = MathTex(r"\mathrm{\Delta H_{total} = \Delta H_1 + \Delta H_2}", color=CHEM_ACCENT)
    note = Text("State function: path independent", font_size=24, color=YELLOW)
    placeInRegion(path, "left", layout=layout, fit=True)
    placeInRegion(note, "right", layout=layout, fit=True)
    scene.play(Write(path), FadeIn(note), run_time=run_time)
    return VGroup(path, note)
