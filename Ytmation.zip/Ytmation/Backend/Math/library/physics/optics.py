"""Optics primitives (native). Plugin-backed lens helpers can wrap manim-physics later."""

from manim import *
import numpy as np


def makeLens(
    center: np.ndarray = ORIGIN,
    height: float = 2.5,
    thickness: float = 0.35,
    color: str = BLUE_B,
) -> VGroup:
    left = ArcBetweenPoints(center + UP * height / 2, center + DOWN * height / 2, angle=-PI / 6, color=color)
    right = ArcBetweenPoints(center + DOWN * height / 2, center + UP * height / 2, angle=-PI / 6, color=color)
    top = Line(left.get_start(), right.get_end(), color=color)
    bottom = Line(left.get_end(), right.get_start(), color=color)
    return VGroup(left, right, top, bottom)


def makeLightRay(
    start: np.ndarray,
    direction: np.ndarray,
    length: float = 4.0,
    color: str = YELLOW,
) -> Arrow:
    unit = direction / np.linalg.norm(direction)
    return Arrow(start, start + unit * length, buff=0, color=color, stroke_width=3)


def makeParallelRays(
    y_start: float = 1.0,
    count: int = 3,
    spacing: float = 0.5,
    length: float = 5.0,
    color: str = YELLOW,
) -> VGroup:
    rays = VGroup()
    for i in range(count):
        y = y_start - i * spacing
        rays.add(makeLightRay(LEFT * 4 + UP * y, RIGHT, length=length, color=color))
    return rays
