"""Layout-aware one-beat physics scenes (show* layer)."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.physics.projectile import (
    makeProjectileAxes,
    sampleProjectilePoints,
    makeProjectilePath,
    animateProjectile,
)
from Math.library.physics.pendulum import makePendulum, animatePendulumSwing
from Math.library.physics.kinematics import makeMotionAxes, makeUniformAccelerationGraph, animateDotOnGraph
from Math.library.physics.energy import makeEnergyBars, animateEnergyTransfer
from Math.library.physics.waves import makeWaveAxes, animateInterference
from Math.library.physics.collisions import makeCollidingBalls, animate1dCollision
from Math.library.physics.springs import makeMassOnSpring, animateSpringOscillation
from Math.library.physics.mechanics import makeGround, makeForceArrow, animateFall, animateBounce
from Math.library.physics.vectors import makeFreeBodyDiagram
from Math.library.physics.optics import makeLens, makeParallelRays
from Math.library.physics.electromagnetism import makeCharge, makeFieldLinesRadial, makeWireWithCurrent


def showProjectile(
    scene: Scene,
    speed: float = 7.0,
    angle_deg: float = 50.0,
    layout: SceneLayout | None = None,
    run_time: float = 2.5,
) -> VGroup:
    layout = layout or SceneLayout.hero()
    axes = makeProjectileAxes()
    pts = sampleProjectilePoints(speed=speed, angle_deg=angle_deg)
    path = makeProjectilePath(axes, pts)
    group = VGroup(axes, path)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(path), run_time=run_time * 0.35)
    animateProjectile(scene, axes, pts, run_time=run_time * 0.65)
    return group


def showPendulum(
    scene: Scene,
    layout: SceneLayout | None = None,
    angle_deg: float = 28.0,
    run_time: float = 2.5,
) -> VGroup:
    layout = layout or SceneLayout.hero()
    pivot, rod, bob = makePendulum(angle_deg=angle_deg)
    group = VGroup(pivot, rod, bob)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(FadeIn(pivot), Create(rod), FadeIn(bob), run_time=run_time * 0.3)
    animatePendulumSwing(scene, pivot, rod, bob, cycles=2, run_time=run_time * 0.7)
    return group


def showKinematicsGraph(
    scene: Scene,
    layout: SceneLayout | None = None,
    a: float = 0.8,
    run_time: float = 2.2,
) -> VGroup:
    layout = layout or SceneLayout.formula_focus()
    axes = makeMotionAxes(y_label="x", y_range=(0, 12, 2))
    graph = makeUniformAccelerationGraph(axes, a=a, t_max=5)
    group = VGroup(axes, graph)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(graph), run_time=run_time * 0.4)
    animateDotOnGraph(scene, axes, graph, run_time=run_time * 0.6)
    return group


def showEnergyBars(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.0,
) -> VGroup:
    layout = layout or SceneLayout.standard()
    bars = makeEnergyBars(ke=0.8, pe=0.2)
    placeInRegion(bars, "main", layout=layout, fit=True)
    scene.play(FadeIn(bars), run_time=run_time * 0.25)
    animateEnergyTransfer(scene, bars, 0.8, 0.2, 0.2, 0.8, run_time=run_time * 0.375)
    animateEnergyTransfer(scene, bars, 0.2, 0.7, 0.8, 0.3, run_time=run_time * 0.375)
    return bars


def showWaveInterference(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.2,
) -> Axes:
    layout = layout or SceneLayout.hero()
    axes = makeWaveAxes()
    placeInRegion(axes, "main", layout=layout, fit=True)
    scene.play(Create(axes), run_time=run_time * 0.2)
    animateInterference(scene, axes, run_time=run_time * 0.8)
    return axes


def showCollision(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.0,
) -> VGroup:
    layout = layout or SceneLayout.hero()
    a, b = makeCollidingBalls()
    group = VGroup(a, b)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(FadeIn(a), FadeIn(b), run_time=run_time * 0.25)
    animate1dCollision(scene, a, b)
    return group


def showSpring(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.4,
) -> VGroup:
    layout = layout or SceneLayout.hero()
    anchor = UP * 1.5
    spring, mass = makeMassOnSpring(anchor=anchor)
    group = VGroup(spring, mass)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(spring), FadeIn(mass), run_time=run_time * 0.3)
    animateSpringOscillation(scene, anchor, spring, mass, cycles=2, run_time=run_time * 0.7)
    return group


def showFreeFall(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.0,
) -> VGroup:
    layout = layout or SceneLayout.standard()
    ground = makeGround()
    ball = Dot(UP * 2.2, radius=0.14, color="#FF4500")
    fg = makeForceArrow(ball.get_center(), direction=DOWN, label="mg")
    group = VGroup(ground, ball, fg)
    placeInRegion(VGroup(ground, ball), "main", layout=layout, fit=True)
    scene.play(Create(ground), FadeIn(ball), run_time=run_time * 0.3)
    scene.play(FadeIn(fg), run_time=run_time * 0.15)
    animateFall(scene, ball, distance=4.5, run_time=run_time * 0.55)
    return group


def showBounce(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.2,
) -> VGroup:
    layout = layout or SceneLayout.hero()
    ground = makeGround()
    ball = Dot(UP * 2.0, radius=0.14, color="#FF4500")
    group = VGroup(ground, ball)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(ground), FadeIn(ball), run_time=run_time * 0.25)
    animateBounce(scene, ball, height=1.2, bounces=3, total_time=run_time * 0.75)
    return group


def showFreeBodyDiagram(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 1.8,
) -> VGroup:
    layout = layout or SceneLayout.sidebar()
    fbd = makeFreeBodyDiagram(
        ORIGIN,
        [(UP * 1.2, "N", BLUE), (DOWN * 0.9, "mg", "#FF4500"), (RIGHT * 0.7, "f", GREEN)],
    )
    placeInRegion(fbd, "main", layout=layout, fit=True)
    scene.play(FadeIn(fbd), run_time=run_time)
    return fbd


def showOptics(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.0,
) -> VGroup:
    layout = layout or SceneLayout.split()
    rays = makeParallelRays()
    lens = makeLens(center=RIGHT * 1.5)
    left = VGroup(rays)
    right = VGroup(lens)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(Create(rays), Create(lens), run_time=run_time)
    return VGroup(rays, lens)


def showElectromagnetism(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.0,
) -> VGroup:
    layout = layout or SceneLayout.split()
    charge = makeCharge(LEFT * 2.5, positive=True)
    field = makeFieldLinesRadial(charge[0].get_center(), count=8)
    wire = makeWireWithCurrent(RIGHT * 2.5 + UP * 1.5, RIGHT * 2.5 + DOWN * 1.5)
    left = VGroup(charge, field)
    right = VGroup(wire)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(charge), Create(field), Create(wire), run_time=run_time)
    return VGroup(left, right)
