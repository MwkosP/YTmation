"""Pendulum building blocks (2D) for reusable composition."""

from manim import *
import numpy as np


def makePendulum(
    pivot: np.ndarray = UP * 2.2,
    length: float = 2.4,
    angle_deg: float = 25,
    bob_radius: float = 0.12,
    rod_color: str = WHITE,
    bob_color: str = "#FF4500",
) -> tuple[Dot, Line, Dot]:
    pivot_dot = Dot(pivot, color=GREY_B, radius=0.04)
    theta = np.deg2rad(angle_deg)
    bob_pos = pivot + np.array([length * np.sin(theta), -length * np.cos(theta), 0.0])
    rod = Line(pivot, bob_pos, color=rod_color, stroke_width=3)
    bob = Dot(bob_pos, color=bob_color, radius=bob_radius)
    return pivot_dot, rod, bob


def animatePendulumSwing(
    scene: Scene,
    pivot_dot: Dot,
    rod: Line,
    bob: Dot,
    length: float = 2.4,
    max_angle_deg: float = 25,
    cycles: int = 2,
    run_time: float = 4.0,
) -> ValueTracker:
    pivot = pivot_dot.get_center()
    theta = ValueTracker(np.deg2rad(max_angle_deg))

    def update_system(_: Mobject) -> None:
        t = theta.get_value()
        new_bob = pivot + np.array([length * np.sin(t), -length * np.cos(t), 0.0])
        bob.move_to(new_bob)
        rod.put_start_and_end_on(pivot, new_bob)

    bob.add_updater(update_system)
    rod.add_updater(update_system)
    scene.add(pivot_dot, rod, bob)
    scene.play(theta.animate.set_value(-np.deg2rad(max_angle_deg)), run_time=run_time / (2 * cycles), rate_func=smooth)
    for _ in range(cycles - 1):
        scene.play(theta.animate.set_value(np.deg2rad(max_angle_deg)), run_time=run_time / cycles, rate_func=smooth)
        scene.play(theta.animate.set_value(-np.deg2rad(max_angle_deg)), run_time=run_time / cycles, rate_func=smooth)
    bob.clear_updaters()
    rod.clear_updaters()
    return theta
