"""1D collision visuals (elastic / inelastic)."""

from manim import *
import numpy as np


def makeCollidingBalls(
    y: float = 0.0,
    separation: float = 4.0,
    radii: tuple[float, float] = (0.14, 0.14),
    colors: tuple[str, str] = ("#FF4500", "#4488FF"),
) -> tuple[Dot, Dot]:
    left = Dot(LEFT * separation / 2 + UP * y, radius=radii[0], color=colors[0])
    right = Dot(RIGHT * separation / 2 + UP * y, radius=radii[1], color=colors[1])
    return left, right


def animate1dCollision(
    scene: Scene,
    ball_a: Dot,
    ball_b: Dot,
    v_a_before: float = 2.0,
    v_b_before: float = -1.0,
    v_a_after: float = -0.5,
    v_b_after: float = 2.5,
    approach_time: float = 0.8,
    separate_time: float = 0.8,
) -> None:
    mid = (ball_a.get_center() + ball_b.get_center()) / 2
    scene.play(
        ball_a.animate.shift(RIGHT * v_a_before * 0.4),
        ball_b.animate.shift(LEFT * abs(v_b_before) * 0.4),
        run_time=approach_time,
        rate_func=smooth,
    )
    flash = Flash(mid, color=YELLOW, line_length=0.2, num_lines=8)
    scene.play(flash, run_time=0.25)
    scene.play(
        ball_a.animate.shift(RIGHT * v_a_after * 0.4),
        ball_b.animate.shift(RIGHT * v_b_after * 0.4),
        run_time=separate_time,
        rate_func=smooth,
    )


def makeMomentumLabels(v1: str, v2: str, color: str = WHITE) -> VGroup:
    return VGroup(
        MathTex(v1, color=color).scale(0.7),
        MathTex(v2, color=color).scale(0.7),
    ).arrange(RIGHT, buff=1.5)
