"""
High-level physics demos for agents.

One function = one teaching moment. Uses show* beats + layout.
"""

from manim import *

from Math.library.common.layout import SceneLayout, makeTitle, makeCaption, makeFormulaBanner, placeInRegion
from Math.library.common.styling import setupScene
from Math.library.physics.shows import (
    showProjectile,
    showPendulum,
    showKinematicsGraph,
    showEnergyBars,
    showWaveInterference,
    showCollision,
    showSpring,
    showFreeFall,
    showBounce,
    showFreeBodyDiagram,
    showOptics,
    showElectromagnetism,
)


def demoProjectile(
    scene: Scene,
    speed: float = 7.0,
    angle_deg: float = 50.0,
    title_text: str = "Projectile Motion",
) -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showProjectile(scene, speed=speed, angle_deg=angle_deg, layout=layout, run_time=2.0)
    scene.play(
        Write(
            makeFormulaBanner(
                r"x=v_0\cos\theta\,t,\quad y=v_0\sin\theta\,t-\tfrac{1}{2}gt^2",
                layout=layout,
            )
        ),
        run_time=0.7,
    )


def demoPendulum(scene: Scene, title_text: str = "Simple Pendulum") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showPendulum(scene, layout=layout, run_time=2.4)
    scene.play(FadeIn(makeCaption("Energy exchanges between KE and PE", layout=layout)), run_time=0.5)


def demoKinematicsGraph(scene: Scene, title_text: str = "Uniform Acceleration") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showKinematicsGraph(scene, layout=layout, run_time=2.2)


def demoEnergyBars(scene: Scene, title_text: str = "Energy Conservation") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showEnergyBars(scene, layout=layout, run_time=2.0)


def demoWaveInterference(scene: Scene, title_text: str = "Wave Interference") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showWaveInterference(scene, layout=layout, run_time=2.2)


def demoCollision(scene: Scene, title_text: str = "1D Collision") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showCollision(scene, layout=layout, run_time=2.0)
    scene.play(FadeIn(makeCaption("Momentum before = momentum after (ideal)", layout=layout)), run_time=0.5)


def demoSpring(scene: Scene, title_text: str = "Spring Motion") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showSpring(scene, layout=layout, run_time=2.4)


def demoFreeFall(scene: Scene, title_text: str = "Free Fall") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showFreeFall(scene, layout=layout, run_time=2.0)


def demoBounce(scene: Scene, title_text: str = "Bouncing Ball") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title_text, size=40, layout=layout)), run_time=0.6)
    showBounce(scene, layout=layout, run_time=2.2)
    scene.play(FadeIn(makeCaption("Energy lost each bounce", layout=layout)), run_time=0.5)


def demoFreeBodyDiagram(scene: Scene, title_text: str = "Free-Body Diagram") -> None:
    setupScene(scene)
    layout = SceneLayout("sidebar")
    scene.play(Write(makeTitle(title_text, size=36, layout=layout)), run_time=0.6)
    showFreeBodyDiagram(scene, layout=layout, run_time=1.8)
    hint = Text("ΣF = ma", font_size=28, color=YELLOW)
    placeInRegion(hint, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)
    scene.play(Write(hint), FadeIn(makeCaption("Draw all forces on the object", layout=layout)), run_time=0.5)


def demoOptics(scene: Scene, title_text: str = "Geometric Optics") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=38, layout=layout)), run_time=0.6)
    showOptics(scene, layout=layout, run_time=2.0)
    scene.play(FadeIn(makeCaption("Parallel rays converge through a lens", layout=layout)), run_time=0.5)


def demoElectromagnetism(scene: Scene, title_text: str = "Charges & Current") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title_text, size=36, layout=layout)), run_time=0.6)
    showElectromagnetism(scene, layout=layout, run_time=2.0)
    scene.play(FadeIn(makeCaption("Field lines + current-carrying wire", layout=layout)), run_time=0.5)
