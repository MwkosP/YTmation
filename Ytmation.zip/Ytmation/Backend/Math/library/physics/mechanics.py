"""Composable mechanics helpers (no render wrappers)."""

from manim import *
import numpy as np


def makeGround(y: float = -2.8, width: float = 12, color: str = "#888888") -> Line:
    return Line(LEFT * width / 2 + UP * y, RIGHT * width / 2 + UP * y, color=color, stroke_width=3)


def makeVelocityArrow(
    origin: np.ndarray,
    direction: np.ndarray = RIGHT,
    length: float = 1.5,
    color: str = BLUE,
    label: str = "v",
) -> VGroup:
    unit = direction / np.linalg.norm(direction)
    arrow = Arrow(origin, origin + unit * length, buff=0, color=color, stroke_width=4)
    txt = MathTex(label, color=color).scale(0.7).next_to(arrow, UP, buff=0.08)
    return VGroup(arrow, txt)


def makeForceArrow(
    origin: np.ndarray,
    direction: np.ndarray = DOWN,
    length: float = 1.5,
    color: str = "#FF4500",
    label: str = "F",
) -> VGroup:
    unit = direction / np.linalg.norm(direction)
    arrow = Arrow(origin, origin + unit * length, buff=0, color=color, stroke_width=4)
    txt = MathTex(label, color=color).scale(0.7).next_to(arrow, RIGHT, buff=0.08)
    return VGroup(arrow, txt)


def animateFall(scene: Scene, body: Mobject, distance: float = 3.0, run_time: float = 1.2) -> None:
    scene.play(body.animate.shift(DOWN * distance), run_time=run_time, rate_func=rate_functions.ease_in_cubic)


def animateBounce(
    scene: Scene,
    body: Mobject,
    height: float = 1.5,
    bounces: int = 3,
    total_time: float = 2.0,
) -> None:
    per_half = total_time / max(1, bounces * 2)
    for i in range(bounces):
        h = height * (0.6**i)
        scene.play(body.animate.shift(UP * h), run_time=per_half, rate_func=rate_functions.ease_out_quad)
        scene.play(body.animate.shift(DOWN * h), run_time=per_half, rate_func=rate_functions.ease_in_quad)
