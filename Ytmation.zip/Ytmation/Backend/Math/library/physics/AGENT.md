# Physics Library — Agent Cookbook

## Where things live

| Layer | Path | Use for |
|-------|------|---------|
| **Shared layout** | `Math/library/common/` | Titles, captions, `SceneLayout`, regions |
| **Math base** | `Math/library/math/` | Graphs, algebra, trig, LA — **import, don't copy** |
| **Physics core** | `Math/library/physics/_core.py` | `G`, colors, `playBeat` |
| **Primitives** | `Math/library/physics/*.py` | `make*` / `animate*` per topic |
| **Show beats** | `Math/library/physics/shows.py` | Layout-aware `show*` (one beat) |
| **Recipes** | `Math/library/physics/recipes.py` | `demo*` full mini-lessons |
| **Showcase** | `Workflows/channels/mathmwk/physicsShowcase.py` | Render + stitch all demos |
| **Math×physics** | `Workflows/channels/mathmwk/physics_showcase.py` | Composition examples only |

---

## Easiest path

```python
def scene1(scene):
    from Math.library.common.styling import setupScene
    from Math.library.physics.recipes import demoProjectile

    setupScene(scene)
    demoProjectile(scene, speed=8, angle_deg=45)
```

### All `demo*` recipes

| Function | Topic |
|----------|--------|
| `demoProjectile` | 2D projectile |
| `demoPendulum` | Simple pendulum |
| `demoKinematicsGraph` | x–t uniform acceleration |
| `demoEnergyBars` | KE/PE transfer |
| `demoWaveInterference` | Superposition |
| `demoCollision` | 1D collision |
| `demoSpring` | Mass on spring |
| `demoFreeFall` | Gravity + fall |
| `demoBounce` | Bouncing ball |
| `demoFreeBodyDiagram` | FBD + ΣF=ma |
| `demoOptics` | Rays + lens |
| `demoElectromagnetism` | Charge field + wire |

### Render full catalog

```bash
python Workflows/channels/mathmwk/physicsShowcase.py
```

Output: `Cache/stitched/mathmwk_physics_showcase_<timestamp>.mp4`

---

## API layers

| Prefix | Plays on scene? | Use when |
|--------|-----------------|----------|
| `make*` | No — mobjects only | Compose custom scenes |
| `animate*` | One animation beat | Low-level control |
| `show*` | One layout-aware beat | Same as math `show*` |
| `demo*` | Full mini-lesson | Showcases, quick tests |

---

## Module map

| Module | `make*` / `animate*` | `show*` |
|--------|----------------------|---------|
| `mechanics` | ground, force/velocity arrows, fall, bounce | `showFreeFall`, `showBounce` |
| `projectile` | axes, path, animate | `showProjectile` |
| `pendulum` | pendulum, swing | `showPendulum` |
| `kinematics` | motion axes, graphs | `showKinematicsGraph` |
| `energy` | energy bars, transfer | `showEnergyBars` |
| `vectors` | FBD, decompose | `showFreeBodyDiagram` |
| `waves` | sine, interference | `showWaveInterference` |
| `springs` | spring, oscillation | `showSpring` |
| `collisions` | balls, 1D collision | `showCollision` |
| `optics` | lens, rays | `showOptics` |
| `electromagnetism` | charge, field, wire | `showElectromagnetism` |

---

## Layout presets (use in demos / custom scenes)

```python
from Math.library.common.layout import SceneLayout, makeTitle, placeInRegion

layout = SceneLayout("hero")  # or sidebar, split, formula_focus, ...
title = makeTitle("Topic", size=40, layout=layout)
placeInRegion(diagram, "main", layout=layout, fit=True)
```

Valid regions depend on preset — see `Math/library/common/layout/presets.py`.

---

## Rules

1. Import inside workflow `sceneX(scene)` functions when generating channel code.
2. Reuse `math/` for generic plots and vectors; use `physics/` for physics-specific visuals.
3. Never put `from __future__ import` in sources passed to `renderCustomScene` wrappers.
4. Long-form default: **1920×1080** when stitching showcases.
