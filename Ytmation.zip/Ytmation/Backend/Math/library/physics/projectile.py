"""Projectile-motion primitives for composition."""

from manim import *
import numpy as np


def makeProjectileAxes(
    x_range: tuple = (0, 10, 1),
    y_range: tuple = (0, 6, 1),
    x_length: float = 8,
    y_length: float = 4.5,
) -> Axes:
    return Axes(
        x_range=list(x_range),
        y_range=list(y_range),
        x_length=x_length,
        y_length=y_length,
        axis_config={"color": GREY_B},
        tips=False,
    )


def sampleProjectilePoints(
    speed: float = 8.0,
    angle_deg: float = 45.0,
    gravity: float = 9.8,
    dt: float = 0.05,
) -> list[tuple[float, float]]:
    angle = np.deg2rad(angle_deg)
    vx = speed * np.cos(angle)
    vy = speed * np.sin(angle)

    points: list[tuple[float, float]] = []
    t = 0.0
    while True:
        x = vx * t
        y = vy * t - 0.5 * gravity * t * t
        if y < 0 and t > 0:
            break
        points.append((float(x), float(max(y, 0))))
        t += dt
    return points


def makeProjectilePath(
    axes: Axes,
    points: list[tuple[float, float]],
    color: str = YELLOW,
    stroke_width: float = 4,
) -> VMobject:
    vm = VMobject(color=color, stroke_width=stroke_width)
    vm.set_points_smoothly([axes.c2p(x, y) for x, y in points])
    return vm


def animateProjectile(
    scene: Scene,
    axes: Axes,
    points: list[tuple[float, float]],
    dot: Dot | None = None,
    path_color: str = YELLOW,
    run_time: float = 2.0,
) -> tuple[Dot, VMobject]:
    body = dot or Dot(axes.c2p(points[0][0], points[0][1]), color=path_color, radius=0.07)
    path = makeProjectilePath(axes, points, color=path_color)
    scene.add(body)
    scene.play(MoveAlongPath(body, path), run_time=run_time, rate_func=linear)
    return body, path
