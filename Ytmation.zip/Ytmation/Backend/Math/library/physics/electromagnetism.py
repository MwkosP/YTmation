"""Basic EM visuals (native). Rich fields: use manim-physics plugin adapters later."""

from manim import *
import numpy as np


def makeCharge(
    pos: np.ndarray = ORIGIN,
    positive: bool = True,
    radius: float = 0.2,
) -> VGroup:
    color = RED if positive else BLUE
    sign = "+" if positive else "-"
    dot = Dot(pos, radius=radius, color=color)
    label = MathTex(sign, color=WHITE).scale(0.6).move_to(pos)
    return VGroup(dot, label)


def makeFieldLinesRadial(
    center: np.ndarray = ORIGIN,
    count: int = 8,
    radius: float = 2.0,
    outward: bool = True,
    color: str = YELLOW,
) -> VGroup:
    lines = VGroup()
    for i in range(count):
        angle = TAU * i / count
        start = center + np.array([np.cos(angle), np.sin(angle), 0]) * 0.3
        end = center + np.array([np.cos(angle), np.sin(angle), 0]) * radius
        if not outward:
            start, end = end, start
        lines.add(Arrow(start, end, buff=0, color=color, stroke_width=2, max_tip_length_to_length_ratio=0.15))
    return lines


def makeWireWithCurrent(
    start: np.ndarray = UP * 2,
    end: np.ndarray = DOWN * 2,
    label: str = "I",
    color: str = WHITE,
) -> VGroup:
    wire = Line(start, end, color=color, stroke_width=4)
    txt = MathTex(label, color=color).scale(0.7).next_to(wire, RIGHT, buff=0.2)
    return VGroup(wire, txt)
