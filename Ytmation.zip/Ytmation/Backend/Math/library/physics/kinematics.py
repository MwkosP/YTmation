"""Motion graphs — wraps Math.library.math.graphs."""

from manim import *

from Math.library.math.graphs.axes import (
    makeLabeledAxes,
    plotOnAxes,
    animateDotOnPath,
)


def makeMotionAxes(
    x_label: str = "t",
    y_label: str = "x",
    x_range: tuple = (0, 5, 1),
    y_range: tuple = (0, 10, 2),
    x_length: float = 6,
    y_length: float = 3.5,
) -> VGroup:
    return makeLabeledAxes(
        x_range=x_range,
        y_range=y_range,
        x_length=x_length,
        y_length=y_length,
        x_label=x_label,
        y_label=y_label,
    )


def plotMotion(axes_group, func, x_range: tuple, color=BLUE):
    return plotOnAxes(axes_group, func, x_range, color=color)


def makeConstantVelocityGraph(axes_group, v: float = 2.0, t_max: float = 5.0):
    return plotMotion(axes_group, lambda t: v * t, x_range=(0, t_max))


def makeUniformAccelerationGraph(axes_group, a: float = 1.0, v0: float = 0.0, t_max: float = 5.0):
    return plotMotion(axes_group, lambda t: v0 * t + 0.5 * a * t * t, x_range=(0, t_max))


def animateDotOnGraph(scene, axes_group, graph, color=YELLOW, run_time: float = 2.0):
    return animateDotOnPath(scene, graph, color=color, run_time=run_time)
