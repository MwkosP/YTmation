"""Wave helpers — trig math from library/math; interference for physics demos."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.trigonometry.sine import (
    plotSine as _plot_sine,
    animateSinePhase,
    plotSuperposition,
)


def makeWaveAxes(
    x_range: tuple = (0, 8, 1),
    y_range: tuple = (-2, 2, 1),
    x_length: float = 8,
    y_length: float = 3,
) -> VGroup:
    return makeLabeledAxes(
        x_range=x_range,
        y_range=y_range,
        x_length=x_length,
        y_length=y_length,
        x_label="x",
        y_label="y",
    )


def _asAxesGroup(axes):
    return axes if isinstance(axes, VGroup) else VGroup(axes)


def makeSineWave(axes, amplitude: float = 1.0, wavenumber: float = 1.0, phase: float = 0.0, color=BLUE):
    return _plot_sine(_asAxesGroup(axes), amplitude=amplitude, frequency=wavenumber, phase=phase, color=color)


def animateWavePhase(scene, axes, amplitude=1.0, wavenumber=1.5, color=BLUE, cycles=1.5, run_time=3.0):
    return animateSinePhase(
        scene, _asAxesGroup(axes), amplitude=amplitude, frequency=wavenumber, color=color, cycles=cycles, run_time=run_time
    )


def makeSuperposedWaves(axes, amp1=1.0, amp2=0.8, k1=1.5, k2=1.7, color1=BLUE, color2="#FF4500", color_sum=YELLOW):
    return plotSuperposition(_asAxesGroup(axes), amp1=amp1, amp2=amp2, k1=k1, k2=k2, phase2=PI / 4)


def animateInterference(scene, axes, run_time=2.5):
    axes_g = _asAxesGroup(axes)
    waves = plotSuperposition(axes_g)
    scene.play(Create(waves[0]), Create(waves[1]), run_time=run_time * 0.4)
    scene.play(Create(waves[2]), run_time=run_time * 0.6)
    return waves
