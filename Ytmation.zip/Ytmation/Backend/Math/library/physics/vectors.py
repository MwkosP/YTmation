"""Free-body diagrams (physics). Vector math from library/math."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra.vectors import decomposeVector as _decompose_vector
from .mechanics import makeForceArrow


def decomposeVector(origin, vector, color_x=BLUE, color_y=GREEN):
    return _decompose_vector(origin, vector, color_x=color_x, color_y=color_y, label_x="v_x", label_y="v_y")


def makeFreeBodyDiagram(
    center: np.ndarray,
    forces: list[tuple[np.ndarray, str, str]],
) -> VGroup:
    body = Dot(center, radius=0.12, color=WHITE)
    arrows = VGroup()
    for direction, label, color in forces:
        arrows.add(makeForceArrow(center, direction=direction, label=label, color=color))
    return VGroup(body, arrows)
