"""Energy bar charts and conservation visuals."""

from manim import *
import numpy as np
from Math.library.common.styling import ACCENT, BLUE_ACCENT, GREEN


def makeEnergyBars(
    ke: float = 0.5,
    pe: float = 0.5,
    max_height: float = 3.0,
    width: float = 1.0,
    labels: bool = True,
) -> VGroup:
    ke_h = max(0.05, ke) * max_height
    pe_h = max(0.05, pe) * max_height
    ke_bar = Rectangle(width=width, height=ke_h, color=ACCENT, fill_opacity=0.85).shift(LEFT * 1.2)
    pe_bar = Rectangle(width=width, height=pe_h, color=BLUE_ACCENT, fill_opacity=0.85).shift(RIGHT * 1.2)
    ke_bar.align_to(DOWN * max_height / 2, DOWN)
    pe_bar.align_to(DOWN * max_height / 2, DOWN)
    group = VGroup(ke_bar, pe_bar)
    if labels:
        ke_l = Text("KE", font_size=24, color=ACCENT).next_to(ke_bar, DOWN, buff=0.2)
        pe_l = Text("PE", font_size=24, color=BLUE_ACCENT).next_to(pe_bar, DOWN, buff=0.2)
        group.add(ke_l, pe_l)
    return group


def animateEnergyTransfer(
    scene: Scene,
    bars: VGroup,
    ke_from: float,
    ke_to: float,
    pe_from: float,
    pe_to: float,
    run_time: float = 2.0,
) -> None:
    new_bars = makeEnergyBars(ke=ke_to, pe=pe_to, labels=False)
    scene.play(Transform(bars[:2], new_bars), run_time=run_time, rate_func=smooth)


def makeWorkArrow(
    origin: np.ndarray,
    direction: np.ndarray = RIGHT,
    length: float = 2.0,
    label: str = "W",
) -> VGroup:
    unit = direction / np.linalg.norm(direction)
    arr = Arrow(origin, origin + unit * length, buff=0, color=GREEN, stroke_width=4)
    txt = MathTex(label, color=GREEN).scale(0.7).next_to(arr, UP, buff=0.08)
    return VGroup(arr, txt)
