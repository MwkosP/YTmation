"""Shared physics constants and small helpers."""

import numpy as np

# SI defaults (agents can override per call)
G = 9.8
DEFAULT_GROUND_Y = -2.8

# Palette (aligned with common/styling)
PHYSICS_ACCENT = "#FF4500"
FORCE_COLOR = "#FF4500"
VELOCITY_COLOR = "#4488FF"
KE_COLOR = "#00ff88"
PE_COLOR = "#FFD700"
WAVE_COLOR = "#88CCFF"
POSITIVE_CHARGE = "#FF4444"
NEGATIVE_CHARGE = "#4488FF"


def gravityVector(mass: float = 1.0) -> np.ndarray:
    return np.array([0.0, -G * mass, 0.0])


from Math.library.common.pacing import playBeat, fadeOutGroup as fadeGroup  # noqa: F401
