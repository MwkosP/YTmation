# Physics Library

Composable physics blocks + **recipes** for agents.

## Layers

1. **`Math/library/common/`** — titles, panels, colors (shared with other subjects)
2. **`Math/library/physics/*.py`** — primitives (arrows, graphs, waves, …)
3. **`recipes.py`** — one-call teaching demos (`demoProjectile`, …)

See **`AGENT.md`** for the full cookbook.

## Modules

| File | Coverage |
|------|----------|
| `mechanics.py` | ground, forces, fall, bounce |
| `projectile.py` | trajectories |
| `pendulum.py` | simple pendulum |
| `kinematics.py` | motion graphs |
| `energy.py` | KE/PE bars, work arrow |
| `vectors.py` | decomposition, free-body diagrams |
| `waves.py` | sine waves, interference |
| `springs.py` | Hooke's law oscillation |
| `collisions.py` | 1D collisions |
| `optics.py` | lens, rays (native) |
| `electromagnetism.py` | charges, field lines, current |
| `recipes.py` | high-level demos |

Future: plugin adapters for `manim-physics` (pendulum sim, lensing, B-field).
