"""Spring (Hooke's law) building blocks."""

from manim import *
import numpy as np


def makeSpring(
    start: np.ndarray,
    end: np.ndarray,
    coils: int = 8,
    color: str = WHITE,
) -> VMobject:
    direction = end - start
    length = np.linalg.norm(direction)
    if length < 1e-6:
        return Line(start, end, color=color)
    unit = direction / length
    perp = np.array([-unit[1], unit[0], 0.0])
    points = [start]
    for i in range(1, coils * 2):
        t = i / (coils * 2)
        offset = perp * (0.15 if i % 2 else -0.15)
        points.append(start + unit * length * t + offset)
    points.append(end)
    spring = VMobject(color=color, stroke_width=2)
    spring.set_points_smoothly(points)
    return spring


def makeMassOnSpring(
    anchor: np.ndarray = UP * 2,
    length: float = 2.0,
    mass_radius: float = 0.14,
    color: str = "#FF4500",
) -> tuple[VMobject, Dot]:
    mass_pos = anchor + DOWN * length
    spring = makeSpring(anchor, mass_pos)
    mass = Dot(mass_pos, radius=mass_radius, color=color)
    return spring, mass


def animateSpringOscillation(
    scene: Scene,
    anchor: np.ndarray,
    spring: VMobject,
    mass: Dot,
    amplitude: float = 0.6,
    cycles: int = 2,
    run_time: float = 3.0,
) -> None:
    rest = mass.get_center()
    for _ in range(cycles):
        down = rest + DOWN * amplitude
        up = rest + UP * amplitude
        new_spring_d = makeSpring(anchor, down)
        new_spring_u = makeSpring(anchor, up)
        scene.play(
            Transform(spring, new_spring_d),
            mass.animate.move_to(down),
            run_time=run_time / (2 * cycles),
            rate_func=smooth,
        )
        scene.play(
            Transform(spring, new_spring_u),
            mass.animate.move_to(up),
            run_time=run_time / (2 * cycles),
            rate_func=smooth,
        )
