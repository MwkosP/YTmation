# Math Library

Reusable animation blocks, organized by domain.

Each module should export small, composable helpers that receive `scene` as the first argument.

## Shared (all domains)

- `common/` — layout (`makeTitle`, panels) and styling (`BG`, `ACCENT`, `setupScene`)

## Category map

### `math/` (filled — start here for pure math)

- `math/graphs/` — axes, plots
- `math/calculus/`, `algebra/`, `linear_algebra/`, `geometry/`
- `math/trigonometry/`, `statistics/`, `number_theory/`
- `math/recipes.py` — agent one-call demos

### Other domains

- `math/calculus`
- `math/algebra`
- `math/linear_algebra`
- `math/geometry`
- `math/statistics`
- `math/number_theory`
- `ml`
- `physics`
- `chemistry`
- `economics`
- `space`
- `text`

## Authoring rules

- Prefer pure helper functions over large monolithic scenes.
- Keep imports local when blocks are optional/plugin-backed.
- Avoid cross-module shared mutable state.
- Return created mobjects when useful for composition.
