"""
Channel-wide pacing and animation timing.

Use one PacingProfile per video (or per scene) so title/beat/pause timing stays consistent.
Manim still runs the animations; this module owns durations and waits.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Callable

from manim import Animation, FadeIn, FadeOut, Mobject, Scene, VGroup, Write


@dataclass(frozen=True)
class PacingProfile:
    """All default durations for a lesson style (seconds)."""

    title_enter: float = 0.6
    subtitle_enter: float = 0.5
    caption_enter: float = 0.5
    beat_default: float = 2.0
    pad_after_beat: float = 1.0
    pad_after_segment: float = 1.0
    fade_quick: float = 0.35
    fade_normal: float = 0.5
    fade_slow: float = 0.8
    lag_ratio: float = 0.15
    crossfade_stitch: float = 0.18


PACING_FAST = PacingProfile(
    title_enter=0.45,
    beat_default=1.5,
    pad_after_beat=0.6,
    pad_after_segment=0.6,
)

PACING_NORMAL = PacingProfile()

PACING_SLOW = PacingProfile(
    beat_default=2.8,
    pad_after_beat=1.4,
    pad_after_segment=1.4,
)

PACING_EXPLAINER = PacingProfile(
    title_enter=0.7,
    beat_default=4.0,
    pad_after_beat=2.0,
    pad_after_segment=2.0,
    caption_enter=0.6,
)

_active: PacingProfile = PACING_NORMAL


def getPacing() -> PacingProfile:
    return _active


def setDefaultPacing(profile: PacingProfile) -> None:
    global _active
    _active = profile


def withPacing(**kwargs) -> PacingProfile:
    """Override fields on the current default profile (returns a new profile)."""
    return replace(getPacing(), **kwargs)


def beatDuration(run_time: float | None = None, pacing: PacingProfile | None = None) -> float:
    if run_time is not None:
        return run_time
    return (pacing or getPacing()).beat_default


def splitRunTime(total: float, *fractions: float) -> list[float]:
    """Split total duration by positive weights (e.g. 0.4, 0.6)."""
    if not fractions:
        return [total]
    s = sum(fractions)
    if s <= 0:
        raise ValueError("fractions must sum to a positive value")
    return [total * (f / s) for f in fractions]


def phaseTimes(phases: int, total: float | None = None, pacing: PacingProfile | None = None) -> list[float]:
    if phases < 1:
        raise ValueError("phases must be >= 1")
    t = beatDuration(total, pacing)
    return [t / phases] * phases


def playBeat(
    scene: Scene,
    *animations: Animation,
    run_time: float | None = None,
    wait: float | None = None,
    pacing: PacingProfile | None = None,
) -> None:
    p = pacing or getPacing()
    w = p.pad_after_beat if wait is None else wait
    if animations:
        scene.play(*animations, run_time=beatDuration(run_time, p))
    if w > 0:
        scene.wait(w)


def playTitle(scene: Scene, title: Mobject, pacing: PacingProfile | None = None) -> None:
    p = pacing or getPacing()
    scene.play(Write(title), run_time=p.title_enter)


def playSubtitle(scene: Scene, subtitle: Mobject, pacing: PacingProfile | None = None) -> None:
    p = pacing or getPacing()
    scene.play(FadeIn(subtitle), run_time=p.subtitle_enter)


def playCaption(scene: Scene, caption: Mobject, pacing: PacingProfile | None = None) -> None:
    p = pacing or getPacing()
    scene.play(FadeIn(caption), run_time=p.caption_enter)


def waitPad(scene: Scene, pacing: PacingProfile | None = None, *, segment: bool = False) -> None:
    p = pacing or getPacing()
    t = p.pad_after_segment if segment else p.pad_after_beat
    if t > 0:
        scene.wait(t)


def fadeOutGroup(
    scene: Scene,
    group: Mobject | VGroup,
    pacing: PacingProfile | None = None,
    *,
    quick: bool = False,
) -> None:
    p = pacing or getPacing()
    rt = p.fade_quick if quick else p.fade_normal
    scene.play(FadeOut(group), run_time=rt)


def sceneTime(scene: Scene) -> float:
    """Elapsed seconds in the current Manim scene."""
    return float(scene.renderer.time)


def waitForVoice(scene: Scene, tracker, buffer: float = 0.15, pacing: PacingProfile | None = None) -> None:
    """Pad scene to match pre-generated voiceover duration."""
    remaining = float(tracker.duration) - sceneTime(scene) - buffer
    if remaining > 0:
        scene.wait(remaining)


def runDemoLesson(
    scene: Scene,
    title_mob: Mobject,
    show_fn: Callable[..., None],
    *,
    layout,
    caption_mob: Mobject | None = None,
    pacing: PacingProfile | None = None,
    show_kwargs: dict | None = None,
) -> None:
    """
    Standard recipe beat: title -> show* -> optional caption -> pad.

    show_fn signature: show_fn(scene, layout=layout, run_time=..., **show_kwargs)
    """
    p = pacing or getPacing()
    kwargs = {"layout": layout, "run_time": p.beat_default, **(show_kwargs or {})}
    playTitle(scene, title_mob, p)
    show_fn(scene, **kwargs)
    if caption_mob is not None:
        playCaption(scene, caption_mob, p)
