"""Shared helpers for mathmwk *Showcase.py workflow scripts."""

from __future__ import annotations

import textwrap
from pathlib import Path

from Math.library.common.pacing import PacingProfile, getPacing


def padWait(pacing: PacingProfile | None = None) -> float:
    return (pacing or getPacing()).pad_after_segment


def beatAnimationBody(fn: str, recipes_module: str, *, pad: float | None = None) -> str:
    """Python source injected into CustomScene.construct (no trailing wait if pad is 0)."""
    wait_line = f"\nself.wait({pad if pad is not None else padWait()})"
    return f"""
from Math.library.common.styling import setupScene
from {recipes_module} import {fn}
setupScene(self)
{fn}(self)
""".strip() + (wait_line if (pad is None or pad > 0) else "")


def demoSegment(
    idx: int,
    slug: str,
    fn: str,
    recipes_module: str,
    *,
    pad: float | None = None,
) -> dict:
    num = f"{idx:02d}"
    return {
        "name": f"{num}_{slug}",
        "beat": fn,
        "animation": beatAnimationBody(fn, recipes_module, pad=pad),
    }


def sceneSource(animation: str, bg: str = "#0a0a0a") -> str:
    body = textwrap.indent(animation.strip(), "        ")
    return f"""
from manim import *

class CustomScene(Scene):
    def construct(self):
        self.camera.background_color = "{bg}"
{body}
"""


def stitchCrossfadeDuration(pacing: PacingProfile | None = None) -> float:
    return (pacing or getPacing()).crossfade_stitch
