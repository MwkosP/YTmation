"""Shared colors and scene setup — not physics-specific."""

from manim import Scene

BG = "#0a0a0a"
ACCENT = "#FF4500"
TEXT = "#ffffff"
MUTED = "#888888"
YELLOW = "#FFD700"
BLUE_ACCENT = "#4488FF"
GREEN = "#00ff88"


def setupScene(scene: Scene, bg: str = BG) -> None:
    scene.camera.background_color = bg
