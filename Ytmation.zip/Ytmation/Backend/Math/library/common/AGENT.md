# Common Library — Agent Cookbook

Cross-domain helpers: **styling**, **layout manager**, titles/captions.

## Layout manager (like GUI layout managers)

Manim has no built-in layout manager. We use **named regions** on the frame (title band, main, sidebar, footer) and **place** mobjects inside them with optional **fit** (scale down if too large).

```python
from Math.library.common.layout import SceneLayout, placeInRegion

layout = SceneLayout("sidebar")  # or .standard(), .split()

title = layout.place(Text("Mean & Median"), "title", v_align="top", fit=False)
diagram = layout.place(axes_group, "main", fit=True)
steps = layout.place(step_list, "sidebar", h_align="left", v_align="top", fit=True)

# Debug: faint region outlines
# scene.add(layout.guideBoxes())
```

### Presets (11)

| Preset | Regions | Use when |
|--------|---------|----------|
| `standard` | title, subtitle, main, caption, formula | Single diagram + title (default) |
| `sidebar` | main + sidebar (right) | Diagram left, steps right |
| `sidebar_left` | sidebar (left) + main | Steps left, diagram right |
| `split` | left, right | Compare two panels |
| `stacked` | main + footer | Diagram top, steps below |
| `formula_focus` | main + formula | Small graph, big equation strip |
| `inset` | main + inset | Full diagram + corner PiP |
| `minimal` | main only | Full-frame diagram |
| `short` | title, main, caption | Portrait-style beats |
| `lecture` | title, subtitle, main, sidebar, caption, formula | Dense teaching slide |
| `hero` | thin title + main | Maximum diagram area |

### Rules for `math/*` `show*` functions

1. **Do not** `.to_edge(UP)` for topic labels if the scene already has `makeTitle()` — use `placeInRegion(cap, "main", v_align="top")` or pass a shared `SceneLayout`.
2. **Diagrams** → `"main"` with `fit=True`.
3. **Step lists** → `"sidebar"` (sidebar preset) or bottom of `"main"`.
4. **Formulas** → `"formula"` or `makeFormulaBanner()`.

### Titles (backward compatible)

```python
from Math.library.common.layout import makeTitle, makeSubtitle, SceneLayout

layout = SceneLayout.sidebar()
makeTitle("Statistics", layout=layout)
makeSubtitle("Sample vs population", layout=layout)
```

## Layout showcase (catalog + 11 presets)

```bash
python Workflows/channels/mathmwk/layoutShowcase.py
```

`layout/recipes.py`: `demoLayoutCatalog` + one `demoLayout*` per preset in `presets.py`.

## Styling

`setupScene(scene)` — dark background `#0a0a0a`. Colors: `TEXT`, `MUTED`, `ACCENT` in `styling.py`.

## Pacing & timing (`common/pacing.py`)

Central control for **how long** things animate and **how long** to pause.

### Profiles

| Profile | Use when |
|---------|----------|
| `PACING_FAST` | Quick catalog / previews |
| `PACING_NORMAL` | Default mathmwk demos |
| `PACING_SLOW` | Longer beats |
| `PACING_EXPLAINER` | ELI5 / narrated explainers |

```python
from Math.library.common.pacing import (
    setDefaultPacing, PACING_SLOW, getPacing,
    playBeat, playTitle, runDemoLesson, beatDuration, splitRunTime,
)

setDefaultPacing(PACING_SLOW)  # whole script or showcase run
```

### Recipe pattern

```python
def demoTopic(scene, pacing=None):
    p = pacing or getPacing()
    setupScene(scene)
    layout = SceneLayout("standard")
    runDemoLesson(
        scene,
        makeTitle("Topic", layout=layout),
        showTopic,
        layout=layout,
        caption_mob=makeCaption("hint", layout=layout),  # optional
        pacing=p,
    )
```

### `show*` pattern

```python
def showTopic(scene, layout=None, run_time=None):
    rt = beatDuration(run_time)
    t1, t2 = splitRunTime(rt, 0.5, 0.5)
    scene.play(Create(axes), run_time=t1)
    scene.play(FadeIn(labels), run_time=t2)
```

### Showcase runner (`common/showcase_runner.py`)

```python
from Math.library.common.showcase_runner import demoSegment, sceneSource, stitchCrossfadeDuration
from Math.library.common.pacing import PACING_NORMAL, setDefaultPacing

setDefaultPacing(PACING_NORMAL)
seg = demoSegment(1, "topic", "demoTopic", "Math.library.economics.recipes", pad=getPacing().pad_after_segment)
```

Segment padding uses `pad_after_segment`; in-scene beats use `beat_default` + optional `splitRunTime`.

### Voiceover

```python
from Math.library.common.pacing import waitForVoice
# inside VoiceoverScene after animations:
waitForVoice(self, tracker)
```
