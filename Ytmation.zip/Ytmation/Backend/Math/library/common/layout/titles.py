"""Title, caption, and panel helpers — positioned via SceneLayout regions."""

from manim import *
import numpy as np

from Math.library.common.styling import TEXT, MUTED, ACCENT
from Math.library.common.layout.manager import SceneLayout


def makeTitle(
    text: str,
    size: int = 44,
    color: str = TEXT,
    layout: SceneLayout | None = None,
) -> Text:
    layout = layout or SceneLayout.standard()
    title = Text(text, font_size=size, color=color, weight=BOLD)
    return layout.place(title, "title", v_align="top", fit=False, buff=0.08)  # type: ignore[return-value]


def makeSubtitle(
    text: str,
    size: int = 28,
    color: str = MUTED,
    layout: SceneLayout | None = None,
    below: Mobject | None = None,
) -> Text:
    layout = layout or SceneLayout.standard()
    sub = Text(text, font_size=size, color=color)
    if below is not None and "subtitle" not in layout.regions:
        sub.next_to(below, DOWN, buff=0.35)
        return sub
    if "subtitle" in layout.regions:
        return layout.place(sub, "subtitle", v_align="top", fit=False, buff=0.05)  # type: ignore[return-value]
    sub.next_to(below or ORIGIN, DOWN, buff=0.35)
    return sub


def makeCaption(
    text: str,
    size: int = 24,
    color: str = MUTED,
    layout: SceneLayout | None = None,
) -> Text:
    layout = layout or SceneLayout.standard()
    cap = Text(text, font_size=size, color=color)
    if "caption" in layout.regions:
        region = "caption"
    elif "footer" in layout.regions:
        region = "footer"
    else:
        region = "formula"
    return layout.place(cap, region, v_align="bottom", fit=False, buff=0.08)  # type: ignore[return-value]


def makeFormulaBanner(
    tex: str,
    color: str = ACCENT,
    scale: float = 0.7,
    layout: SceneLayout | None = None,
) -> MathTex:
    layout = layout or SceneLayout.standard()
    banner = MathTex(tex, color=color).scale(scale)
    if "formula" in layout.regions:
        region = "formula"
    elif "footer" in layout.regions:
        region = "footer"
    else:
        region = "caption"
    return layout.place(banner, region, v_align="bottom", fit=True, buff=0.1)  # type: ignore[return-value]


def makeSplitPanels(
    layout: SceneLayout | None = None,
    width: float | None = None,
    height: float | None = None,
    stroke_color=GREY_D,
) -> tuple[Rectangle, Rectangle]:
    """Outline rectangles matching split preset left/right regions."""
    layout = layout or SceneLayout.split()
    left_r = layout.region("left", buff=0.1)
    right_r = layout.region("right", buff=0.1)
    lw = width or left_r.width
    lh = height or left_r.height
    rw = width or right_r.width
    rh = height or right_r.height
    left = Rectangle(width=lw, height=lh, stroke_width=1.2, color=stroke_color).move_to(left_r.center)
    right = Rectangle(width=rw, height=rh, stroke_width=1.2, color=stroke_color).move_to(right_r.center)
    return left, right
