"""Scene layout manager — place mobjects into named regions."""

from __future__ import annotations

from typing import Literal

import numpy as np
from manim import Mobject, VGroup

from Math.library.common.layout.presets import PRESETS
from Math.library.common.layout.regions import Region

HAlign = Literal["left", "center", "right"]
VAlign = Literal["top", "center", "bottom"]


class SceneLayout:
    """
    Layout manager for one scene beat.

    Think: Android ConstraintLayout / Qt grid — fixed regions, you place content inside.
    """

    def __init__(self, preset: str = "standard", regions: dict[str, Region] | None = None):
        if regions is not None:
            self.regions = dict(regions)
        elif preset not in PRESETS:
            raise ValueError(f"Unknown layout preset {preset!r}. Choose from: {list(PRESETS)}")
        else:
            self.regions = dict(PRESETS[preset])
        self.preset = preset

    @classmethod
    def standard(cls) -> SceneLayout:
        return cls("standard")

    @classmethod
    def sidebar(cls) -> SceneLayout:
        return cls("sidebar")

    @classmethod
    def split(cls) -> SceneLayout:
        return cls("split")

    @classmethod
    def sidebarLeft(cls) -> SceneLayout:
        return cls("sidebar_left")

    @classmethod
    def stacked(cls) -> SceneLayout:
        return cls("stacked")

    @classmethod
    def formulaFocus(cls) -> SceneLayout:
        return cls("formula_focus")

    @classmethod
    def inset(cls) -> SceneLayout:
        return cls("inset")

    @classmethod
    def lecture(cls) -> SceneLayout:
        return cls("lecture")

    @classmethod
    def hero(cls) -> SceneLayout:
        return cls("hero")

    def region(self, name: str, *, buff: float = 0.0) -> Region:
        if name not in self.regions:
            raise KeyError(f"Region {name!r} not in preset {self.preset!r}. Have: {list(self.regions)}")
        r = self.regions[name]
        return r.shrunk(buff) if buff else r

    def place(
        self,
        mob: Mobject,
        region_name: str,
        *,
        h_align: HAlign = "center",
        v_align: VAlign = "center",
        fit: bool = True,
        buff: float = 0.12,
    ) -> Mobject:
        """Move (and optionally scale down) *mob* inside a named region."""
        reg = self.region(region_name, buff=buff)
        if fit:
            _fitToRegion(mob, reg)
        target = _alignPoint(mob, reg, h_align, v_align)
        mob.move_to(target)
        return mob

    def placeGroup(
        self,
        group: VGroup | list[Mobject],
        region_name: str,
        *,
        direction=np.array([0.0, -1.0, 0.0]),
        buff: float = 0.35,
        fit: bool = True,
        h_align: HAlign = "center",
        v_align: VAlign = "center",
        region_buff: float = 0.12,
    ) -> VGroup:
        g = group if isinstance(group, VGroup) else VGroup(*group)
        g.arrange(direction, buff=buff)
        return self.place(g, region_name, h_align=h_align, v_align=v_align, fit=fit, buff=region_buff)  # type: ignore[return-value]

    def guideBoxes(self, opacity: float = 0.08) -> VGroup:
        """Debug overlay: show region rectangles."""
        from manim import GREY_B, Rectangle

        boxes = VGroup()
        for reg in self.regions.values():
            r = Rectangle(
                width=reg.width,
                height=reg.height,
                stroke_width=1,
                stroke_color=GREY_B,
                fill_opacity=opacity,
            )
            r.move_to(reg.center)
            boxes.add(r)
        return boxes


def _fitToRegion(mob: Mobject, reg: Region) -> None:
    if mob.width > reg.width and mob.width > 1e-6:
        mob.scale(reg.width / mob.width)
    if mob.height > reg.height and mob.height > 1e-6:
        mob.scale(reg.height / mob.height)


def _alignPoint(mob: Mobject, reg: Region, h_align: HAlign, v_align: VAlign) -> np.ndarray:
    left = reg.x0 + mob.width / 2
    right = reg.x1 - mob.width / 2
    bottom = reg.y0 + mob.height / 2
    top = reg.y1 - mob.height / 2
    cx = (reg.x0 + reg.x1) / 2

    if h_align == "left":
        x = left
    elif h_align == "right":
        x = right
    else:
        x = cx

    if v_align == "top":
        y = top
    elif v_align == "bottom":
        y = bottom
    else:
        y = (reg.y0 + reg.y1) / 2

    return np.array([x, y, 0.0])


def placeInRegion(
    mob: Mobject,
    region_name: str,
    layout: SceneLayout | None = None,
    **kwargs,
) -> Mobject:
    """Convenience: place one mobject without holding a layout reference."""
    layout = layout or SceneLayout.standard()
    return layout.place(mob, region_name, **kwargs)
