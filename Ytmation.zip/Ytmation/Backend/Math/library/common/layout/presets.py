"""Named region maps — like layout XML / CSS grid templates."""

from __future__ import annotations

from manim import config

from Math.library.common.layout.regions import Region

# Default Manim frame (~16:9): 14.22 × 8
FW = float(config.frame_width)
FH = float(config.frame_height)
HX = FW / 2
HY = FH / 2
MX = 0.55  # side margin
MY = 0.45  # vertical margin between bands


def _band_top(y1: float, height: float) -> Region:
    return Region(-HX + MX, HX - MX, y1 - height, y1)


def _main_full(y0: float, y1: float) -> Region:
    return Region(-HX + MX, HX - MX, y0, y1)


PRESETS: dict[str, dict[str, Region]] = {
    # Title + full-width diagram + optional footer (default math demos)
    "standard": {
        "title": _band_top(HY - MY, 0.95),
        "subtitle": _band_top(HY - MY - 1.05, 0.55),
        "main": _main_full(-HY + MY + 0.95, HY - MY - 1.15),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
        "formula": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
    },
    # Diagram left, steps/labels right (stats steps, algebra)
    "sidebar": {
        "title": _band_top(HY - MY, 0.95),
        "subtitle": _band_top(HY - MY - 1.05, 0.55),
        "main": Region(-HX + MX, 0.15, -HY + MY + 0.95, HY - MY - 1.15),
        "sidebar": Region(0.55, HX - MX, -HY + MY + 0.95, HY - MY - 1.15),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
        "formula": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
    },
    # Two equal columns (before/after, compare)
    "split": {
        "title": _band_top(HY - MY, 0.95),
        "left": Region(-HX + MX, -0.25, -HY + MY + 0.7, HY - MY - 1.0),
        "right": Region(0.25, HX - MX, -HY + MY + 0.7, HY - MY - 1.0),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
    },
    # Diagram only — no reserved title band (caller adds floating title in title region)
    "minimal": {
        "main": Region(-HX + MX, HX - MX, -HY + MY, HY - MY),
    },
    # Portrait-friendly bands (when frame is tall/narrow or scaled content)
    "short": {
        "title": _band_top(HY - MY, 0.85),
        "main": _main_full(-HY + MY + 1.0, HY - MY - 1.35),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.7),
    },
    # Steps on left, diagram on right (mirror of sidebar)
    "sidebar_left": {
        "title": _band_top(HY - MY, 0.95),
        "subtitle": _band_top(HY - MY - 1.05, 0.55),
        "sidebar": Region(-HX + MX, -0.15, -HY + MY + 0.95, HY - MY - 1.15),
        "main": Region(-0.55, HX - MX, -HY + MY + 0.95, HY - MY - 1.15),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
        "formula": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
    },
    # Single column: diagram on top, steps / text below
    "stacked": {
        "title": _band_top(HY - MY, 0.9),
        "main": Region(-HX + MX, HX - MX, 0.05, HY - MY - 1.05),
        "footer": Region(-HX + MX, HX - MX, -HY + MY, 0.0),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
    },
    # Small diagram top, large formula / derivation strip
    "formula_focus": {
        "title": _band_top(HY - MY, 0.85),
        "main": Region(-HX + MX, HX - MX, 0.35, HY - MY - 0.95),
        "formula": Region(-HX + MX, HX - MX, -HY + MY, 0.3),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.65),
    },
    # Full diagram + corner inset (PiP)
    "inset": {
        "title": _band_top(HY - MY, 0.9),
        "main": _main_full(-HY + MY + 0.95, HY - MY - 1.0),
        "inset": Region(2.6, HX - MX, -2.35, -HY + MY + 1.1),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.75),
    },
    # Dense teaching slide: subtitle + sidebar + footer
    "lecture": {
        "title": _band_top(HY - MY, 0.85),
        "subtitle": _band_top(HY - MY - 0.98, 0.5),
        "main": Region(-HX + MX, 0.2, -HY + MY + 1.05, HY - MY - 1.2),
        "sidebar": Region(0.6, HX - MX, -HY + MY + 1.05, HY - MY - 1.2),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.7),
        "formula": Region(-HX + MX, 0.2, -HY + MY, -HY + MY + 0.7),
    },
    # Thin title strip, maximum diagram area
    "hero": {
        "title": _band_top(HY - MY, 0.55),
        "main": _main_full(-HY + MY + 0.55, HY - MY - 0.35),
        "caption": Region(-HX + MX, HX - MX, -HY + MY, -HY + MY + 0.55),
    },
}
