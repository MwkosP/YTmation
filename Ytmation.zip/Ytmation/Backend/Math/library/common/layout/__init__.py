"""Layout manager — regions, presets, placement."""

from Math.library.common.layout.manager import SceneLayout, placeInRegion
from Math.library.common.layout.presets import PRESETS
from Math.library.common.layout.regions import Region
from Math.library.common.layout.titles import (
    makeCaption,
    makeFormulaBanner,
    makeSplitPanels,
    makeSubtitle,
    makeTitle,
)
from Math.library.common.layout import recipes as layoutRecipes

__all__ = [
    "Region",
    "PRESETS",
    "SceneLayout",
    "placeInRegion",
    "makeTitle",
    "makeSubtitle",
    "makeCaption",
    "makeFormulaBanner",
    "makeSplitPanels",
    "layoutRecipes",
]
