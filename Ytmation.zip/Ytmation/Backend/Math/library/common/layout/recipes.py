"""Layout manager demos — one preset per beat."""

from manim import *

from Math.library.common.styling import setupScene, ACCENT, MUTED
from Math.library.common.layout import (
    SceneLayout,
    makeTitle,
    makeSubtitle,
    makeCaption,
    makeSplitPanels,
    placeInRegion,
)


def _regionLabel(name: str, color=WHITE) -> Text:
    return Text(name, font_size=22, color=color, weight=BOLD)


def _sampleDiagram(color=BLUE) -> VGroup:
    axes = Axes(x_range=[-2, 2, 1], y_range=[-1, 3, 1], x_length=5, y_length=3.2, axis_config={"include_tip": False})
    curve = axes.plot(lambda x: x**2, color=color, x_range=[-1.6, 1.6])
    return VGroup(axes, curve)


def _sampleSteps() -> VGroup:
    return VGroup(
        MathTex(r"\bar{x} = 5.57", font_size=32),
        MathTex(r"s = 2.14", font_size=32, color=ACCENT),
        Text("steps / labels", font_size=22, color=MUTED),
    ).arrange(DOWN, aligned_edge=LEFT, buff=0.28)


def demoLayoutStandard(scene: Scene, title: str = "Standard") -> None:
    """Title + full-width main + caption."""
    setupScene(scene)
    layout = SceneLayout.standard()
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=42, layout=layout)
    diagram = _sampleDiagram()
    placeInRegion(diagram, "main", layout=layout, fit=True)
    cap = makeCaption("caption / formula band", layout=layout)
    scene.play(FadeIn(guides), Write(t), run_time=0.7)
    scene.play(Create(diagram), FadeIn(cap), run_time=1.2)


def demoLayoutSidebar(scene: Scene, title: str = "Sidebar") -> None:
    """Diagram in main, steps in right column."""
    setupScene(scene)
    layout = SceneLayout.sidebar()
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=42, layout=layout)
    diagram = _sampleDiagram("#00ff88")
    steps = _sampleSteps()
    placeInRegion(diagram, "main", layout=layout, fit=True)
    placeInRegion(steps, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)
    scene.play(FadeIn(guides), Write(t), run_time=0.65)
    scene.play(Create(diagram), FadeIn(steps), run_time=1.25)


def demoLayoutSplit(scene: Scene, title: str = "Split") -> None:
    """Two equal columns."""
    setupScene(scene)
    layout = SceneLayout.split()
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=42, layout=layout)
    left_panel, right_panel = makeSplitPanels(layout=layout)
    left_lbl = _regionLabel("left").scale(0.85)
    right_lbl = _regionLabel("right", color=ACCENT).scale(0.85)
    placeInRegion(left_lbl, "left", layout=layout, fit=False)
    placeInRegion(right_lbl, "right", layout=layout, fit=False)
    cap = makeCaption("compare · before / after", layout=layout)
    scene.play(FadeIn(guides), Write(t), run_time=0.6)
    scene.play(Create(left_panel), Create(right_panel), FadeIn(left_lbl), FadeIn(right_lbl), FadeIn(cap), run_time=1.3)


def demoLayoutMinimal(scene: Scene, title: str = "Minimal") -> None:
    """Full-frame main only."""
    setupScene(scene)
    layout = SceneLayout("minimal")
    guides = layout.guideBoxes(opacity=0.14)
    diagram = _sampleDiagram(YELLOW)
    placeInRegion(diagram, "main", layout=layout, fit=True)
    lbl = Text("main fills frame", font_size=28, color=MUTED).to_edge(UP, buff=0.35)
    scene.play(FadeIn(guides), FadeIn(lbl), run_time=0.5)
    scene.play(Create(diagram), run_time=1.4)


def demoLayoutShort(scene: Scene, title: str = "Short") -> None:
    """Tighter bands for portrait-style beats."""
    setupScene(scene)
    layout = SceneLayout("short")
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=38, layout=layout)
    sub = makeSubtitle(
        "Math.library.common.layout · short preset",
        size=22,
        layout=layout,
        below=t,
    )
    diagram = Circle(radius=1.8, color=ACCENT, fill_opacity=0.25, stroke_width=3)
    placeInRegion(diagram, "main", layout=layout, fit=True)
    cap = makeCaption("tall main · compact title", layout=layout)
    scene.play(FadeIn(guides), Write(t), FadeIn(sub), run_time=0.75)
    scene.play(Create(diagram), FadeIn(cap), run_time=1.15)


def demoLayoutSidebarLeft(scene: Scene, title: str = "Sidebar Left") -> None:
    """Steps left, diagram right."""
    setupScene(scene)
    layout = SceneLayout.sidebarLeft()
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=38, layout=layout)
    steps = _sampleSteps()
    diagram = _sampleDiagram("#4488FF")
    placeInRegion(steps, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)
    placeInRegion(diagram, "main", layout=layout, fit=True)
    scene.play(FadeIn(guides), Write(t), FadeIn(steps), run_time=0.65)
    scene.play(Create(diagram), run_time=1.2)


def demoLayoutStacked(scene: Scene, title: str = "Stacked") -> None:
    """Diagram above, footer steps below (one column)."""
    setupScene(scene)
    layout = SceneLayout.stacked()
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=40, layout=layout)
    diagram = _sampleDiagram()
    steps = _sampleSteps()
    placeInRegion(diagram, "main", layout=layout, fit=True, v_align="top")
    placeInRegion(steps, "footer", layout=layout, h_align="center", v_align="center", fit=True)
    scene.play(FadeIn(guides), Write(t), run_time=0.55)
    scene.play(Create(diagram), FadeIn(steps), run_time=1.35)


def demoLayoutFormulaFocus(scene: Scene, title: str = "Formula Focus") -> None:
    """Small graph on top, big formula strip."""
    setupScene(scene)
    layout = SceneLayout.formulaFocus()
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=38, layout=layout)
    diagram = _sampleDiagram().scale(0.85)
    placeInRegion(diagram, "main", layout=layout, fit=True, v_align="top")
    formula = MathTex(
        r"\int_a^b f(x)\,dx = F(b)-F(a)",
        color=ACCENT,
    ).scale(0.95)
    placeInRegion(formula, "formula", layout=layout, fit=True)
    scene.play(FadeIn(guides), Write(t), run_time=0.55)
    scene.play(Create(diagram), Write(formula), run_time=1.35)


def demoLayoutInset(scene: Scene, title: str = "Inset") -> None:
    """Full diagram + corner picture-in-picture."""
    setupScene(scene)
    layout = SceneLayout.inset()
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=40, layout=layout)
    diagram = _sampleDiagram()
    placeInRegion(diagram, "main", layout=layout, fit=True)
    inset_box = Rectangle(width=2.4, height=1.5, color=ACCENT, stroke_width=2, fill_opacity=0.15)
    inset_axes = Axes(x_range=[0, 4, 1], y_range=[0, 4, 1], x_length=2.0, y_length=1.2, axis_config={"include_tip": False})
    inset_curve = inset_axes.plot(lambda x: 0.3 * x**2, color=YELLOW, x_range=[0, 3.5])
    inset_g = VGroup(inset_box, inset_axes, inset_curve)
    placeInRegion(inset_g, "inset", layout=layout, fit=True)
    cap = makeCaption("inset · zoom / detail", layout=layout)
    scene.play(FadeIn(guides), Write(t), run_time=0.55)
    scene.play(Create(diagram), FadeIn(inset_g), FadeIn(cap), run_time=1.3)


def demoLayoutLecture(scene: Scene, title: str = "Lecture") -> None:
    """Title + subtitle + main + sidebar + footer (dense slide)."""
    setupScene(scene)
    layout = SceneLayout.lecture()
    guides = layout.guideBoxes(opacity=0.12)
    t = makeTitle(title, size=36, layout=layout)
    sub = makeSubtitle("all teaching bands at once", size=20, layout=layout)
    diagram = _sampleDiagram(GREEN)
    steps = _sampleSteps().scale(0.9)
    placeInRegion(diagram, "main", layout=layout, fit=True)
    placeInRegion(steps, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)
    cap = makeCaption("caption under main column", layout=layout)
    scene.play(FadeIn(guides), Write(t), FadeIn(sub), run_time=0.6)
    scene.play(Create(diagram), FadeIn(steps), FadeIn(cap), run_time=1.25)


def demoLayoutHero(scene: Scene, title: str = "Hero") -> None:
    """Thin title, maximum diagram area."""
    setupScene(scene)
    layout = SceneLayout.hero()
    guides = layout.guideBoxes(opacity=0.1)
    t = makeTitle(title, size=34, layout=layout)
    diagram = _sampleDiagram().scale(1.15)
    placeInRegion(diagram, "main", layout=layout, fit=True)
    scene.play(FadeIn(guides), Write(t), run_time=0.5)
    scene.play(Create(diagram), run_time=1.45)


def demoLayoutCatalog(scene: Scene, title: str = "Layout Presets") -> None:
    """Intro: list every preset name."""
    setupScene(scene)
    from Math.library.common.layout.presets import PRESETS

    names = sorted(PRESETS.keys())
    t = Text(title, font_size=46, color=WHITE, weight=BOLD).to_edge(UP, buff=0.45)
    cols = VGroup(
        *[Text(f"• {n}", font_size=24, color=MUTED) for n in names]
    ).arrange_in_grid(rows=6, cols=2, buff=(0.5, 0.18), flow_order="rd")
    cols.next_to(t, DOWN, buff=0.4)
    sub = Text(f"{len(names)} presets · common.layout", font_size=26, color=ACCENT).to_edge(DOWN, buff=0.4)
    scene.play(Write(t), FadeIn(cols, lag_ratio=0.04), FadeIn(sub), run_time=2.0)
