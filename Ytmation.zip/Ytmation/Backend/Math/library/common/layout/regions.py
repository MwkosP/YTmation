"""Rectangular regions on the Manim frame (layout cells)."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Region:
    """Axis-aligned rectangle in scene coordinates (y up)."""

    x0: float
    x1: float
    y0: float
    y1: float

    @property
    def width(self) -> float:
        return self.x1 - self.x0

    @property
    def height(self) -> float:
        return self.y1 - self.y0

    @property
    def center(self) -> np.ndarray:
        return np.array([(self.x0 + self.x1) / 2, (self.y0 + self.y1) / 2, 0.0])

    def shrunk(self, buff: float = 0.15) -> Region:
        return Region(self.x0 + buff, self.x1 - buff, self.y0 + buff, self.y1 - buff)
