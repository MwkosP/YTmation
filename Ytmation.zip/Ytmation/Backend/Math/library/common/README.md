# Common Library

Cross-domain helpers for **all** `Math/library/*` categories.

- `styling.py` — colors and `setupScene(scene)`
- `layout/` — **layout manager** (regions + presets), titles, captions, split panels

## Layout quick start

```python
from Math.library.common.layout import SceneLayout, makeTitle

layout = SceneLayout("standard")
makeTitle("Derivative", layout=layout)
layout.place(my_axes, "main", fit=True)
```

See `AGENT.md` for presets and rules (avoid title/diagram overlap).
