"""Regression visuals."""

from manim import *
import numpy as np

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.ml._core import ML_NEUTRAL


def showBestFitLine(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.0,
) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(
        x_range=[0, 10, 1],
        y_range=[0, 10, 1],
        x_length=6.7,
        y_length=4.3,
        tips=False,
        axis_config={"color": GREY_B},
    )
    pts = [(1, 1.6), (2, 2.8), (3, 3.4), (5, 5.1), (7, 6.8), (8, 8.2)]
    dots = VGroup(*[Dot(axes.c2p(x, y), radius=0.08, color=ML_NEUTRAL) for x, y in pts])
    line = axes.plot(lambda x: 0.9 * x + 0.6, x_range=[0.5, 9], color=YELLOW)
    group = VGroup(axes, dots, line)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(axes), FadeIn(dots), run_time=run_time * 0.45)
    scene.play(Create(line), run_time=run_time * 0.55)
    return group


def showUnderfitVsOverfit(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.0,
) -> VGroup:
    layout = layout or SceneLayout("split")
    left_axes = Axes(x_range=[0, 10, 2], y_range=[0, 10, 2], x_length=3.8, y_length=2.8, tips=False)
    right_axes = Axes(x_range=[0, 10, 2], y_range=[0, 10, 2], x_length=3.8, y_length=2.8, tips=False)
    dots = [(1, 2), (2.5, 3.6), (4, 4.5), (6, 6.2), (8, 7.7)]
    left_dots = VGroup(*[Dot(left_axes.c2p(x, y), radius=0.06, color=WHITE) for x, y in dots])
    right_dots = VGroup(*[Dot(right_axes.c2p(x, y), radius=0.06, color=WHITE) for x, y in dots])
    # Underfit: a simple line that misses the curvature trend.
    under = left_axes.plot(lambda x: 0.55 * x + 1.8, x_range=[1, 8], color=BLUE_B)

    # Overfit: intentionally wiggly but constrained to the same data bounds.
    over_points = [
        right_axes.c2p(1.0, 2.2),
        right_axes.c2p(2.0, 4.2),
        right_axes.c2p(3.0, 3.1),
        right_axes.c2p(4.0, 5.4),
        right_axes.c2p(5.5, 4.8),
        right_axes.c2p(6.4, 7.2),
        right_axes.c2p(7.1, 6.4),
        right_axes.c2p(8.0, 7.8),
    ]
    over = VMobject(color=RED_B, stroke_width=3)
    over.set_points_smoothly(over_points)
    left = VGroup(Text("Underfit", font_size=24, color=BLUE_B), left_axes, left_dots, under).arrange(DOWN, buff=0.2)
    right = VGroup(Text("Overfit", font_size=24, color=RED_B), right_axes, right_dots, over).arrange(DOWN, buff=0.2)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)
