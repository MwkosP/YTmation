"""ML recipes — one topic per call."""

from manim import *

from Math.library.common.layout import SceneLayout, makeTitle, makeCaption
from Math.library.common.styling import setupScene
from Math.library.ml.classification import showDecisionBoundary, showLogisticCurve
from Math.library.ml.regression import showBestFitLine, showUnderfitVsOverfit
from Math.library.ml.loss import showMSECurve, showCrossEntropyIntuition
from Math.library.ml.gradient_descent import showGradientDescentPath, showLearningRateEffect
from Math.library.ml.metrics import showConfusionMatrix, showPrecisionRecallF1, showRocAuc
from Math.library.ml.nn_core import showForwardPass
from Math.library.ml.knn import showKnnClassification
from Math.library.ml.trees import showDecisionTreeSplit, showRandomForestIdea
from Math.library.ml.clustering import showKMeansIteration
from Math.library.ml.svm import showSvmMargin
from Math.library.ml.naive_bayes import showNaiveBayesIntuition
from Math.library.ml.pca import showPcaProjection
from Math.library.ml.pipeline import showTrainValTestSplit, showCrossValidation
from Math.library.ml.backprop import showBackpropStep, showWeightUpdate
from Math.library.ml.cnn import showConvolutionKernel, showPooling
from Math.library.ml.rnn import showRnnUnrolled
from Math.library.ml.embeddings import showTokenEmbeddings
from Math.library.ml.attention import showAttentionMatrix, showSelfAttentionFlow
from Math.library.ml.transformers import showTransformerBlock, showResidualConnection
from Math.library.ml.architectures import showArchitectureOverview
from Math.library.ml.llm_inference import showNextTokenLoop, showSamplingControls


def demoDecisionBoundary(scene: Scene, title: str = "Classification Boundary") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showDecisionBoundary(scene, layout=layout)


def demoLogistic(scene: Scene, title: str = "Logistic Curve") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showLogisticCurve(scene, layout=layout)


def demoRegression(scene: Scene, title: str = "Best Fit Line") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=40, layout=layout)), run_time=0.6)
    showBestFitLine(scene, layout=layout)


def demoBiasVariance(scene: Scene, title: str = "Underfit vs Overfit") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showUnderfitVsOverfit(scene, layout=layout)


def demoLoss(scene: Scene, title: str = "Loss Functions") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title, size=40, layout=layout)), run_time=0.6)
    showMSECurve(scene, layout=layout, run_time=1.6)
    scene.play(FadeIn(makeCaption("Lower loss means better fit", layout=layout)), run_time=0.5)


def demoCrossEntropy(scene: Scene, title: str = "Cross Entropy Intuition") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showCrossEntropyIntuition(scene, layout=layout)


def demoGradientDescent(scene: Scene, title: str = "Gradient Descent") -> None:
    setupScene(scene)
    layout = SceneLayout("formula_focus")
    scene.play(Write(makeTitle(title, size=40, layout=layout)), run_time=0.6)
    showGradientDescentPath(scene, layout=layout)


def demoLearningRate(scene: Scene, title: str = "Learning Rate") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showLearningRateEffect(scene, layout=layout)


def demoConfusionMatrix(scene: Scene, title: str = "Confusion Matrix") -> None:
    setupScene(scene)
    layout = SceneLayout("sidebar")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showConfusionMatrix(scene, layout=layout)


def demoNeuralNet(scene: Scene, title: str = "Neural Network Forward Pass") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title, size=34, layout=layout)), run_time=0.6)
    showForwardPass(scene, layout=layout)


def demoKnn(scene: Scene, title: str = "k-Nearest Neighbors") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showKnnClassification(scene, layout=layout)


def demoDecisionTree(scene: Scene, title: str = "Decision Tree Split") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showDecisionTreeSplit(scene, layout=layout)


def demoRandomForest(scene: Scene, title: str = "Random Forest") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showRandomForestIdea(scene, layout=layout)


def demoKMeans(scene: Scene, title: str = "k-Means Clustering") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showKMeansIteration(scene, layout=layout)


def demoSvm(scene: Scene, title: str = "Support Vector Machine") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showSvmMargin(scene, layout=layout)


def demoNaiveBayes(scene: Scene, title: str = "Naive Bayes") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showNaiveBayesIntuition(scene, layout=layout)


def demoPca(scene: Scene, title: str = "PCA Projection") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showPcaProjection(scene, layout=layout)


def demoTrainValTest(scene: Scene, title: str = "Train/Val/Test Split") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showTrainValTestSplit(scene, layout=layout)


def demoCrossValidation(scene: Scene, title: str = "Cross Validation") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showCrossValidation(scene, layout=layout)


def demoPrecisionRecallF1(scene: Scene, title: str = "Precision / Recall / F1") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=34, layout=layout)), run_time=0.6)
    showPrecisionRecallF1(scene, layout=layout)


def demoRocAuc(scene: Scene, title: str = "ROC and PR Curves") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showRocAuc(scene, layout=layout)


def demoBackprop(scene: Scene, title: str = "Backpropagation") -> None:
    setupScene(scene)
    layout = SceneLayout("hero")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showBackpropStep(scene, layout=layout)


def demoWeightUpdate(scene: Scene, title: str = "Weight Update Rule") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showWeightUpdate(scene, layout=layout)


def demoCnnConv(scene: Scene, title: str = "CNN Convolution") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showConvolutionKernel(scene, layout=layout)


def demoCnnPooling(scene: Scene, title: str = "CNN Pooling") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showPooling(scene, layout=layout)


def demoRnn(scene: Scene, title: str = "RNN Unrolled") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showRnnUnrolled(scene, layout=layout)


def demoEmbeddings(scene: Scene, title: str = "Token Embeddings") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showTokenEmbeddings(scene, layout=layout)


def demoAttentionMatrix(scene: Scene, title: str = "Attention Matrix") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showAttentionMatrix(scene, layout=layout)


def demoSelfAttention(scene: Scene, title: str = "Self Attention Flow") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showSelfAttentionFlow(scene, layout=layout)


def demoTransformerBlock(scene: Scene, title: str = "Transformer Block") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showTransformerBlock(scene, layout=layout)


def demoResidual(scene: Scene, title: str = "Residual Connections") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showResidualConnection(scene, layout=layout)


def demoArchitectureOverview(scene: Scene, title: str = "Architecture Overview") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=36, layout=layout)), run_time=0.6)
    showArchitectureOverview(scene, layout=layout)


def demoLlmInference(scene: Scene, title: str = "LLM Next-Token Inference") -> None:
    setupScene(scene)
    layout = SceneLayout("standard")
    scene.play(Write(makeTitle(title, size=34, layout=layout)), run_time=0.6)
    showNextTokenLoop(scene, layout=layout)


def demoSampling(scene: Scene, title: str = "Sampling Controls") -> None:
    setupScene(scene)
    layout = SceneLayout("split")
    scene.play(Write(makeTitle(title, size=38, layout=layout)), run_time=0.6)
    showSamplingControls(scene, layout=layout)
