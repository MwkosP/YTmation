"""Loss functions and metrics visuals."""

from manim import *
import numpy as np

from Math.library.common.layout import SceneLayout, placeInRegion


def showMSECurve(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    axes = Axes(
        x_range=[-3, 3, 1],
        y_range=[0, 10, 2],
        x_length=6.4,
        y_length=3.8,
        tips=False,
        axis_config={"color": GREY_B},
    )
    curve = axes.plot(lambda x: x * x + 0.5, x_range=[-3, 3], color=ORANGE)
    dot = Dot(axes.c2p(2.2, 2.2 * 2.2 + 0.5), color=YELLOW, radius=0.09)
    group = VGroup(axes, curve, dot)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(curve), run_time=run_time * 0.75)
    scene.play(FadeIn(dot), run_time=run_time * 0.25)
    return group


def showCrossEntropyIntuition(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    text = VGroup(
        Text("True label: 1", font_size=30),
        Text("Predicted p=0.95 -> low loss", font_size=26, color=GREEN),
        Text("Predicted p=0.10 -> high loss", font_size=26, color=RED),
    ).arrange(DOWN, aligned_edge=LEFT, buff=0.28)
    placeInRegion(text, "main", layout=layout, fit=True)
    scene.play(LaggedStart(*[FadeIn(t, shift=UP * 0.1) for t in text], lag_ratio=0.2), run_time=run_time)
    return text
