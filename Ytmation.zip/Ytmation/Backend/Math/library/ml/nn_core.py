"""Neural-network diagram abstractions."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def makeNeuron(radius: float = 0.14, color=BLUE_B) -> Circle:
    return Circle(radius=radius, color=color, fill_color=color, fill_opacity=0.8, stroke_width=1.2)


def makeDenseLayer(count: int, color=BLUE_B, buff: float = 0.22) -> VGroup:
    return VGroup(*[makeNeuron(color=color) for _ in range(count)]).arrange(DOWN, buff=buff)


def connectLayers(left: VGroup, right: VGroup, color=GREY_B) -> VGroup:
    lines = VGroup()
    for l in left:
        for r in right:
            lines.add(Line(l.get_right(), r.get_left(), color=color, stroke_width=1))
    return lines


def makeMLP(sizes: list[int] = [3, 4, 2]) -> VGroup:
    layers = VGroup(*[makeDenseLayer(n) for n in sizes]).arrange(RIGHT, buff=1.2)
    edges = VGroup()
    for i in range(len(layers) - 1):
        edges.add(connectLayers(layers[i], layers[i + 1]))
    return VGroup(edges, layers)


def showForwardPass(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("hero")
    mlp = makeMLP([3, 4, 2])
    placeInRegion(mlp, "main", layout=layout, fit=True)
    scene.play(Create(mlp[0]), FadeIn(mlp[1]), run_time=run_time * 0.7)
    scene.play(mlp[0].animate.set_color(YELLOW), run_time=run_time * 0.3)
    return mlp
