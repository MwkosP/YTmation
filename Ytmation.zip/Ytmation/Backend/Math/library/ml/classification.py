"""Classification visuals."""

from manim import *
import numpy as np

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.ml._core import makeDataset2D, ML_POS, ML_NEG


def showDecisionBoundary(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.0,
) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(
        x_range=[0, 10, 1],
        y_range=[0, 10, 1],
        x_length=6.5,
        y_length=4.2,
        tips=False,
        axis_config={"color": GREY_B},
    )
    points = [
        (2.0, 7.0, 1),
        (3.0, 8.0, 1),
        (2.8, 6.5, 1),
        (7.2, 2.7, 0),
        (8.1, 3.2, 0),
        (6.9, 2.3, 0),
    ]
    dots = makeDataset2D(points, axes)
    # Clear separation for this synthetic dataset: classes split mostly by x-position.
    boundary = DashedLine(axes.c2p(5.2, 0.5), axes.c2p(5.2, 9.5), color=YELLOW)
    group = VGroup(axes, dots, boundary)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(axes), FadeIn(dots), run_time=run_time * 0.45)
    scene.play(Create(boundary), run_time=run_time * 0.55)
    return group


def showLogisticCurve(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 1.8,
) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    axes = Axes(
        x_range=[-6, 6, 2],
        y_range=[0, 1.2, 0.2],
        x_length=6.6,
        y_length=3.8,
        tips=False,
        axis_config={"color": GREY_B},
    )
    curve = axes.plot(lambda x: 1 / (1 + np.exp(-x)), x_range=[-6, 6], color=ML_POS)
    threshold = DashedLine(axes.c2p(-6, 0.5), axes.c2p(6, 0.5), color=YELLOW)
    group = VGroup(axes, curve, threshold)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(curve), run_time=run_time * 0.7)
    scene.play(Create(threshold), run_time=run_time * 0.3)
    return group
