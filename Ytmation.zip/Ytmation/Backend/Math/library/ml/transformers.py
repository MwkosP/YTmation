"""Transformer block visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def makeTransformerBlock() -> VGroup:
    sa = RoundedRectangle(width=3.0, height=0.8, corner_radius=0.1, color=BLUE_B).set_fill(BLUE_E, opacity=0.25)
    ff = RoundedRectangle(width=3.0, height=0.8, corner_radius=0.1, color=GREEN_B).set_fill(GREEN_E, opacity=0.25)
    t1 = Text("Multi-Head Attention", font_size=20).move_to(sa.get_center())
    t2 = Text("Feed Forward", font_size=20).move_to(ff.get_center())
    return VGroup(VGroup(sa, t1), VGroup(ff, t2)).arrange(DOWN, buff=0.3)


def showTransformerBlock(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    block = makeTransformerBlock()
    placeInRegion(block, "main", layout=layout, fit=True)
    scene.play(FadeIn(block), run_time=run_time)
    return block


def showResidualConnection(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    block = makeTransformerBlock()
    res = Arrow(block.get_left() + LEFT * 1.2, block.get_right() + RIGHT * 1.2, color=YELLOW, buff=0.1)
    label = Text("Residual", font_size=22, color=YELLOW).next_to(res, UP, buff=0.15)
    g = VGroup(block, res, label)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(block), GrowArrow(res), Write(label), run_time=run_time)
    return g
