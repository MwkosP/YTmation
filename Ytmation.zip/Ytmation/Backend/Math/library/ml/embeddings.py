"""Embedding visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showTokenEmbeddings(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    tokens = VGroup(
        Text("cat", font_size=30),
        Text("dog", font_size=30),
        Text("car", font_size=30),
    ).arrange(DOWN, buff=0.25)
    vectors = VGroup(
        Text("[0.12, -0.41, ...]", font_size=20, color=YELLOW),
        Text("[0.09, -0.37, ...]", font_size=20, color=YELLOW),
        Text("[-0.55, 0.21, ...]", font_size=20, color=YELLOW),
    ).arrange(DOWN, buff=0.25)
    placeInRegion(tokens, "left", layout=layout, fit=True)
    placeInRegion(vectors, "right", layout=layout, fit=True)
    scene.play(FadeIn(tokens), FadeIn(vectors), run_time=run_time)
    return VGroup(tokens, vectors)
