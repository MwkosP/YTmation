"""Shared ML helpers and constants."""

from manim import *
import numpy as np

ML_POS = "#4CAF50"
ML_NEG = "#FF5252"
ML_NEUTRAL = "#42A5F5"
ML_ACCENT = "#FFD54F"


def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + np.exp(-x))


def mse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean((y_true - y_pred) ** 2))


def accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(y_true == y_pred))


def makeDataset2D(
    points: list[tuple[float, float, int]],
    axes: Axes,
    pos_color: str = ML_POS,
    neg_color: str = ML_NEG,
    radius: float = 0.08,
) -> VGroup:
    dots = VGroup()
    for x, y, cls in points:
        dots.add(Dot(axes.c2p(x, y), radius=radius, color=pos_color if cls else neg_color))
    return dots


def makeStepList(lines: list[str], font_size: int = 24, color=WHITE) -> VGroup:
    return VGroup(*[Text(t, font_size=font_size, color=color) for t in lines]).arrange(
        DOWN, aligned_edge=LEFT, buff=0.24
    )
