"""Backpropagation visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.ml.nn_core import makeMLP


def showBackpropStep(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("hero")
    mlp = makeMLP([3, 4, 2])
    placeInRegion(mlp, "main", layout=layout, fit=True)
    grad_label = Text("Gradients flow backward", font_size=26, color=YELLOW)
    placeInRegion(grad_label, "caption", layout=layout, fit=True)
    scene.play(Create(mlp[0]), FadeIn(mlp[1]), run_time=run_time * 0.45)
    scene.play(mlp[0].animate.set_color(ORANGE), run_time=run_time * 0.25)
    scene.play(mlp[0].animate.set_color(PURPLE_B), FadeIn(grad_label), run_time=run_time * 0.3)
    return VGroup(mlp, grad_label)


def showWeightUpdate(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = Text("w := w - lr * grad", font_size=30, color=YELLOW)
    right = Text("Loss decreases", font_size=30, color=GREEN)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)
