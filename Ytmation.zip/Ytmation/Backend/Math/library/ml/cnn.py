"""CNN visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showConvolutionKernel(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("split")
    img = VGroup(*[Square(0.35, color=GREY_B).set_fill(GREY_E, opacity=0.2) for _ in range(25)]).arrange_in_grid(5, 5, buff=0.02)
    ker = VGroup(*[Square(0.35, color=YELLOW).set_fill(YELLOW_E, opacity=0.25) for _ in range(9)]).arrange_in_grid(3, 3, buff=0.02)
    fmap = VGroup(*[Square(0.35, color=BLUE_B).set_fill(BLUE_E, opacity=0.25) for _ in range(9)]).arrange_in_grid(3, 3, buff=0.02)
    left = VGroup(Text("Image", font_size=24), img).arrange(DOWN, buff=0.2)
    right = VGroup(Text("Feature map", font_size=24, color=BLUE_B), fmap).arrange(DOWN, buff=0.2)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    ker.move_to(img[6].get_center())
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time * 0.45)
    scene.play(FadeIn(ker), ker.animate.shift(RIGHT * 0.75 + DOWN * 0.35), run_time=run_time * 0.35)
    scene.play(FadeOut(ker), run_time=run_time * 0.2)
    return VGroup(left, right)


def showPooling(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = VGroup(*[Square(0.35, color=BLUE_B).set_fill(BLUE_E, opacity=0.25) for _ in range(16)]).arrange_in_grid(4, 4, buff=0.02)
    right = VGroup(*[Square(0.45, color=GREEN).set_fill(GREEN_E, opacity=0.25) for _ in range(4)]).arrange_in_grid(2, 2, buff=0.05)
    l = VGroup(Text("Feature map", font_size=24), left).arrange(DOWN, buff=0.2)
    r = VGroup(Text("Max pool", font_size=24, color=GREEN), right).arrange(DOWN, buff=0.2)
    placeInRegion(l, "left", layout=layout, fit=True)
    placeInRegion(r, "right", layout=layout, fit=True)
    scene.play(FadeIn(l), FadeIn(r), run_time=run_time)
    return VGroup(l, r)
