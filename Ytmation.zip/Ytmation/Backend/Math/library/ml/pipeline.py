"""Data pipeline visuals (split, scaling, CV)."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showTrainValTestSplit(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    train = Rectangle(width=3.8, height=0.8, color=GREEN).set_fill(GREEN_E, opacity=0.25)
    val = Rectangle(width=1.6, height=0.8, color=YELLOW).set_fill(YELLOW_E, opacity=0.25)
    test = Rectangle(width=1.6, height=0.8, color=BLUE).set_fill(BLUE_E, opacity=0.25)
    bar = VGroup(train, val, test).arrange(RIGHT, buff=0.06)
    labels = VGroup(
        Text("Train 70%", font_size=22, color=GREEN),
        Text("Val 15%", font_size=22, color=YELLOW),
        Text("Test 15%", font_size=22, color=BLUE),
    ).arrange(RIGHT, buff=0.35).next_to(bar, DOWN, buff=0.3)
    g = VGroup(bar, labels)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(bar), Write(labels), run_time=run_time)
    return g


def showCrossValidation(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    folds = VGroup(*[Rectangle(width=1.0, height=0.8, color=GREY_B).set_fill(GREY_E, opacity=0.25) for _ in range(5)]).arrange(RIGHT, buff=0.1)
    txt = Text("k-fold cross validation", font_size=28, color=YELLOW).next_to(folds, DOWN, buff=0.35)
    g = VGroup(folds, txt)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(folds), Write(txt), run_time=run_time)
    return g
