"""LLM inference loop visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showNextTokenLoop(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    prompt = Text("Prompt: 'The sky is'", font_size=26)
    logits = Text("next-token probs -> ['blue', 'clear', ...]", font_size=22, color=YELLOW)
    out = Text("Generated: blue", font_size=28, color=GREEN)
    chain = VGroup(prompt, logits, out).arrange(DOWN, buff=0.28, aligned_edge=LEFT)
    placeInRegion(chain, "main", layout=layout, fit=True)
    scene.play(FadeIn(prompt), run_time=run_time * 0.35)
    scene.play(FadeIn(logits), run_time=run_time * 0.3)
    scene.play(FadeIn(out), run_time=run_time * 0.35)
    return chain


def showSamplingControls(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = Text("Temperature", font_size=28, color=BLUE_B)
    right = Text("Top-k / Top-p", font_size=28, color=YELLOW)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)
