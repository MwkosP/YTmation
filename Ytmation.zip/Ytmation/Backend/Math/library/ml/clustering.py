"""Clustering visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showKMeansIteration(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.2) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(
        x_range=[0, 10, 1],
        y_range=[0, 10, 1],
        x_length=6.6,
        y_length=4.2,
        tips=False,
        axis_config={"color": GREY_B},
    )
    pts = VGroup(
        *[Dot(axes.c2p(x, y), radius=0.07, color=WHITE) for x, y in [(2, 7), (2.8, 6.5), (3.4, 7.5), (7, 3), (7.7, 2.5), (8.2, 3.5)]]
    )
    c1 = Dot(axes.c2p(2.4, 7.2), radius=0.12, color=RED)
    c2 = Dot(axes.c2p(7.6, 3.0), radius=0.12, color=BLUE)
    c1_new = Dot(axes.c2p(2.9, 7.0), radius=0.12, color=RED)
    c2_new = Dot(axes.c2p(7.6, 3.0), radius=0.12, color=BLUE)
    g = VGroup(axes, pts, c1, c2)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), FadeIn(pts), run_time=run_time * 0.35)
    scene.play(FadeIn(c1), FadeIn(c2), run_time=run_time * 0.2)
    scene.play(Transform(c1, c1_new), Transform(c2, c2_new), run_time=run_time * 0.45)
    return g
