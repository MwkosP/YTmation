"""RNN visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showRnnUnrolled(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    cells = VGroup(*[RoundedRectangle(width=1.2, height=0.8, corner_radius=0.12, color=PURPLE_B).set_fill(PURPLE_E, opacity=0.25) for _ in range(4)]).arrange(RIGHT, buff=0.45)
    labels = VGroup(*[Text(f"t{i+1}", font_size=20) for i in range(4)])
    for i, l in enumerate(labels):
        l.next_to(cells[i], DOWN, buff=0.15)
    arrows = VGroup(*[Arrow(cells[i].get_right(), cells[i+1].get_left(), buff=0.05, color=YELLOW) for i in range(3)])
    g = VGroup(cells, labels, arrows)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(cells), Write(labels), run_time=run_time * 0.5)
    scene.play(LaggedStart(*[GrowArrow(a) for a in arrows], lag_ratio=0.2), run_time=run_time * 0.5)
    return g
