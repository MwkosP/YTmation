"""Gradient descent visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showGradientDescentPath(
    scene: Scene,
    layout: SceneLayout | None = None,
    run_time: float = 2.2,
) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    axes = Axes(
        x_range=[-4, 4, 1],
        y_range=[0, 12, 2],
        x_length=6.4,
        y_length=3.8,
        tips=False,
        axis_config={"color": GREY_B},
    )
    curve = axes.plot(lambda x: 0.8 * x * x + 0.7, x_range=[-4, 4], color=BLUE_B)
    points = [2.8, 1.7, 1.0, 0.5, 0.2]
    dots = VGroup(*[Dot(axes.c2p(x, 0.8 * x * x + 0.7), radius=0.07, color=YELLOW) for x in points])
    arrows = VGroup()
    for i in range(len(dots) - 1):
        arrows.add(Arrow(dots[i].get_center(), dots[i + 1].get_center(), buff=0.05, color=YELLOW, stroke_width=4))
    group = VGroup(axes, curve, dots, arrows)
    placeInRegion(group, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(curve), run_time=run_time * 0.35)
    scene.play(FadeIn(dots[0]), run_time=0.2)
    for i in range(len(arrows)):
        scene.play(GrowArrow(arrows[i]), FadeIn(dots[i + 1]), run_time=run_time * 0.65 / len(arrows))
    return group


def showLearningRateEffect(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = Text("Small LR: stable, slow", font_size=28, color=GREEN)
    right = Text("Large LR: fast, may overshoot", font_size=28, color=RED)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)
