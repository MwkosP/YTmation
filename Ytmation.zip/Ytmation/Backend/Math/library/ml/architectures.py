"""High-level architecture cards."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def makeArchitectureCard(name: str, color=BLUE_B) -> VGroup:
    card = RoundedRectangle(width=2.8, height=1.0, corner_radius=0.12, color=color).set_fill(color, opacity=0.2)
    txt = Text(name, font_size=24, color=color).move_to(card.get_center())
    return VGroup(card, txt)


def showArchitectureOverview(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    cards = VGroup(
        makeArchitectureCard("MLP", BLUE_B),
        makeArchitectureCard("CNN", GREEN_B),
        makeArchitectureCard("RNN", PURPLE_B),
        makeArchitectureCard("Transformer", ORANGE),
    ).arrange_in_grid(2, 2, buff=0.3)
    placeInRegion(cards, "main", layout=layout, fit=True)
    scene.play(LaggedStart(*[FadeIn(c, shift=UP * 0.1) for c in cards], lag_ratio=0.15), run_time=run_time)
    return cards
