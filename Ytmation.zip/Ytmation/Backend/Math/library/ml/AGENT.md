# ML Library — Agent Cookbook

## Where things live

| Layer | Path | Use for |
|------|------|---------|
| Shared layout | `Math/library/common/` | `SceneLayout`, titles, captions |
| ML domain | `Math/library/ml/` | make/show/demo ML blocks |
| Channel showcase | `Workflows/channels/mathmwk/mlShowcase.py` | Render + stitch catalog |

## API layers

| Prefix | Plays on scene? | Use when |
|------|-------------------|---------|
| `make*` | No | Build reusable diagrams |
| `show*` | Yes (one beat) | Compose inside scenes |
| `demo*` | Yes (mini lesson) | Showcase segments |

## Available v1 demos

- `demoDecisionBoundary`
- `demoLogistic`
- `demoRegression`
- `demoBiasVariance`
- `demoLoss`
- `demoCrossEntropy`
- `demoGradientDescent`
- `demoLearningRate`
- `demoConfusionMatrix`
- `demoNeuralNet`

## Classical ML demos (expanded)

- `demoKnn`
- `demoDecisionTree`
- `demoRandomForest`
- `demoKMeans`
- `demoSvm`
- `demoNaiveBayes`
- `demoPca`
- `demoTrainValTest`
- `demoCrossValidation`
- `demoPrecisionRecallF1`
- `demoRocAuc`

## Deep learning + modern ML demos

- `demoBackprop`
- `demoWeightUpdate`
- `demoCnnConv`
- `demoCnnPooling`
- `demoRnn`
- `demoEmbeddings`
- `demoAttentionMatrix`
- `demoSelfAttention`
- `demoTransformerBlock`
- `demoResidual`
- `demoArchitectureOverview`
- `demoLlmInference`
- `demoSampling`

## Quick usage

```python
from Math.library.common.styling import setupScene
from Math.library.ml.recipes import demoDecisionBoundary

setupScene(scene)
demoDecisionBoundary(scene)
```

## Render full catalog

```bash
python Workflows/channels/mathmwk/mlShowcase.py
```
