"""ML metrics visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showConfusionMatrix(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("sidebar")
    grid = VGroup(*[Square(0.9, stroke_color=WHITE, fill_opacity=0.15) for _ in range(4)]).arrange_in_grid(2, 2, buff=0.0)
    vals = VGroup(
        Text("42", font_size=28, color=GREEN),
        Text("6", font_size=28, color=RED),
        Text("5", font_size=28, color=RED),
        Text("47", font_size=28, color=GREEN),
    )
    for i, v in enumerate(vals):
        v.move_to(grid[i].get_center())
    matrix = VGroup(grid, vals)
    side = VGroup(
        Text("Accuracy", font_size=28, color=YELLOW),
        Text("Precision", font_size=28, color=YELLOW),
        Text("Recall", font_size=28, color=YELLOW),
    ).arrange(DOWN, aligned_edge=LEFT, buff=0.24)
    placeInRegion(matrix, "main", layout=layout, fit=True)
    placeInRegion(side, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)
    scene.play(FadeIn(matrix), Write(side), run_time=run_time)
    return VGroup(matrix, side)


def showPrecisionRecallF1(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    lines = VGroup(
        Text("Precision = TP / (TP + FP)", font_size=26, color=YELLOW),
        Text("Recall = TP / (TP + FN)", font_size=26, color=YELLOW),
        Text("F1 = harmonic mean of precision & recall", font_size=24, color=WHITE),
    ).arrange(DOWN, aligned_edge=LEFT, buff=0.24)
    placeInRegion(lines, "main", layout=layout, fit=True)
    scene.play(LaggedStart(*[FadeIn(l, shift=UP * 0.1) for l in lines], lag_ratio=0.2), run_time=run_time)
    return lines


def showRocAuc(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("split")
    axes1 = Axes(x_range=[0, 1, 0.2], y_range=[0, 1, 0.2], x_length=3.4, y_length=3.0, tips=False)
    roc = axes1.plot(lambda x: x ** 0.4, x_range=[0, 1], color=GREEN)
    auc = Text("ROC AUC ~ 0.86", font_size=22, color=GREEN)
    left = VGroup(Text("ROC", font_size=24), axes1, roc, auc).arrange(DOWN, buff=0.2)

    axes2 = Axes(x_range=[0, 1, 0.2], y_range=[0, 1, 0.2], x_length=3.4, y_length=3.0, tips=False)
    pr = axes2.plot(lambda x: 1 - 0.6 * x, x_range=[0, 1], color=BLUE_B)
    right = VGroup(Text("PR Curve", font_size=24), axes2, pr).arrange(DOWN, buff=0.2)

    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)
