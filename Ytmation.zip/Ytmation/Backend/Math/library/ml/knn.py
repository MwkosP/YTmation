"""k-NN visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.ml._core import makeDataset2D, ML_POS, ML_NEG, ML_ACCENT


def showKnnClassification(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(
        x_range=[0, 10, 1],
        y_range=[0, 10, 1],
        x_length=6.6,
        y_length=4.2,
        tips=False,
        axis_config={"color": GREY_B},
    )
    points = [
        (2.0, 8.0, 1), (2.7, 7.0, 1), (3.2, 8.2, 1),
        (7.0, 2.3, 0), (8.0, 2.9, 0), (7.2, 3.4, 0),
    ]
    dots = makeDataset2D(points, axes)
    query = Dot(axes.c2p(5.0, 5.0), radius=0.1, color=ML_ACCENT)
    neighbors = VGroup(
        DashedLine(query.get_center(), dots[1].get_center(), color=ML_ACCENT),
        DashedLine(query.get_center(), dots[4].get_center(), color=ML_ACCENT),
        DashedLine(query.get_center(), dots[5].get_center(), color=ML_ACCENT),
    )
    klabel = Text("k=3 vote -> class 0", font_size=24, color=YELLOW)
    group = VGroup(axes, dots, query, neighbors)
    placeInRegion(group, "main", layout=layout, fit=True)
    placeInRegion(klabel, "caption", layout=layout, fit=True)
    scene.play(Create(axes), FadeIn(dots), run_time=run_time * 0.4)
    scene.play(FadeIn(query), Create(neighbors), run_time=run_time * 0.4)
    scene.play(Write(klabel), run_time=run_time * 0.2)
    return VGroup(group, klabel)
