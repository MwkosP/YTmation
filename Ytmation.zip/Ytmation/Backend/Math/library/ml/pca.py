"""PCA / dimensionality-reduction visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showPcaProjection(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("split")
    left_axes = Axes(x_range=[0, 10, 2], y_range=[0, 10, 2], x_length=3.8, y_length=3.0, tips=False)
    right_axes = Axes(x_range=[0, 10, 2], y_range=[0, 2, 1], x_length=3.8, y_length=3.0, tips=False)
    pts = [(2, 3), (3, 4), (4, 5), (6, 7), (7, 8)]
    left_pts = VGroup(*[Dot(left_axes.c2p(x, y), radius=0.06, color=WHITE) for x, y in pts])
    right_pts = VGroup(*[Dot(right_axes.c2p((x + y) / 2, 1), radius=0.06, color=YELLOW) for x, y in pts])
    arrow = Arrow(ORIGIN, RIGHT * 1.2, color=YELLOW)
    left = VGroup(Text("2D", font_size=24), left_axes, left_pts).arrange(DOWN, buff=0.2)
    right = VGroup(Text("1D projection", font_size=24, color=YELLOW), right_axes, right_pts).arrange(DOWN, buff=0.2)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    arrow.move_to((left.get_right() + right.get_left()) / 2)
    scene.play(FadeIn(left), GrowArrow(arrow), FadeIn(right), run_time=run_time)
    return VGroup(left, arrow, right)
