"""Machine learning visuals and recipes."""

from Math.library.ml._core import sigmoid, mse, accuracy
from Math.library.ml.classification import showDecisionBoundary, showLogisticCurve
from Math.library.ml.regression import showBestFitLine, showUnderfitVsOverfit
from Math.library.ml.loss import showMSECurve, showCrossEntropyIntuition
from Math.library.ml.gradient_descent import showGradientDescentPath, showLearningRateEffect
from Math.library.ml.metrics import showConfusionMatrix, showPrecisionRecallF1, showRocAuc
from Math.library.ml.knn import showKnnClassification
from Math.library.ml.trees import showDecisionTreeSplit, showRandomForestIdea
from Math.library.ml.clustering import showKMeansIteration
from Math.library.ml.svm import showSvmMargin
from Math.library.ml.naive_bayes import showNaiveBayesIntuition
from Math.library.ml.pca import showPcaProjection
from Math.library.ml.pipeline import showTrainValTestSplit, showCrossValidation
from Math.library.ml.backprop import showBackpropStep, showWeightUpdate
from Math.library.ml.cnn import showConvolutionKernel, showPooling
from Math.library.ml.rnn import showRnnUnrolled
from Math.library.ml.embeddings import showTokenEmbeddings
from Math.library.ml.attention import showAttentionMatrix, showSelfAttentionFlow
from Math.library.ml.transformers import showTransformerBlock, showResidualConnection
from Math.library.ml.architectures import showArchitectureOverview
from Math.library.ml.llm_inference import showNextTokenLoop, showSamplingControls
from Math.library.ml.nn_core import (
    makeNeuron,
    makeDenseLayer,
    connectLayers,
    makeMLP,
    showForwardPass,
)
from Math.library.ml.recipes import (
    demoDecisionBoundary,
    demoLogistic,
    demoRegression,
    demoBiasVariance,
    demoLoss,
    demoCrossEntropy,
    demoGradientDescent,
    demoLearningRate,
    demoConfusionMatrix,
    demoNeuralNet,
    demoKnn,
    demoDecisionTree,
    demoRandomForest,
    demoKMeans,
    demoSvm,
    demoNaiveBayes,
    demoPca,
    demoTrainValTest,
    demoCrossValidation,
    demoPrecisionRecallF1,
    demoRocAuc,
    demoBackprop,
    demoWeightUpdate,
    demoCnnConv,
    demoCnnPooling,
    demoRnn,
    demoEmbeddings,
    demoAttentionMatrix,
    demoSelfAttention,
    demoTransformerBlock,
    demoResidual,
    demoArchitectureOverview,
    demoLlmInference,
    demoSampling,
)
from Math.library.ml import recipes as mlRecipes

__all__ = [
    "sigmoid",
    "mse",
    "accuracy",
    "showDecisionBoundary",
    "showLogisticCurve",
    "showBestFitLine",
    "showUnderfitVsOverfit",
    "showMSECurve",
    "showCrossEntropyIntuition",
    "showGradientDescentPath",
    "showLearningRateEffect",
    "showConfusionMatrix",
    "showPrecisionRecallF1",
    "showRocAuc",
    "showKnnClassification",
    "showDecisionTreeSplit",
    "showRandomForestIdea",
    "showKMeansIteration",
    "showSvmMargin",
    "showNaiveBayesIntuition",
    "showPcaProjection",
    "showTrainValTestSplit",
    "showCrossValidation",
    "showBackpropStep",
    "showWeightUpdate",
    "showConvolutionKernel",
    "showPooling",
    "showRnnUnrolled",
    "showTokenEmbeddings",
    "showAttentionMatrix",
    "showSelfAttentionFlow",
    "showTransformerBlock",
    "showResidualConnection",
    "showArchitectureOverview",
    "showNextTokenLoop",
    "showSamplingControls",
    "makeNeuron",
    "makeDenseLayer",
    "connectLayers",
    "makeMLP",
    "showForwardPass",
    "demoDecisionBoundary",
    "demoLogistic",
    "demoRegression",
    "demoBiasVariance",
    "demoLoss",
    "demoCrossEntropy",
    "demoGradientDescent",
    "demoLearningRate",
    "demoConfusionMatrix",
    "demoNeuralNet",
    "demoKnn",
    "demoDecisionTree",
    "demoRandomForest",
    "demoKMeans",
    "demoSvm",
    "demoNaiveBayes",
    "demoPca",
    "demoTrainValTest",
    "demoCrossValidation",
    "demoPrecisionRecallF1",
    "demoRocAuc",
    "demoBackprop",
    "demoWeightUpdate",
    "demoCnnConv",
    "demoCnnPooling",
    "demoRnn",
    "demoEmbeddings",
    "demoAttentionMatrix",
    "demoSelfAttention",
    "demoTransformerBlock",
    "demoResidual",
    "demoArchitectureOverview",
    "demoLlmInference",
    "demoSampling",
    "mlRecipes",
]
