"""Naive Bayes intuition visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showNaiveBayesIntuition(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    text = VGroup(
        Text("P(Spam | words)", font_size=34, color=YELLOW),
        Text("~ P(word1|spam) * P(word2|spam) * ...", font_size=24, color=WHITE),
        Text("Assumes features are independent", font_size=24, color=GREY_B),
    ).arrange(DOWN, aligned_edge=LEFT, buff=0.28)
    placeInRegion(text, "main", layout=layout, fit=True)
    scene.play(LaggedStart(*[FadeIn(t, shift=UP * 0.1) for t in text], lag_ratio=0.2), run_time=run_time)
    return text
