"""Decision tree and random forest visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showDecisionTreeSplit(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    root = RoundedRectangle(width=2.2, height=0.7, corner_radius=0.1, color=YELLOW).set_fill(YELLOW_E, opacity=0.3)
    root_t = Text("x1 < 5 ?", font_size=22).move_to(root.get_center())
    left = RoundedRectangle(width=2.4, height=0.7, corner_radius=0.1, color=BLUE).set_fill(BLUE_E, opacity=0.25)
    right = RoundedRectangle(width=2.4, height=0.7, corner_radius=0.1, color=GREEN).set_fill(GREEN_E, opacity=0.25)
    left_t = Text("Leaf: Class A", font_size=20).move_to(left.get_center())
    right_t = Text("Leaf: Class B", font_size=20).move_to(right.get_center())
    left.move_to(LEFT * 2.2 + DOWN * 1.6)
    right.move_to(RIGHT * 2.2 + DOWN * 1.6)
    root.move_to(UP * 1.0)
    e1 = Arrow(root.get_bottom(), left.get_top(), buff=0.08, color=WHITE)
    e2 = Arrow(root.get_bottom(), right.get_top(), buff=0.08, color=WHITE)
    g = VGroup(root, left, right, e1, e2, root_t, left_t, right_t)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(root), Write(root_t), run_time=run_time * 0.3)
    scene.play(GrowArrow(e1), GrowArrow(e2), FadeIn(left), FadeIn(right), run_time=run_time * 0.4)
    scene.play(Write(left_t), Write(right_t), run_time=run_time * 0.3)
    return g


def showRandomForestIdea(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    trees = VGroup(*[Text(f"Tree {i+1}", font_size=24, color=BLUE_B) for i in range(3)]).arrange(DOWN, buff=0.3)
    vote = Text("Majority Vote", font_size=28, color=YELLOW)
    placeInRegion(trees, "left", layout=layout, fit=True)
    placeInRegion(vote, "right", layout=layout, fit=True)
    scene.play(FadeIn(trees), FadeIn(vote), run_time=run_time)
    return VGroup(trees, vote)
