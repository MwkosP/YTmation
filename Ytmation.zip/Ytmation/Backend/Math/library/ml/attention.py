"""Attention visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion


def showAttentionMatrix(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("split")
    qkv = VGroup(
        Text("Q", font_size=36, color=BLUE_B),
        Text("K", font_size=36, color=GREEN_B),
        Text("V", font_size=36, color=ORANGE),
    ).arrange(DOWN, buff=0.3)
    mat = VGroup(*[Square(0.45, color=YELLOW).set_fill(YELLOW_E, opacity=0.18) for _ in range(16)]).arrange_in_grid(4, 4, buff=0.02)
    placeInRegion(qkv, "left", layout=layout, fit=True)
    placeInRegion(mat, "right", layout=layout, fit=True)
    scene.play(FadeIn(qkv), FadeIn(mat), run_time=run_time)
    return VGroup(qkv, mat)


def showSelfAttentionFlow(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("standard")
    tokens = VGroup(*[Text(t, font_size=26) for t in ["The", "cat", "sat"]]).arrange(RIGHT, buff=0.8)
    arrows = VGroup(
        CurvedArrow(tokens[1].get_top(), tokens[0].get_top(), angle=0.7, color=YELLOW),
        CurvedArrow(tokens[1].get_top(), tokens[2].get_top(), angle=-0.7, color=YELLOW),
    )
    g = VGroup(tokens, arrows)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(FadeIn(tokens), run_time=run_time * 0.4)
    scene.play(Create(arrows), run_time=run_time * 0.6)
    return g
