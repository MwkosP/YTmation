"""SVM visuals."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.ml._core import makeDataset2D


def showSvmMargin(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(
        x_range=[0, 10, 1],
        y_range=[0, 10, 1],
        x_length=6.6,
        y_length=4.2,
        tips=False,
        axis_config={"color": GREY_B},
    )
    points = [(2, 7.2, 1), (3, 8.0, 1), (2.8, 6.6, 1), (7.2, 2.8, 0), (8.0, 2.2, 0), (7.4, 3.6, 0)]
    dots = makeDataset2D(points, axes)
    boundary = axes.plot(lambda x: -1.0 * x + 9.7, x_range=[1.3, 8.5], color=YELLOW)
    m1 = axes.plot(lambda x: -1.0 * x + 10.7, x_range=[1.3, 8.5], color=GREY_B)
    m2 = axes.plot(lambda x: -1.0 * x + 8.7, x_range=[1.3, 8.5], color=GREY_B)
    g = VGroup(axes, dots, boundary, m1, m2)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), FadeIn(dots), run_time=run_time * 0.45)
    scene.play(Create(boundary), Create(m1), Create(m2), run_time=run_time * 0.55)
    return g
