"""Central limit: sample means histogram (simplified)."""

from manim import *
import numpy as np


def showSampleMeansBars(
    scene: Scene,
    n_samples: int = 40,
    sample_size: int = 10,
    run_time: float = 2.5,
) -> VGroup:
    rng = np.random.default_rng(42)
    means = [rng.uniform(0, 1, sample_size).mean() for _ in range(n_samples)]
    bars = VGroup()
    for i, m in enumerate(means[:12]):
        h = m * 3
        bar = Rectangle(width=0.35, height=h, color=BLUE, fill_opacity=0.8)
        bar.move_to(RIGHT * (i - 6) * 0.45 + DOWN * 2 + UP * h / 2)
        bars.add(bar)
    title = Text("Sample means (preview)", font_size=32, color=WHITE).to_edge(UP, buff=0.4)
    scene.play(Write(title), LaggedStart(*[GrowFromEdge(b, DOWN) for b in bars], lag_ratio=0.08), run_time=run_time)
    return VGroup(title, bars)
