"""Shared statistics helpers — pure math, no domain narrative."""

from __future__ import annotations

import numpy as np
from manim import DOWN, LEFT, VGroup, WHITE

from Math.library.math.graphs._core import makeMath


def mean(data: list[float] | np.ndarray) -> float:
    return float(np.mean(np.asarray(data, dtype=float)))


def median(data: list[float] | np.ndarray) -> float:
    return float(np.median(np.asarray(data, dtype=float)))


def mode(data: list[float] | np.ndarray) -> float:
    vals, counts = np.unique(np.asarray(data, dtype=float), return_counts=True)
    return float(vals[int(np.argmax(counts))])


def sampleStd(data: list[float] | np.ndarray) -> float:
    return float(np.std(np.asarray(data, dtype=float), ddof=1))


def rangeVal(data: list[float] | np.ndarray) -> float:
    arr = np.asarray(data, dtype=float)
    return float(np.max(arr) - np.min(arr))


def quartiles(data: list[float] | np.ndarray) -> tuple[float, float, float]:
    arr = np.asarray(data, dtype=float)
    q1, q2, q3 = np.percentile(arr, [25, 50, 75])
    return float(q1), float(q2), float(q3)


def fiveNumberSummary(data: list[float] | np.ndarray) -> tuple[float, float, float, float, float]:
    arr = np.asarray(data, dtype=float)
    q1, med, q3 = quartiles(arr)
    return float(np.min(arr)), q1, med, q3, float(np.max(arr))


def correlation(xs: list[float], ys: list[float]) -> float:
    x = np.asarray(xs, dtype=float)
    y = np.asarray(ys, dtype=float)
    if len(x) < 2:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


def makeStepList(steps: list[str], buff: float = 0.42, color=WHITE) -> VGroup:
    rows = VGroup(*[makeMath(s, color=color, scale=0.8) for s in steps])
    rows.arrange(DOWN, aligned_edge=LEFT, buff=buff)
    return rows
