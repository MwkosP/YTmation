"""Histograms and frequency displays."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.graphs._core import makeMath, getAxes


def showHistogram(
    scene: Scene,
    data: list[float] | None = None,
    bins: int = 5,
    run_time: float = 2.4,
) -> VGroup:
    data = data or [2, 3, 3, 4, 5, 5, 5, 6, 7, 8, 9, 9, 10]
    counts, edges = np.histogram(data, bins=bins)
    y_max = max(int(max(counts)), 1) + 1
    axes_g = makeLabeledAxes(
        x_range=(float(edges[0]), float(edges[-1]), 1),
        y_range=(0, y_max, 1),
        x_label="x",
        y_label="f",
    )
    axes = getAxes(axes_g)
    bars = VGroup()
    for i, c in enumerate(counts):
        left, right = edges[i], edges[i + 1]
        w = axes.c2p(right, 0)[0] - axes.c2p(left, 0)[0]
        h = axes.c2p(0, c)[1] - axes.c2p(0, 0)[1]
        bar = Rectangle(width=w * 0.92, height=h, color=BLUE, fill_opacity=0.55, stroke_width=1)
        bar.move_to(axes.c2p((left + right) / 2, 0), aligned_edge=DOWN)
        bars.add(bar)

    cap = makeMath(r"\text{Histogram}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(bars), run_time=run_time)
    return VGroup(axes_g, bars, cap)


def showFrequencyTable(
    scene: Scene,
    data: list[float] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    data = data or [1, 1, 2, 2, 2, 3, 4]
    vals, counts = np.unique(data, return_counts=True)
    cap = makeMath(r"\text{Frequency table}").to_edge(UP, buff=0.45)
    header = VGroup(
        Text("Value", font_size=28, color=GREY_B),
        Text("Count", font_size=28, color=GREY_B),
    ).arrange(RIGHT, buff=2.2)
    rows = VGroup()
    for v, c in zip(vals, counts):
        row = VGroup(
            Text(f"{v:.0f}", font_size=26),
            Text(str(int(c)), font_size=26, color="#FF4500"),
        ).arrange(RIGHT, buff=2.35)
        rows.add(row)
    rows.arrange(DOWN, aligned_edge=LEFT, buff=0.22)
    table = VGroup(header, rows).arrange(DOWN, buff=0.35).shift(DOWN * 0.2)

    scene.play(Write(cap), FadeIn(table), run_time=run_time)
    return VGroup(cap, table)
