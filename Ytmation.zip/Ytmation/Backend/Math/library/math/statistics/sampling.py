"""Sampling — random sample, central limit preview."""

from manim import *
import numpy as np

from Math.library.math.graphs._core import makeMath
from Math.library.math.statistics.central_limit import showSampleMeansBars


def showRandomSample(
    scene: Scene,
    population_size: int = 20,
    sample_size: int = 6,
    run_time: float = 2.4,
) -> VGroup:
    rng = np.random.default_rng(7)
    pop = rng.integers(1, 10, population_size)
    sample_idx = rng.choice(population_size, size=sample_size, replace=False)
    pop_dots = VGroup()
    for i, val in enumerate(pop):
        d = Square(side_length=0.35, color=GREY_B, fill_opacity=0.2)
        d.move_to(LEFT * 3.5 + RIGHT * (i % 10) * 0.38 + UP * (1 - i // 10) * 0.45)
        pop_dots.add(VGroup(d, Text(str(val), font_size=18)))
    sample_dots = VGroup(*[pop_dots[i].copy().set_color("#FF4500") for i in sample_idx])
    sample_dots.arrange_in_grid(rows=1, buff=0.4).to_edge(DOWN, buff=0.8)

    cap = makeMath(r"\text{Random sample}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), FadeIn(pop_dots, lag_ratio=0.03), run_time=run_time * 0.55)
    scene.play(TransformFromCopy(VGroup(*[pop_dots[i] for i in sample_idx]), sample_dots), run_time=run_time * 0.45)
    return VGroup(cap, pop_dots, sample_dots)


def showCentralLimitPreview(scene: Scene, run_time: float = 2.5) -> VGroup:
    """Reuse CLT bar animation."""
    return showSampleMeansBars(scene, run_time=run_time)
