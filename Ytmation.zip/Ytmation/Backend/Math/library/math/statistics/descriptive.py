"""Descriptive statistics — center, spread, five-number summary."""

from manim import *

from Math.library.math.graphs.axes import makeNumberLine
from Math.library.math.graphs._core import makeMath
from Math.library.math.statistics._core import (
    mean,
    median,
    mode,
    sampleStd,
    rangeVal,
    fiveNumberSummary,
    makeStepList,
)
from Math.library.math.statistics.nl_viz import (
    dataDotsAbove,
    makeNlForValues,
    pointOnNl,
    spanBetween,
    tickAt,
    niceStep,
)
from Math.library.common.layout import SceneLayout, placeInRegion


def showMeanMedian(
    scene: Scene,
    data: list[float] | None = None,
    run_time: float = 2.4,
    layout: SceneLayout | None = None,
) -> VGroup:
    data = data or [2, 3, 5, 5, 7, 8, 9]
    layout = layout or SceneLayout.sidebar()
    m, med = mean(data), median(data)
    nl = makeNlForValues(data)
    dots = dataDotsAbove(nl, data)
    mean_tick = tickAt(nl, m, height=0.5, color=BLUE)
    med_tick = tickAt(nl, med, height=0.62, color="#FF4500")

    diagram = VGroup(nl, dots, mean_tick, med_tick)
    placeInRegion(diagram, "main", layout=layout, fit=True)

    labels = makeStepList([
        rf"\bar{{x}} = {m:.2f}",
        rf"\text{{median}} = {med:.2f}",
    ])
    placeInRegion(labels, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

    scene.play(Create(nl), FadeIn(dots), run_time=run_time * 0.5)
    scene.play(Create(mean_tick), Create(med_tick), FadeIn(labels), run_time=run_time * 0.5)
    return VGroup(diagram, labels)


def showMode(
    scene: Scene,
    data: list[float] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    data = data or [1, 2, 2, 2, 3, 4, 5]
    m = mode(data)
    nl = makeNlForValues(data)
    dots = dataDotsAbove(nl, data)
    hi_dot = Dot(pointOnNl(nl, m, 0.42), color="#FF4500", radius=0.1)
    cap = makeMath(r"\text{Mode}").to_edge(UP, buff=0.45)
    lbl = makeMath(rf"\text{{mode}} = {m:.0f}").to_edge(DOWN, buff=0.4)

    scene.play(Write(cap), Create(nl), FadeIn(dots), run_time=run_time * 0.55)
    scene.play(FadeIn(hi_dot), Write(lbl), run_time=run_time * 0.45)
    return VGroup(nl, dots, hi_dot, cap, lbl)


def showStandardDeviation(
    scene: Scene,
    data: list[float] | None = None,
    run_time: float = 2.6,
    layout: SceneLayout | None = None,
) -> VGroup:
    """Mean tick, μ±s band above the axis, and deviation segments to data."""
    data = data or [4, 6, 8, 10, 12]
    layout = layout or SceneLayout.sidebar()
    m, s = mean(data), sampleStd(data)
    display_s = s if s > 1e-9 else 0.5

    lo = min(min(data), m - 2.2 * display_s)
    hi = max(max(data), m + 2.2 * display_s)
    pad = max((hi - lo) * 0.08, 0.4)
    nl = makeNumberLine(lo - pad, hi + pad, niceStep(hi - lo + 2 * pad), length=9)

    dot_h = 0.48
    dots = VGroup(*[Dot(pointOnNl(nl, x, dot_h), color=YELLOW, radius=0.07) for x in data])
    dev_lines = VGroup(
        *[
            DashedLine(pointOnNl(nl, m, 0.06), pointOnNl(nl, x, dot_h), color=GREY_B, stroke_width=1.8)
            for x in data
        ]
    )

    mean_tick = tickAt(nl, m, height=0.55, color=BLUE, dashed=False)
    sigma_band = spanBetween(nl, m - display_s, m + display_s, y_offset=0.3, color=BLUE, stroke_width=6)
    left_tick = tickAt(nl, m - display_s, height=0.3, color=BLUE)
    right_tick = tickAt(nl, m + display_s, height=0.3, color=BLUE)
    band_lbl = makeMath(r"\mu \pm s", color=BLUE, scale=0.75).next_to(sigma_band, UP, buff=0.12)

    diagram = VGroup(nl, dots, dev_lines, mean_tick, sigma_band, left_tick, right_tick, band_lbl)
    placeInRegion(diagram, "main", layout=layout, fit=True)

    steps = makeStepList([
        rf"\bar{{x}} = {m:.2f}",
        rf"s = {s:.2f}",
    ])
    placeInRegion(steps, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)

    scene.play(Create(nl), run_time=run_time * 0.2)
    scene.play(Create(mean_tick), Create(sigma_band), Create(left_tick), Create(right_tick), run_time=run_time * 0.25)
    scene.play(FadeIn(dev_lines), FadeIn(dots), Write(band_lbl), run_time=run_time * 0.3)
    scene.play(FadeIn(steps), run_time=run_time * 0.25)
    return VGroup(diagram, steps)


def showRangeAndIQR(
    scene: Scene,
    data: list[float] | None = None,
    run_time: float = 2.4,
) -> VGroup:
    data = data or [3, 5, 7, 8, 9, 11, 14, 18]
    mn, q1, med, q3, mx = fiveNumberSummary(data)
    rng = rangeVal(data)
    iqr = q3 - q1
    nl = makeNlForValues(data)

    range_span = spanBetween(nl, mn, mx, y_offset=0.26, color=BLUE, stroke_width=5)
    iqr_span = spanBetween(nl, q1, q3, y_offset=0.44, color="#FF4500", stroke_width=6)
    end_ticks = VGroup(
        tickAt(nl, mn, height=0.22, color=BLUE, dashed=False),
        tickAt(nl, mx, height=0.22, color=BLUE, dashed=False),
        tickAt(nl, q1, height=0.4, color="#FF4500", dashed=False),
        tickAt(nl, q3, height=0.4, color="#FF4500", dashed=False),
    )

    cap = makeMath(r"\text{Range and IQR}").to_edge(UP, buff=0.45)
    steps = makeStepList([
        rf"\text{{range}} = {rng:.1f}",
        rf"\text{{IQR}} = Q_3 - Q_1 = {iqr:.1f}",
    ]).to_edge(RIGHT, buff=0.55)

    scene.play(Write(cap), Create(nl), Create(range_span), FadeIn(end_ticks[:2]), run_time=run_time * 0.45)
    scene.play(Create(iqr_span), FadeIn(end_ticks[2:]), FadeIn(steps), run_time=run_time * 0.55)
    return VGroup(nl, range_span, iqr_span, end_ticks, cap, steps)
