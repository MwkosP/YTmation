"""Statistical charts — box plot, pie chart, dot plot."""

from manim import *
import numpy as np

from Math.library.math.graphs._core import makeMath
from Math.library.math.statistics._core import fiveNumberSummary
from Math.library.math.statistics.nl_viz import makeNlForValues, pointOnNl, tickAt


def showDotPlot(
    scene: Scene,
    data: list[float] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    data = data or [2, 3, 3, 4, 5, 5, 6, 7]
    nl = makeNlForValues(data)
    stacks: dict[float, int] = {}
    dots = VGroup()
    for x in data:
        stacks[x] = stacks.get(x, 0) + 1
        y_off = 0.1 + 0.12 * stacks[x]
        dots.add(Dot(pointOnNl(nl, x, y_off), color=YELLOW, radius=0.06))

    cap = makeMath(r"\text{Dot plot}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(nl), FadeIn(dots, lag_ratio=0.05), run_time=run_time)
    return VGroup(nl, dots, cap)


def showBoxPlot(
    scene: Scene,
    data: list[float] | None = None,
    run_time: float = 2.5,
) -> VGroup:
    data = data or [4, 7, 8, 9, 10, 12, 14, 18, 22]
    mn, q1, med, q3, mx = fiveNumberSummary(data)
    nl = makeNlForValues(data)
    y_off = 0.32
    axis = Line(pointOnNl(nl, mn, y_off), pointOnNl(nl, mx, y_off), color=WHITE, stroke_width=2)
    whisker_l = Line(pointOnNl(nl, mn, y_off), pointOnNl(nl, q1, y_off), color=GREY_B, stroke_width=2)
    whisker_r = Line(pointOnNl(nl, q3, y_off), pointOnNl(nl, mx, y_off), color=GREY_B, stroke_width=2)
    box = Rectangle(
        width=pointOnNl(nl, q3, y_off)[0] - pointOnNl(nl, q1, y_off)[0],
        height=0.38,
        color=BLUE,
        fill_opacity=0.35,
    ).move_to(
        [
            (pointOnNl(nl, q1, y_off)[0] + pointOnNl(nl, q3, y_off)[0]) / 2,
            pointOnNl(nl, med, y_off)[1],
            0,
        ]
    )
    med_line = Line(
        pointOnNl(nl, med, y_off - 0.2),
        pointOnNl(nl, med, y_off + 0.2),
        color="#FF4500",
        stroke_width=4,
    )
    end_ticks = VGroup(
        tickAt(nl, mn, height=y_off, color=GREY_B, dashed=False),
        tickAt(nl, mx, height=y_off, color=GREY_B, dashed=False),
    )

    cap = makeMath(r"\text{Box plot}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(nl), Create(axis), FadeIn(end_ticks), run_time=run_time * 0.35)
    scene.play(Create(whisker_l), Create(whisker_r), FadeIn(box), Create(med_line), run_time=run_time * 0.65)
    return VGroup(nl, axis, whisker_l, whisker_r, box, med_line, end_ticks, cap)


def showPieChart(
    scene: Scene,
    values: list[float] | None = None,
    labels: list[str] | None = None,
    run_time: float = 2.4,
) -> VGroup:
    values = values or [30, 25, 20, 25]
    labels = labels or ["A", "B", "C", "D"]
    total = sum(values)
    colors = [BLUE, "#FF4500", GREEN, YELLOW]
    sectors = VGroup()
    start = 0.0
    for v, lab, col in zip(values, labels, colors):
        angle = (v / total) * TAU
        pct = int(round(100 * v / total))
        sec = Sector(outer_radius=2.2, angle=angle, start_angle=start, color=col, fill_opacity=0.75)
        mid = start + angle / 2
        lbl = Text(f"{lab}\n{pct}%", font_size=22).move_to(1.1 * np.array([np.cos(mid), np.sin(mid), 0]))
        sectors.add(VGroup(sec, lbl))
        start += angle

    cap = makeMath(r"\text{Pie chart}").to_edge(UP, buff=0.45)
    sectors.shift(LEFT * 1.5)
    scene.play(Write(cap), FadeIn(sectors, lag_ratio=0.08), run_time=run_time)
    return VGroup(cap, sectors)
