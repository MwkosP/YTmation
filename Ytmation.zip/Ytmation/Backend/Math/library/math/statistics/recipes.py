"""Statistics demos — one topic per call."""

from manim import *

from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.statistics.descriptive import (
    showMeanMedian,
    showMode,
    showStandardDeviation,
    showRangeAndIQR,
)
from Math.library.math.statistics.histogram import showHistogram, showFrequencyTable
from Math.library.math.statistics.charts import showDotPlot, showBoxPlot, showPieChart
from Math.library.math.statistics.normal_dist import showNormalDistribution, showZScore
from Math.library.math.statistics.distributions import (
    showEmpiricalRule,
    showBinomialDistribution,
    showUniformDistribution,
)
from Math.library.math.statistics.correlation import showCorrelationScatter, showRegressionLine
from Math.library.math.statistics.probability import showComplementProbability, showTwoWayTable
from Math.library.math.statistics.inference import showConfidenceInterval, showMarginOfError
from Math.library.math.statistics.sampling import showRandomSample, showCentralLimitPreview


def demoMeanMedian(scene: Scene, title: str = "Mean & Median") -> None:
    setupScene(scene)
    layout = SceneLayout.sidebar()
    scene.play(Write(makeTitle(title, size=40, layout=layout)))
    showMeanMedian(scene, layout=layout)


def demoMode(scene: Scene, title: str = "Mode") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showMode(scene)


def demoStandardDeviation(scene: Scene, title: str = "Standard Deviation") -> None:
    setupScene(scene)
    layout = SceneLayout.sidebar()
    scene.play(Write(makeTitle(title, size=34, layout=layout)))
    showStandardDeviation(scene, layout=layout)


def demoRangeAndIQR(scene: Scene, title: str = "Range & IQR") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showRangeAndIQR(scene)


def demoDotPlot(scene: Scene, title: str = "Dot Plot") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showDotPlot(scene)


def demoHistogram(scene: Scene, title: str = "Histogram") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showHistogram(scene)


def demoFrequencyTable(scene: Scene, title: str = "Frequency Table") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showFrequencyTable(scene)


def demoBoxPlot(scene: Scene, title: str = "Box Plot") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showBoxPlot(scene)


def demoPieChart(scene: Scene, title: str = "Pie Chart") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showPieChart(scene)


def demoNormalDistribution(scene: Scene, title: str = "Normal Distribution") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showNormalDistribution(scene)


def demoEmpiricalRule(scene: Scene, title: str = "Empirical Rule") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showEmpiricalRule(scene)


def demoZScore(scene: Scene, title: str = "Z-Score") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showZScore(scene)


def demoUniformDistribution(scene: Scene, title: str = "Uniform Distribution") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=32)))
    showUniformDistribution(scene)


def demoBinomialDistribution(scene: Scene, title: str = "Binomial Distribution") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=32)))
    showBinomialDistribution(scene)


def demoCorrelationScatter(scene: Scene, title: str = "Correlation") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showCorrelationScatter(scene)


def demoRegressionLine(scene: Scene, title: str = "Regression Line") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showRegressionLine(scene)


def demoComplementProbability(scene: Scene, title: str = "Complement") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showComplementProbability(scene)


def demoTwoWayTable(scene: Scene, title: str = "Two-Way Table") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showTwoWayTable(scene)


def demoConfidenceInterval(scene: Scene, title: str = "Confidence Interval") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=32)))
    showConfidenceInterval(scene)


def demoMarginOfError(scene: Scene, title: str = "Margin of Error") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showMarginOfError(scene)


def demoRandomSample(scene: Scene, title: str = "Random Sample") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showRandomSample(scene)


def demoCentralLimitPreview(scene: Scene, title: str = "Central Limit") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showCentralLimitPreview(scene)
