"""Statistics building blocks — descriptive, distributions, inference previews."""

from Math.library.math.statistics import recipes as statisticsRecipes
from Math.library.math.statistics.descriptive import (
    showMeanMedian,
    showMode,
    showStandardDeviation,
    showRangeAndIQR,
)
from Math.library.math.statistics.histogram import showHistogram, showFrequencyTable
from Math.library.math.statistics.charts import showDotPlot, showBoxPlot, showPieChart
from Math.library.math.statistics.normal_dist import showNormalDistribution, showZScore, normalPdf
from Math.library.math.statistics.distributions import (
    showEmpiricalRule,
    showBinomialDistribution,
    showUniformDistribution,
)
from Math.library.math.statistics.correlation import showCorrelationScatter, showRegressionLine
from Math.library.math.statistics.probability import showComplementProbability, showTwoWayTable
from Math.library.math.statistics.inference import showConfidenceInterval, showMarginOfError
from Math.library.math.statistics.sampling import showRandomSample, showCentralLimitPreview
from Math.library.math.statistics.central_limit import showSampleMeansBars

__all__ = [
    "statisticsRecipes",
    "showMeanMedian",
    "showMode",
    "showStandardDeviation",
    "showRangeAndIQR",
    "showHistogram",
    "showFrequencyTable",
    "showDotPlot",
    "showBoxPlot",
    "showPieChart",
    "showNormalDistribution",
    "showZScore",
    "normalPdf",
    "showEmpiricalRule",
    "showBinomialDistribution",
    "showUniformDistribution",
    "showCorrelationScatter",
    "showRegressionLine",
    "showComplementProbability",
    "showTwoWayTable",
    "showConfidenceInterval",
    "showMarginOfError",
    "showRandomSample",
    "showCentralLimitPreview",
    "showSampleMeansBars",
]
