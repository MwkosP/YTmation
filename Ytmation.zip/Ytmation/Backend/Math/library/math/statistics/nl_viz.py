"""Number-line layout helpers for statistics visuals."""

from __future__ import annotations

import numpy as np
from manim import BLUE, DashedLine, Dot, Line, NumberLine, UP, VGroup, YELLOW


def pointOnNl(nl: NumberLine, x: float, y_offset: float = 0.0) -> np.ndarray:
    return nl.number_to_point(x) + UP * y_offset


def tickAt(
    nl: NumberLine,
    x: float,
    height: float = 0.38,
    color=BLUE,
    dashed: bool = True,
) -> DashedLine | Line:
    base = pointOnNl(nl, x, 0)
    top = pointOnNl(nl, x, height)
    if dashed:
        return DashedLine(base, top, color=color, stroke_width=3)
    return Line(base, top, color=color, stroke_width=4)


def spanBetween(
    nl: NumberLine,
    a: float,
    b: float,
    y_offset: float = 0.28,
    color=BLUE,
    stroke_width: float = 5,
) -> Line:
    return Line(
        pointOnNl(nl, a, y_offset),
        pointOnNl(nl, b, y_offset),
        color=color,
        stroke_width=stroke_width,
    )


def niceStep(span: float, target_ticks: int = 8) -> float:
    if span <= 0:
        return 1.0
    raw = span / target_ticks
    mag = 10 ** np.floor(np.log10(raw))
    for m in (1, 2, 5, 10):
        step = m * mag
        if step >= raw:
            return float(step)
    return float(raw)


def makeNlForValues(
    values: list[float],
    pad_fraction: float = 0.12,
    length: float = 9,
    include_numbers: bool = True,
) -> NumberLine:
    lo, hi = float(min(values)), float(max(values))
    if hi == lo:
        lo, hi = lo - 1, hi + 1
    span = hi - lo
    pad = max(span * pad_fraction, 0.5)
    start, end = lo - pad, hi + pad
    step = niceStep(end - start)
    from Math.library.math.graphs.axes import makeNumberLine

    return makeNumberLine(start, end, step, length=length, include_numbers=include_numbers)


def dataDotsAbove(
    nl: NumberLine,
    data: list[float],
    base_offset: float = 0.42,
    color=YELLOW,
    radius: float = 0.07,
) -> VGroup:
    return VGroup(*[Dot(pointOnNl(nl, x, base_offset), color=color, radius=radius) for x in data])
