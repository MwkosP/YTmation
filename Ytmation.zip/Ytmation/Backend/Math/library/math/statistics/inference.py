"""Inference previews — confidence intervals, margin of error."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath, getAxes
from Math.library.math.statistics.normal_dist import normalPdf


def showConfidenceInterval(
    scene: Scene,
    mean: float = 50.0,
    margin: float = 4.0,
    run_time: float = 2.5,
) -> VGroup:
    lo, hi = mean - margin, mean + margin
    axes_g = makeLabeledAxes(x_range=(mean - 12, mean + 12, 2), y_range=(0, 0.12, 0.02), x_label="x", y_label="")
    axes = getAxes(axes_g)
    curve = plotOnAxes(axes_g, lambda x: normalPdf(x, mean, 3.0), x_range=(mean - 10, mean + 10), color=BLUE)
    band = axes.get_area(curve, x_range=(lo, hi), color=BLUE, opacity=0.35)
    center = DashedLine(axes.c2p(mean, 0), axes.c2p(mean, normalPdf(mean, mean, 3)), color=YELLOW)

    cap = makeMath(rf"\bar{{x}} \pm ME").to_edge(UP, buff=0.45)
    lbl = makeMath(rf"[{lo:.1f},\ {hi:.1f}]").scale(0.9).to_edge(DOWN, buff=0.4)
    scene.play(Write(cap), Create(axes_g), Create(curve), FadeIn(band), Create(center), Write(lbl), run_time=run_time)
    return VGroup(axes_g, curve, band, center, cap, lbl)


def showMarginOfError(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    formula = makeMath(r"ME = z^*\frac{s}{\sqrt{n}}").scale(1.05)
    example = makeMath(r"ME = 1.96 \cdot \frac{2.1}{\sqrt{100}} \approx 0.41", color="#FF4500").scale(0.9)
    example.next_to(formula, DOWN, buff=0.55)
    cap = makeMath(r"\text{Margin of error}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Write(formula), FadeIn(example), run_time=run_time)
    return VGroup(cap, formula, example)
