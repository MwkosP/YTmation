"""Probability distributions — empirical rule, binomial, uniform."""

from manim import *
import numpy as np
from math import comb

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath, getAxes
from Math.library.math.statistics.normal_dist import normalPdf


def showEmpiricalRule(
    scene: Scene,
    mean: float = 0.0,
    std: float = 1.0,
    run_time: float = 2.6,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-4, 4, 1), y_range=(0, 0.45, 0.1), x_label="x", y_label="")
    axes = getAxes(axes_g)
    curve = plotOnAxes(axes_g, lambda x: normalPdf(x, mean, std), x_range=(-3.5, 3.5), color=BLUE)
    bands = VGroup(
        axes.get_area(curve, x_range=(mean - std, mean + std), color=BLUE, opacity=0.35),
        axes.get_area(curve, x_range=(mean - 2 * std, mean + 2 * std), color=GREEN, opacity=0.2),
        axes.get_area(curve, x_range=(mean - 3 * std, mean + 3 * std), color=YELLOW, opacity=0.12),
    )
    cap = makeMath(r"68\%\ \ 95\%\ \ 99.7\%").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(curve), FadeIn(bands), run_time=run_time)
    return VGroup(axes_g, curve, bands, cap)


def showBinomialDistribution(
    scene: Scene,
    n: int = 8,
    p: float = 0.4,
    run_time: float = 2.5,
) -> VGroup:
    probs = [comb(n, k) * (p ** k) * ((1 - p) ** (n - k)) for k in range(n + 1)]
    y_max = max(probs) * 1.2
    axes_g = makeLabeledAxes(x_range=(-0.5, n + 0.5, 1), y_range=(0, y_max, y_max / 4), x_label="k", y_label="P")
    axes = getAxes(axes_g)
    bars = VGroup()
    for k, pr in enumerate(probs):
        w = 0.55
        h = axes.c2p(0, pr)[1] - axes.c2p(0, 0)[1]
        bar = Rectangle(width=w, height=h, color=BLUE, fill_opacity=0.6)
        bar.move_to(axes.c2p(k, 0), aligned_edge=DOWN)
        bars.add(bar)
    cap = makeMath(rf"B({n}, {p})").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(bars), run_time=run_time)
    return VGroup(axes_g, bars, cap)


def showUniformDistribution(
    scene: Scene,
    a: float = 2.0,
    b: float = 8.0,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(0, 10, 1), y_range=(0, 0.25, 0.05), x_label="x", y_label="f")
    axes = getAxes(axes_g)
    height = 1 / (b - a)
    x_left, x_right = axes.c2p(a, 0)[0], axes.c2p(b, 0)[0]
    y_bot, y_top = axes.c2p(0, 0)[1], axes.c2p(0, height)[1]
    rect = Rectangle(
        width=x_right - x_left,
        height=y_bot - y_top,
        color=BLUE,
        fill_opacity=0.5,
        stroke_width=1,
    ).move_to([(x_left + x_right) / 2, (y_bot + y_top) / 2, 0])
    cap = makeMath(rf"U({a},{b})").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), FadeIn(rect), run_time=run_time)
    return VGroup(axes_g, rect, cap)
