"""Correlation and regression — composes graphs scatter/trend."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs.points import makePoints
from Math.library.math.graphs._core import makeMath
from Math.library.math.statistics._core import correlation


def showCorrelationScatter(
    scene: Scene,
    run_time: float = 2.3,
) -> VGroup:
    coords = [(1, 1.1), (2, 2.0), (3, 2.8), (4, 4.1), (5, 4.9), (6, 6.2)]
    xs = [c[0] for c in coords]
    ys = [c[1] for c in coords]
    r = correlation(xs, ys)
    axes_g = makeLabeledAxes(x_range=(0, 7, 1), y_range=(0, 7, 1))
    dots = makePoints(axes_g, coords, color=YELLOW)
    cap = makeMath(rf"r \approx {r:.2f}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), FadeIn(dots), run_time=run_time)
    return VGroup(axes_g, dots, cap)


def showRegressionLine(
    scene: Scene,
    run_time: float = 2.4,
) -> VGroup:
    coords = [(1, 1.1), (2, 2.0), (3, 2.8), (4, 4.1), (5, 4.9)]
    xs = np.array([c[0] for c in coords])
    ys = np.array([c[1] for c in coords])
    m, b = np.polyfit(xs, ys, 1)
    axes_g = makeLabeledAxes(x_range=(0, 6, 1), y_range=(0, 6, 1))
    dots = makePoints(axes_g, coords, color=YELLOW)
    line = plotOnAxes(axes_g, lambda x: m * x + b, x_range=(0.5, 5.5), color="#FF4500")
    cap = makeMath(rf"\hat{{y}} = {m:.2f}x + {b:.2f}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), FadeIn(dots), Create(line), run_time=run_time)
    return VGroup(axes_g, dots, line, cap)
