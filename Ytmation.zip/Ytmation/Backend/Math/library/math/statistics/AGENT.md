# Statistics Library — Agent Cookbook

Intro statistics visuals: descriptive stats, charts, distributions, correlation, probability, sampling, inference previews.

## Module map

| File | Topics |
|------|--------|
| `_core.py` | mean, median, mode, std, quartiles, correlation helpers |
| `descriptive.py` | mean/median, mode, standard deviation, range & IQR |
| `histogram.py` | histogram, frequency table |
| `charts.py` | dot plot, box plot, pie chart |
| `normal_dist.py` | normal PDF curve, z-score |
| `distributions.py` | empirical rule, binomial, uniform |
| `correlation.py` | scatter + r, least-squares line |
| `probability.py` | complement, two-way table |
| `inference.py` | confidence interval, margin of error |
| `sampling.py` | random sample, CLT preview |
| `central_limit.py` | sample-means bar preview |
| `recipes.py` | `demo*` wrappers for showcases |

Reuses `math/graphs` for axes, number lines, scatter points, and plotting.

## API layers

| Prefix | Use when |
|--------|----------|
| `show…` | One beat (may `scene.play`) |
| `make…` | Mobjects only (see `_core` helpers) |
| `demo…` | Full fixed topic in `recipes.py` |

## Showcase

```bash
python Workflows/channels/mathmwk/statisticsShowcase.py
```

→ `Cache/stitched/mathmwk_statistics_showcase_<ts>.mp4`
