"""Normal distribution curve."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes


def normalPdf(x: float, mean: float = 0.0, std: float = 1.0) -> float:
    return (1 / (std * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((x - mean) / std) ** 2)


def showNormalDistribution(
    scene: Scene,
    mean: float = 0.0,
    std: float = 1.0,
    x_range: tuple = (-4, 4, 1),
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=(0, 0.5, 0.1), x_label="x", y_label="f(x)")
    f = lambda x: normalPdf(x, mean, std)
    graph = plotOnAxes(axes_g, f, x_range=(x_range[0], x_range[1]), color=BLUE)
    mean_line = DashedLine(
        axes_g[0].c2p(mean, 0),
        axes_g[0].c2p(mean, normalPdf(mean, mean, std)),
        color=YELLOW,
    )
    scene.play(Create(axes_g), Create(graph), Create(mean_line), run_time=run_time)
    return VGroup(axes_g, graph, mean_line)


def showZScore(
    scene: Scene,
    x: float = 1.5,
    mean: float = 0.0,
    std: float = 1.0,
    run_time: float = 2.3,
) -> VGroup:
    z = (x - mean) / std if std != 0 else 0.0
    axes_g = makeLabeledAxes(x_range=(-3, 3, 1), y_range=(0, 0.45, 0.1), x_label="x", y_label="")
    graph = plotOnAxes(axes_g, lambda t: normalPdf(t, mean, std), x_range=(-2.8, 2.8), color=BLUE)
    axes = axes_g[0]
    x_line = DashedLine(axes.c2p(x, 0), axes.c2p(x, normalPdf(x, mean, std)), color=YELLOW)
    cap = MathTex(r"z=\frac{x-\mu}{\sigma}", color=WHITE).scale(0.85).to_edge(UP, buff=0.45)
    val = MathTex(rf"z \approx {z:.2f}", color="#FF4500").scale(0.85).to_edge(DOWN, buff=0.4)
    scene.play(Write(cap), Create(axes_g), Create(graph), Create(x_line), Write(val), run_time=run_time)
    return VGroup(axes_g, graph, x_line, cap, val)
