"""Basic probability visuals."""

from manim import *

from Math.library.math.graphs._core import makeMath


def showComplementProbability(
    scene: Scene,
    p: float = 0.35,
    run_time: float = 2.2,
) -> VGroup:
    rect = Rectangle(width=6, height=1.2, color=WHITE)
    a = Rectangle(width=6 * p, height=1.2, color=BLUE, fill_opacity=0.6).align_to(rect, LEFT)
    b = Rectangle(width=6 * (1 - p), height=1.2, color="#FF4500", fill_opacity=0.35).align_to(rect, RIGHT)
    cap = makeMath(r"P(A^c) = 1 - P(A)").to_edge(UP, buff=0.45)
    labels = VGroup(
        makeMath(rf"P(A)={p:.2f}", color=BLUE).next_to(a, DOWN, buff=0.2),
        makeMath(rf"P(A^c)={1-p:.2f}", color="#FF4500").next_to(b, DOWN, buff=0.2),
    )
    scene.play(Write(cap), Create(rect), FadeIn(a), FadeIn(b), FadeIn(labels), run_time=run_time)
    return VGroup(rect, a, b, cap, labels)


def showTwoWayTable(
    scene: Scene,
    run_time: float = 2.3,
) -> VGroup:
    cap = makeMath(r"\text{Two-way table}").to_edge(UP, buff=0.45)
    header = VGroup(
        Text("", font_size=24),
        Text("Yes", font_size=24, color=GREY_B),
        Text("No", font_size=24, color=GREY_B),
    ).arrange(RIGHT, buff=1.1)
    rows = VGroup(
        VGroup(Text("A", font_size=24), Text("12", font_size=24), Text("8", font_size=24)).arrange(RIGHT, buff=1.15),
        VGroup(Text("B", font_size=24), Text("5", font_size=24), Text("15", font_size=24)).arrange(RIGHT, buff=1.15),
    ).arrange(DOWN, buff=0.25)
    table = VGroup(header, rows).arrange(DOWN, buff=0.3).shift(DOWN * 0.15)
    note = makeMath(r"P(A\mid \text{Yes})=\frac{12}{17}").scale(0.85).to_edge(DOWN, buff=0.45)
    scene.play(Write(cap), FadeIn(table), Write(note), run_time=run_time)
    return VGroup(cap, table, note)
