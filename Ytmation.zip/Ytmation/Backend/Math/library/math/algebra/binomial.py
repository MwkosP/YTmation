"""Binomial theorem and Pascal's triangle."""

from manim import *
import math

from Math.library.math.algebra._core import makeMath


def makePascalTriangle(rows: int = 6) -> VGroup:
    tri = VGroup()
    for n in range(rows):
        row = VGroup()
        for k in range(n + 1):
            val = math.comb(n, k)
            row.add(MathTex(str(val), font_size=28, color=WHITE))
        row.arrange(RIGHT, buff=0.45)
        tri.add(row)
    tri.arrange(DOWN, buff=0.35)
    return tri


def makeBinomialExpansion(
    n: int = 4,
    a: str = "a",
    b: str = "b",
) -> MathTex:
    parts = []
    for k in range(n + 1):
        coef = math.comb(n, k)
        parts.append(rf"{coef}{a}^{{{n-k}}}{b}^{{{k}}}")
    return makeMath(r"(" + a + r"+" + b + r")^{" + str(n) + r"}=" + "+".join(parts))


def showPascalTriangle(
    scene: Scene,
    rows: int = 6,
    run_time: float = 2.0,
) -> VGroup:
    tri = makePascalTriangle(rows)
    scene.play(*[FadeIn(row, shift=DOWN * 0.1) for row in tri], run_time=run_time)
    return tri


def showBinomialTheorem(
    scene: Scene,
    n: int = 4,
    run_time: float = 1.8,
) -> VGroup:
    tri = makePascalTriangle(n + 1).scale(0.85).shift(LEFT * 2.5)
    exp = makeBinomialExpansion(n).scale(0.75).shift(RIGHT * 2.2)
    scene.play(FadeIn(tri), Write(exp), run_time=run_time)
    return VGroup(tri, exp)
