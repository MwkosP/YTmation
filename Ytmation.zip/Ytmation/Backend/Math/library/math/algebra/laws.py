"""Area models for identities (distributive, square, difference of squares)."""

from manim import *


def makeAreaModelSquare(side: float = 2.0, color=BLUE, fill_opacity: float = 0.35) -> Square:
    return Square(side_length=side, color=color, fill_opacity=fill_opacity, stroke_width=2)


def makeAreaModelRectangle(width: float, height: float, color=GREEN, fill_opacity: float = 0.35) -> Rectangle:
    return Rectangle(width=width, height=height, color=color, fill_opacity=fill_opacity, stroke_width=2)


def makeSquareIdentityDiagram(a_len: float = 2.0, b_len: float = 1.2) -> VGroup:
    """Visual for (a+b)^2 = a^2 + 2ab + b^2."""
    big = a_len + b_len
    outline = Square(side_length=big, color=WHITE, stroke_width=2)
    a_sq = makeAreaModelSquare(a_len, color=BLUE).move_to(outline.get_corner(DL) + RIGHT * a_len / 2 + UP * a_len / 2)
    b_sq = makeAreaModelSquare(b_len, color="#FF4500").move_to(outline.get_corner(UR) + LEFT * b_len / 2 + DOWN * b_len / 2)
    ab1 = makeAreaModelRectangle(a_len, b_len, color=GREEN).move_to(
        outline.get_corner(DR) + LEFT * (a_len / 2 + b_len / 2) + UP * b_len / 2
    )
    ab2 = makeAreaModelRectangle(a_len, b_len, color=GREEN).move_to(
        outline.get_corner(UL) + RIGHT * (a_len / 2 + b_len / 2) + DOWN * a_len / 2
    )
    labels = VGroup(
        MathTex("a", color=BLUE).scale(0.7).next_to(a_sq, LEFT, buff=0.1),
        MathTex("b", color="#FF4500").scale(0.7).next_to(b_sq, RIGHT, buff=0.1),
    )
    return VGroup(outline, a_sq, b_sq, ab1, ab2, labels)


def makeDifferenceOfSquaresDiagram(side_a: float = 2.5, side_b: float = 1.0) -> VGroup:
    """a^2 - b^2 as L-shape / rectangles (schematic)."""
    outer = makeAreaModelSquare(side_a, color=BLUE)
    inner = makeAreaModelSquare(side_b, color="#FF4500").move_to(outer.get_corner(UR) + LEFT * side_b / 2 + DOWN * side_b / 2)
    return VGroup(outer, inner)


def showSquareIdentity(
    scene: Scene,
    a_len: float = 2.0,
    b_len: float = 1.2,
    run_time: float = 2.0,
) -> VGroup:
    diagram = makeSquareIdentityDiagram(a_len, b_len)
    formula = MathTex(r"(a+b)^2 = a^2 + 2ab + b^2", color=WHITE).scale(0.75).to_edge(UP, buff=0.45)
    scene.play(Write(formula), Create(diagram), run_time=run_time)
    return VGroup(diagram, formula)


def showDifferenceOfSquaresIdentity(
    scene: Scene,
    run_time: float = 1.8,
) -> VGroup:
    diagram = makeDifferenceOfSquaresDiagram()
    formula = MathTex(r"a^2 - b^2 = (a-b)(a+b)", color=WHITE).scale(0.8).to_edge(UP, buff=0.45)
    scene.play(Write(formula), FadeIn(diagram), run_time=run_time)
    return VGroup(diagram, formula)
