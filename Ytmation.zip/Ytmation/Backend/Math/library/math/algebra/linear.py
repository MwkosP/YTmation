"""Linear equations and graphs."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath, makeStepList, playStepReveal


def makeLinearGraph(
    slope: float = 1.0,
    intercept: float = 0.0,
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-4, 4, 1),
    color=BLUE,
) -> tuple[VGroup, VMobject]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    graph = plotOnAxes(axes_g, lambda x: slope * x + intercept, x_range=(x_range[0], x_range[1]), color=color)
    return axes_g, graph


def makeBalanceScale() -> VGroup:
    """Simple balance scale (mobjects only)."""
    base = Line(LEFT * 2, RIGHT * 2, color=GREY_B)
    fulcrum = Triangle(fill_opacity=1, color=GREY_B).scale(0.2).move_to(DOWN * 0.1)
    beam = Line(LEFT * 2.5, RIGHT * 2.5, color=WHITE).shift(UP * 0.5)
    left_pan = Circle(radius=0.35, color=BLUE, fill_opacity=0.2).move_to(beam.get_start() + DOWN * 0.6)
    right_pan = Circle(radius=0.35, color="#FF4500", fill_opacity=0.2).move_to(beam.get_end() + DOWN * 0.6)
    return VGroup(base, fulcrum, beam, left_pan, right_pan)


def makeLinearEquationTex(
    a: float = 2.0,
    b: float = 3.0,
    c: float = 7.0,
    var: str = "x",
) -> MathTex:
    sign = "+" if b >= 0 else "-"
    return MathTex(rf"{a}{var}{sign}{abs(b)}={c}", color=WHITE).scale(0.9)


def showBalanceEquation(
    scene: Scene,
    left_tex: str = r"2x+3",
    right_tex: str = r"7",
    run_time: float = 1.5,
) -> VGroup:
    scale = makeBalanceScale().scale(0.9).shift(DOWN * 0.5)
    left = makeMath(left_tex).next_to(scale[3], UP, buff=0.15)
    right = makeMath(right_tex).next_to(scale[4], UP, buff=0.15)
    scene.play(Create(scale), Write(left), Write(right), run_time=run_time)
    return VGroup(scale, left, right)


def showSolveLinear(
    scene: Scene,
    steps: list[str] | None = None,
    slope: float = 1.5,
    intercept: float = -1.0,
    run_time: float = 2.5,
) -> VGroup:
    steps = steps or [
        r"2x + 3 = 7",
        r"2x = 4",
        r"x = 2",
    ]
    axes_g, graph = makeLinearGraph(slope=slope, intercept=intercept)
    axes_g.shift(RIGHT * 2.8)
    step_col = makeStepList(steps).to_edge(LEFT, buff=0.6)
    scene.play(FadeIn(step_col[0]), Create(axes_g), Create(graph), run_time=run_time * 0.45)
    for i in range(1, len(step_col)):
        playStepReveal(scene, step_col, i, run_time=run_time * 0.2)
    root_x = -intercept / slope if abs(slope) > 1e-9 else 0
    axes = axes_g[0]
    dot = Dot(axes.c2p(root_x, slope * root_x + intercept), color=YELLOW)
    scene.play(FadeIn(dot), run_time=run_time * 0.15)
    return VGroup(step_col, axes_g, graph, dot)
