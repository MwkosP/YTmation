"""Polynomial roots on graphs and synthetic division steps."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import evalPolynomialAt, makeMath, makeStepList, playStepReveal
from Math.library.math.algebra.polynomial import evalPolynomial


def findRationalRoots(coeffs: list[float], max_k: int = 12) -> list[float]:
    """Simple rational root test for low-degree polys."""
    roots = []
    const = coeffs[0] if coeffs else 0
    lead = coeffs[-1] if coeffs else 1
    if abs(lead) < 1e-12:
        return roots
    candidates = set()
    for p in range(1, max_k + 1):
        if abs(const) < 1e-9 or abs(p) < 1e-9:
            continue
        if abs(const / p - round(const / p)) < 1e-6:
            candidates.add(const / p)
            candidates.add(-const / p)
    for q in range(1, max_k + 1):
        candidates.add(1.0 / q)
        candidates.add(-1.0 / q)
    for r in sorted(candidates):
        if abs(evalPolynomialAt(coeffs, r)) < 1e-4:
            roots.append(round(r, 4))
    return list(dict.fromkeys(roots))


def makeRootDots(axes: Axes, roots: list[float], y: float = 0.0, color=YELLOW) -> VGroup:
    return VGroup(*[Dot(axes.c2p(r, y), color=color, radius=0.09) for r in roots])


def makeFactoredLabel(factors: list[str]) -> MathTex:
    return makeMath("".join([rf"({f})" for f in factors]))


def showRootsOnGraph(
    scene: Scene,
    coeffs: list[float],
    x_range: tuple = (-4, 4, 1),
    y_range: tuple = (-5, 8, 2),
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, lambda x: evalPolynomial(coeffs, x), x_range=(x_range[0], x_range[1]))
    roots = findRationalRoots(coeffs)
    dots = makeRootDots(axes, roots)
    scene.play(Create(axes_g), Create(graph), run_time=run_time * 0.65)
    if len(dots) > 0:
        scene.play(FadeIn(dots), run_time=run_time * 0.35)
    return VGroup(axes_g, graph, dots)


def showSyntheticDivision(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.0,
) -> VGroup:
    steps = steps or [
        r"\text{Divide } x^3 - 6x^2 + 11x - 6 \text{ by } (x-1)",
        r"\text{Root } x=1",
        r"\text{Quotient } x^2 - 5x + 6",
        r"(x-2)(x-3)",
    ]
    rows = makeStepList(steps).scale(0.85)
    scene.play(FadeIn(rows[0]), run_time=run_time * 0.3)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.18)
    return rows
