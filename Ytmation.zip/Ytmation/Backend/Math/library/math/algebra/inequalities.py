"""Inequalities on number line and plane."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, makeNumberLine
from Math.library.math.algebra._core import makeMath


def makeIntervalShading(
    number_line: NumberLine,
    start: float,
    end: float,
    closed_start: bool = True,
    closed_end: bool = True,
    color=BLUE,
) -> VGroup:
    a = number_line.n2p(start)
    b = number_line.n2p(end)
    segment = Line(a, b, color=color, stroke_width=8)
    dots = VGroup()
    if closed_start:
        dots.add(Dot(a, color=color, radius=0.08))
    else:
        dots.add(Circle(radius=0.08, color=color).move_to(a))
    if closed_end:
        dots.add(Dot(b, color=color, radius=0.08))
    else:
        dots.add(Circle(radius=0.08, color=color).move_to(b))
    return VGroup(segment, dots)


def makeLinearInequalityBoundary(
    slope: float,
    intercept: float,
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-3, 3, 1),
    color=WHITE,
) -> tuple[VGroup, VMobject]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    line = axes.plot(lambda x: slope * x + intercept, x_range=[x_range[0], x_range[1]], color=color)
    return axes_g, line


def shadeHalfPlane(
    axes: Axes,
    slope: float,
    intercept: float,
    above: bool = True,
    color=BLUE,
    opacity: float = 0.25,
) -> Polygon:
    x0, x1 = axes.x_range[0], axes.x_range[1]
    y0, y1 = axes.y_range[0], axes.y_range[1]
    p1 = axes.c2p(x0, y1 if above else y0)
    p2 = axes.c2p(x1, y1 if above else y0)
    p3 = axes.c2p(x1, slope * x1 + intercept)
    p4 = axes.c2p(x0, slope * x0 + intercept)
    return Polygon(p1, p2, p3, p4, color=color, fill_opacity=opacity, stroke_width=0)


def showInequalityOnNumberLine(
    scene: Scene,
    tex: str = r"x > 2",
    start: float = 2.0,
    end: float = 5.0,
    run_time: float = 1.6,
) -> VGroup:
    nl = makeNumberLine(-1, 6, 1, length=9).shift(DOWN * 0.3)
    label = makeMath(tex).to_edge(UP, buff=0.5)
    shade = makeIntervalShading(nl, start, end, closed_start=False, closed_end=True)
    scene.play(Write(label), Create(nl), run_time=run_time * 0.5)
    scene.play(Create(shade), run_time=run_time * 0.5)
    return VGroup(nl, label, shade)


def showLinearInequality(
    scene: Scene,
    slope: float = 0.5,
    intercept: float = 0.0,
    above: bool = True,
    tex: str = r"y > x",
    run_time: float = 1.8,
) -> VGroup:
    axes_g, line = makeLinearInequalityBoundary(slope, intercept)
    region = shadeHalfPlane(axes_g[0], slope, intercept, above=above)
    label = makeMath(tex).to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(line), FadeIn(region), run_time=run_time)
    return VGroup(axes_g, line, region, label)
