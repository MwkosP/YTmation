"""
Algebra building blocks — composable primitives for workflows and other domains.

API layers:
  make*     → mobjects only (agent controls scene.play)
  show*     → one animation beat on scene
  demo*     → full recipe in algebra.recipes
"""

from Math.library.math.algebra._core import (
    evalPolynomialAt,
    coeffsFromRoots,
    quadraticRoots,
    makeMath,
    makeStepList,
)
from Math.library.math.algebra.expressions import (
    makeExpression,
    showCombineLikeTerms,
    showDistribute,
    showExpressionSteps,
)
from Math.library.math.algebra.linear import (
    makeLinearGraph,
    makeBalanceScale,
    showSolveLinear,
    showBalanceEquation,
)
from Math.library.math.algebra.quadratic import (
    makeQuadraticGraph,
    showQuadratic,
    showCompletingSquare,
    showVertexForm,
)
from Math.library.math.algebra.polynomial import (
    evalPolynomial,
    makePolynomialGraph,
    showPolynomial,
)
from Math.library.math.algebra.factoring import (
    showFactorTrinomial,
    showFactorDifferenceOfSquares,
)
from Math.library.math.algebra.systems import (
    makeSystemLines,
    showSystemIntersection,
)
from Math.library.math.algebra.functions import (
    makeFunctionMachine,
    makePiecewiseGraph,
)

# Full catalog: algebra.recipes.demo*
from Math.library.math.algebra import recipes as algebraRecipes

__all__ = [
    "evalPolynomialAt",
    "coeffsFromRoots",
    "quadraticRoots",
    "makeMath",
    "makeStepList",
    "makeExpression",
    "showCombineLikeTerms",
    "showDistribute",
    "showExpressionSteps",
    "makeLinearGraph",
    "makeBalanceScale",
    "showSolveLinear",
    "showBalanceEquation",
    "makeQuadraticGraph",
    "showQuadratic",
    "showCompletingSquare",
    "showVertexForm",
    "evalPolynomial",
    "makePolynomialGraph",
    "showPolynomial",
    "showFactorTrinomial",
    "showFactorDifferenceOfSquares",
    "makeSystemLines",
    "showSystemIntersection",
    "makeFunctionMachine",
    "makePiecewiseGraph",
    "algebraRecipes",
]
