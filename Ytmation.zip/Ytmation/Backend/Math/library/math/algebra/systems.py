"""Systems of linear equations."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.algebra._core import makeMath, makeStepList, playStepReveal


def makeSystemLines(
    slopes: tuple[float, float] = (1.0, -0.5),
    intercepts: tuple[float, float] = (0.0, 2.0),
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-2, 5, 1),
    colors: tuple = (BLUE, "#FF4500"),
) -> tuple[VGroup, VGroup]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    lines = VGroup()
    for m, b, c in zip(slopes, intercepts, colors):
        lines.add(axes.plot(lambda x, m=m, b=b: m * x + b, x_range=[x_range[0], x_range[1]], color=c))
    return axes_g, lines


def solve2x2(
    a1: float, b1: float, c1: float,
    a2: float, b2: float, c2: float,
) -> tuple[float, float] | None:
    det = a1 * b2 - a2 * b1
    if abs(det) < 1e-12:
        return None
    x = (c1 * b2 - c2 * b1) / det
    y = (a1 * c2 - a2 * c1) / det
    return x, y


def makeIntersectionDot(axes_g: VGroup, x: float, y: float, color=YELLOW) -> Dot:
    return Dot(axes_g[0].c2p(x, y), color=color, radius=0.1)


def showSystemIntersection(
    scene: Scene,
    slopes: tuple[float, float] = (1.0, -1.0),
    intercepts: tuple[float, float] = (0.0, 3.0),
    run_time: float = 2.0,
) -> VGroup:
    axes_g, lines = makeSystemLines(slopes, intercepts)
    m1, b1 = slopes[0], intercepts[0]
    m2, b2 = slopes[1], intercepts[1]
    sol = solve2x2(m1, -1, -b1, m2, -1, -b2)
    scene.play(Create(axes_g), Create(lines), run_time=run_time * 0.6)
    group = VGroup(axes_g, lines)
    if sol:
        dot = makeIntersectionDot(axes_g, sol[0], sol[1])
        coord = makeMath(rf"({sol[0]:.2f},\, {sol[1]:.2f})", color=YELLOW).next_to(dot, UR, buff=0.15)
        scene.play(FadeIn(dot), Write(coord), run_time=run_time * 0.4)
        group.add(dot, coord)
    return group


def showEliminationSteps(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    steps = steps or [
        r"x + y = 5",
        r"2x - y = 1",
        r"3x = 6",
        r"x = 2",
        r"y = 3",
    ]
    rows = makeStepList(steps).move_to(ORIGIN)
    scene.play(FadeIn(rows[0]), run_time=run_time * 0.25)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.15)
    return rows
