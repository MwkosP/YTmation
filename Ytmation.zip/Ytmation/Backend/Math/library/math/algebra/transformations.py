"""Graph transformations of parent functions."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath


def makeParentGraph(
    parent,
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-2, 6, 1),
    color=GREY_B,
) -> tuple[VGroup, VMobject]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    graph = plotOnAxes(axes_g, parent, x_range=(x_range[0], x_range[1]), color=color)
    return axes_g, graph


def makeTransformedGraph(
    axes_g: VGroup,
    transformed,
    x_range: tuple,
    color=BLUE,
) -> VMobject:
    return plotOnAxes(axes_g, transformed, x_range=x_range, color=color)


def showGraphTransformation(
    scene: Scene,
    parent_tex: str = r"y=x^2",
    child_tex: str = r"y=(x-2)^2+1",
    parent=None,
    child=None,
    run_time: float = 2.2,
) -> VGroup:
    parent = parent or (lambda x: x**2)
    child = child or (lambda x: (x - 2) ** 2 + 1)
    axes_g, g_parent = makeParentGraph(parent)
    g_child = makeTransformedGraph(axes_g, child, (-1, 4))
    labels = VGroup(makeMath(parent_tex, color=GREY_B), makeMath(child_tex, color=BLUE)).arrange(DOWN).to_edge(UP)
    scene.play(Create(axes_g), Create(g_parent), Write(labels[0]), run_time=run_time * 0.45)
    scene.play(Transform(g_parent.copy(), g_child), Write(labels[1]), run_time=run_time * 0.55)
    return VGroup(axes_g, g_parent, g_child, labels)
