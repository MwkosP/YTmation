"""
Algebra demos — fixed recipes for showcases and quick tests.

Prefer primitives in workflow scenes when combining multiple beats.
"""

from manim import *

from Math.library.common.layout import makeTitle, makeCaption
from Math.library.common.styling import setupScene
from Math.library.math.algebra.expressions import showCombineLikeTerms, showDistribute
from Math.library.math.algebra.laws import showSquareIdentity
from Math.library.math.algebra.linear import showSolveLinear, showBalanceEquation
from Math.library.math.algebra.systems import showSystemIntersection, showEliminationSteps
from Math.library.math.algebra.factoring import showFactorTrinomial, showFactorDifferenceOfSquares
from Math.library.math.algebra.quadratic import showQuadratic, showCompletingSquare, showVertexForm
from Math.library.math.algebra.polynomial import showPolynomial
from Math.library.math.algebra.functions import showFunctionMachine, showPiecewise
from Math.library.math.algebra.composition import showComposition
from Math.library.math.algebra.inverse import showInverseReflection
from Math.library.math.algebra.transformations import showGraphTransformation
from Math.library.math.algebra.exponential import showExponentialGrowth
from Math.library.math.algebra.logarithmic import showExpLogInverse
from Math.library.math.algebra.sequences import showArithmeticSequence, showGeometricSequence
from Math.library.math.algebra.binomial import showBinomialTheorem
from Math.library.math.algebra.complex import showComplexMultiply
from Math.library.math.algebra.conics import showParabola
from Math.library.math.algebra.inequalities import showInequalityOnNumberLine
from Math.library.math.algebra.absolute_value import showAbsoluteValue
from Math.library.math.algebra.rational import showRationalFunction
from Math.library.math.algebra.induction import showInduction
from Math.library.math.algebra.groups import showCayleyTable


def demoCombineLikeTerms(scene: Scene, title: str = "Like Terms") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showCombineLikeTerms(scene)


def demoDistribute(scene: Scene, title: str = "Distributive Law") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showDistribute(scene)


def demoSolveLinear(scene: Scene, title: str = "Linear Equation") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showSolveLinear(scene)


def demoBalanceEquation(scene: Scene, title: str = "Balance Method") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showBalanceEquation(scene)


def demoSystem(scene: Scene, title: str = "System of Equations") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showSystemIntersection(scene)
    scene.play(FadeIn(makeCaption("Intersection = solution")), run_time=0.5)


def demoElimination(scene: Scene, title: str = "Elimination") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showEliminationSteps(scene)


def demoFactorTrinomial(scene: Scene, title: str = "Factoring") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showFactorTrinomial(scene)


def demoFactorDots(scene: Scene, title: str = "Difference of Squares") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showFactorDifferenceOfSquares(scene)


def demoQuadratic(scene: Scene, title: str = "Quadratic") -> None:
    setupScene(scene)
    showQuadratic(scene, a=1, b=-1, c=-1)


def demoCompletingSquare(scene: Scene, title: str = "Completing the Square") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showCompletingSquare(scene)


def demoVertexForm(scene: Scene, title: str = "Vertex Form") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showVertexForm(scene, h=2, k=-1)


def demoPolynomial(scene: Scene, title: str = "Polynomial") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showPolynomial(scene, coeffs=[1, 0, -2, 0.5])


def demoFunctionMachine(scene: Scene, title: str = "Functions") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showFunctionMachine(scene)


def demoComposition(scene: Scene, title: str = "Composition") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showComposition(scene)


def demoGraphTransform(scene: Scene, title: str = "Transformations") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showGraphTransformation(scene)


def demoExponential(scene: Scene, title: str = "Exponential") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showExponentialGrowth(scene)


def demoExpLogInverse(scene: Scene, title: str = "Log ↔ Exp") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showExpLogInverse(scene)


def demoArithmeticSequence(scene: Scene, title: str = "Arithmetic Sequence") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showArithmeticSequence(scene)


def demoBinomialTheorem(scene: Scene, title: str = "Binomial Theorem") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showBinomialTheorem(scene)


def demoComplexMultiply(scene: Scene, title: str = "Complex Multiply") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showComplexMultiply(scene)


def demoSquareIdentity(scene: Scene, title: str = "Identity") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showSquareIdentity(scene)


def demoInduction(scene: Scene, title: str = "Induction") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showInduction(scene)


def demoCayleyTable(scene: Scene, title: str = "Group Table") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showCayleyTable(scene)
