"""Polynomial graphs and operations."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import evalPolynomialAt, makeMath, makeStepList, playStepReveal


def evalPolynomial(coeffs: list[float], x: float) -> float:
    """coeffs[i] is coefficient of x^i."""
    return evalPolynomialAt(coeffs, x)


def makePolynomialGraph(
    coeffs: list[float],
    x_range: tuple = (-2, 2, 1),
    y_range: tuple = (-5, 5, 1),
    color=BLUE,
) -> tuple[VGroup, VMobject]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    graph = plotOnAxes(
        axes_g,
        lambda x: evalPolynomial(coeffs, x),
        x_range=(x_range[0], x_range[1]),
        color=color,
    )
    return axes_g, graph


def makePolynomialTex(coeffs: list[float], var: str = "x") -> MathTex:
    """Simple display for low-degree polynomials."""
    terms = []
    for i, c in enumerate(coeffs):
        if abs(c) < 1e-9:
            continue
        if i == 0:
            terms.append(f"{c:.3g}")
        elif i == 1:
            terms.append(f"{c:.3g}{var}")
        else:
            terms.append(f"{c:.3g}{var}^{i}")
    body = " + ".join(terms) if terms else "0"
    return makeMath(body.replace("+ -", "- "))


def showPolynomial(
    scene: Scene,
    coeffs: list[float],
    x_range: tuple = (-2, 2, 1),
    y_range: tuple = (-5, 5, 1),
    color=BLUE,
    run_time: float = 2.0,
) -> VGroup:
    axes_g, graph = makePolynomialGraph(coeffs, x_range, y_range, color)
    scene.play(Create(axes_g), Create(graph), run_time=run_time)
    return VGroup(axes_g, graph)


def showPolynomialLongDivision(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    steps = steps or [
        r"(x^3 - 6x^2 + 11x - 6) \div (x-1)",
        r"= x^2 - 5x + 6",
        r"= (x-2)(x-3)",
    ]
    rows = makeStepList(steps)
    scene.play(FadeIn(rows[0]), run_time=run_time * 0.35)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.22)
    return rows
