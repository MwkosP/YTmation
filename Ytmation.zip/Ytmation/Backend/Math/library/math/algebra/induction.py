"""Mathematical induction staircase / domino metaphor."""

from manim import *

from Math.library.math.algebra._core import makeMath, makeStepList, playStepReveal


def makeInductionDominoes(n: int = 5) -> VGroup:
    dominoes = VGroup()
    for i in range(n):
        d = Rectangle(width=0.35, height=1.0, color=WHITE, fill_opacity=0.15)
        d.rotate(0.12 * i)
        d.move_to(RIGHT * i * 0.55 + DOWN * 0.1 * i)
        dominoes.add(d)
    return dominoes


def showInduction(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.5,
) -> VGroup:
    steps = steps or [
        r"P(1)\ \text{true (base)}",
        r"\text{Assume } P(k)",
        r"P(k+1)\ \text{ follows}",
        r"\therefore P(n)\ \forall n \in \mathbb{N}",
    ]
    dominoes = makeInductionDominoes().shift(LEFT * 2.8 + DOWN * 0.5)
    rows = makeStepList(steps).shift(RIGHT * 2.0)
    scene.play(FadeIn(dominoes), FadeIn(rows[0]), run_time=run_time * 0.35)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.16)
        if i < len(dominoes):
            scene.play(dominoes[i].animate.rotate(-0.35), run_time=run_time * 0.08)
    return VGroup(dominoes, rows)
