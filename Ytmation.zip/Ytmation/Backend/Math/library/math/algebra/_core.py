"""Shared helpers for algebra modules — no scene, no domain narrative."""

from manim import *
import numpy as np


def makeMath(tex: str, color=WHITE, scale: float = 0.85) -> MathTex:
    return MathTex(tex, color=color).scale(scale)


def makeStepList(steps: list[str], buff: float = 0.42, color=WHITE) -> VGroup:
    rows = VGroup(*[makeMath(s, color=color, scale=0.8) for s in steps])
    rows.arrange(DOWN, aligned_edge=LEFT, buff=buff)
    return rows


def evalPolynomialAt(coeffs: list[float], x: float) -> float:
    """coeffs[0] + coeffs[1]*x + coeffs[2]*x^2 + ..."""
    return sum(c * (x**i) for i, c in enumerate(coeffs))


def coeffsFromRoots(roots: list[float], leading: float = 1.0) -> list[float]:
    """Expand leading * (x-r1)(x-r2)... into [a0, a1, ..., an]."""
    coeffs = [leading]
    for r in roots:
        next_c = [0.0] * (len(coeffs) + 1)
        for i, c in enumerate(coeffs):
            next_c[i] += c * (-r)
            next_c[i + 1] += c
        coeffs = next_c
    return coeffs


def quadraticRoots(a: float, b: float, c: float) -> list[float]:
    disc = b * b - 4 * a * c
    if disc < 0:
        return []
    if abs(disc) < 1e-12:
        return [-b / (2 * a)]
    s = np.sqrt(disc)
    return [(-b - s) / (2 * a), (-b + s) / (2 * a)]


def playStepReveal(scene: Scene, steps: VGroup, up_to: int, run_time: float = 0.55) -> None:
    """Reveal steps[0..up_to] inclusive."""
    if up_to < 0 or up_to >= len(steps):
        return
    scene.play(FadeIn(steps[up_to]), run_time=run_time)
