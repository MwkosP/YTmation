"""Absolute value graphs and distance interpretation."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath


def makeAbsoluteValueGraph(
    a: float = 1.0,
    h: float = 0.0,
    k: float = 0.0,
    x_range: tuple = (-4, 4, 1),
    y_range: tuple = (-1, 5, 1),
    color=BLUE,
) -> tuple[VGroup, VMobject]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    graph = plotOnAxes(axes_g, lambda x: a * abs(x - h) + k, x_range=(x_range[0], x_range[1]), color=color)
    return axes_g, graph


def makeAbsoluteValueDistance(
    x1: float = -2.0,
    x2: float = 3.0,
    y_pos: float = 0.0,
) -> VGroup:
    nl = NumberLine(x_range=[-5, 5, 1], length=10, include_numbers=True, font_size=22)
    d1 = Dot(nl.n2p(x1), color=BLUE)
    d2 = Dot(nl.n2p(x2), color="#FF4500")
    brace = Brace(Line(d1.get_center(), d2.get_center()), DOWN, buff=0.15)
    label = brace.get_text(rf"|{x2}-{x1}|={abs(x2-x1):.0f}")
    return VGroup(nl, d1, d2, brace, label).shift(UP * y_pos)


def showAbsoluteValue(
    scene: Scene,
    tex: str = r"y=|x|",
    run_time: float = 1.8,
) -> VGroup:
    axes_g, graph = makeAbsoluteValueGraph()
    label = makeMath(tex).to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(graph), run_time=run_time)
    return VGroup(axes_g, graph, label)
