"""Conic sections from standard equations."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.algebra._core import makeMath


def _center3(center: tuple[float, float] | np.ndarray) -> np.ndarray:
    """Manim positions are 3D; accept (x, y) or xyz."""
    if isinstance(center, np.ndarray):
        c = center.flatten()
        return np.array([float(c[0]), float(c[1]), float(c[2]) if len(c) > 2 else 0.0])
    return np.array([float(center[0]), float(center[1]), 0.0])


def makeParabola(
    a: float = 0.25,
    h: float = 0.0,
    k: float = 0.0,
    x_range: tuple = (-4, 4, 1),
    y_range: tuple = (-1, 5, 1),
    color=BLUE,
) -> tuple[VGroup, VMobject]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    curve = axes.plot(lambda x: a * (x - h) ** 2 + k, x_range=[x_range[0], x_range[1]], color=color)
    return axes_g, curve


def makeEllipse(
    a: float = 3.0,
    b: float = 2.0,
    center: tuple = (0.0, 0.0),
    color=BLUE,
) -> Ellipse:
    return Ellipse(width=2 * a, height=2 * b, color=color).move_to(_center3(center))


def makeHyperbolaBranches(
    a: float = 1.0,
    b: float = 1.0,
    x_range: tuple = (-4, 4, 1),
    y_range: tuple = (-4, 4, 1),
) -> tuple[VGroup, VGroup]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    right = axes.plot(lambda x: (b / a) * np.sqrt(max(x * x - a * a, 0)), x_range=[a, x_range[1]], color="#FF4500")
    left = axes.plot(lambda x: -(b / a) * np.sqrt(max(x * x - a * a, 0)), x_range=[x_range[0], -a], color="#FF4500")
    return axes_g, VGroup(left, right)


def showParabola(
    scene: Scene,
    tex: str = r"y=\frac{1}{4}x^2",
    run_time: float = 1.8,
) -> VGroup:
    axes_g, curve = makeParabola()
    label = makeMath(tex).to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(curve), run_time=run_time)
    return VGroup(axes_g, curve, label)


def showEllipse(
    scene: Scene,
    a: float = 3.0,
    b: float = 2.0,
    run_time: float = 1.8,
) -> VGroup:
    ell = makeEllipse(a, b)
    label = makeMath(rf"\frac{{x^2}}{{{a**2}}}+\frac{{y^2}}{{{b**2}}}=1").scale(0.75).to_edge(UP)
    scene.play(Write(label), Create(ell), run_time=run_time)
    return VGroup(ell, label)


def showHyperbola(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g, branches = makeHyperbolaBranches()
    label = makeMath(r"\frac{x^2}{a^2}-\frac{y^2}{b^2}=1").scale(0.75).to_edge(UP)
    scene.play(Write(label), Create(axes_g), Create(branches), run_time=run_time)
    return VGroup(axes_g, branches, label)
