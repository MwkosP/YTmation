"""Arithmetic and geometric sequences."""

from manim import *

from Math.library.math.algebra._core import makeMath


def makeArithmeticSequenceBars(
    first: float = 2.0,
    diff: float = 1.5,
    n: int = 6,
    color=BLUE,
) -> VGroup:
    bars = VGroup()
    val = first
    for i in range(n):
        h = 0.3 + val * 0.22
        bar = Rectangle(width=0.5, height=h, color=color, fill_opacity=0.55)
        bar.move_to(LEFT * 3.2 + RIGHT * i * 0.65 + UP * h / 2)
        tex = MathTex(f"a_{{{i+1}}}={val:.1f}", font_size=20, color=WHITE).next_to(bar, DOWN, buff=0.06)
        bars.add(VGroup(bar, tex))
        val += diff
    return bars


def makeGeometricSequenceBars(
    first: float = 1.0,
    ratio: float = 1.5,
    n: int = 6,
    color="#FF4500",
) -> VGroup:
    bars = VGroup()
    val = first
    for i in range(n):
        h = 0.25 + val * 0.28
        bar = Rectangle(width=0.5, height=h, color=color, fill_opacity=0.55)
        bar.move_to(LEFT * 3.2 + RIGHT * i * 0.65 + UP * h / 2)
        tex = MathTex(f"g_{{{i+1}}}={val:.2f}", font_size=20).next_to(bar, DOWN, buff=0.06)
        bars.add(VGroup(bar, tex))
        val *= ratio
    return bars


def makeSequenceFormula(
    explicit_tex: str = r"a_n = 2 + (n-1)\cdot 3",
) -> MathTex:
    return makeMath(explicit_tex)


def showArithmeticSequence(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    bars = makeArithmeticSequenceBars()
    formula = makeSequenceFormula().to_edge(UP, buff=0.45)
    scene.play(Write(formula), *[GrowFromEdge(b[0], DOWN) for b in bars], run_time=run_time)
    return VGroup(bars, formula)


def showGeometricSequence(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    bars = makeGeometricSequenceBars()
    formula = makeMath(r"g_n = g_1 \cdot r^{n-1}").to_edge(UP, buff=0.45)
    scene.play(Write(formula), *[GrowFromEdge(b[0], DOWN) for b in bars], run_time=run_time)
    return VGroup(bars, formula)
