"""Intro abstract algebra — Cayley tables and modular arithmetic."""

from manim import *

from Math.library.math.algebra._core import makeMath


def _operationTable(n: int, op) -> list[list[int]]:
    return [[op(i, j) for j in range(n)] for i in range(n)]


def makeCayleyTable(
    elements: list[str] | None = None,
    table: list[list[int]] | None = None,
    title_tex: str = r"\cdot",
) -> VGroup:
    """Small group/Z_n addition or multiplication table."""
    n = len(table) if table else 4
    elements = elements or [str(i) for i in range(n)]
    table = table or _operationTable(n, lambda a, b: (a + b) % n)
    header = makeMath(title_tex, scale=0.7)
    grid = VGroup()
    for i in range(n):
        row = VGroup()
        for j in range(n):
            row.add(MathTex(elements[table[i][j]], font_size=24, color=WHITE))
        row.arrange(RIGHT, buff=0.55)
        grid.add(row)
    grid.arrange(DOWN, buff=0.35)
    labels = VGroup()
    for e in elements:
        labels.add(MathTex(e, font_size=24, color=GREY_B))
    labels.arrange(DOWN, buff=0.35).next_to(grid, LEFT, buff=0.4)
    top = VGroup(*[MathTex(e, font_size=24, color=GREY_B) for e in elements]).arrange(RIGHT, buff=0.55)
    top.next_to(grid, UP, buff=0.35)
    return VGroup(header, labels, top, grid)


def makeModularAdditionTable(n: int = 5) -> VGroup:
    return makeCayleyTable(
        elements=[str(i) for i in range(n)],
        table=_operationTable(n, lambda a, b: (a + b) % n),
        title_tex=rf"\mathbb{{Z}}_{{{n}}}\ (+)",
    )


def showCayleyTable(
    scene: Scene,
    n: int = 4,
    run_time: float = 2.0,
) -> VGroup:
    table = makeModularAdditionTable(n)
    scene.play(FadeIn(table), run_time=run_time)
    return table
