"""Factoring patterns — visual and symbolic."""

from manim import *

from Math.library.math.algebra._core import makeMath


def makeFactorTiles(
    left_tex: str = r"x^2",
    right_tex: str = r"5x",
    constant_tex: str = r"6",
) -> VGroup:
    return VGroup(
        makeMath(left_tex, color=BLUE),
        makeMath(right_tex, color=GREEN),
        makeMath(constant_tex, color="#FF4500"),
    ).arrange(RIGHT, buff=0.5)


def makeFactoredForm(
    factors: list[str],
    color=WHITE,
) -> MathTex:
    body = "".join([rf"({f})" for f in factors])
    return makeMath(body, color=color)


def showFactorDifferenceOfSquares(
    scene: Scene,
    before_tex: str = r"x^2 - 9",
    after_tex: str = r"(x-3)(x+3)",
    run_time: float = 1.6,
) -> VGroup:
    before = makeMath(before_tex)
    after = makeMath(after_tex, color="#FF4500")
    arrow = makeMath(r"\Rightarrow").scale(0.85)
    row = VGroup(before, arrow, after).arrange(RIGHT, buff=0.35)
    scene.play(Write(before), run_time=run_time * 0.4)
    scene.play(TransformMatchingTex(before.copy(), after), FadeIn(arrow), run_time=run_time * 0.6)
    return row


def showFactorTrinomial(
    scene: Scene,
    before_tex: str = r"x^2 + 5x + 6",
    after_tex: str = r"(x+2)(x+3)",
    run_time: float = 1.6,
) -> VGroup:
    before = makeMath(before_tex)
    after = makeMath(after_tex, color="#FF4500")
    row = VGroup(before, makeMath(r"\Rightarrow").scale(0.85), after).arrange(RIGHT, buff=0.35)
    scene.play(Write(before), run_time=run_time * 0.45)
    scene.play(TransformMatchingTex(before.copy(), after), run_time=run_time * 0.55)
    return row


def showFactorGcf(
    scene: Scene,
    before_tex: str = r"6x^2 + 9x",
    after_tex: str = r"3x(2x+3)",
    run_time: float = 1.5,
) -> VGroup:
    before = makeMath(before_tex)
    after = makeMath(after_tex, color=YELLOW)
    scene.play(Write(before), run_time=run_time * 0.45)
    scene.play(TransformMatchingTex(before.copy(), after), run_time=run_time * 0.55)
    return VGroup(before, after)
