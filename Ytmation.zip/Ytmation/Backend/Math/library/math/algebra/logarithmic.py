"""Logarithmic functions and inverse-of-exp pairing."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath


def makeLogGraph(
    base: float = np.e,
    x_range: tuple = (0.15, 5, 1),
    y_range: tuple = (-2, 3, 1),
    color="#FF4500",
) -> tuple[VGroup, VMobject]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    graph = plotOnAxes(
        axes_g,
        lambda x: np.log(x) / np.log(base) if x > 0 else np.nan,
        x_range=(x_range[0], x_range[1]),
        color=color,
    )
    return axes_g, graph


def makeExpLogPair(
    base: float = np.e,
) -> tuple[VGroup, VMobject, VMobject, DashedLine]:
    axes_g = makeLabeledAxes(x_range=(0, 4, 1), y_range=(0, 4, 1))
    axes = axes_g[0]
    exp_g = plotOnAxes(axes_g, lambda x: base**x, x_range=(0, 2.2), color=BLUE)
    log_g = plotOnAxes(axes_g, lambda x: np.log(x) / np.log(base), x_range=(0.2, 4), color="#FF4500")
    diag = DashedLine(axes.c2p(0, 0), axes.c2p(4, 4), color=GREY_B)
    return axes_g, exp_g, log_g, diag


def showLogGraph(
    scene: Scene,
    base: float = np.e,
    tex: str = r"y=\ln x",
    run_time: float = 2.0,
) -> VGroup:
    axes_g, graph = makeLogGraph(base=base)
    label = makeMath(tex).to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(graph), run_time=run_time)
    return VGroup(axes_g, graph, label)


def showExpLogInverse(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g, exp_g, log_g, diag = makeExpLogPair()
    scene.play(Create(axes_g), Create(diag), Create(exp_g), Create(log_g), run_time=run_time)
    return VGroup(axes_g, exp_g, log_g, diag)
