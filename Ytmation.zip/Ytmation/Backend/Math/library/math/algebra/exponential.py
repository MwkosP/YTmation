"""Exponential growth and decay."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath


def makeExponentialGraph(
    base: float = np.e,
    coefficient: float = 1.0,
    shift: float = 0.0,
    x_range: tuple = (-2, 3, 1),
    y_range: tuple = (0, 8, 2),
    color=BLUE,
) -> tuple[VGroup, VMobject]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range, x_label="x", y_label="y")
    graph = plotOnAxes(
        axes_g,
        lambda x: coefficient * (base**x) + shift,
        x_range=(x_range[0], x_range[1]),
        color=color,
    )
    return axes_g, graph


def makeExponentialGrowthBars(
    rate: float = 0.5,
    steps: int = 5,
    start: float = 1.0,
) -> VGroup:
    bars = VGroup()
    val = start
    for i in range(steps):
        h = 0.35 + val * 0.25
        bar = Rectangle(width=0.55, height=h, color=BLUE, fill_opacity=0.6)
        bar.move_to(LEFT * 3 + RIGHT * i * 0.75 + UP * h / 2)
        label = MathTex(f"{val:.1f}", font_size=22).next_to(bar, DOWN, buff=0.08)
        bars.add(VGroup(bar, label))
        val *= 1 + rate
    return bars


def showExponentialGrowth(
    scene: Scene,
    base: float = 2.0,
    tex: str = r"y=2^x",
    run_time: float = 2.0,
) -> VGroup:
    axes_g, graph = makeExponentialGraph(base=base)
    label = makeMath(tex).to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(graph), run_time=run_time)
    return VGroup(axes_g, graph, label)
