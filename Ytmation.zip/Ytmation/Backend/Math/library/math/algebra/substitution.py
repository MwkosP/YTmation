"""Substitution into expressions."""

from manim import *

from Math.library.math.algebra._core import makeMath


def makeSubstitutionRow(
    expr_tex: str,
    sub_tex: str,
    result_tex: str,
) -> VGroup:
    e = makeMath(expr_tex)
    arrow = makeMath(r",\quad x \mapsto").scale(0.75)
    s = makeMath(sub_tex, color="#FF4500")
    eq = makeMath("=")
    r = makeMath(result_tex, color=YELLOW)
    return VGroup(e, s, eq, r).arrange(RIGHT, buff=0.25)


def showSubstitution(
    scene: Scene,
    expr_tex: str = r"f(x)=x^2+1",
    value_tex: str = r"3",
    result_tex: str = r"f(3)=10",
    run_time: float = 1.6,
) -> VGroup:
    row = makeSubstitutionRow(expr_tex, value_tex, result_tex)
    scene.play(Write(row[0]), Write(row[1]), run_time=run_time * 0.5)
    scene.play(Write(row[2]), TransformFromCopy(row[0].copy(), row[3]), run_time=run_time * 0.5)
    return row
