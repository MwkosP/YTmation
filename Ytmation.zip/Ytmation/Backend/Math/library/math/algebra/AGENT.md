# Algebra Library — Agent Cookbook

Pure algebra primitives. **Reused by** `physics/`, `ml/`, workflows. No domain story (no forces, loss, etc.).

## API layers

| Prefix | Example | Agent use |
|--------|---------|-----------|
| `make…` | `makeLinearGraph`, `makeCayleyTable` | Returns mobjects; you `scene.play` |
| `show…` | `showFactorTrinomial`, `showSystemIntersection` | One beat; chain several in one `sceneX` |
| `demo…` | `demoQuadratic` in `recipes.py` | Whole topic; one per segment usually |

## Module map

| File | Topics |
|------|--------|
| `expressions.py` | like terms, distribute, step lists |
| `laws.py` | area models, (a+b)², a²−b² |
| `substitution.py` | plug-in values |
| `linear.py` | lines, balance scale, solve steps |
| `inequalities.py` | number line, half-plane |
| `absolute_value.py` | V-shape, distance |
| `systems.py` | two lines, elimination steps |
| `factoring.py` | GCF, trinomial, DOTS |
| `roots.py` | roots on graph, synthetic division steps |
| `polynomial.py` | eval, graph, long division steps |
| `quadratic.py` | graph, vertex, completing square |
| `rational.py` | rational graph + asymptote |
| `functions.py` | machine, piecewise |
| `composition.py` | f∘g diagram |
| `inverse.py` | inverse graphs + y=x |
| `transformations.py` | parent → child graph |
| `exponential.py` | growth curve, bars |
| `logarithmic.py` | log curve, exp–log pair |
| `sequences.py` | arithmetic / geometric bars |
| `binomial.py` | Pascal, expansion |
| `complex.py` | Argand plane, multiply |
| `conics.py` | parabola, ellipse, hyperbola |
| `radical.py` | sqrt on number line |
| `identities.py` | wrappers → `laws` |
| `induction.py` | domino + proof steps |
| `groups.py` | Cayley / ℤₙ table |
| `recipes.py` | all `demo…` |

## Recipes (`recipes.py`)

`demoCombineLikeTerms`, `demoDistribute`, `demoSolveLinear`, `demoBalanceEquation`, `demoSystem`, `demoElimination`, `demoFactorTrinomial`, `demoFactorDots`, `demoQuadratic`, `demoCompletingSquare`, `demoVertexForm`, `demoPolynomial`, `demoFunctionMachine`, `demoComposition`, `demoGraphTransform`, `demoExponential`, `demoExpLogInverse`, `demoArithmeticSequence`, `demoBinomialTheorem`, `demoComplexMultiply`, `demoSquareIdentity`, `demoInduction`, `demoCayleyTable`

## Compose in one scene (preferred)

```python
def scene2(scene):
    from Math.library.common.layout import makeTitle
    from Math.library.common.styling import setupScene
    from Math.library.math.algebra.linear import makeLinearGraph
    from Math.library.math.algebra.factoring import showFactorTrinomial

    setupScene(scene)
    scene.play(Write(makeTitle("Factoring then graph")))
    showFactorTrinomial(scene)
    axes, graph = makeLinearGraph(slope=1, intercept=2)
    scene.play(Create(axes), Create(graph))
```

## Polynomial coeffs

`coeffs[i]` = coefficient of **xⁱ** (constant term first): `evalPolynomial([1, -2, 0.5], x)` → 1 − 2x + 0.5x².
