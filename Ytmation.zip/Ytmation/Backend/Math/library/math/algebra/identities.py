"""Classic identities — thin wrappers over area models."""

from manim import *

from Math.library.math.algebra.laws import (
    showSquareIdentity,
    showDifferenceOfSquaresIdentity,
)


def showIdentitySquare(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    return showSquareIdentity(scene, run_time=run_time)


def showIdentityDifferenceOfSquares(
    scene: Scene,
    run_time: float = 1.8,
) -> VGroup:
    return showDifferenceOfSquaresIdentity(scene, run_time=run_time)
