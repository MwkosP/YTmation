"""Function composition."""

from manim import *

from Math.library.math.algebra._core import makeMath


def makeCompositionDiagram(
    f_tex: str = r"f(x)=x^2",
    g_tex: str = r"g(x)=x+1",
    fg_tex: str = r"(f\circ g)(x)=f(g(x))",
) -> VGroup:
    boxes = VGroup()
    for tex, color in [(g_tex, BLUE), (f_tex, "#FF4500"), (fg_tex, YELLOW)]:
        r = RoundedRectangle(width=3.0, height=1.0, corner_radius=0.15, color=color)
        t = makeMath(tex, scale=0.7).move_to(r)
        boxes.add(VGroup(r, t))
    boxes.arrange(RIGHT, buff=0.55)
    arrows = VGroup(
        Arrow(boxes[0].get_right(), boxes[1].get_left(), buff=0.08),
        Arrow(boxes[1].get_right(), boxes[2].get_left(), buff=0.08),
    )
    x_in = makeMath("x", color=WHITE).next_to(boxes[0], LEFT, buff=0.4)
    x_out = makeMath(r"(f\circ g)(x)", color=WHITE).next_to(boxes[2], RIGHT, buff=0.35)
    return VGroup(x_in, boxes, arrows, x_out)


def showComposition(
    scene: Scene,
    f_tex: str = r"f(x)=x^2",
    g_tex: str = r"g(x)=x+1",
    run_time: float = 2.0,
) -> VGroup:
    diagram = makeCompositionDiagram(f_tex, g_tex)
    scene.play(Create(diagram), run_time=run_time)
    return diagram
