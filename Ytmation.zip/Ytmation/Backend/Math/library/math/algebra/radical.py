"""Radicals and roots on number line / axes."""

from manim import *

from Math.library.math.graphs.axes import makeNumberLine
from Math.library.math.algebra._core import makeMath


def makeRadicalTex(n: int = 2, radicand_tex: str = "x") -> MathTex:
    if n == 2:
        return makeMath(rf"\sqrt{{{radicand_tex}}}")
    return makeMath(rf"\sqrt[{n}]{{{radicand_tex}}}")


def showRadicalOnNumberLine(
    scene: Scene,
    value: float = 2.0,
    run_time: float = 1.6,
) -> VGroup:
    nl = makeNumberLine(0, 5, 1, length=8)
    dot = Dot(nl.n2p(value), color=YELLOW)
    label = makeRadicalTex(2, f"{value:.0f}")
    label.next_to(dot, UP, buff=0.25)
    scene.play(Create(nl), FadeIn(dot), Write(label), run_time=run_time)
    return VGroup(nl, dot, label)


def showSimplifyRadical(
    scene: Scene,
    before_tex: str = r"\sqrt{50}",
    after_tex: str = r"5\sqrt{2}",
    run_time: float = 1.5,
) -> VGroup:
    before = makeMath(before_tex)
    after = makeMath(after_tex, color="#FF4500")
    scene.play(Write(before), run_time=run_time * 0.45)
    scene.play(TransformMatchingTex(before.copy(), after), run_time=run_time * 0.55)
    return VGroup(before, after)
