"""Quadratics: graph, vertex form, completing the square."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath, quadraticRoots


def makeQuadraticGraph(
    a: float = 1.0,
    b: float = 0.0,
    c: float = -2.0,
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-3, 5, 1),
    color=BLUE,
) -> tuple[VGroup, VMobject, VGroup]:
    f = lambda x: a * x * x + b * x + c
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, f, x_range=(x_range[0], x_range[1]), color=color)
    roots = VGroup()
    for r in quadraticRoots(a, b, c):
        roots.add(Dot(axes.c2p(r, 0), color=YELLOW, radius=0.09))
    return axes_g, graph, roots


def makeVertexFormLabel(h: float, k: float) -> MathTex:
    return makeMath(rf"y = a(x - {h})^2 + {k}", color=WHITE)


def makeCompletingSquareDiagram(a: float = 1.0, b: float = 4.0, c: float = 1.0) -> VGroup:
    """Algebra tiles hint: square + rectangle for b/2."""
    side = max(0.6, abs(b) / (2 * max(abs(a), 0.5)) * 0.35)
    sq = Square(side_length=side, color=BLUE, fill_opacity=0.35)
    rect = Rectangle(width=side, height=0.4, color=GREEN, fill_opacity=0.35).next_to(sq, RIGHT, buff=0)
    return VGroup(sq, rect)


def showQuadratic(
    scene: Scene,
    a: float = 1.0,
    b: float = 0.0,
    c: float = -2.0,
    x_range: tuple = (-3, 3, 1),
    run_time: float = 2.0,
) -> VGroup:
    axes_g, graph, roots = makeQuadraticGraph(a, b, c, x_range=x_range)
    formula = makeMath(rf"y={a}x^2+{b}x+{c}").to_edge(UP, buff=0.5)
    scene.play(Create(axes_g), Create(graph), Write(formula), run_time=run_time * 0.75)
    if len(roots) > 0:
        scene.play(FadeIn(roots), run_time=run_time * 0.25)
    return VGroup(axes_g, graph, roots, formula)


def showCompletingSquare(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    from Math.library.math.algebra._core import makeStepList, playStepReveal

    steps = steps or [
        r"x^2 + 4x + 1",
        r"x^2 + 4x + 4 - 4 + 1",
        r"(x+2)^2 - 3",
    ]
    tiles = makeCompletingSquareDiagram().shift(LEFT * 3.2)
    rows = makeStepList(steps).shift(RIGHT * 2.2)
    scene.play(FadeIn(tiles), FadeIn(rows[0]), run_time=run_time * 0.35)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.22)
    return VGroup(tiles, rows)


def showVertexForm(
    scene: Scene,
    h: float = 2.0,
    k: float = -1.0,
    a: float = 1.0,
    run_time: float = 2.0,
) -> VGroup:
    b = -2 * a * h
    c = a * h * h + k
    axes_g, graph, _ = makeQuadraticGraph(a, b, c)
    vertex = Dot(axes_g[0].c2p(h, k), color=YELLOW)
    label = makeVertexFormLabel(h, k).to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(graph), FadeIn(vertex), run_time=run_time)
    return VGroup(axes_g, graph, vertex, label)
