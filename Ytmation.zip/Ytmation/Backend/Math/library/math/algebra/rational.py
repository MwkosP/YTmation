"""Rational functions — graphs, asymptotes, holes."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath


def makeRationalGraph(
    numerator,
    denominator,
    x_range: tuple = (-4, 4, 1),
    y_range: tuple = (-5, 5, 1),
    plot_range: tuple | None = None,
    color=BLUE,
    asymptote_color=GREY_B,
) -> tuple[VGroup, VMobject, VGroup]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    x0, x1 = (plot_range or (x_range[0] + 0.2, x_range[1] - 0.2))
    graph = axes.plot(
        lambda x: numerator(x) / denominator(x) if abs(denominator(x)) > 1e-6 else np.nan,
        x_range=[x0, x1],
        color=color,
        use_smoothing=False,
    )
    asym_lines = VGroup()
    # vertical asymptotes where denominator zero (linear denom)
    try:
        if hasattr(denominator, "__code__") and denominator.__code__.co_argcount == 1:
            for x_try in np.linspace(x_range[0], x_range[1], 80):
                if abs(denominator(x_try)) < 0.05:
                    asym_lines.add(
                        DashedLine(
                            axes.c2p(x_try, y_range[0]),
                            axes.c2p(x_try, y_range[1]),
                            color=asymptote_color,
                        )
                    )
                    break
    except Exception:
        pass
    return axes_g, graph, asym_lines


def showRationalFunction(
    scene: Scene,
    tex: str = r"y=\frac{x+1}{x-2}",
    run_time: float = 2.0,
) -> VGroup:
    axes_g, graph, asym = makeRationalGraph(
        lambda x: x + 1,
        lambda x: x - 2,
        plot_range=(-3.8, 1.8),
    )
    label = makeMath(tex).to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(asym), Create(graph), run_time=run_time)
    return VGroup(axes_g, graph, asym, label)
