"""Functions: domain/range, piecewise, machine diagram."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath


def makeFunctionMachine(
    input_label: str = "x",
    rule_tex: str = r"f(x)=x^2",
    output_label: str = r"f(x)",
) -> VGroup:
    box = RoundedRectangle(width=3.2, height=1.4, corner_radius=0.2, color=WHITE)
    rule = makeMath(rule_tex, scale=0.75).move_to(box)
    inp = makeMath(input_label, color=BLUE).next_to(box, LEFT, buff=0.5)
    out = makeMath(output_label, color="#FF4500").next_to(box, RIGHT, buff=0.5)
    arr_in = Arrow(inp.get_right(), box.get_left(), buff=0.1)
    arr_out = Arrow(box.get_right(), out.get_left(), buff=0.1)
    return VGroup(inp, arr_in, box, rule, arr_out, out)


def makePiecewiseGraph(
    pieces: list[tuple[callable, tuple[float, float]]],
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-2, 6, 1),
    colors: list | None = None,
) -> tuple[VGroup, VGroup]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    colors = colors or [BLUE, "#FF4500", GREEN]
    graphs = VGroup()
    for i, (func, xr) in enumerate(pieces):
        graphs.add(
            axes.plot(func, x_range=list(xr), color=colors[i % len(colors)], stroke_width=3)
        )
    return axes_g, graphs


def makeDomainRangeLabels(
    domain_tex: str = r"\mathbb{R}",
    range_tex: str = r"[0,\infty)",
) -> VGroup:
    d = makeMath(rf"\text{{Domain: }}{domain_tex}", color=BLUE)
    r = makeMath(rf"\text{{Range: }}{range_tex}", color="#FF4500")
    return VGroup(d, r).arrange(DOWN, aligned_edge=LEFT, buff=0.25)


def showFunctionMachine(
    scene: Scene,
    rule_tex: str = r"f(x)=2x+1",
    run_time: float = 1.8,
) -> VGroup:
    machine = makeFunctionMachine(rule_tex=rule_tex)
    scene.play(Create(machine), run_time=run_time)
    return machine


def showPiecewise(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    pieces = [
        (lambda x: -x, (-3, 0)),
        (lambda x: x**2, (0, 2)),
        (lambda x: 2, (2, 3)),
    ]
    axes_g, graphs = makePiecewiseGraph(pieces)
    label = makeMath(rf"\text{{piecewise}}").to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), *[Create(g) for g in graphs], run_time=run_time)
    return VGroup(axes_g, graphs, label)
