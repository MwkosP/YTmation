"""Complex numbers on the Argand plane."""

from manim import *
import numpy as np

from Math.library.math.algebra._core import makeMath


def makeComplexPlane(
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-3, 3, 1),
    x_length: float = 6,
    y_length: float = 6,
) -> VGroup:
    plane = Axes(
        x_range=list(x_range),
        y_range=list(y_range),
        x_length=x_length,
        y_length=y_length,
        axis_config={"color": GREY_B, "include_tip": True},
    )
    labels = VGroup(
        MathTex(r"\mathrm{Re}", color=GREY_B).scale(0.65).next_to(plane.x_axis, DOWN, buff=0.12),
        MathTex(r"\mathrm{Im}", color=GREY_B).scale(0.65).next_to(plane.y_axis, LEFT, buff=0.12),
    )
    return VGroup(plane, labels)


def makeComplexVector(
    plane: Axes,
    z: complex,
    color=YELLOW,
) -> Arrow:
    return Arrow(
        plane.c2p(0, 0),
        plane.c2p(z.real, z.imag),
        buff=0,
        color=color,
        stroke_width=4,
    )


def makeComplexMultiplyArc(
    plane: Axes,
    z1: complex,
    z2: complex,
    color=BLUE,
) -> VGroup:
    v1 = makeComplexVector(plane, z1, color=color)
    v2 = makeComplexVector(plane, z1 * z2, color="#FF4500")
    return VGroup(v1, v2)


def showComplexPlane(
    scene: Scene,
    z: complex = 2 + 1.5j,
    run_time: float = 2.0,
) -> VGroup:
    plane_g = makeComplexPlane()
    plane = plane_g[0]
    vec = makeComplexVector(plane, z)
    label = makeMath(rf"z={z.real:.1f}{z.imag:+.1f}i").to_edge(UP, buff=0.45)
    scene.play(Create(plane_g), Write(label), GrowArrow(vec), run_time=run_time)
    return VGroup(plane_g, vec, label)


def showComplexMultiply(
    scene: Scene,
    z1: complex = 1 + 1j,
    z2: complex = 0 + 1j,
    run_time: float = 2.2,
) -> VGroup:
    plane_g = makeComplexPlane()
    plane = plane_g[0]
    vecs = makeComplexMultiplyArc(plane, z1, z2)
    caption = makeMath(rf"z_1 \cdot z_2 = {z1*z2:.2f}").to_edge(UP, buff=0.45)
    scene.play(Create(plane_g), Write(caption), GrowArrow(vecs[0]), run_time=run_time * 0.55)
    scene.play(TransformFromCopy(vecs[0], vecs[1]), run_time=run_time * 0.45)
    return VGroup(plane_g, vecs, caption)
