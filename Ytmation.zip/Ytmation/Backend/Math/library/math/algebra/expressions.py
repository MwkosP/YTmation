"""Expression labels and symbolic rearrangement visuals."""

from manim import *

from Math.library.math.algebra._core import makeMath, makeStepList, playStepReveal


def makeExpression(tex: str, color=WHITE, scale: float = 0.9) -> MathTex:
    return makeMath(tex, color=color, scale=scale)


def makeLikeTermsPair(
    left_tex: str = r"2x + 3x",
    right_tex: str = r"5x",
    color=WHITE,
) -> tuple[MathTex, MathTex]:
    return makeMath(left_tex, color=color), makeMath(right_tex, color=color)


def showCombineLikeTerms(
    scene: Scene,
    left_tex: str = r"2x + 3x",
    right_tex: str = r"= 5x",
    run_time: float = 1.4,
) -> VGroup:
    left = makeMath(left_tex)
    arrow = makeMath(r"\Rightarrow", color=GREY_B).scale(0.9)
    right = makeMath(right_tex, color="#FF4500")
    row = VGroup(left, arrow, right).arrange(RIGHT, buff=0.35).move_to(ORIGIN)
    scene.play(Write(left), run_time=run_time * 0.45)
    scene.play(FadeIn(arrow), TransformFromCopy(left.copy(), right), run_time=run_time * 0.55)
    return VGroup(row)


def showDistribute(
    scene: Scene,
    before_tex: str = r"a(b+c)",
    after_tex: str = r"ab + ac",
    run_time: float = 1.5,
) -> VGroup:
    before = makeMath(before_tex)
    after = makeMath(after_tex, color="#FF4500")
    arrow = makeMath(r"\Rightarrow").scale(0.85)
    group = VGroup(before, arrow, after).arrange(RIGHT, buff=0.4)
    scene.play(Write(before), run_time=run_time * 0.4)
    scene.play(TransformMatchingTex(before.copy(), after), FadeIn(arrow), run_time=run_time * 0.6)
    return group


def showExpressionSteps(
    scene: Scene,
    steps: list[str],
    run_time_per_step: float = 0.55,
) -> VGroup:
    rows = makeStepList(steps)
    rows.to_edge(LEFT, buff=0.8)
    scene.play(FadeIn(rows[0]), run_time=run_time_per_step)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time_per_step)
    return rows
