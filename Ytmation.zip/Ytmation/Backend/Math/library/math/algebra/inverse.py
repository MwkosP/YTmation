"""Inverse functions — reflection across y=x."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.algebra._core import makeMath


def makeInverseGraphs(
    func,
    inverse_func,
    x_range: tuple = (0, 4, 1),
    y_range: tuple = (0, 4, 1),
    f_color=BLUE,
    inv_color="#FF4500",
) -> tuple[VGroup, VMobject, VMobject, DashedLine]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    f_graph = plotOnAxes(axes_g, func, x_range=(x_range[0], x_range[1]), color=f_color)
    inv_graph = plotOnAxes(axes_g, inverse_func, x_range=(x_range[0], x_range[1]), color=inv_color)
    diag = DashedLine(axes.c2p(x_range[0], x_range[0]), axes.c2p(x_range[1], x_range[1]), color=GREY_B)
    return axes_g, f_graph, inv_graph, diag


def showInverseReflection(
    scene: Scene,
    func=None,
    run_time: float = 2.2,
) -> VGroup:
    func = func or (lambda x: 2 * x)
    inverse_func = (lambda x: x / 2) if func(1) == 2 else (lambda x: x)
    axes_g, f_g, inv_g, diag = makeInverseGraphs(func, inverse_func)
    labels = VGroup(makeMath("f", color=BLUE), makeMath("f^{-1}", color="#FF4500")).arrange(RIGHT, buff=1.2).to_edge(UP)
    scene.play(Create(axes_g), Create(diag), Create(f_g), Create(inv_g), Write(labels), run_time=run_time)
    return VGroup(axes_g, f_g, inv_g, diag, labels)
