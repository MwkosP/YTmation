"""High-level math demos — one call per topic."""

from manim import *

from Math.library.common.layout import makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.calculus.recipes import (
    demoDerivative as _demoDerivative,
    demoIntegral as _demoIntegral,
)
from Math.library.math.algebra.quadratic import showQuadratic  # primitives
from Math.library.math.algebra.recipes import demoQuadratic as _demoQuadratic
from Math.library.math.geometry.recipes import demoPythagorean as _demoPythagorean
from Math.library.math.linear_algebra.recipes import demoMatrixTransform as _demoMatrixTransform
from Math.library.math.statistics.recipes import demoNormalDistribution as _demoNormalDistribution
from Math.library.math.number_theory.recipes import (
    demoPrimeSieve as _demoPrimeSieve,
    demoNumberSpiral as _demoNumberSpiral,
)
from Math.library.math.trigonometry.sine import makeTrigAxes, plotSine, plotCosine
import numpy as np


def demoDerivative(scene: Scene, title: str = "Derivative") -> None:
    _demoDerivative(scene, title=title)


def demoIntegral(scene: Scene, title: str = "Integral") -> None:
    _demoIntegral(scene, title=title)


def demoQuadratic(scene: Scene, title: str = "Quadratic") -> None:
    _demoQuadratic(scene, title=title)


def demoPythagorean(scene: Scene, title: str = "Pythagorean Theorem") -> None:
    _demoPythagorean(scene, title=title)


def demoSineCos(scene: Scene, title: str = "Sine and Cosine") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    axes = makeTrigAxes()
    s = plotSine(axes, color=BLUE)
    c = plotCosine(axes, color="#FF4500")
    scene.play(Create(axes), Create(s), Create(c), run_time=2.0)


def demoMatrixTransform(scene: Scene, title: str = "Linear Transform") -> None:
    _demoMatrixTransform(scene, title=title)


def demoNormalDist(scene: Scene, title: str = "Normal Distribution") -> None:
    _demoNormalDistribution(scene, title=title)


def demoPrimeSieve(scene: Scene, title: str = "Prime Sieve") -> None:
    _demoPrimeSieve(scene, title=title)


def demoNumberSpiral(scene: Scene, title: str = "Number Spiral") -> None:
    _demoNumberSpiral(scene, title=title)
