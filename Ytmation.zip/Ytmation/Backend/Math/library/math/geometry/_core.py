"""Shared geometry helpers — pure math, no domain narrative."""

from manim import *
import numpy as np


def makeMath(tex: str, color=WHITE, scale: float = 0.85) -> MathTex:
    return MathTex(tex, color=color).scale(scale)


def makeAngleArc(
    vertex: np.ndarray,
    p1: np.ndarray,
    p2: np.ndarray,
    radius: float = 0.45,
    color=YELLOW,
) -> Arc:
    v1 = p1 - vertex
    v2 = p2 - vertex
    a1 = np.arctan2(v1[1], v1[0])
    a2 = np.arctan2(v2[1], v2[0])
    return Arc(radius=radius, start_angle=a1, angle=a2 - a1, arc_center=vertex, color=color, stroke_width=2)


def labelSegment(mid: np.ndarray, tex: str, direction=UP, buff: float = 0.15) -> MathTex:
    return makeMath(tex, scale=0.65).next_to(mid, direction, buff=buff)


def polygonInteriorAngleSum(n: int) -> float:
    return (n - 2) * PI
