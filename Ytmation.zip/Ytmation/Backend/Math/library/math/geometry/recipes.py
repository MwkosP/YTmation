"""Geometry demos — one topic per call."""

from manim import *

from Math.library.common.layout import makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.geometry.pythagorean import showPythagorean
from Math.library.math.geometry.circle_pi import showCirclePi
from Math.library.math.geometry.sine_wave import showUnitCircleSine
from Math.library.math.geometry.triangles import (
    showTriangleAngleSum,
    showExteriorAngle,
    showSpecialRightTriangle,
    showTriangleInequality,
    showMidsegment,
    showIsoscelesTriangle,
    showClassifyTriangles,
)
from Math.library.math.geometry.angles import (
    showVerticalAngles,
    showComplementaryAngles,
    showSupplementaryAngles,
    showAngleBisector,
)
from Math.library.math.geometry.parallel_lines import (
    showParallelLinesTransversal,
    showAlternateInteriorAngles,
    showSameSideInterior,
)
from Math.library.math.geometry.congruence import (
    showCongruenceSSS,
    showCongruenceSAS,
    showCongruenceASA,
    showCongruenceHL,
)
from Math.library.math.geometry.laws import showLawOfSines, showLawOfCosines
from Math.library.math.geometry.perimeter import showPolygonPerimeter, showCircumference
from Math.library.math.geometry.symmetry import showLineSymmetry
from Math.library.math.geometry.similarity import showSimilarTriangles, showAASimilarity
from Math.library.math.geometry.polygons import showRegularPolygon, showInteriorAngleSum
from Math.library.math.geometry.circles import (
    showCentralAngle,
    showInscribedAngle,
    showTangentRadius,
    showChordAndArc,
    showThalesTheorem,
)
from Math.library.math.geometry.area import (
    showRectangleArea,
    showTriangleArea,
    showCircleArea,
    showTrapezoidArea,
    showParallelogramArea,
    showSectorArea,
    showArcLength,
)
from Math.library.math.geometry.solids import (
    showPrismVolume,
    showCylinderVolume,
    showConeVolume,
    showSphereVolume,
    showBoxSurfaceArea,
    showCrossSection,
)
from Math.library.math.geometry.coordinate import (
    showDistanceFormula,
    showMidpoint,
    showSlope,
    showParallelLinesSlope,
    showPerpendicularLinesSlope,
)
from Math.library.math.geometry.rigid_motion import (
    showTranslation,
    showReflection,
    showRotation,
    showDilation,
)


def demoPythagorean(scene: Scene, title: str = "Pythagorean") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showPythagorean(scene)


def demoCirclePi(scene: Scene, title: str = "Circumference") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showCirclePi(scene)


def demoUnitCircleSine(scene: Scene, title: str = "Unit Circle") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showUnitCircleSine(scene)


def demoTriangleAngleSum(scene: Scene, title: str = "Angle Sum") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showTriangleAngleSum(scene)


def demoExteriorAngle(scene: Scene, title: str = "Exterior Angle") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showExteriorAngle(scene)


def demoSpecialRightTriangle(scene: Scene, title: str = "3-4-5 Triangle") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showSpecialRightTriangle(scene, kind="345")


def demo454590Triangle(scene: Scene, title: str = "45-45-90") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showSpecialRightTriangle(scene, kind="4545")


def demoVerticalAngles(scene: Scene, title: str = "Vertical Angles") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showVerticalAngles(scene)


def demoComplementaryAngles(scene: Scene, title: str = "Complementary") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showComplementaryAngles(scene)


def demoAngleBisector(scene: Scene, title: str = "Angle Bisector") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showAngleBisector(scene)


def demoParallelTransversal(scene: Scene, title: str = "Transversal") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showParallelLinesTransversal(scene)


def demoAlternateInterior(scene: Scene, title: str = "Alternate Interior") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showAlternateInteriorAngles(scene)


def demoCongruenceSSS(scene: Scene, title: str = "SSS") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showCongruenceSSS(scene)


def demoCongruenceSAS(scene: Scene, title: str = "SAS") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showCongruenceSAS(scene)


def demoSimilarTriangles(scene: Scene, title: str = "Similarity") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showSimilarTriangles(scene)


def demoAASimilarity(scene: Scene, title: str = "AA Similarity") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showAASimilarity(scene)


def demoRegularPolygon(scene: Scene, title: str = "Regular Polygon") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showRegularPolygon(scene, n=6)


def demoInteriorAngleSum(scene: Scene, title: str = "Interior Angles") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showInteriorAngleSum(scene, n=5)


def demoCentralAngle(scene: Scene, title: str = "Central Angle") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showCentralAngle(scene)


def demoInscribedAngle(scene: Scene, title: str = "Inscribed Angle") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showInscribedAngle(scene)


def demoTangentRadius(scene: Scene, title: str = "Tangent ⊥ Radius") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showTangentRadius(scene)


def demoChordAndArc(scene: Scene, title: str = "Chord") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showChordAndArc(scene)


def demoRectangleArea(scene: Scene, title: str = "Rectangle Area") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showRectangleArea(scene)


def demoTriangleArea(scene: Scene, title: str = "Triangle Area") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showTriangleArea(scene)


def demoCircleArea(scene: Scene, title: str = "Circle Area") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showCircleArea(scene)


def demoTrapezoidArea(scene: Scene, title: str = "Trapezoid Area") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showTrapezoidArea(scene)


def demoPrismVolume(scene: Scene, title: str = "Prism Volume") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showPrismVolume(scene)


def demoCylinderVolume(scene: Scene, title: str = "Cylinder Volume") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showCylinderVolume(scene)


def demoConeVolume(scene: Scene, title: str = "Cone Volume") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showConeVolume(scene)


def demoSphereVolume(scene: Scene, title: str = "Sphere Volume") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showSphereVolume(scene)


def demoDistanceFormula(scene: Scene, title: str = "Distance") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showDistanceFormula(scene)


def demoMidpoint(scene: Scene, title: str = "Midpoint") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showMidpoint(scene)


def demoSlope(scene: Scene, title: str = "Slope") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showSlope(scene)


def demoTranslation(scene: Scene, title: str = "Translation") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showTranslation(scene)


def demoReflection(scene: Scene, title: str = "Reflection") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showReflection(scene)


def demoRotation(scene: Scene, title: str = "Rotation") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showRotation(scene)


def demoDilation(scene: Scene, title: str = "Dilation") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showDilation(scene)


def demoSupplementaryAngles(scene: Scene, title: str = "Supplementary") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showSupplementaryAngles(scene)


def demoCongruenceASA(scene: Scene, title: str = "ASA") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showCongruenceASA(scene)


def demoCongruenceHL(scene: Scene, title: str = "HL") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showCongruenceHL(scene)


def demoSameSideInterior(scene: Scene, title: str = "Same-Side Interior") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=32)))
    showSameSideInterior(scene)


def demoTriangleInequality(scene: Scene, title: str = "Triangle Inequality") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showTriangleInequality(scene)


def demoMidsegment(scene: Scene, title: str = "Midsegment") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showMidsegment(scene)


def demoIsoscelesTriangle(scene: Scene, title: str = "Isosceles") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showIsoscelesTriangle(scene)


def demoClassifyTriangles(scene: Scene, title: str = "Classify Triangles") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showClassifyTriangles(scene)


def demoLawOfSines(scene: Scene, title: str = "Law of Sines") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showLawOfSines(scene)


def demoLawOfCosines(scene: Scene, title: str = "Law of Cosines") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showLawOfCosines(scene)


def demoPerimeter(scene: Scene, title: str = "Perimeter") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showPolygonPerimeter(scene)


def demoCircumference(scene: Scene, title: str = "Circumference") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showCircumference(scene)


def demoParallelogramArea(scene: Scene, title: str = "Parallelogram") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showParallelogramArea(scene)


def demoSectorArea(scene: Scene, title: str = "Sector Area") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showSectorArea(scene)


def demoArcLength(scene: Scene, title: str = "Arc Length") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showArcLength(scene)


def demoThalesTheorem(scene: Scene, title: str = "Thales") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showThalesTheorem(scene)


def demoBoxSurfaceArea(scene: Scene, title: str = "Surface Area") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showBoxSurfaceArea(scene)


def demoCrossSection(scene: Scene, title: str = "Cross Section") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showCrossSection(scene)


def demoParallelSlopes(scene: Scene, title: str = "Parallel Slopes") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showParallelLinesSlope(scene)


def demoPerpendicularSlopes(scene: Scene, title: str = "Perpendicular Slopes") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=32)))
    showPerpendicularLinesSlope(scene)


def demoLineSymmetry(scene: Scene, title: str = "Line Symmetry") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showLineSymmetry(scene)
