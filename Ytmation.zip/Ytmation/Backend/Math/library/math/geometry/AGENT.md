# Geometry Library — Agent Cookbook

Pure Euclidean / coordinate geometry for workflows. **Conics** (parabola, ellipse, hyperbola as graphs) stay in `algebra/conics.py`. **Trig waves** also in `trigonometry/`.

## API layers

| Prefix | Use when |
|--------|----------|
| `make…` | Mobjects only |
| `show…` | One beat |
| `demo…` | Full topic (`recipes.py`) |

## Module map (~85–90% intro high-school geometry)

| File | Topics |
|------|--------|
| `pythagorean.py` | a²+b²=c² squares |
| `circle_pi.py` | C=2πr unwrap |
| `sine_wave.py` | unit circle → sine graph |
| `triangles.py` | angle sum, exterior, 3-4-5 / 45-45-90, inequality, midsegment, isosceles, classify |
| `angles.py` | vertical, complementary, supplementary, bisector |
| `parallel_lines.py` | transversal, alternate interior, same-side interior |
| `congruence.py` | SSS, SAS, ASA, HL |
| `similarity.py` | scale factor, AA |
| `laws.py` | law of sines, law of cosines |
| `polygons.py` | regular n-gon, (n−2)·180° |
| `circles.py` | central, inscribed, tangent⊥radius, chord, Thales (semicircle) |
| `perimeter.py` | polygon perimeter, circumference |
| `area.py` | rectangle, triangle, circle, trapezoid, parallelogram, sector, arc length |
| `solids.py` | prism/cylinder/cone/sphere volume, box SA, cross-section |
| `coordinate.py` | distance, midpoint, slope, parallel/perp slopes |
| `rigid_motion.py` | translate, reflect, rotate, dilate |
| `symmetry.py` | line symmetry |
| `recipes.py` | all `demo…` |

## Recipes (56 demos)

See `recipes.py` for full list — includes angle pairs, all congruence shortcuts, triangle tools, circle arc/sector, perimeter, coordinate slopes, solids SA/cross-section, laws, symmetry.

## Showcase

```bash
python Workflows/channels/mathmwk/geometryShowcase.py
```

## Optional later

Compass constructions, 3D Manim solids, coordinate proofs, transformations via matrices (`linear_algebra`).
