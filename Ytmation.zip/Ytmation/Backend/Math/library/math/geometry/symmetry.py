"""Symmetry — line symmetry."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath


def showLineSymmetry(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axis = DashedLine(UP * 2.5, DOWN * 2.5, color=YELLOW, stroke_width=2)
    butterfly = VGroup(
        Polygon(ORIGIN, LEFT * 1.2 + UP * 0.8, LEFT * 0.5 + UP * 1.8, color=BLUE, fill_opacity=0.4),
        Polygon(ORIGIN, RIGHT * 1.2 + UP * 0.8, RIGHT * 0.5 + UP * 1.8, color=BLUE, fill_opacity=0.4),
    )
    cap = makeMath(r"\text{reflection symmetry}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axis), Create(butterfly), run_time=run_time)
    return VGroup(axis, butterfly, cap)
