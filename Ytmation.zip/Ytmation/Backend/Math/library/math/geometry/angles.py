"""Angles — pairs, bisector."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath, makeAngleArc


def showVerticalAngles(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    center = ORIGIN
    l1 = Line(center + UL * 2.5, center + DR * 2.5, color=WHITE)
    l2 = Line(center + UR * 2.2, center + DL * 2.2, color=WHITE)
    a1 = makeAngleArc(center, center + UL, center + UR, color=BLUE)
    a2 = makeAngleArc(center, center + DR, center + DL, color=BLUE)
    cap = makeMath(r"\text{vertical angles equal}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(l1), Create(l2), Create(a1), Create(a2), run_time=run_time)
    return VGroup(l1, l2, a1, a2, cap)


def showComplementaryAngles(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    origin = LEFT * 2 + DOWN
    base = Line(origin, origin + RIGHT * 4, color=GREY_B)
    slant = Line(origin, origin + 2.2 * (RIGHT + UP * 0.75), color=WHITE)
    arc = makeAngleArc(origin, origin + RIGHT, origin + 2.2 * (RIGHT + UP * 0.75), color=YELLOW)
    cap = makeMath(r"\alpha+\beta=90^\circ").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(base), Create(slant), Create(arc), run_time=run_time)
    return VGroup(base, slant, arc, cap)


def showAngleBisector(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    v = ORIGIN + DOWN * 0.5
    ray1 = Line(v, v + UP * 2.5 + LEFT * 1.2, color=WHITE)
    ray2 = Line(v, v + UP * 2.5 + RIGHT * 1.8, color=WHITE)
    bisect = Line(v, v + UP * 2.8, color="#FF4500", stroke_width=3)
    cap = makeMath(r"\text{angle bisector}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(ray1), Create(ray2), run_time=run_time * 0.5)
    scene.play(Create(bisect), run_time=run_time * 0.5)
    return VGroup(ray1, ray2, bisect, cap)


def showSupplementaryAngles(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    origin = ORIGIN + DOWN * 0.5
    line = Line(origin + LEFT * 3.5, origin + RIGHT * 3.5, color=GREY_B, stroke_width=3)
    ray = Line(origin, origin + UP * 2.2 + RIGHT * 1.5, color=WHITE)
    a1 = makeAngleArc(origin, origin + RIGHT, origin + UP + RIGHT * 0.7, radius=0.45, color=BLUE)
    a2 = makeAngleArc(origin, origin + UP + RIGHT * 0.7, origin + LEFT, radius=0.45, color="#FF4500")
    cap = makeMath(r"\alpha+\beta=180^\circ").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(line), Create(ray), Create(a1), Create(a2), run_time=run_time)
    return VGroup(line, ray, a1, a2, cap)
