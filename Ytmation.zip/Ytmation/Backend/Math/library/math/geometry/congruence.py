"""Triangle congruence — SSS, SAS, ASA markings."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath
from Math.library.math.geometry.triangles import makeTriangle


def showCongruenceSSS(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    tri1 = makeTriangle(LEFT * 3 + DOWN, LEFT * 1 + DOWN, LEFT * 2 + UP * 1.5, color=BLUE)
    tri2 = makeTriangle(RIGHT * 1 + DOWN, RIGHT * 3 + DOWN, RIGHT * 2 + UP * 1.5, color="#FF4500")
    cap = makeMath(r"\text{SSS} \Rightarrow \cong").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri1), Create(tri2), run_time=run_time)
    return VGroup(tri1, tri2, cap)


def showCongruenceSAS(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    tri = makeTriangle(LEFT * 2, RIGHT * 2, UP * 2, color=BLUE)
    angle = Arc(radius=0.5, start_angle=0, angle=PI / 3, arc_center=LEFT * 2, color=YELLOW)
    cap = makeMath(r"\text{SAS}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), Create(angle), run_time=run_time)
    return VGroup(tri, angle, cap)


def showCongruenceASA(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    tri = makeTriangle(LEFT * 2.5, RIGHT * 2, UP * 1.8, color=BLUE)
    a1 = Arc(radius=0.45, start_angle=0, angle=PI / 4, arc_center=LEFT * 2.5, color=YELLOW)
    a2 = Arc(radius=0.4, start_angle=PI / 2, angle=-PI / 5, arc_center=RIGHT * 2, color=YELLOW)
    cap = makeMath(r"\text{ASA}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), Create(a1), Create(a2), run_time=run_time)
    return VGroup(tri, a1, a2, cap)


def showCongruenceHL(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    """Right triangles — hypotenuse & leg."""
    p1, p2, p3 = LEFT * 2 + DOWN, LEFT * 2 + UP * 1.8, LEFT * 0.2 + DOWN
    tri = makeTriangle(p1, p2, p3, color=BLUE)
    right = RightAngle(Line(p1, p3), Line(p1, p2), length=0.25, color=GREEN)
    cap = makeMath(r"\text{HL (right triangles)}").scale(0.8).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), Create(right), run_time=run_time)
    return VGroup(tri, right, cap)
