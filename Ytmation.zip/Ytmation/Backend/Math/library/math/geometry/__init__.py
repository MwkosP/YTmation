"""Geometry building blocks."""

from Math.library.math.geometry.pythagorean import showPythagorean
from Math.library.math.geometry.circle_pi import showCirclePi
from Math.library.math.geometry.triangles import showTriangleAngleSum
from Math.library.math.geometry.circles import showCentralAngle, showInscribedAngle
from Math.library.math.geometry.area import showRectangleArea, showCircleArea
from Math.library.math.geometry import recipes as geometryRecipes

__all__ = [
    "showPythagorean",
    "showCirclePi",
    "showTriangleAngleSum",
    "showCentralAngle",
    "showInscribedAngle",
    "showRectangleArea",
    "showCircleArea",
    "geometryRecipes",
]
