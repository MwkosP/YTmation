"""Polygons — regular polygons, interior angle sum."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath


def showRegularPolygon(
    scene: Scene,
    n: int = 6,
    run_time: float = 2.0,
) -> VGroup:
    poly = RegularPolygon(n=n, radius=2.2, color=BLUE, stroke_width=3)
    cap = makeMath(rf"n={n}\ \text{{regular}}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(poly), run_time=run_time)
    return VGroup(poly, cap)


def showInteriorAngleSum(
    scene: Scene,
    n: int = 5,
    run_time: float = 2.2,
) -> VGroup:
    poly = RegularPolygon(n=n, radius=2.0, color=BLUE)
    formula = makeMath(rf"(n-2)\cdot 180^\circ = {(n-2)*180}^\circ").to_edge(UP, buff=0.45)
    scene.play(Write(formula), Create(poly), run_time=run_time)
    return VGroup(poly, formula)
