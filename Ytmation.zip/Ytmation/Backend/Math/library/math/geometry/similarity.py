"""Similar figures — scale factor."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath
from Math.library.math.geometry.triangles import makeTriangle


def showSimilarTriangles(
    scene: Scene,
    scale: float = 1.6,
    run_time: float = 2.2,
) -> VGroup:
    small = makeTriangle(LEFT * 3 + DOWN, LEFT * 1.5 + DOWN, LEFT * 2.2 + UP, color=BLUE)
    big = makeTriangle(RIGHT * 0.5 + DOWN, RIGHT * 3.5 + DOWN, RIGHT * 2 + UP * 2.2, color="#FF4500")
    cap = makeMath(rf"\text{{scale }} k={scale}").to_edge(UP, buff=0.45)
    arrow = DoubleArrow(small.get_right(), big.get_left(), buff=0.2, color=YELLOW)
    scene.play(Write(cap), Create(small), Create(big), GrowArrow(arrow), run_time=run_time)
    return VGroup(small, big, arrow, cap)


def showAASimilarity(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    cap = makeMath(r"\text{AA} \Rightarrow \sim").to_edge(UP, buff=0.45)
    t1 = makeTriangle(LEFT * 3, LEFT * 1.5, LEFT * 2 + UP * 1.2, color=BLUE)
    t2 = makeTriangle(RIGHT * 0.5, RIGHT * 3, RIGHT * 1.8 + UP * 2, color="#FF4500")
    scene.play(Write(cap), Create(t1), Create(t2), run_time=run_time)
    return VGroup(t1, t2, cap)
