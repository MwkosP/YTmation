"""Law of sines and cosines — triangle geometry."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath
from Math.library.math.geometry.triangles import makeTriangle


def showLawOfSines(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    p1, p2, p3 = LEFT * 2 + DOWN, RIGHT * 2.5 + DOWN, RIGHT * 0.3 + UP * 2
    tri = makeTriangle(p1, p2, p3, color=BLUE)
    cap = makeMath(r"\frac{a}{\sin A}=\frac{b}{\sin B}=\frac{c}{\sin C}").scale(0.7).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), run_time=run_time)
    return VGroup(tri, cap)


def showLawOfCosines(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    tri = makeTriangle(LEFT * 2, RIGHT * 2, UP * 1.5 + RIGHT * 0.5, color=BLUE)
    cap = makeMath(r"c^2=a^2+b^2-2ab\cos C").scale(0.85).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), run_time=run_time)
    return VGroup(tri, cap)
