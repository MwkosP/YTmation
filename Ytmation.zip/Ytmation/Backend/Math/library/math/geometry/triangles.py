"""Triangles — types, angle sum, special triangles."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath, makeAngleArc, labelSegment


def makeTriangle(
    p1: np.ndarray,
    p2: np.ndarray,
    p3: np.ndarray,
    color=WHITE,
) -> Polygon:
    return Polygon(p1, p2, p3, color=color, stroke_width=3)


def showTriangleAngleSum(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    """Interior angles α+β+γ = 180°."""
    p1, p2, p3 = LEFT * 2 + DOWN, RIGHT * 2 + DOWN, ORIGIN + UP * 2.2
    tri = makeTriangle(p1, p2, p3)
    arcs = VGroup(
        makeAngleArc(p1, p2, p3, radius=0.4, color=BLUE),
        makeAngleArc(p2, p3, p1, radius=0.4, color="#FF4500"),
        makeAngleArc(p3, p1, p2, radius=0.4, color=GREEN),
    )
    cap = makeMath(r"\alpha+\beta+\gamma=180^\circ").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), run_time=run_time * 0.45)
    scene.play(*[Create(a) for a in arcs], run_time=run_time * 0.55)
    return VGroup(tri, arcs, cap)


def showExteriorAngle(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    p1, p2, p3 = LEFT * 2, RIGHT * 1.5, LEFT * 0.5 + UP * 2
    tri = makeTriangle(p1, p2, p3)
    ext = Line(p1, p1 + RIGHT * 2.5, color=YELLOW, stroke_width=3)
    cap = makeMath(r"\text{exterior}=\alpha+\beta").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), Create(ext), run_time=run_time)
    return VGroup(tri, ext, cap)


def showSpecialRightTriangle(
    scene: Scene,
    kind: str = "345",
    run_time: float = 2.0,
) -> VGroup:
    """345 or 45-45-90 triangle with side labels."""
    if kind == "4545":
        p1, p2, p3 = ORIGIN + LEFT * 2 + DOWN, ORIGIN + RIGHT * 2 + DOWN, ORIGIN + LEFT * 2 + UP * 2
        labels = ("a", "a", r"a\sqrt{2}")
    else:
        p1, p2, p3 = ORIGIN + LEFT * 2.4 + DOWN, ORIGIN + RIGHT * 1.6 + DOWN, ORIGIN + LEFT * 2.4 + UP * 1.8
        labels = ("3", "4", "5")
    tri = makeTriangle(p1, p2, p3, color=BLUE)
    mids = [(p1 + p2) / 2, (p2 + p3) / 2, (p3 + p1) / 2]
    dirs = [DOWN, RIGHT, LEFT]
    lbls = VGroup(*[labelSegment(m, t, d) for m, t, d in zip(mids, labels, dirs)])
    cap = makeMath(r"45^\circ\text{-}45^\circ\text{-}90^\circ" if kind == "4545" else r"3\text{-}4\text{-}5").to_edge(
        UP, buff=0.45
    )
    scene.play(Write(cap), Create(tri), FadeIn(lbls), run_time=run_time)
    return VGroup(tri, lbls, cap)


def showTriangleInequality(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    a, b, c = 3.0, 4.0, 6.0
    seg_a = Line(ORIGIN, RIGHT * a, color=BLUE, stroke_width=5)
    seg_b = Line(RIGHT * a, RIGHT * (a + b), color="#FF4500", stroke_width=5).shift(UP * 0.3)
    cap = makeMath(r"a+b>c").to_edge(UP, buff=0.45)
    note = makeMath(rf"{a}+{b}>{c}\ \checkmark", scale=0.75).next_to(seg_b, DOWN, buff=0.5)
    scene.play(Write(cap), Create(seg_a), Create(seg_b), Write(note), run_time=run_time)
    return VGroup(seg_a, seg_b, cap, note)


def showMidsegment(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    p1, p2, p3 = LEFT * 2.5 + DOWN, RIGHT * 2.5 + DOWN, ORIGIN + UP * 2.2
    tri = makeTriangle(p1, p2, p3, color=BLUE)
    mid1, mid2 = (p1 + p2) / 2, (p1 + p3) / 2
    midseg = Line(mid1, mid2, color="#FF4500", stroke_width=4)
    cap = makeMath(r"\text{midsegment} \parallel \text{base},\ \frac12\text{length}").scale(0.7).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), Create(midseg), run_time=run_time)
    return VGroup(tri, midseg, cap)


def showIsoscelesTriangle(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    p1, p2, p3 = LEFT * 2 + DOWN, RIGHT * 2 + DOWN, ORIGIN + UP * 2.2
    tri = makeTriangle(p1, p2, p3, color=BLUE)
    ticks = VGroup(
        Line((p1 + p3) / 2 + LEFT * 0.08, (p1 + p3) / 2 + RIGHT * 0.08, color=YELLOW),
        Line((p2 + p3) / 2 + LEFT * 0.08, (p2 + p3) / 2 + RIGHT * 0.08, color=YELLOW),
    )
    cap = makeMath(r"\text{two equal sides}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), Create(ticks), run_time=run_time)
    return VGroup(tri, ticks, cap)


def showClassifyTriangles(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    equilateral = RegularPolygon(3, radius=0.9, color=BLUE).shift(LEFT * 3.5)
    isosceles = makeTriangle(LEFT * 0.5 + DOWN, RIGHT * 1.5 + DOWN, ORIGIN + UP * 1.2, color="#FF4500")
    scalene = makeTriangle(RIGHT * 2.5 + DOWN, RIGHT * 4.2 + DOWN, RIGHT * 3 + UP * 1.5, color=GREEN)
    labels = VGroup(
        makeMath(r"\text{equilateral}", scale=0.6).next_to(equilateral, DOWN, buff=0.2),
        makeMath(r"\text{isosceles}", scale=0.6).next_to(isosceles, DOWN, buff=0.2),
        makeMath(r"\text{scalene}", scale=0.6).next_to(scalene, DOWN, buff=0.2),
    )
    cap = makeMath(r"\text{classify by sides}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(equilateral), Create(isosceles), Create(scalene), FadeIn(labels), run_time=run_time)
    return VGroup(equilateral, isosceles, scalene, labels, cap)
