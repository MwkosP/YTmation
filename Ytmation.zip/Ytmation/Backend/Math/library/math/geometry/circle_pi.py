"""Circle circumference unwrap hint."""

from manim import *
import numpy as np


def showCirclePi(
    scene: Scene,
    radius: float = 1.5,
    run_time: float = 2.5,
) -> VGroup:
    circle = Circle(radius=radius, color=BLUE, stroke_width=3)
    diameter = Line(LEFT * radius, RIGHT * radius, color=GREY_B)
    r_label = MathTex("r", color=WHITE).next_to(diameter, DOWN, buff=0.1)
    formula = MathTex(r"C=2\pi r", color="#FF4500").scale(0.9).to_edge(UP, buff=0.4)
    line = Line(LEFT * PI * radius, RIGHT * PI * radius, color=YELLOW).shift(DOWN * 2)
    line_label = MathTex(r"\pi d", color=YELLOW).scale(0.7).next_to(line, DOWN, buff=0.15)
    scene.play(Create(circle), Write(formula), run_time=run_time * 0.4)
    scene.play(Create(diameter), Write(r_label), run_time=run_time * 0.3)
    scene.play(TransformFromCopy(circle, line), FadeIn(line_label), run_time=run_time * 0.3)
    return VGroup(circle, diameter, formula, line)
