"""Rigid motions and dilations — shape on plane."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath


def showTranslation(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    tri = Triangle(color=BLUE, fill_opacity=0.35).scale(0.9).shift(LEFT * 2)
    moved = tri.copy().set_color("#FF4500").shift(RIGHT * 3.5)
    arrow = Arrow(tri.get_center(), moved.get_center(), buff=0.1, color=YELLOW)
    cap = makeMath(r"\vec{T}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), FadeIn(tri), run_time=run_time * 0.35)
    scene.play(GrowArrow(arrow), TransformFromCopy(tri, moved), run_time=run_time * 0.65)
    return VGroup(tri, moved, arrow, cap)


def showReflection(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axis = Line(UP * 2.5, DOWN * 2.5, color=GREY_B, stroke_width=2)
    tri = Triangle(color=BLUE, fill_opacity=0.35).scale(0.9).shift(LEFT * 1.5)
    reflected = tri.copy().stretch(-1, 0, about_point=ORIGIN)
    reflected.set_color("#FF4500")
    cap = makeMath(r"\text{reflection}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axis), FadeIn(tri), run_time=run_time * 0.45)
    scene.play(TransformFromCopy(tri, reflected), run_time=run_time * 0.55)
    return VGroup(axis, tri, reflected, cap)


def showRotation(
    scene: Scene,
    angle: float = PI / 3,
    run_time: float = 2.2,
) -> VGroup:
    tri = Triangle(color=BLUE, fill_opacity=0.35).scale(0.9)
    pivot = Dot(ORIGIN, color=YELLOW)
    rotated = tri.copy().set_color("#FF4500").rotate(angle, about_point=ORIGIN)
    cap = makeMath(r"\text{rotation}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), FadeIn(tri), FadeIn(pivot), run_time=run_time * 0.35)
    scene.play(Rotate(tri, angle=angle, about_point=ORIGIN), run_time=run_time * 0.65)
    return VGroup(tri, pivot, cap)


def showDilation(
    scene: Scene,
    scale: float = 1.8,
    run_time: float = 2.0,
) -> VGroup:
    sq = Square(side_length=1.4, color=BLUE, fill_opacity=0.35).shift(LEFT * 2)
    big = sq.copy().scale(scale).set_color("#FF4500").shift(RIGHT * 2.5)
    cap = makeMath(rf"\text{{dilation }} k={scale}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), FadeIn(sq), TransformFromCopy(sq, big), run_time=run_time)
    return VGroup(sq, big, cap)
