"""Perimeter and circumference."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath, labelSegment


def showPolygonPerimeter(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    rect = Rectangle(width=3.5, height=2, color=BLUE, fill_opacity=0.2)
    lbl = VGroup(
        labelSegment(rect.get_bottom(), "a", DOWN),
        labelSegment(rect.get_right(), "b", RIGHT),
    )
    cap = makeMath(r"P=2a+2b").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(rect), FadeIn(lbl), run_time=run_time)
    return VGroup(rect, lbl, cap)


def showCircumference(
    scene: Scene,
    radius: float = 1.6,
    run_time: float = 2.0,
) -> VGroup:
    c = Circle(radius=radius, color=BLUE)
    cap = makeMath(r"C=2\pi r=\pi d").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(c), run_time=run_time)
    return VGroup(c, cap)
