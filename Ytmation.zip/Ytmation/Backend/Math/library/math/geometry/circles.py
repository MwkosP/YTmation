"""Circle geometry — chords, arcs, inscribed & central angles, tangent."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath, makeAngleArc


def showCentralAngle(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    c = Circle(radius=2, color=BLUE)
    center = c.get_center()
    p1 = center + RIGHT * 2
    p2 = center + 2 * np.array([np.cos(PI / 3), np.sin(PI / 3), 0])
    r1, r2 = Line(center, p1, color=YELLOW), Line(center, p2, color=YELLOW)
    arc = Arc(radius=0.55, start_angle=0, angle=PI / 3, arc_center=center, color="#FF4500")
    cap = makeMath(r"\text{central angle}=\text{arc}").scale(0.8).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(c), Create(r1), Create(r2), Create(arc), run_time=run_time)
    return VGroup(c, r1, r2, arc, cap)


def showInscribedAngle(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    c = Circle(radius=2, color=BLUE)
    center = c.get_center()
    a = center + 2 * np.array([np.cos(-0.8), np.sin(-0.8), 0])
    b = center + 2 * np.array([np.cos(0.9), np.sin(0.9), 0])
    p = center + 2 * np.array([np.cos(2.2), np.sin(2.2), 0])
    chords = VGroup(Line(a, p, color=WHITE), Line(b, p, color=WHITE))
    cap = makeMath(r"\text{inscribed}=\frac12\text{central}").scale(0.75).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(c), Create(chords), run_time=run_time)
    return VGroup(c, chords, cap)


def showTangentRadius(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    c = Circle(radius=1.8, color=BLUE)
    center = c.get_center()
    touch = center + RIGHT * 1.8
    tangent = Line(touch + UP * 2, touch + DOWN * 2, color=YELLOW, stroke_width=3)
    radius = Line(center, touch, color="#FF4500")
    right = RightAngle(radius, tangent, length=0.25, color=GREEN)
    cap = makeMath(r"\text{tangent}\perp\text{radius}").scale(0.8).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(c), Create(radius), Create(tangent), Create(right), run_time=run_time)
    return VGroup(c, radius, tangent, right, cap)


def showChordAndArc(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    c = Circle(radius=2, color=BLUE)
    center = c.get_center()
    p1 = center + UL * 1.4
    p2 = center + DR * 1.4
    chord = Line(p1, p2, color=YELLOW, stroke_width=4)
    cap = makeMath(r"\text{chord}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(c), Create(chord), run_time=run_time)
    return VGroup(c, chord, cap)


def showThalesTheorem(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    """Inscribed angle in a semicircle is 90°."""
    diameter = Line(LEFT * 2, RIGHT * 2, color=GREY_B, stroke_width=3)
    semi = Arc(radius=2, start_angle=0, angle=PI, arc_center=ORIGIN, color=BLUE, stroke_width=3)
    p = ORIGIN + UP * 2
    tri = Polygon(LEFT * 2, RIGHT * 2, p, color=YELLOW, stroke_width=2)
    right = RightAngle(Line(p, LEFT * 2), Line(p, RIGHT * 2), length=0.3, color=GREEN)
    cap = makeMath(r"\text{inscribed in semicircle} \Rightarrow 90^\circ").scale(0.7).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(diameter), Create(semi), Create(tri), Create(right), run_time=run_time)
    return VGroup(diameter, semi, tri, right, cap)
