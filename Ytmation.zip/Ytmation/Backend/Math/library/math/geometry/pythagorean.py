"""Pythagorean theorem visual."""

from manim import *
import numpy as np


def showPythagorean(
    scene: Scene,
    a: float = 3.0,
    b: float = 4.0,
    run_time: float = 2.5,
) -> VGroup:
    c = np.sqrt(a * a + b * b)
    tri = Polygon(
        ORIGIN,
        RIGHT * a,
        RIGHT * a + UP * b,
        color=WHITE,
        stroke_width=3,
    ).shift(LEFT * 2 + DOWN * 0.5)
    sq_a = Square(side_length=a, color=BLUE, fill_opacity=0.35).next_to(tri, DOWN, buff=0).align_to(tri, LEFT)
    sq_b = Square(side_length=b, color="#FF4500", fill_opacity=0.35).next_to(tri, RIGHT, buff=0).align_to(tri, UP)
    sq_c = Square(side_length=c, color=YELLOW, fill_opacity=0.35).rotate(
        np.arctan2(b, a)
    ).move_to(tri.get_center() + (RIGHT * a + UP * b) / 2 + UL * 0.3)
    labels = MathTex(r"a^2+b^2=c^2", color=WHITE).scale(0.9).to_edge(UP, buff=0.4)
    scene.play(Create(tri), run_time=run_time * 0.35)
    scene.play(FadeIn(sq_a), FadeIn(sq_b), run_time=run_time * 0.35)
    scene.play(FadeIn(sq_c), Write(labels), run_time=run_time * 0.3)
    return VGroup(tri, sq_a, sq_b, sq_c, labels)
