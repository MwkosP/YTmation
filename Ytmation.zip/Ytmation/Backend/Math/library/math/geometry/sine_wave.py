"""Unit circle connection to sine (geometry view)."""

from manim import *
import numpy as np


def showUnitCircleSine(
    scene: Scene,
    angle_tracker: ValueTracker | None = None,
    run_time: float = 3.0,
) -> tuple[ValueTracker, VGroup]:
    t = angle_tracker or ValueTracker(0.0)
    circle = Circle(radius=1.5, color=GREY_B).shift(LEFT * 3)
    axes = Axes(x_range=[0, TAU, PI / 2], y_range=[-1.5, 1.5, 1], x_length=5, y_length=2.5).shift(RIGHT * 2.5)
    dot = always_redraw(
        lambda: Dot(
            circle.get_center() + 1.5 * np.array([np.cos(t.get_value()), np.sin(t.get_value()), 0]),
            color=YELLOW,
        )
    )
    radius_line = always_redraw(
        lambda: Line(circle.get_center(), dot.get_center(), color=YELLOW)
    )
    wave = always_redraw(
        lambda: axes.plot(
            lambda x: np.sin(x),
            x_range=[0, max(0.01, t.get_value())],
            color=BLUE,
        )
    )

    scene.add(circle, axes, dot, radius_line, wave)
    scene.play(t.animate.set_value(TAU), run_time=run_time, rate_func=linear)
    return t, VGroup(circle, axes, dot, radius_line, wave)
