"""Parallel lines and transversals."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath, makeAngleArc


def showParallelLinesTransversal(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    y1, y2 = 1.2, -1.0
    line1 = Line(LEFT * 4 + UP * y1, RIGHT * 4 + UP * y1, color=BLUE)
    line2 = Line(LEFT * 4 + UP * y2, RIGHT * 4 + UP * y2, color=BLUE)
    trans = Line(LEFT * 2 + UP * 2.5, RIGHT * 3 + DOWN * 2.2, color=WHITE, stroke_width=3)
    p = line1.get_center() + LEFT * 0.5
    corr = makeAngleArc(p, p + RIGHT, p + UP + RIGHT * 0.3, radius=0.35, color=YELLOW)
    cap = makeMath(r"\text{corresponding angles}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(line1), Create(line2), Create(trans), run_time=run_time * 0.55)
    scene.play(Create(corr), run_time=run_time * 0.45)
    return VGroup(line1, line2, trans, corr, cap)


def showAlternateInteriorAngles(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    line1 = Line(LEFT * 4 + UP * 1, RIGHT * 4 + UP * 1, color=BLUE)
    line2 = Line(LEFT * 4 + DOWN * 1, RIGHT * 4 + DOWN * 1, color=BLUE)
    trans = Line(LEFT * 1 + UP * 2.5, RIGHT * 2 + DOWN * 2.5, color=WHITE)
    cap = makeMath(r"\text{alternate interior}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(line1), Create(line2), Create(trans), run_time=run_time)
    return VGroup(line1, line2, trans, cap)


def showSameSideInterior(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    line1 = Line(LEFT * 4 + UP * 1, RIGHT * 4 + UP * 1, color=BLUE)
    line2 = Line(LEFT * 4 + DOWN * 1, RIGHT * 4 + DOWN * 1, color=BLUE)
    trans = Line(LEFT * 2 + UP * 2.5, RIGHT * 3 + DOWN * 2.2, color=WHITE, stroke_width=3)
    cap = makeMath(r"\text{same-side interior sum to }180^\circ").scale(0.75).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(line1), Create(line2), Create(trans), run_time=run_time)
    return VGroup(line1, line2, trans, cap)
