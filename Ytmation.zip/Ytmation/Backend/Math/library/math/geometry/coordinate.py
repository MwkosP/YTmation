"""Coordinate geometry — distance, midpoint, slope."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.geometry._core import makeMath


def showDistanceFormula(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-1, 5, 1), y_range=(-1, 5, 1))
    axes = axes_g[0]
    p1, p2 = axes.c2p(1, 1), axes.c2p(4, 4)
    seg = Line(p1, p2, color=YELLOW, stroke_width=4)
    d1 = DashedLine(p1, axes.c2p(4, 1), color=GREY_B)
    d2 = DashedLine(axes.c2p(4, 1), p2, color=GREY_B)
    cap = makeMath(r"d=\sqrt{(x_2-x_1)^2+(y_2-y_1)^2}").scale(0.75).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(seg), Create(d1), Create(d2), run_time=run_time)
    return VGroup(axes_g, seg, d1, d2, cap)


def showMidpoint(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-1, 5, 1), y_range=(-1, 5, 1))
    axes = axes_g[0]
    p1, p2 = axes.c2p(0.5, 1), axes.c2p(4, 3)
    mid = (p1 + p2) / 2
    seg = Line(p1, p2, color=BLUE)
    dot = Dot(mid, color=YELLOW)
    cap = makeMath(r"M=\left(\frac{x_1+x_2}{2},\frac{y_1+y_2}{2}\right)").scale(0.7).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(seg), FadeIn(dot), run_time=run_time)
    return VGroup(axes_g, seg, dot, cap)


def showSlope(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-1, 5, 1), y_range=(-1, 5, 1))
    axes = axes_g[0]
    line = axes.plot(lambda x: 0.6 * x + 0.5, x_range=[0, 4], color=BLUE)
    cap = makeMath(r"m=\frac{\Delta y}{\Delta x}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(line), run_time=run_time)
    return VGroup(axes_g, line, cap)


def showParallelLinesSlope(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-1, 5, 1), y_range=(-1, 5, 1))
    axes = axes_g[0]
    l1 = axes.plot(lambda x: 0.5 * x + 1, x_range=[0, 4], color=BLUE)
    l2 = axes.plot(lambda x: 0.5 * x - 0.5, x_range=[0, 4], color="#FF4500")
    cap = makeMath(r"m_1=m_2 \Rightarrow \parallel").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(l1), Create(l2), run_time=run_time)
    return VGroup(axes_g, l1, l2, cap)


def showPerpendicularLinesSlope(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-1, 5, 1), y_range=(-1, 5, 1))
    axes = axes_g[0]
    l1 = axes.plot(lambda x: 0.6 * x + 0.5, x_range=[0, 4], color=BLUE)
    l2 = axes.plot(lambda x: (-1 / 0.6) * x + 3.5, x_range=[0, 4], color="#FF4500")
    cap = makeMath(r"m_1 m_2=-1 \Rightarrow \perp").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(l1), Create(l2), run_time=run_time)
    return VGroup(axes_g, l1, l2, cap)
