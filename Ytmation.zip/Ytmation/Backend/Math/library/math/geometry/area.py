"""Area formulas — plane figures."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath, labelSegment
from Math.library.math.geometry.triangles import makeTriangle


def showRectangleArea(
    scene: Scene,
    w: float = 4.0,
    h: float = 2.5,
    run_time: float = 2.0,
) -> VGroup:
    rect = Rectangle(width=w, height=h, color=BLUE, fill_opacity=0.35)
    lbl = VGroup(
        labelSegment(rect.get_bottom(), "b", DOWN),
        labelSegment(rect.get_right(), "h", RIGHT),
    )
    cap = makeMath(r"A=bh").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(rect), FadeIn(lbl), run_time=run_time)
    return VGroup(rect, lbl, cap)


def showTriangleArea(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    p1, p2, p3 = LEFT * 2 + DOWN, RIGHT * 2 + DOWN, RIGHT * 0.5 + UP * 2
    tri = makeTriangle(p1, p2, p3, color=BLUE).set_fill(BLUE, opacity=0.35)
    base = DashedLine(p1, p2, color=YELLOW)
    height = DashedLine((p1 + p2) / 2, p3, color=YELLOW)
    cap = makeMath(r"A=\frac12 bh").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(tri), Create(base), Create(height), run_time=run_time)
    return VGroup(tri, base, height, cap)


def showCircleArea(
    scene: Scene,
    radius: float = 1.8,
    run_time: float = 2.0,
) -> VGroup:
    c = Circle(radius=radius, color=BLUE, fill_opacity=0.35)
    r_line = Line(c.get_center(), c.get_center() + RIGHT * radius, color=YELLOW)
    cap = makeMath(r"A=\pi r^2").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(c), Create(r_line), run_time=run_time)
    return VGroup(c, r_line, cap)


def showTrapezoidArea(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    trap = Polygon(
        LEFT * 2 + DOWN,
        RIGHT * 2 + DOWN,
        RIGHT * 1 + UP,
        LEFT * 1 + UP,
        color=BLUE,
        fill_opacity=0.35,
        stroke_width=3,
    )
    cap = makeMath(r"A=\frac12(b_1+b_2)h").scale(0.85).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(trap), run_time=run_time)
    return VGroup(trap, cap)


def showParallelogramArea(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    para = Polygon(LEFT * 2 + DOWN, RIGHT * 1.5 + DOWN, RIGHT * 2.5 + UP, LEFT * 0.5 + UP, color=BLUE, fill_opacity=0.35)
    height = DashedLine(RIGHT * 1.5 + DOWN, RIGHT * 1.5 + UP, color=YELLOW)
    cap = makeMath(r"A=bh").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(para), Create(height), run_time=run_time)
    return VGroup(para, height, cap)


def showSectorArea(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    c = Circle(radius=2, color=BLUE)
    center = c.get_center()
    sector = Sector(radius=2, angle=PI / 2, start_angle=0, color="#FF4500", fill_opacity=0.4).move_to(center)
    cap = makeMath(r"A=\frac{\theta}{360^\circ}\pi r^2").scale(0.75).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(c), FadeIn(sector), run_time=run_time)
    return VGroup(c, sector, cap)


def showArcLength(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    c = Circle(radius=2, color=BLUE)
    center = c.get_center()
    arc = Arc(radius=2, start_angle=0, angle=PI / 2, arc_center=center, color="#FF4500", stroke_width=5)
    cap = makeMath(r"L=\frac{\theta}{360^\circ}\cdot 2\pi r").scale(0.7).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(c), Create(arc), run_time=run_time)
    return VGroup(c, arc, cap)
