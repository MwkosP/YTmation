"""Solid geometry — volume schematics (2D cross-section style)."""

from manim import *
import numpy as np

from Math.library.math.geometry._core import makeMath


def showPrismVolume(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    base = Rectangle(width=3, height=1.2, color=BLUE, fill_opacity=0.3)
    top = base.copy().shift(UP * 2 + RIGHT * 0.4).set_stroke("#FF4500")
    edges = VGroup(*[Line(base.get_corner(c), top.get_corner(c), color=GREY_B) for c in (DL, DR, UR, UL)])
    cap = makeMath(r"V=Bh").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(base), Create(top), Create(edges), run_time=run_time)
    return VGroup(base, top, edges, cap)


def showCylinderVolume(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    body = Rectangle(width=2.2, height=2.8, color=BLUE, fill_opacity=0.25)
    top = Ellipse(width=2.2, height=0.5, color=BLUE).next_to(body, UP, buff=0)
    cap = makeMath(r"V=\pi r^2 h").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(body), Create(top), run_time=run_time)
    return VGroup(body, top, cap)


def showConeVolume(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    cone = Polygon(LEFT * 1.2 + DOWN, RIGHT * 1.2 + DOWN, ORIGIN + UP * 2.5, color="#FF4500", fill_opacity=0.35)
    cap = makeMath(r"V=\frac13\pi r^2 h").scale(0.85).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(cone), run_time=run_time)
    return VGroup(cone, cap)


def showSphereVolume(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    sphere = Circle(radius=1.8, color=BLUE, fill_opacity=0.35)
    cap = makeMath(r"V=\frac43\pi r^3").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(sphere), run_time=run_time)
    return VGroup(sphere, cap)


def showBoxSurfaceArea(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    box = Square(side_length=2.2, color=BLUE, fill_opacity=0.25).shift(LEFT * 0.5)
    front = box.copy().set_stroke("#FF4500").shift(RIGHT * 2.8 + UP * 0.3)
    cap = makeMath(r"SA=2(lw+lh+wh)").scale(0.85).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(box), Create(front), run_time=run_time)
    return VGroup(box, front, cap)


def showCrossSection(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    """Horizontal slice through a cylinder schematic."""
    body = Rectangle(width=2, height=2.6, color=BLUE, fill_opacity=0.2)
    slice_ellipse = Ellipse(width=2, height=0.45, color="#FF4500", fill_opacity=0.45).move_to(body.get_center())
    cap = makeMath(r"\text{cross-section}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(body), FadeIn(slice_ellipse), run_time=run_time)
    return VGroup(body, slice_ellipse, cap)
