# Math Library (`library/math`)

Pure mathematics building blocks — **no physics/ML/economics narrative**.

Other packages (`physics/`, future `ml/`, `economics/`) import from here instead of duplicating axes, vectors, plots, or algebra. Keep functions topic-specific but reusable: e.g. `makeLabeledAxes`, not `makeProjectileAxes` (that wrapper lives in `physics/`).

## Structure

| Folder | Topics |
|--------|--------|
| `graphs/` | axes, multi-plot, asymptotes, piecewise, polar, scatter, shade, discrete — see `graphs/AGENT.md` |
| `calculus/` | ~90% intro calc: limits, FTC, rules, MVT, series test, volume, ODE, multivar — see `calculus/AGENT.md` |
| `algebra/` | expressions, linear, systems, factoring, quadratics, functions, exp/log, sequences, complex, conics, abstract intro — see `algebra/AGENT.md` |
| `linear_algebra/` | vectors, matrices, transforms, determinant, dot, projection, span, eigen, systems, vector field — see `linear_algebra/AGENT.md` |
| `geometry/` | ~90% intro geometry: triangles, circles, area, solids, transforms — see `geometry/AGENT.md` |
| `trigonometry/` | sine, cosine, superposition, phase |
| `statistics/` | normal distribution, sample means |
| `number_theory/` | prime sieve, number spiral |
| `recipes.py` | one-call demos for agents |

## Usage

```python
def scene1(scene):
    from Math.library.math.recipes import demoPythagorean
    from Math.library.common.styling import setupScene
    setupScene(scene)
    demoPythagorean(scene)
```

See `AGENT.md` for full map.
