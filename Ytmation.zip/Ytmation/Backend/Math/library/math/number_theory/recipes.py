"""Number theory demos — one topic per call."""

from manim import *

from Math.library.common.layout import makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.number_theory.prime_sieve import showPrimeSieve
from Math.library.math.number_theory.number_spiral import showNumberSpiral
from Math.library.math.number_theory.divisibility import (
    showDivisibilityBy2,
    showDivisibilityBy5,
    showDivisibilityByDigitSum,
)
from Math.library.math.number_theory.gcd_lcm import showEuclidAlgorithm, showGcdLcmRelationship
from Math.library.math.number_theory.modular import showModClock, showModAddition, showCongruenceClasses
from Math.library.math.number_theory.prime_factor import showPrimeFactorTree


def demoPrimeSieve(scene: Scene, title: str = "Prime Sieve") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showPrimeSieve(scene, n=40, run_time=2.8)


def demoNumberSpiral(scene: Scene, title: str = "Number Spiral") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showNumberSpiral(scene, n=70, run_time=2.8)


def demoDivisibleBy2(scene: Scene, title: str = "Divisible by 2") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showDivisibilityBy2(scene, example=37, max_n=60)


def demoDivisibleBy3(scene: Scene, title: str = "Divisible by 3") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showDivisibilityByDigitSum(scene, divisor=3, example=357, max_n=81)


def demoDivisibleBy5(scene: Scene, title: str = "Divisible by 5") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showDivisibilityBy5(scene, example=125, max_n=60)


def demoDivisibleBy9(scene: Scene, title: str = "Divisible by 9") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showDivisibilityByDigitSum(scene, divisor=9, example=648, max_n=90)


def demoGcdEuclid(scene: Scene, title: str = "Euclidean Algorithm") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showEuclidAlgorithm(scene, a=252, b=198)


def demoLcmRelationship(scene: Scene, title: str = "GCD ⇔ LCM") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showGcdLcmRelationship(scene, a=12, b=18)


def demoModClock(scene: Scene, title: str = "Mod Clock") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=42)))
    showModClock(scene, modulus=7, value=5)


def demoModAddition(scene: Scene, title: str = "Mod Addition") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showModAddition(scene, a=3, b=5, modulus=7)


def demoCongruenceClasses(scene: Scene, title: str = "Congruence Classes") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showCongruenceClasses(scene, residue=2, modulus=7)


def demoPrimeFactorTree(scene: Scene, title: str = "Prime Factors") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showPrimeFactorTree(scene, n=72)

