"""Ulam-style spiral (first n integers)."""

from manim import *
import numpy as np


def showNumberSpiral(
    scene: Scene,
    n: int = 80,
    run_time: float = 3.0,
) -> VGroup:
    dots = VGroup()
    for k in range(1, n + 1):
        angle = k * 0.35
        r = 0.08 * np.sqrt(k)
        pos = np.array([r * np.cos(angle), r * np.sin(angle), 0])
        is_prime = k > 1 and all(k % d for d in range(2, int(k**0.5) + 1))
        color = "#FF4500" if is_prime else GREY_B
        dots.add(Dot(pos, radius=0.06, color=color))
    scene.play(LaggedStart(*[GrowFromCenter(d) for d in dots], lag_ratio=0.01), run_time=run_time)
    return dots
