"""GCD / LCM visualizations (Euclidean algorithm, relationships)."""

from manim import *

from Math.library.math.number_theory._core import (
    makeMath,
    makeStepList,
    playStepReveal,
    euclidSteps,
    gcdInt,
    lcmInt,
)


def showEuclidAlgorithm(
    scene: Scene,
    a: int = 252,
    b: int = 198,
    run_time: float = 2.6,
) -> VGroup:
    """Euclidean algorithm remainders: a = bq + r."""
    steps = euclidSteps(a, b)
    gcd = gcdInt(a, b)

    step_tex: list[str] = []
    for (aa, bb, r) in steps:
        q = aa // bb if bb != 0 else 0
        step_tex.append(rf"{aa} = {bb}\cdot {q} + {r}")

    cap = makeMath(rf"\gcd({a},{b})").to_edge(UP, buff=0.45)
    rows = makeStepList(step_tex)

    scene.play(Write(cap), FadeIn(rows[0]), run_time=run_time * 0.35)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.18)

    fin = makeMath(rf"\gcd({a},{b}) = {gcd}").to_edge(DOWN, buff=0.4)
    scene.play(Write(fin), run_time=run_time * 0.25)
    return VGroup(cap, rows, fin)


def showGcdLcmRelationship(
    scene: Scene,
    a: int = 12,
    b: int = 18,
    run_time: float = 2.3,
) -> VGroup:
    """lcm(a,b)=|ab|/gcd(a,b) and a numeric example."""
    g = gcdInt(a, b)
    L = lcmInt(a, b)
    cap = makeMath(rf"\mathrm{{lcm}}({a},{b})").to_edge(UP, buff=0.45)

    formula = makeMath(r"\mathrm{lcm}(a,b)=\frac{|ab|}{\gcd(a,b)}").scale(0.9)
    calc = makeMath(rf"\mathrm{{lcm}}({a},{b})=\frac{{|{a}\cdot {b}|}}{{{g}}}={L}").scale(0.9).set_color("#FF4500")

    scene.play(Write(cap), Write(formula), run_time=run_time * 0.55)
    scene.play(FadeIn(calc), run_time=run_time * 0.45)
    return VGroup(cap, formula, calc)

