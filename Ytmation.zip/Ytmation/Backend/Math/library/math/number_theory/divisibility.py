"""Divisibility rules — primes/prep topics for intro number theory."""

from manim import *

from Math.library.math.graphs.axes import makeNumberLine
from Math.library.math.number_theory._core import makeMath, makeStepList, playStepReveal


def _digitSum(n: int) -> int:
    return sum(int(ch) for ch in str(abs(int(n))))


def showDivisibilityBy2(
    scene: Scene,
    example: int = 37,
    max_n: int = 60,
    run_time: float = 2.2,
) -> VGroup:
    """Even/odd test via last digit parity."""
    nl = makeNumberLine(0, max_n, 1, length=9, include_numbers=True)
    multiples = [k for k in range(0, max_n + 1) if k % 2 == 0]
    dots = VGroup(*[Dot(nl.number_to_point(k), color=BLUE, radius=0.06) for k in multiples])
    ex_dot = Dot(nl.number_to_point(example - (example % 2)), color="#FF4500", radius=0.09)

    last_digit = abs(example) % 10
    is_even = last_digit % 2 == 0
    steps = [
        rf"\text{{last digit of }}{example}\text{{ is }}{last_digit}",
        rf"{last_digit}\equiv {last_digit}\pmod 2",
        rf"{'even' if is_even else 'odd'} \Rightarrow {example}\text{{ divisible by 2}}",
    ]
    cap = makeMath(r"\text{Divisible by }2").to_edge(UP, buff=0.45)
    rows = makeStepList(steps)

    scene.play(Write(cap), Create(nl), FadeIn(dots, lag_ratio=0.02), run_time=run_time * 0.55)
    scene.play(FadeIn(ex_dot), run_time=run_time * 0.15)
    scene.play(FadeIn(rows[0]), run_time=run_time * 0.2)
    scene.play(FadeIn(rows[1]), run_time=run_time * 0.1)
    scene.play(FadeIn(rows[2]), run_time=run_time * 0.1)
    return VGroup(nl, dots, ex_dot, cap, rows)


def showDivisibilityBy5(
    scene: Scene,
    example: int = 125,
    max_n: int = 60,
    run_time: float = 2.2,
) -> VGroup:
    """Ending in 0 or 5."""
    nl = makeNumberLine(0, max_n, 1, length=9, include_numbers=True)
    multiples = [k for k in range(0, max_n + 1) if k % 5 == 0]
    dots = VGroup(*[Dot(nl.number_to_point(k), color=BLUE, radius=0.06) for k in multiples])

    last_digit = abs(example) % 10
    is_ok = last_digit in (0, 5)
    ex_in_range = example if 0 <= example <= max_n else (max_n - (max_n % 5))
    ex_dot = Dot(nl.number_to_point(ex_in_range), color="#FF4500", radius=0.09)

    cap = makeMath(r"\text{Divisible by }5").to_edge(UP, buff=0.45)
    truth = "true" if is_ok else "false"
    steps = [
        rf"\text{{last digit of }}{example}\text{{ is }}{last_digit}",
        r"\text{rule: ends in }0\text{ or }5 \Rightarrow \text{divisible by }5",
        rf"\text{{Result: {truth}}}",
    ]
    rows = makeStepList(steps)
    scene.play(Write(cap), Create(nl), FadeIn(dots, lag_ratio=0.02), run_time=run_time * 0.55)
    scene.play(FadeIn(ex_dot), run_time=run_time * 0.15)
    scene.play(FadeIn(rows[0]), run_time=run_time * 0.15)
    scene.play(FadeIn(rows[1]), run_time=run_time * 0.15)
    return VGroup(nl, dots, ex_dot, cap, rows)


def showDivisibilityByDigitSum(
    scene: Scene,
    divisor: int,
    example: int = 357,
    max_n: int = 80,
    run_time: float = 2.4,
) -> VGroup:
    """Divisible by 3 or 9 via digit sum."""
    nl = makeNumberLine(0, max_n, 1, length=9, include_numbers=True)
    multiples = [k for k in range(0, max_n + 1) if k % divisor == 0]
    dots = VGroup(*[Dot(nl.number_to_point(k), color=BLUE, radius=0.06) for k in multiples])

    s = _digitSum(example)
    is_ok = s % divisor == 0
    cap = makeMath(rf"\text{{Divisible by }}{divisor}").to_edge(UP, buff=0.45)

    ex_in_range = example if 0 <= example <= max_n else (divisor * (max_n // divisor))
    ex_dot = Dot(nl.number_to_point(ex_in_range), color="#FF4500", radius=0.09)

    steps = [
        rf"\text{{digit sum of }}{example}\text{{ is }}{s}",
        rf"{s}\equiv {s}\pmod {divisor}",
        rf"{'divisible' if is_ok else 'not divisible'} \Rightarrow {example} \text{{ divisible by }}{divisor}",
    ]
    rows = makeStepList(steps)

    scene.play(Write(cap), Create(nl), FadeIn(dots, lag_ratio=0.02), run_time=run_time * 0.55)
    scene.play(FadeIn(ex_dot), run_time=run_time * 0.15)
    scene.play(FadeIn(rows[0]), run_time=run_time * 0.16)
    scene.play(FadeIn(rows[1]), run_time=run_time * 0.07)
    scene.play(FadeIn(rows[2]), run_time=run_time * 0.07)
    return VGroup(nl, dots, ex_dot, cap, rows)

