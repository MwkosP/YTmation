# Number Theory Library — Agent Cookbook

Intro number theory visuals for workflows: primes, divisibility, gcd/lcm, modular arithmetic, factorization.

## Module map

| File | Topics |
|------|--------|
| `_core.py` | gcd/lcm helpers, Euclid steps, prime factorization |
| `prime_sieve.py` | Eratosthenes grid (`showPrimeSieve`) |
| `number_spiral.py` | Ulam-style number spiral (`showNumberSpiral`) |
| `divisibility.py` | rules for 2, 5, and digit-sum rules (3/9) |
| `gcd_lcm.py` | Euclidean algorithm + lcm relationship |
| `modular.py` | mod clock, mod addition, congruence classes |
| `prime_factor.py` | prime factorization as circles/exponents |
| `recipes.py` | `demo*` wrappers for showcases |

## API layers

| Prefix | Use when |
|--------|----------|
| `show…` | One beat (may `scene.play`) |
| `make…` | Mobjects only (no `scene`) |
| `demo…` (`recipes.py`) | Full fixed demo for one topic |

## Showcase

```bash
python Workflows/channels/mathmwk/numberTheoryShowcase.py
```

