"""Shared number theory helpers — pure math, no domain narrative."""

from manim import *
import numpy as np


def makeMath(tex: str, color=WHITE, scale: float = 0.85) -> MathTex:
    return MathTex(tex, color=color).scale(scale)


def makeStepList(steps: list[str], buff: float = 0.42, color=WHITE) -> VGroup:
    rows = VGroup(*[makeMath(s, color=color, scale=0.8) for s in steps])
    rows.arrange(DOWN, aligned_edge=LEFT, buff=buff)
    return rows


def playStepReveal(scene: Scene, steps: VGroup, up_to: int, run_time: float = 0.55) -> None:
    if 0 <= up_to < len(steps):
        scene.play(FadeIn(steps[up_to]), run_time=run_time)


def gcdInt(a: int, b: int) -> int:
    a, b = abs(int(a)), abs(int(b))
    while b != 0:
        a, a, b = b, b, a % b
    return a


def lcmInt(a: int, b: int) -> int:
    a, b = int(a), int(b)
    if a == 0 or b == 0:
        return 0
    return abs(a * b) // gcdInt(a, b)


def euclidSteps(a: int, b: int) -> list[tuple[int, int, int]]:
    """Euclidean algorithm steps: (a, b, r) where a = b*q + r."""
    a, b = int(a), int(b)
    a, b = abs(a), abs(b)
    steps: list[tuple[int, int, int]] = []
    while b != 0:
        r = a % b
        steps.append((a, b, r))
        a, b = b, r
    return steps


def factorizeInt(n: int) -> dict[int, int]:
    """Prime factorization n = Π p^e (trial division)."""
    n = int(n)
    if n == 0:
        return {}
    n = abs(n)
    factors: dict[int, int] = {}
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors[d] = factors.get(d, 0) + 1
            n //= d
        d = 3 if d == 2 else d + 2
    if n > 1:
        factors[n] = factors.get(n, 0) + 1
    return factors


def factorListInt(n: int) -> list[int]:
    """Prime factors with multiplicity."""
    f = factorizeInt(n)
    out: list[int] = []
    for p in sorted(f.keys()):
        out.extend([p] * f[p])
    return out

