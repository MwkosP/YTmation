"""Sieve of Eratosthenes grid animation."""

from manim import *
import numpy as np


def sievePrimes(n: int) -> list[bool]:
    is_prime = [True] * (n + 1)
    is_prime[0] = is_prime[1] = False
    for p in range(2, int(n**0.5) + 1):
        if is_prime[p]:
            for k in range(p * p, n + 1, p):
                is_prime[k] = False
    return is_prime


def showPrimeSieve(
    scene: Scene,
    n: int = 50,
    cols: int = 10,
    run_time: float = 3.0,
) -> VGroup:
    flags = sievePrimes(n)
    cells = VGroup()
    for i in range(1, n + 1):
        col = (i - 1) % cols
        row = (i - 1) // cols
        color = GREEN if flags[i] else GREY_D
        sq = Square(side_length=0.45, color=color, fill_opacity=0.5 if flags[i] else 0.1)
        num = Text(str(i), font_size=18, color=WHITE).move_to(sq)
        g = VGroup(sq, num).move_to(RIGHT * col * 0.55 + DOWN * row * 0.55)
        cells.add(g)
    cells.move_to(ORIGIN)
    scene.play(LaggedStart(*[FadeIn(c) for c in cells], lag_ratio=0.02), run_time=run_time)
    return cells
