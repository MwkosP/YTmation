"""Modular arithmetic — clocks, congruence classes, simple operations."""

from manim import *
import numpy as np

from Math.library.math.number_theory._core import makeMath, playStepReveal


def _makeModClock(
    modulus: int,
    radius: float = 2.2,
    tick_color=GREY_B,
):
    center = ORIGIN
    circle = Circle(radius=radius, color=tick_color, stroke_width=3)

    ticks = VGroup()
    labels = VGroup()
    for i in range(modulus):
        theta = (i / modulus) * TAU
        tick_end = circle.point_at_angle(theta)
        ticks.add(Line(center, tick_end, color=tick_color, stroke_width=2))
        lbl = Integer(i).scale(0.55).move_to(tick_end * 1.05)
        labels.add(lbl)

    return VGroup(circle, ticks, labels)


def _highlightResidue(clock: VGroup, modulus: int, residue: int, color="#FF4500"):
    circle = clock[0]
    center = circle.get_center()
    radius = circle.radius
    theta = (residue / modulus) * TAU
    pos = center + radius * np.array([np.cos(theta), np.sin(theta), 0.0])
    dot = Dot(pos, color=color, radius=0.09)
    ring = Circle(radius=0.18, color=color).move_to(pos)
    return VGroup(dot, ring)


def showModClock(
    scene: Scene,
    modulus: int = 7,
    value: int = 5,
    run_time: float = 2.4,
) -> VGroup:
    """Highlight residue value mod m on a clock."""
    residue = value % modulus
    clock = _makeModClock(modulus).shift(LEFT * 2.8)
    cap = makeMath(rf"\text{{Highlight }}{value}\bmod {modulus} = {residue}").to_edge(UP, buff=0.45)
    hi = _highlightResidue(clock, modulus, residue)

    scene.play(Create(cap), Create(clock[0]), FadeIn(clock[1]), FadeIn(clock[2]), run_time=run_time * 0.55)
    scene.play(FadeIn(hi), run_time=run_time * 0.45)
    return VGroup(cap, clock, hi)


def showModAddition(
    scene: Scene,
    a: int = 3,
    b: int = 5,
    modulus: int = 7,
    run_time: float = 2.6,
) -> VGroup:
    """Show (a+b) mod m by highlighting a, b, and the result."""
    rA, rB = a % modulus, b % modulus
    rS = (a + b) % modulus
    clock = _makeModClock(modulus).shift(LEFT * 2.8)
    cap = makeMath(rf"\text{{(}}{a}+{b}\text{{)}}\bmod {modulus} = {rS}").to_edge(UP, buff=0.45)

    hiA = _highlightResidue(clock, modulus, rA, color=BLUE)
    hiB = _highlightResidue(clock, modulus, rB, color="#00ff88")
    hiS = _highlightResidue(clock, modulus, rS, color="#FF4500")

    scene.play(Create(cap), run_time=run_time * 0.35)
    scene.play(Create(clock[0]), FadeIn(clock[1]), FadeIn(clock[2]), run_time=run_time * 0.25)
    scene.play(FadeIn(hiA), run_time=run_time * 0.15)
    scene.play(FadeIn(hiB), run_time=run_time * 0.15)
    scene.play(FadeIn(hiS), run_time=run_time * 0.2)

    return VGroup(cap, clock, hiA, hiB, hiS)


def showCongruenceClasses(
    scene: Scene,
    residue: int = 2,
    modulus: int = 7,
    run_time: float = 2.4,
) -> VGroup:
    """Show x ≡ residue (mod modulus) as a chain on a number line."""
    from Math.library.math.graphs.axes import makeNumberLine

    r = residue % modulus
    max_x = modulus * 4
    nl = makeNumberLine(0, max_x, 1, length=10, include_numbers=False)
    dots_x = [r + k * modulus for k in range(max_x // modulus + 1)]
    dots = VGroup(*[Dot(nl.number_to_point(x), color=BLUE, radius=0.06) for x in dots_x])
    hi = Dot(nl.number_to_point(r), color="#FF4500", radius=0.09)

    cap = makeMath(rf"{r}\equiv x \pmod {modulus}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(nl), FadeIn(dots, lag_ratio=0.02), run_time=run_time * 0.6)
    scene.play(FadeIn(hi), run_time=run_time * 0.4)
    return VGroup(cap, nl, dots, hi)

