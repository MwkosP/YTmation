"""Prime factorization visuals (factor trees / product forms)."""

from manim import *

from Math.library.math.number_theory._core import makeMath, makeStepList, factorizeInt


def showPrimeFactorTree(
    scene: Scene,
    n: int = 72,
    run_time: float = 2.8,
) -> VGroup:
    """Show n = Π p^e as circles (distinct primes + exponents)."""
    factors = factorizeInt(n)  # prime -> exponent
    if not factors:
        cap = makeMath(rf"\text{{Prime or 1: }}{n}").to_edge(UP, buff=0.45)
        scene.play(Write(cap), run_time=run_time)
        return VGroup(cap)

    primes = sorted(factors.keys())

    cap = makeMath(rf"\text{{Prime factorization of }}{n}").to_edge(UP, buff=0.45)

    circles = VGroup()
    exp_text = VGroup()
    for i, p in enumerate(primes):
        e = factors[p]
        c = Circle(radius=0.55, color=BLUE, stroke_width=3, fill_opacity=0.15)
        c.move_to(LEFT * (len(primes) - 1) * 1.7 / 2 + RIGHT * i * 1.7)
        prime_lbl = Integer(p).scale(0.6).move_to(c.get_center())
        exp = makeMath(rf"^{e}", color="#FF4500", scale=0.6).next_to(prime_lbl, UP, buff=0.15)
        circles.add(VGroup(c, prime_lbl, exp))

    # Product banner
    prod = r" \cdot ".join([rf"{p}^{{{factors[p]}}}" for p in primes])
    bottom = makeMath(rf"{n}={prod}").scale(0.95).to_edge(DOWN, buff=0.4).set_color("#FF4500")

    # Small "expanded" chain steps: p·p·... (multiplicity)
    chain: list[str] = []
    for p in primes:
        chain.extend([str(p)] * factors[p])
    chain_expr = r" \cdot ".join(chain)
    steps = [
        rf"{n}={chain_expr}",
        rf"{n}={prod}",
    ]
    rows = makeStepList(steps).to_edge(RIGHT, buff=0.7)

    scene.play(Write(cap), run_time=run_time * 0.25)
    scene.play(FadeIn(circles, lag_ratio=0.08), run_time=run_time * 0.45)
    scene.play(Write(bottom), run_time=run_time * 0.15)
    scene.play(FadeIn(rows[0]), run_time=run_time * 0.1)
    scene.play(FadeIn(rows[1]), run_time=run_time * 0.05)
    return VGroup(cap, circles, bottom, rows)

