"""Number theory building blocks (primes, gcd/lcm, modular arithmetic)."""

from Math.library.math.number_theory import recipes as numberTheoryRecipes
from Math.library.math.number_theory.number_spiral import showNumberSpiral
from Math.library.math.number_theory.prime_sieve import showPrimeSieve
from Math.library.math.number_theory.divisibility import (
    showDivisibilityBy2,
    showDivisibilityBy5,
    showDivisibilityByDigitSum,
)
from Math.library.math.number_theory.gcd_lcm import showEuclidAlgorithm, showGcdLcmRelationship
from Math.library.math.number_theory.modular import (
    showModClock,
    showModAddition,
    showCongruenceClasses,
)
from Math.library.math.number_theory.prime_factor import showPrimeFactorTree

__all__ = [
    "numberTheoryRecipes",
    "showPrimeSieve",
    "showNumberSpiral",
    "showDivisibilityBy2",
    "showDivisibilityBy5",
    "showDivisibilityByDigitSum",
    "showEuclidAlgorithm",
    "showGcdLcmRelationship",
    "showModClock",
    "showModAddition",
    "showCongruenceClasses",
    "showPrimeFactorTree",
]
