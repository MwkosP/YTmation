"""Sine/cosine plots and phase animation."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes


def makeTrigAxes(
    x_range: tuple = (0, 2 * PI, PI / 2),
    y_range: tuple = (-1.5, 1.5, 0.5),
    x_length: float = 8,
    y_length: float = 3,
) -> VGroup:
    return makeLabeledAxes(
        x_range=x_range,
        y_range=y_range,
        x_length=x_length,
        y_length=y_length,
        x_label="\\theta",
        y_label="y",
    )


def plotSine(axes_group: VGroup, amplitude: float = 1.0, frequency: float = 1.0, phase: float = 0.0, color=BLUE) -> VMobject:
    axes = axes_group[0]
    x0, x1 = axes.x_range[0], axes.x_range[1]
    return axes.plot(
        lambda x: amplitude * np.sin(frequency * x + phase),
        x_range=[x0, x1],
        color=color,
    )


def plotCosine(axes_group: VGroup, amplitude: float = 1.0, frequency: float = 1.0, phase: float = 0.0, color="#FF4500") -> VMobject:
    axes = axes_group[0]
    x0, x1 = axes.x_range[0], axes.x_range[1]
    return axes.plot(
        lambda x: amplitude * np.cos(frequency * x + phase),
        x_range=[x0, x1],
        color=color,
    )


def animateSinePhase(
    scene: Scene,
    axes_group: VGroup,
    amplitude: float = 1.0,
    frequency: float = 1.0,
    color=BLUE,
    cycles: float = 1.0,
    run_time: float = 3.0,
) -> tuple[ValueTracker, VMobject]:
    phase = ValueTracker(0.0)
    axes = axes_group[0]

    def redraw():
        x0, x1 = axes.x_range[0], axes.x_range[1]
        return axes.plot(
            lambda x: amplitude * np.sin(frequency * x + phase.get_value()),
            x_range=[x0, x1],
            color=color,
        )

    wave = always_redraw(redraw)
    scene.add(wave)
    scene.play(phase.animate.set_value(TAU * cycles), run_time=run_time, rate_func=linear)
    return phase, wave


def plotSuperposition(
    axes_group: VGroup,
    amp1: float = 1.0,
    amp2: float = 0.7,
    k1: float = 1.0,
    k2: float = 1.3,
    phase2: float = PI / 4,
) -> VGroup:
    axes = axes_group[0]
    x0, x1 = axes.x_range[0], axes.x_range[1]
    w1 = plotSine(axes_group, amplitude=amp1, frequency=k1, color=BLUE)
    w2 = axes.plot(
        lambda x: amp2 * np.sin(k2 * x + phase2),
        x_range=[x0, x1],
        color="#FF4500",
    )
    wsum = axes.plot(
        lambda x: amp1 * np.sin(k1 * x) + amp2 * np.sin(k2 * x + phase2),
        x_range=[x0, x1],
        color=YELLOW,
    )
    return VGroup(w1, w2, wsum)
