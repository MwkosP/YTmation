"""Even / odd symmetry on graphs."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath, getAxes


def showEvenFunction(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-3, 3, 1), y_range=(0, 5, 1))
    graph = plotOnAxes(axes_g, lambda x: x**2, x_range=(-2.8, 2.8), color=BLUE)
    axis = DashedLine(getAxes(axes_g).c2p(0, -0.5), getAxes(axes_g).c2p(0, 5), color=YELLOW)
    cap = makeMath(r"f(-x)=f(x)").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), Create(axis), run_time=run_time)
    return VGroup(axes_g, graph, axis, cap)


def showOddFunction(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-3, 3, 1), y_range=(-3, 3, 1))
    graph = plotOnAxes(axes_g, lambda x: x**3 / 3, x_range=(-2.5, 2.5), color="#FF4500")
    cap = makeMath(r"f(-x)=-f(x)").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), run_time=run_time)
    return VGroup(axes_g, graph, cap)
