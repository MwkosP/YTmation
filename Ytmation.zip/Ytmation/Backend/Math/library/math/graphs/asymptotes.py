"""Asymptote guides on graphs."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath, getAxes


def showVerticalAsymptote(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-4, 4, 1), y_range=(-4, 4, 1))
    axes = getAxes(axes_g)
    try:
        graph = axes.plot(
            lambda x: 1 / x,
            x_range=[-3.5, 3.5],
            discontinuities=[0],
            color=BLUE,
            stroke_width=3,
        )
    except TypeError:
        graph = plotOnAxes(
            axes_g,
            lambda x: 1 / x if abs(x) > 0.15 else 0,
            x_range=(-3.5, 3.5),
            color=BLUE,
        )
    vasym = DashedLine(axes.c2p(0, -4), axes.c2p(0, 4), color=YELLOW)
    cap = makeMath(r"x=a").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), Create(vasym), run_time=run_time)
    return VGroup(axes_g, graph, vasym, cap)


def showHorizontalAsymptote(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-4, 4, 1), y_range=(-1, 3, 1))
    axes = getAxes(axes_g)
    graph = plotOnAxes(axes_g, lambda x: (x**2 + 1) / (x**2 + 2), x_range=(-4, 4), color=BLUE)
    hasym = DashedLine(axes.c2p(-4, 1), axes.c2p(4, 1), color=YELLOW)
    cap = makeMath(r"y=L").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), Create(hasym), run_time=run_time)
    return VGroup(axes_g, graph, hasym, cap)
