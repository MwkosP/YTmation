"""Function shifts on axes."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath


def showHorizontalShift(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-4, 4, 1), y_range=(-1, 5, 1))
    parent = plotOnAxes(axes_g, lambda x: x**2, x_range=(-3, 3), color=GREY_B)
    shifted = plotOnAxes(axes_g, lambda x: (x - 2) ** 2, x_range=(-1, 5), color=BLUE)
    cap = makeMath(r"f(x-2)").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(parent), Create(shifted), run_time=run_time)
    return VGroup(axes_g, parent, shifted, cap)


def showVerticalShift(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-3, 3, 1), y_range=(-2, 6, 1))
    parent = plotOnAxes(axes_g, lambda x: x**2, x_range=(-2.5, 2.5), color=GREY_B)
    shifted = plotOnAxes(axes_g, lambda x: x**2 + 2, x_range=(-2.5, 2.5), color="#FF4500")
    cap = makeMath(r"f(x)+2").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(parent), Create(shifted), run_time=run_time)
    return VGroup(axes_g, parent, shifted, cap)
