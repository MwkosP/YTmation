"""Polar plots."""

from manim import *
import numpy as np

from Math.library.math.graphs._core import makeMath


def makePolarAxes(
    radius_max: float = 2.5,
    size: float = 6,
) -> PolarPlane:
    return PolarPlane(
        radius_max=radius_max,
        size=size,
        background_line_style={"stroke_color": GREY_E, "stroke_opacity": 0.4},
    )


def showPolarRose(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    plane = makePolarAxes()
    curve = plane.plot_polar_graph(lambda theta: np.cos(2 * theta), [0, 2 * PI], color=BLUE, stroke_width=3)
    cap = makeMath(r"r=\cos(2\theta)").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(plane), Create(curve), run_time=run_time)
    return VGroup(plane, curve, cap)
