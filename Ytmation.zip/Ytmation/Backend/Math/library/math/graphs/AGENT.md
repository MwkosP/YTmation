# Graphs Library — Agent Cookbook

**Shared plotting layer** for math, physics, economics, statistics. Domain packages import these — do not duplicate `makeLabeledAxes` in physics except thin wrappers (`makeMotionAxes`).

## API layers

| Prefix | Use when |
|--------|----------|
| `make…` | Axes, points, polar plane — you `scene.play` |
| `show…` | One beat (comparison, shade, asymptote, …) |
| `demo…` | Full topic (`recipes.py`) |

## Module map (~85–90% intro graphing)

| File | Topics |
|------|--------|
| `axes.py` | `makeLabeledAxes`, `makeAxesWithGrid`, `plotOnAxes`, `plotMultipleOnAxes`, `animateDotOnPath`, `makeNumberLine` |
| `points.py` | plot (x,y) points, connect-the-dots |
| `multi.py` | two+ functions, legend |
| `intersections.py` | intersection dot, roots on x-axis |
| `asymptotes.py` | vertical / horizontal asymptote guides |
| `piecewise.py` | piecewise f(x) |
| `parametric.py` | parametric curve on xy axes |
| `polar.py` | polar plane, rose r=cos(2θ) |
| `scatter.py` | scatter, linear trend line |
| `shade.py` | under curve, between curves |
| `discontinuity.py` | hole, jump |
| `annotations.py` | vertical marker, dot tracing path |
| `shifts.py` | horizontal / vertical shifts |
| `discrete.py` | bar chart, stem plot |
| `intervals.py` | interval on number line |
| `symmetry.py` | even / odd |
| `recipes.py` | all `demo…` |

## What stays elsewhere

| Topic | Package |
|-------|---------|
| Quadratic vertex, completing square | `algebra/quadratic` |
| Inequality half-plane (algebra story) | `algebra/inequalities` |
| Derivative tangent, Riemann sum | `calculus/*` |
| Normal PDF | `statistics/normal_dist` |
| Motion x–t labels | `physics/kinematics` wraps `makeLabeledAxes` |

## Showcase

```bash
python Workflows/channels/mathmwk/graphsShowcase.py
```

## Compose (physics example)

```python
from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes, animateDotOnPath
from Math.library.physics.kinematics import makeMotionAxes  # t, x labels

axes = makeMotionAxes()
graph = plotOnAxes(axes, lambda t: 2 * t, x_range=(0, 5))
scene.play(Create(axes), Create(graph))
animateDotOnPath(scene, graph)
```
