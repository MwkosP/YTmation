"""Parametric curves on axes (projected to xy)."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.graphs._core import makeMath


def showParametricPlot(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-2, 2, 1), y_range=(-2, 2, 1), x_label="x", y_label="y")
    t_vals = np.linspace(0, 2 * PI, 200)
    points = [axes_g[0].c2p(np.cos(t), np.sin(t)) for t in t_vals]
    curve = VMobject(color=BLUE, stroke_width=3).set_points_smoothly(points)
    cap = makeMath(r"x=\cos t,\ y=\sin t").scale(0.8).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(curve), run_time=run_time)
    return VGroup(axes_g, curve, cap)
