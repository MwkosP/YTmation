"""Multiple functions on one set of axes."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotMultipleOnAxes
from Math.library.math.graphs._core import makeMath


def showTwoFunctions(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-3, 3, 1), y_range=(-2, 8, 1))
    graphs = plotMultipleOnAxes(
        axes_g,
        [lambda x: x**2, lambda x: 2 * x + 1],
        x_range=(-2.5, 2.5),
    )
    leg1 = makeMath(r"y=x^2", color=BLUE, scale=0.7)
    leg2 = makeMath(r"y=2x+1", color="#FF4500", scale=0.7).next_to(leg1, DOWN, aligned_edge=LEFT)
    legend = VGroup(leg1, leg2).to_corner(UR, buff=0.5)
    cap = makeMath(r"\text{compare graphs}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), run_time=run_time * 0.35)
    scene.play(*[Create(g) for g in graphs], FadeIn(legend), run_time=run_time * 0.65)
    return VGroup(axes_g, graphs, legend, cap)
