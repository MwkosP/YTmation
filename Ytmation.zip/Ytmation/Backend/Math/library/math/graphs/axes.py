"""Generic axes and function plotting — used by physics, economics, etc."""

from manim import *
import numpy as np

from Math.library.math.graphs._core import makeMath


def makeLabeledAxes(
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-3, 3, 1),
    x_length: float = 7,
    y_length: float = 4,
    x_label: str = "x",
    y_label: str = "y",
) -> VGroup:
    axes = Axes(
        x_range=list(x_range),
        y_range=list(y_range),
        x_length=x_length,
        y_length=y_length,
        axis_config={"color": GREY_B, "include_tip": True},
    )
    xlab = MathTex(x_label, color=GREY_B).scale(0.65).next_to(axes.x_axis, DOWN, buff=0.15)
    ylab = MathTex(y_label, color=GREY_B).scale(0.65).next_to(axes.y_axis, LEFT, buff=0.15)
    return VGroup(axes, xlab, ylab)


def makeAxesWithGrid(
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-3, 3, 1),
    x_length: float = 7,
    y_length: float = 4,
    x_label: str = "x",
    y_label: str = "y",
    grid_color=GREY_E,
) -> VGroup:
    """Labeled axes with background grid."""
    axes_g = makeLabeledAxes(x_range, y_range, x_length, y_length, x_label, y_label)
    axes = axes_g[0]
    grid = NumberPlane(
        x_range=x_range,
        y_range=y_range,
        x_length=x_length,
        y_length=y_length,
        background_line_style={"stroke_color": grid_color, "stroke_width": 1, "stroke_opacity": 0.5},
        axis_config={"stroke_opacity": 0},
    ).move_to(axes.get_center())
    return VGroup(grid, axes_g)


def plotOnAxes(
    axes_group: VGroup,
    func,
    x_range: tuple,
    color=BLUE,
    stroke_width: float = 3,
) -> VMobject:
    axes = axes_group[0]
    return axes.plot(func, x_range=list(x_range), color=color, stroke_width=stroke_width)


def plotMultipleOnAxes(
    axes_group: VGroup,
    funcs: list,
    x_range: tuple,
    colors: list | None = None,
    stroke_width: float = 3,
) -> VGroup:
    colors = colors or [BLUE, "#FF4500", GREEN, YELLOW]
    graphs = VGroup()
    for i, func in enumerate(funcs):
        graphs.add(
            plotOnAxes(
                axes_group,
                func,
                x_range,
                color=colors[i % len(colors)],
                stroke_width=stroke_width,
            )
        )
    return graphs


def animateDotOnPath(
    scene: Scene,
    path: VMobject,
    color=YELLOW,
    radius: float = 0.08,
    run_time: float = 2.0,
) -> Dot:
    dot = Dot(color=color, radius=radius)
    scene.add(dot)
    scene.play(MoveAlongPath(dot, path), run_time=run_time, rate_func=linear)
    return dot


def makeNumberLine(
    start: float = -5,
    end: float = 5,
    step: float = 1,
    length: float = 10,
    include_numbers: bool = True,
) -> NumberLine:
    return NumberLine(
        x_range=[start, end, step],
        length=length,
        color=WHITE,
        include_numbers=include_numbers,
        font_size=22,
    )
