"""Graph demos — one topic per call."""

from manim import *
import numpy as np

from Math.library.common.layout import makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.graphs.axes import (
    makeLabeledAxes,
    plotOnAxes,
    animateDotOnPath,
    makeNumberLine,
    makeAxesWithGrid,
    plotMultipleOnAxes,
)
from Math.library.math.graphs.points import showPlotPoints
from Math.library.math.graphs.multi import showTwoFunctions
from Math.library.math.graphs.intersections import showIntersection, showRootsOnGraph
from Math.library.math.graphs.asymptotes import showVerticalAsymptote, showHorizontalAsymptote
from Math.library.math.graphs.piecewise import showPiecewiseGraph
from Math.library.math.graphs.parametric import showParametricPlot
from Math.library.math.graphs.polar import showPolarRose
from Math.library.math.graphs.scatter import showScatterPlot, showTrendLine
from Math.library.math.graphs.shade import showShadeUnderCurve, showShadeBetweenCurves
from Math.library.math.graphs.discontinuity import showRemovableHole, showJumpDiscontinuity
from Math.library.math.graphs.annotations import showVerticalMarker, showDotTracingGraph
from Math.library.math.graphs.shifts import showHorizontalShift, showVerticalShift
from Math.library.math.graphs.discrete import showBarChart, showStemPlot
from Math.library.math.graphs.intervals import showIntervalOnNumberLine
from Math.library.math.graphs.symmetry import showEvenFunction, showOddFunction


def demoLabeledAxes(scene: Scene, title: str = "Labeled Axes") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    axes_g = makeLabeledAxes()
    graph = plotOnAxes(axes_g, lambda x: 0.5 * x**2, x_range=(-2.5, 2.5))
    scene.play(Create(axes_g), Create(graph), run_time=1.8)


def demoAxesWithGrid(scene: Scene, title: str = "Grid Axes") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    group = makeAxesWithGrid()
    scene.play(Create(group), run_time=1.8)


def demoPlotFunction(scene: Scene, title: str = "Plot f(x)") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    axes_g = makeLabeledAxes()
    graph = plotOnAxes(axes_g, lambda x: np.sin(x), x_range=(-3, 3))
    scene.play(Create(axes_g), Create(graph), run_time=1.8)


def demoNumberLine(scene: Scene, title: str = "Number Line") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    nl = makeNumberLine()
    scene.play(Create(nl), run_time=1.8)


def demoPlotPoints(scene: Scene, title: str = "Plot Points") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showPlotPoints(scene, connect=True)


def demoTwoFunctions(scene: Scene, title: str = "Two Functions") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showTwoFunctions(scene)


def demoIntersection(scene: Scene, title: str = "Intersection") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showIntersection(scene)


def demoRootsOnGraph(scene: Scene, title: str = "Roots") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showRootsOnGraph(scene)


def demoVerticalAsymptote(scene: Scene, title: str = "Vertical Asymptote") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showVerticalAsymptote(scene)


def demoHorizontalAsymptote(scene: Scene, title: str = "Horizontal Asymptote") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=32)))
    showHorizontalAsymptote(scene)


def demoPiecewiseGraph(scene: Scene, title: str = "Piecewise") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showPiecewiseGraph(scene)


def demoParametricPlot(scene: Scene, title: str = "Parametric") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showParametricPlot(scene)


def demoPolarRose(scene: Scene, title: str = "Polar Rose") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showPolarRose(scene)


def demoScatterPlot(scene: Scene, title: str = "Scatter") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showScatterPlot(scene)


def demoTrendLine(scene: Scene, title: str = "Trend Line") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showTrendLine(scene)


def demoShadeUnderCurve(scene: Scene, title: str = "Shade Under") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showShadeUnderCurve(scene)


def demoShadeBetweenCurves(scene: Scene, title: str = "Shade Between") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showShadeBetweenCurves(scene)


def demoRemovableHole(scene: Scene, title: str = "Removable Hole") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showRemovableHole(scene)


def demoJumpDiscontinuity(scene: Scene, title: str = "Jump") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showJumpDiscontinuity(scene)


def demoVerticalMarker(scene: Scene, title: str = "x Marker") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showVerticalMarker(scene)


def demoDotTracingGraph(scene: Scene, title: str = "Trace Dot") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showDotTracingGraph(scene)


def demoHorizontalShift(scene: Scene, title: str = "Horizontal Shift") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showHorizontalShift(scene)


def demoVerticalShift(scene: Scene, title: str = "Vertical Shift") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showVerticalShift(scene)


def demoBarChart(scene: Scene, title: str = "Bar Chart") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showBarChart(scene)


def demoStemPlot(scene: Scene, title: str = "Stem Plot") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showStemPlot(scene)


def demoIntervalOnNumberLine(scene: Scene, title: str = "Interval") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showIntervalOnNumberLine(scene)


def demoEvenFunction(scene: Scene, title: str = "Even") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showEvenFunction(scene)


def demoOddFunction(scene: Scene, title: str = "Odd") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=44)))
    showOddFunction(scene)
