"""Plot points, scatter-style markers."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath, getAxes


def makePoints(
    axes_group: VGroup,
    coords: list[tuple[float, float]],
    color=YELLOW,
    radius: float = 0.08,
) -> VGroup:
    axes = getAxes(axes_group)
    return VGroup(*[Dot(axes.c2p(x, y), color=color, radius=radius) for x, y in coords])


def makePointLabels(
    axes_group: VGroup,
    coords: list[tuple[float, float]],
    labels: list[str] | None = None,
) -> VGroup:
    axes = getAxes(axes_group)
    labels = labels or [rf"({x},{y})" for x, y in coords]
    return VGroup(
        *[
            makeMath(lbl, scale=0.55).next_to(axes.c2p(x, y), UR, buff=0.08)
            for (x, y), lbl in zip(coords, labels)
        ]
    )


def showPlotPoints(
    scene: Scene,
    coords: list[tuple[float, float]] | None = None,
    connect: bool = False,
    run_time: float = 2.0,
) -> VGroup:
    coords = coords or [(0, 1), (1, 3), (2, 2), (3, 5)]
    axes_g = makeLabeledAxes(x_range=(-1, 4, 1), y_range=(-1, 6, 1))
    dots = makePoints(axes_g, coords)
    lines = VGroup()
    if connect and len(coords) > 1:
        axes = getAxes(axes_g)
        for i in range(len(coords) - 1):
            lines.add(
                Line(axes.c2p(*coords[i]), axes.c2p(*coords[i + 1]), color=BLUE, stroke_width=2)
            )
    cap = makeMath(r"\text{plot }(x,y)\text{ points}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), run_time=run_time * 0.35)
    scene.play(Create(dots), *[Create(l) for l in lines], run_time=run_time * 0.65)
    return VGroup(axes_g, dots, lines, cap)
