"""Discontinuities — holes and jumps."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath, getAxes


def showRemovableHole(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-2, 2, 1), y_range=(-1, 5, 1))
    axes = getAxes(axes_g)
    graph = plotOnAxes(axes_g, lambda x: x + 1, x_range=(-1.8, 1.8), color=BLUE)
    hole = Circle(radius=0.08, color=BLACK, fill_opacity=1, stroke_color=BLUE).move_to(axes.c2p(0, 1))
    open_dot = Circle(radius=0.08, color=BLUE, stroke_width=2).move_to(axes.c2p(0, 1))
    cap = makeMath(r"\text{removable hole}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), FadeIn(open_dot), run_time=run_time)
    return VGroup(axes_g, graph, open_dot, cap)


def showJumpDiscontinuity(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-2, 2, 1), y_range=(-1, 4, 1))
    axes = getAxes(axes_g)
    left = axes.plot(lambda x: x + 2, x_range=[-2, 0], color=BLUE, stroke_width=3)
    right = axes.plot(lambda x: x + 3, x_range=[0, 2], color=BLUE, stroke_width=3)
    dot_l = Dot(axes.c2p(0, 2), color=BLUE, radius=0.07)
    dot_r_open = Circle(radius=0.07, color=BLUE, stroke_width=2).move_to(axes.c2p(0, 3))
    cap = makeMath(r"\text{jump discontinuity}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(left), Create(right), FadeIn(dot_l), FadeIn(dot_r_open), run_time=run_time)
    return VGroup(axes_g, left, right, dot_l, dot_r_open, cap)
