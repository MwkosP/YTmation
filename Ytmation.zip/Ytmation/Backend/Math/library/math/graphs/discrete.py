"""Discrete graphs — bar chart, stem plot."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.graphs._core import makeMath, getAxes


def showBarChart(
    scene: Scene,
    values: list[float] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    values = values or [2, 5, 3, 7, 4]
    axes_g = makeLabeledAxes(x_range=(0, len(values) + 1, 1), y_range=(0, 8, 2), x_label="k", y_label="")
    axes = getAxes(axes_g)
    bars = VGroup()
    for i, v in enumerate(values, start=1):
        w = 0.6
        h = axes.c2p(0, v)[1] - axes.c2p(0, 0)[1]
        bar = Rectangle(width=w, height=h, color=BLUE, fill_opacity=0.5, stroke_width=1)
        bar.move_to(axes.c2p(i, 0), aligned_edge=DOWN)
        bars.add(bar)
    cap = makeMath(r"\text{bar chart}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(bars), run_time=run_time)
    return VGroup(axes_g, bars, cap)


def showStemPlot(
    scene: Scene,
    coords: list[tuple[float, float]] | None = None,
    run_time: float = 2.0,
) -> VGroup:
    coords = coords or [(1, 2), (2, 4), (3, 3), (4, 5)]
    axes_g = makeLabeledAxes(x_range=(0, 5, 1), y_range=(0, 6, 1))
    axes = getAxes(axes_g)
    stems = VGroup(
        *[
            Line(axes.c2p(x, 0), axes.c2p(x, y), color=BLUE, stroke_width=2)
            for x, y in coords
        ]
    )
    dots = VGroup(*[Dot(axes.c2p(x, y), color=YELLOW, radius=0.07) for x, y in coords])
    cap = makeMath(r"\text{stem plot}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(stems), FadeIn(dots), run_time=run_time)
    return VGroup(axes_g, stems, dots, cap)
