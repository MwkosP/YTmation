"""Shared plotting axes and graph animations."""

from .axes import (
    makeLabeledAxes,
    makeAxesWithGrid,
    plotOnAxes,
    plotMultipleOnAxes,
    animateDotOnPath,
    makeNumberLine,
)
from .points import makePoints, makePointLabels, showPlotPoints
from . import recipes as graphsRecipes

__all__ = [
    "makeLabeledAxes",
    "makeAxesWithGrid",
    "plotOnAxes",
    "plotMultipleOnAxes",
    "animateDotOnPath",
    "makeNumberLine",
    "makePoints",
    "makePointLabels",
    "showPlotPoints",
    "graphsRecipes",
]
