"""Shared graph helpers."""

from manim import *


def makeMath(tex: str, color=WHITE, scale: float = 0.85) -> MathTex:
    return MathTex(tex, color=color).scale(scale)


def getAxes(axes_group: VGroup) -> Axes:
    return axes_group[0]
