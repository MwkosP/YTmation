"""Number line intervals."""

from manim import *

from Math.library.math.graphs.axes import makeNumberLine
from Math.library.math.graphs._core import makeMath


def showIntervalOnNumberLine(
    scene: Scene,
    a: float = 1.0,
    b: float = 4.0,
    closed_left: bool = True,
    closed_right: bool = False,
    run_time: float = 2.0,
) -> VGroup:
    nl = makeNumberLine(-1, 6, 1, length=9)
    start = nl.number_to_point(a)
    end = nl.number_to_point(b)
    interval = Line(start, end, color=BLUE, stroke_width=6)
    cap = makeMath(r"[1,4)" if closed_left and not closed_right else r"\text{interval}").to_edge(UP, buff=0.45)
    dots = VGroup()
    if closed_left:
        dots.add(Dot(start, color=BLUE, radius=0.08))
    else:
        dots.add(Circle(radius=0.08, color=BLUE, stroke_width=2).move_to(start))
    if closed_right:
        dots.add(Dot(end, color=BLUE, radius=0.08))
    else:
        dots.add(Circle(radius=0.08, color=BLUE, stroke_width=2).move_to(end))
    scene.play(Write(cap), Create(nl), Create(interval), FadeIn(dots), run_time=run_time)
    return VGroup(nl, interval, dots, cap)
