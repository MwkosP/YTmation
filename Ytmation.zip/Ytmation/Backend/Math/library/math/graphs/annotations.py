"""Graph annotations — guides, markers."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes, animateDotOnPath
from Math.library.math.graphs._core import makeMath, getAxes


def showVerticalMarker(
    scene: Scene,
    x0: float = 2.0,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(0, 4, 1), y_range=(0, 6, 1))
    axes = getAxes(axes_g)
    graph = plotOnAxes(axes_g, lambda x: 0.4 * x**2, x_range=(0, 3.5), color=BLUE)
    vline = DashedLine(axes.c2p(x0, 0), axes.c2p(x0, 6), color=YELLOW)
    dot = Dot(axes.c2p(x0, 0.4 * x0**2), color="#FF4500")
    cap = makeMath(rf"x={x0}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), Create(vline), FadeIn(dot), run_time=run_time)
    return VGroup(axes_g, graph, vline, dot, cap)


def showDotTracingGraph(
    scene: Scene,
    run_time: float = 2.5,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(0, 2 * PI, PI / 2), y_range=(-1.5, 1.5, 0.5))
    graph = plotOnAxes(axes_g, np.sin, x_range=(0, 2 * PI), color=BLUE)
    cap = makeMath(r"\text{trace along graph}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), run_time=run_time * 0.4)
    animateDotOnPath(scene, graph, run_time=run_time * 0.55)
    return VGroup(axes_g, graph, cap)
