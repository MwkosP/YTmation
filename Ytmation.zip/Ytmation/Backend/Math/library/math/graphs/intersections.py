"""Intersections and roots on graphs."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath, getAxes


def findIntersectionApprox(
    f,
    g,
    x0: float,
    x1: float,
    n: int = 80,
) -> tuple[float, float] | None:
    xs = np.linspace(x0, x1, n)
    best_x, best_d = xs[0], abs(f(xs[0]) - g(xs[0]))
    for x in xs:
        d = abs(f(x) - g(x))
        if d < best_d:
            best_d, best_x = d, x
    if best_d > 0.15:
        return None
    return float(best_x), float(f(best_x))


def showIntersection(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    f, g = lambda x: x**2, lambda x: x + 2
    axes_g = makeLabeledAxes(x_range=(-3, 3, 1), y_range=(-1, 6, 1))
    g1 = plotOnAxes(axes_g, f, x_range=(-2.5, 2.5), color=BLUE)
    g2 = plotOnAxes(axes_g, g, x_range=(-2.5, 2.5), color="#FF4500")
    hit = findIntersectionApprox(f, g, -1, 3)
    markers = VGroup()
    if hit:
        markers.add(Dot(getAxes(axes_g).c2p(*hit), color=YELLOW, radius=0.1))
    cap = makeMath(r"\text{intersection}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(g1), Create(g2), run_time=run_time * 0.55)
    scene.play(FadeIn(markers), run_time=run_time * 0.45)
    return VGroup(axes_g, g1, g2, markers, cap)


def showRootsOnGraph(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    f = lambda x: x**2 - 4
    axes_g = makeLabeledAxes(x_range=(-4, 4, 1), y_range=(-5, 5, 1))
    graph = plotOnAxes(axes_g, f, x_range=(-3.5, 3.5), color=BLUE)
    axes = getAxes(axes_g)
    roots = VGroup(
        Dot(axes.c2p(-2, 0), color=YELLOW, radius=0.09),
        Dot(axes.c2p(2, 0), color=YELLOW, radius=0.09),
    )
    cap = makeMath(r"f(x)=0").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), FadeIn(roots), run_time=run_time)
    return VGroup(axes_g, graph, roots, cap)
