"""Piecewise graphs."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.graphs._core import makeMath, getAxes


def showPiecewiseGraph(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-3, 3, 1), y_range=(-1, 5, 1))
    axes = getAxes(axes_g)

    def f(x):
        return x + 2 if x < 0 else x**2

    try:
        graph = axes.plot(f, x_range=[-2.5, 2.5], discontinuities=[0], color=BLUE, stroke_width=3)
    except TypeError:
        left = axes.plot(lambda x: x + 2, x_range=[-2.5, 0], color=BLUE, stroke_width=3)
        right = axes.plot(lambda x: x**2, x_range=[0, 2.5], color=BLUE, stroke_width=3)
        graph = VGroup(left, right)
    cap = makeMath(r"f(x)=\begin{cases}x+2 & x<0\\ x^2 & x\ge0\end{cases}").scale(0.65).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), run_time=run_time)
    return VGroup(axes_g, graph, cap)
