"""Scatter plots and trend lines."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs.points import makePoints
from Math.library.math.graphs._core import makeMath, getAxes


def showScatterPlot(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    coords = [(1, 1.2), (2, 1.9), (3, 3.1), (4, 3.8), (5, 5.2)]
    axes_g = makeLabeledAxes(x_range=(0, 6, 1), y_range=(0, 6, 1))
    dots = makePoints(axes_g, coords, color=YELLOW)
    cap = makeMath(r"\text{scatter plot}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), FadeIn(dots), run_time=run_time)
    return VGroup(axes_g, dots, cap)


def showTrendLine(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    coords = [(1, 1.2), (2, 1.9), (3, 3.1), (4, 3.8), (5, 5.2)]
    xs = np.array([c[0] for c in coords])
    ys = np.array([c[1] for c in coords])
    m, b = np.polyfit(xs, ys, 1)
    axes_g = makeLabeledAxes(x_range=(0, 6, 1), y_range=(0, 6, 1))
    dots = makePoints(axes_g, coords, color=YELLOW)
    line = plotOnAxes(axes_g, lambda x: m * x + b, x_range=(0.5, 5.5), color="#FF4500")
    cap = makeMath(r"\text{trend line}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), FadeIn(dots), Create(line), run_time=run_time)
    return VGroup(axes_g, dots, line, cap)
