"""Shaded regions between curves or under a graph."""

from manim import *

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.graphs._core import makeMath, getAxes


def showShadeUnderCurve(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(0, 4, 1), y_range=(0, 5, 1))
    axes = getAxes(axes_g)
    graph = plotOnAxes(axes_g, lambda x: 0.3 * x**2 + 0.5, x_range=(0, 3.5), color=BLUE)
    area = axes.get_area(graph, x_range=(0.5, 3), color=BLUE, opacity=0.35)
    cap = makeMath(r"\text{region under curve}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), FadeIn(area), run_time=run_time)
    return VGroup(axes_g, graph, area, cap)


def showShadeBetweenCurves(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(0, 4, 1), y_range=(0, 5, 1))
    axes = getAxes(axes_g)
    f = plotOnAxes(axes_g, lambda x: x + 1, x_range=(0, 3.5), color=BLUE)
    g = plotOnAxes(axes_g, lambda x: 0.25 * x**2 + 0.5, x_range=(0, 3.5), color="#FF4500")
    area = axes.get_area(f, x_range=(0.5, 3), bounded_graph=g, color=GREEN, opacity=0.35)
    cap = makeMath(r"\text{area between curves}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(f), Create(g), FadeIn(area), run_time=run_time)
    return VGroup(axes_g, f, g, area, cap)
