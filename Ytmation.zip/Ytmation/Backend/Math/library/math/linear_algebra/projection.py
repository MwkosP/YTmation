"""Orthogonal projection onto a line."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def projectOnto2d(v: np.ndarray, onto: np.ndarray) -> np.ndarray:
    u = onto[:2].astype(float)
    v2 = v[:2].astype(float)
    denom = np.dot(u, u)
    if denom < 1e-12:
        return np.zeros(3)
    coef = np.dot(v2, u) / denom
    p = coef * u
    return np.array([p[0], p[1], 0.0])


def makeProjectionDiagram(
    origin: np.ndarray,
    v: np.ndarray,
    line_dir: np.ndarray,
) -> VGroup:
    proj = projectOnto2d(v, line_dir)
    line_unit = line_dir / np.linalg.norm(line_dir[:2])
    line = DashedLine(
        origin - line_unit * 3,
        origin + line_unit * 3,
        color=GREY_B,
    )
    v_arrow = makeVectorArrow(origin, v, label=r"\vec{v}", color=BLUE)
    p_arrow = makeVectorArrow(origin, proj, label=r"\mathrm{proj}", color="#FF4500")
    perp = DashedLine(origin + proj, origin + v, color=YELLOW, stroke_width=2)
    return VGroup(line, v_arrow, p_arrow, perp)


def showProjection(
    scene: Scene,
    v: np.ndarray | None = None,
    line_dir: np.ndarray | None = None,
    run_time: float = 2.0,
) -> VGroup:
    v = v if v is not None else np.array([2.0, 1.5, 0.0])
    line_dir = line_dir if line_dir is not None else RIGHT + UP * 0.3
    diagram = makeProjectionDiagram(ORIGIN, v, line_dir)
    caption = makeMath(r"\mathrm{proj}_{\vec{u}}\vec{v}").to_edge(UP, buff=0.45)
    scene.play(Write(caption), Create(diagram[0]), run_time=run_time * 0.3)
    scene.play(Create(diagram[1]), Create(diagram[2]), Create(diagram[3]), run_time=run_time * 0.7)
    return VGroup(diagram, caption)
