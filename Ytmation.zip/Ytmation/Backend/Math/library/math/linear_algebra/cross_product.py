"""Cross product — 2D area / 3D right-hand rule."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def cross2d(a: np.ndarray, b: np.ndarray) -> float:
    return float(a[0] * b[1] - a[1] * b[0])


def makeCrossProductParallelogram(
    origin: np.ndarray,
    a: np.ndarray,
    b: np.ndarray,
) -> VGroup:
    a2 = np.array(a[:2], dtype=float)
    b2 = np.array(b[:2], dtype=float)
    poly = Polygon(
        origin,
        origin + np.array([a2[0], a2[1], 0]),
        origin + np.array([a2[0] + b2[0], a2[1] + b2[1], 0]),
        origin + np.array([b2[0], b2[1], 0]),
        color=BLUE,
        fill_opacity=0.3,
        stroke_width=2,
    )
    arrows = VGroup(
        makeVectorArrow(origin, a, color=YELLOW, label=r"\vec{a}"),
        makeVectorArrow(origin, b, color="#FF4500", label=r"\vec{b}"),
    )
    z = cross2d(a2, b2)
    label = makeMath(rf"\vec{{a}}\times\vec{{b}} = {z:.2f}\,\hat{{k}}", scale=0.75)
    return VGroup(poly, arrows, label)


def showCrossProduct2d(
    scene: Scene,
    a: np.ndarray | None = None,
    b: np.ndarray | None = None,
    run_time: float = 2.0,
) -> VGroup:
    a = a if a is not None else np.array([2.0, 0.4, 0.0])
    b = b if b is not None else np.array([0.5, 1.5, 0.0])
    diagram = makeCrossProductParallelogram(ORIGIN, a, b)
    diagram[2].to_edge(UP, buff=0.45)
    scene.play(Create(diagram[0]), Create(diagram[1]), Write(diagram[2]), run_time=run_time)
    return diagram


def showCrossProduct3d(
    scene: Scene,
    a: np.ndarray | None = None,
    b: np.ndarray | None = None,
    run_time: float = 2.5,
) -> VGroup:
    """Works best on ThreeDScene; sets camera if available."""
    a = a if a is not None else np.array([1.5, 0.0, 0.0])
    b = b if b is not None else np.array([0.0, 1.2, 0.0])
    c = np.cross(a, b)
    if hasattr(scene, "set_camera_orientation"):
        scene.set_camera_orientation(phi=68 * DEGREES, theta=-40 * DEGREES)
    try:
        arr_a = Arrow3D(start=ORIGIN, end=a, color=BLUE)
        arr_b = Arrow3D(start=ORIGIN, end=b, color="#FF4500")
        arr_c = Arrow3D(start=ORIGIN, end=c, color=YELLOW)
        objs = VGroup(arr_a, arr_b, arr_c)
    except Exception:
        objs = makeCrossProductParallelogram(ORIGIN, a, b)
    label = makeMath(r"\vec{a}\times\vec{b}").to_edge(UP, buff=0.4)
    scene.play(Write(label), Create(objs), run_time=run_time)
    return VGroup(objs, label)
