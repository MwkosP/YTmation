"""Linear transforms on grids and shapes."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import as2x2, makeMath
from Math.library.math.linear_algebra.matrices import (
    makeMatrixTex,
    makeUnitSquare,
    makeUnitSquareWithBasis,
    makeTransformedMobject,
)


def makeNumberPlaneGrid(
    x_range: tuple = (-4, 4, 1),
    y_range: tuple = (-4, 4, 1),
    background_line_style: dict | None = None,
) -> NumberPlane:
    style = background_line_style or {"stroke_color": GREY_D, "stroke_width": 1, "stroke_opacity": 0.6}
    return NumberPlane(x_range=x_range, y_range=y_range, background_line_style=style)


def makeTransformedGrid(plane: NumberPlane, matrix: np.ndarray) -> NumberPlane:
    return plane.copy().apply_matrix(as2x2(matrix))


def showLinearTransform(
    scene: Scene,
    matrix: np.ndarray,
    show_grid: bool = True,
    run_time: float = 2.0,
) -> VGroup:
    mat_tex = makeMatrixTex(matrix).to_corner(UR, buff=0.45)
    if show_grid:
        plane = makeNumberPlaneGrid()
        target = makeTransformedGrid(plane, matrix)
        scene.play(Create(plane), Write(mat_tex), run_time=run_time * 0.35)
        scene.play(Transform(plane, target), run_time=run_time * 0.65)
        return VGroup(plane, mat_tex)
    sq_bundle = makeUnitSquareWithBasis()
    target = makeTransformedMobject(sq_bundle, matrix)
    scene.play(Create(sq_bundle), Write(mat_tex), run_time=run_time * 0.4)
    scene.play(Transform(sq_bundle, target), run_time=run_time * 0.6)
    return VGroup(sq_bundle, mat_tex)


def applyMatrixToSquare(
    scene: Scene,
    matrix: np.ndarray,
    side: float = 2.0,
    run_time: float = 2.0,
) -> VGroup:
    """Backward-compatible API (used by math.recipes.demoMatrixTransform)."""
    square = makeUnitSquare(side, fill_opacity=0.3).shift(LEFT * 2)
    target = makeTransformedMobject(square, matrix)
    mat_tex = makeMatrixTex(matrix)
    scene.play(Create(square), Write(mat_tex), run_time=0.8)
    scene.play(Transform(square, target), run_time=run_time, rate_func=smooth)
    return VGroup(square, mat_tex)
