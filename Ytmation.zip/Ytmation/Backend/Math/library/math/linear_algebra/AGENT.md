# Linear Algebra Library — Agent Cookbook

Pure LA primitives. Reused by `physics/`, future `ml/`. **No domain narrative.**

## API layers

| Prefix | Use when |
|--------|----------|
| `make…` | Returns mobjects; you control `scene.play` |
| `show…` | One beat on `scene` |
| `demo…` | Full topic (`recipes.py`) |

## Module map

| File | Topics |
|------|--------|
| `vectors.py` | arrows, sum, decompose |
| `matrices.py` | `makeMatrixTex`, `makeTransformedMobject` |
| `transformations.py` | grid/square linear map, `applyMatrixToSquare` |
| `matrix_vector.py` | **Av** on arrows |
| `matrix_multiply.py` | **AB vs BA** on same vector |
| `inverse.py` | **A⁻¹** undoes transform |
| `determinant.py` | area scaling |
| `dot_product.py` | dot |
| `projection.py` | orthogonal proj |
| `span.py` | span of two vectors |
| `subspaces.py` | **Col(A)**, **Null(A)** (2D) |
| `eigenvectors.py` | real eigen (2×2) |
| `rotation.py` | rotation matrix, complex λ |
| `systems.py` | elimination **text** steps |
| `rref.py` | animated **matrix** row ops |
| `cross_product.py` | 2D parallelogram / 3D (Arrow3D) |
| `gram_schmidt.py` | 2-vector GS |
| `norms.py` | length + angle arc |
| `vector_field.py` | field plot |

## Recipes (all `demo…`)

`demoMatrixTransform`, `demoLinearTransformGrid`, `demoMatrixVectorProduct`, `demoMatrixMultiplyOrder`, `demoRref`, `demoMatrixInverse`, `demoEigenvectors`, `demoEigenStretch`, `demoRotation`, `demoComplexEigenRotation`, `demoDeterminant`, `demoDotProduct`, `demoProjection`, `demoSpan`, `demoColumnNullSpace`, `demoGramSchmidt`, `demoNormAngle`, `demoCrossProduct2d`, `demoCrossProduct3d`, `demoVectorAddition`, `demoVectorDecompose`, `demoGaussianElimination`, `demoVectorField`

## N×N (`nxn.py` + `_core.py`)

| n | What you get |
|---|----------------|
| **2** | Arrows, parallelogram det, eigen lines (default) |
| **3** | `Matrix` product display, `Arrow3D` for Av, det label (volume) |
| **4+** | `Matrix` math only: A·B, A·v, det, eigenvalues list, inverse |

Helpers: `asNxN`, `multiplyNxN`, `multiplyMatrixVectorNxN`, `detNxN`, `inverseNxN`, `eigenNxN`.

`showMatrixProductNxN`, `showMatrixVectorNxN`, `showMatrixMultiplyOrderNxN`, `showDeterminantNxN`, `showEigenNxN` auto-dispatch or call directly.

`rref.eliminationStates` already supports n×n augmented matrices.

## Still deferred (ML / advanced)

SVD, PCA, least squares, animated 4×4+ geometry — add under `ml/` later.

## 3D note

`showCrossProduct3d` uses `Arrow3D` when available; prefer `ThreeDScene` in workflow for best camera.
