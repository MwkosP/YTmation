"""Vector norms and angles."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath
from Math.library.math.linear_algebra.dot_product import dot2d
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def norm2d(v: np.ndarray) -> float:
    return float(np.linalg.norm(v[:2]))


def angleBetween2d(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = norm2d(a), norm2d(b)
    if na < 1e-12 or nb < 1e-12:
        return 0.0
    cos_t = np.clip(dot2d(a, b) / (na * nb), -1.0, 1.0)
    return float(np.arccos(cos_t))


def makeAngleArc(origin: np.ndarray, a: np.ndarray, b: np.ndarray, radius: float = 0.7) -> Angle:
    o = origin
    p1 = o + np.array([a[0], a[1], 0]) / max(norm2d(a), 1e-9) * radius
    p2 = o + np.array([b[0], b[1], 0]) / max(norm2d(b), 1e-9) * radius
    l1 = Line(o, p1)
    l2 = Line(o, p2)
    return Angle(l1, l2, radius=radius, color=YELLOW)


def showNormAndAngle(
    scene: Scene,
    a: np.ndarray | None = None,
    b: np.ndarray | None = None,
    run_time: float = 2.0,
) -> VGroup:
    a = a if a is not None else np.array([2.0, 0.6, 0.0])
    b = b if b is not None else np.array([1.0, 1.4, 0.0])
    va = makeVectorArrow(ORIGIN, a, color=BLUE, label=rf"|\vec{{a}}|={norm2d(a):.2f}")
    vb = makeVectorArrow(ORIGIN, b, color="#FF4500", label=rf"|\vec{{b}}|={norm2d(b):.2f}")
    arc = makeAngleArc(ORIGIN, a, b)
    theta = np.rad2deg(angleBetween2d(a, b))
    caption = makeMath(rf"\theta \approx {theta:.0f}^\circ").to_edge(UP, buff=0.45)
    scene.play(Write(caption), Create(va), Create(vb), run_time=run_time * 0.6)
    scene.play(Create(arc), run_time=run_time * 0.4)
    return VGroup(va, vb, arc, caption)
