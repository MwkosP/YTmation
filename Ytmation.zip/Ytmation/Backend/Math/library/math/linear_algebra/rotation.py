"""Rotation matrices and complex eigenvalues."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath
from Math.library.math.linear_algebra.transformations import showLinearTransform


def makeRotationMatrix(angle_rad: float) -> np.ndarray:
    c, s = np.cos(angle_rad), np.sin(angle_rad)
    return np.array([[c, -s], [s, c]])


def showRotation(
    scene: Scene,
    angle_deg: float = 40.0,
    run_time: float = 2.0,
) -> VGroup:
    R = makeRotationMatrix(np.deg2rad(angle_deg))
    caption = makeMath(rf"R(\theta),\ \theta={angle_deg:.0f}^\circ").to_edge(UP, buff=0.4)
    scene.play(Write(caption), run_time=0.4)
    g = showLinearTransform(scene, R, show_grid=True, run_time=run_time - 0.4)
    return VGroup(g, caption)


def showComplexEigenRotation(
    scene: Scene,
    angle_deg: float = 90.0,
    run_time: float = 2.2,
) -> VGroup:
    """Pure rotation: eigenvalues e^{±iθ} — vectors rotate, no real eigen lines."""
    R = makeRotationMatrix(np.deg2rad(angle_deg))
    caption = makeMath(r"\lambda = e^{\pm i\theta}\ \Rightarrow\ \text{rotation}").to_edge(UP, buff=0.4)
    scene.play(Write(caption), run_time=0.4)
    g = showLinearTransform(scene, R, show_grid=False, run_time=run_time - 0.4)
    return VGroup(g, caption)
