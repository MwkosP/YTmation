"""Column space and null space (2D geometry)."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import det2x2, makeMath
from Math.library.math.linear_algebra.span import makeSpanParallelogram
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def nullDirection2d(A: np.ndarray) -> np.ndarray | None:
    m = np.array(A[:2, :2], dtype=float)
    if abs(det2x2(m)) > 1e-8:
        return None
    if np.linalg.norm(m[0]) < 1e-9:
        v = m[1]
    else:
        v = np.array([-m[0, 1], m[0, 0], 0.0])
    n = np.linalg.norm(v[:2])
    return v / n if n > 1e-9 else None


def showColumnSpaceNullSpace(
    scene: Scene,
    A: np.ndarray | None = None,
    run_time: float = 2.2,
) -> VGroup:
    A = A if A is not None else np.array([[1.0, 2.0], [2.0, 4.0]])
    c1 = np.array([A[0, 0], A[1, 0], 0.0])
    c2 = np.array([A[0, 1], A[1, 1], 0.0])
    col_span = makeSpanParallelogram(ORIGIN, c1, c2, color=BLUE, fill_opacity=0.15)
    title = makeMath(r"\mathrm{Col}(A)").to_edge(UP, buff=0.45)
    scene.play(Write(title), FadeIn(col_span[0]), Create(col_span[1]), run_time=run_time * 0.55)
    null_v = nullDirection2d(A)
    extras = VGroup(title, col_span)
    if null_v is not None:
        null_line = DashedLine(ORIGIN - null_v * 2.5, ORIGIN + null_v * 2.5, color="#FF4500")
        null_lbl = makeMath(r"\mathrm{Null}(A)", color="#FF4500").next_to(null_line, DOWN, buff=0.2)
        scene.play(Create(null_line), Write(null_lbl), run_time=run_time * 0.45)
        extras.add(null_line, null_lbl)
    return extras
