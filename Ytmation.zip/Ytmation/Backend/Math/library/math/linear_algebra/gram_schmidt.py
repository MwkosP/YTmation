"""Gram–Schmidt orthogonalization (2 vectors)."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath
from Math.library.math.linear_algebra.projection import projectOnto2d
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def gramSchmidt2(v1: np.ndarray, v2: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    u1 = np.array(v1, dtype=float)
    u2 = np.array(v2, dtype=float) - projectOnto2d(v2, u1)
    if np.linalg.norm(u2[:2]) < 1e-9:
        u2 = np.array([0.0, 1.0, 0.0])
    return u1, u2


def makeGramSchmidtDiagram(v1: np.ndarray, v2: np.ndarray) -> VGroup:
    u1, u2 = gramSchmidt2(v1, v2)
    return VGroup(
        makeVectorArrow(ORIGIN, v1, color=GREY_B, label=r"\vec{v}_1"),
        makeVectorArrow(ORIGIN, v2, color=GREY_B, label=r"\vec{v}_2"),
        makeVectorArrow(ORIGIN, u1, color=BLUE, label=r"\vec{u}_1"),
        makeVectorArrow(ORIGIN, u2, color="#FF4500", label=r"\vec{u}_2"),
    )


def showGramSchmidt(
    scene: Scene,
    v1: np.ndarray | None = None,
    v2: np.ndarray | None = None,
    run_time: float = 2.2,
) -> VGroup:
    v1 = v1 if v1 is not None else np.array([2.0, 0.5, 0.0])
    v2 = v2 if v2 is not None else np.array([1.0, 1.5, 0.0])
    diagram = makeGramSchmidtDiagram(v1, v2)
    caption = makeMath(r"\text{Gram–Schmidt}").to_edge(UP, buff=0.45)
    scene.play(Write(caption), Create(diagram[0]), Create(diagram[1]), run_time=run_time * 0.45)
    scene.play(Create(diagram[2]), Create(diagram[3]), run_time=run_time * 0.55)
    return VGroup(diagram, caption)
