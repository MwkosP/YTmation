"""2D vector field from function R2 -> R2."""

from manim import *
import numpy as np


def makeVectorField(
    func,
    x_range: tuple = (-2, 2, 1),
    y_range: tuple = (-2, 2, 1),
    step: float = 0.8,
    color=BLUE,
) -> VGroup:
    arrows = VGroup()
    for x in np.arange(x_range[0], x_range[1] + 0.01, step):
        for y in np.arange(y_range[0], y_range[1] + 0.01, step):
            vx, vy = func(x, y)[:2]
            mag = np.hypot(vx, vy)
            if mag < 1e-6:
                continue
            scale = 0.35 / max(mag, 0.3)
            start = np.array([x, y, 0.0])
            end = start + np.array([vx, vy, 0.0]) * scale
            arrows.add(Arrow(start, end, buff=0, stroke_width=2, max_tip_length_to_length_ratio=0.2, color=color))
    return arrows


def showVectorField(
    scene: Scene,
    func,
    run_time: float = 2.0,
) -> VGroup:
    field = makeVectorField(func, color=BLUE)
    scene.play(Create(field), run_time=run_time)
    return field
