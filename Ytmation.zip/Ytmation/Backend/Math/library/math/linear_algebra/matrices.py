"""Matrix display and application to mobjects."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath, as2x2, asNxN, formatMatrixForManim


def makeMatrixTex(matrix: np.ndarray, scale: float = 0.8) -> Matrix:
    return Matrix(formatMatrixForManim(matrix)).scale(scale)


def makeMatrixTexNxN(matrix: np.ndarray, scale: float = 0.8) -> Matrix:
    """Alias — any n×n."""
    return makeMatrixTex(matrix, scale=scale)


def makeUnitSquare(
    side: float = 2.0,
    color=BLUE,
    fill_opacity: float = 0.25,
    shift: np.ndarray | None = None,
) -> Square:
    sq = Square(side_length=side, color=color, fill_opacity=fill_opacity)
    if shift is not None:
        sq.shift(shift)
    return sq


def makeUnitSquareWithBasis(
    side: float = 2.0,
    show_basis: bool = True,
) -> VGroup:
    sq = makeUnitSquare(side)
    group = VGroup(sq)
    if show_basis:
        o = sq.get_center()
        group.add(
            Arrow(o, o + RIGHT * side * 0.55, buff=0, color=YELLOW, stroke_width=3),
            Arrow(o, o + UP * side * 0.55, buff=0, color=GREEN, stroke_width=3),
            MathTex(r"\hat{\imath}", color=YELLOW).scale(0.6).next_to(o + RIGHT, RIGHT, buff=0.05),
            MathTex(r"\hat{\jmath}", color=GREEN).scale(0.6).next_to(o + UP, UP, buff=0.05),
        )
    return group


def applyMatrixToMobject(mobject: Mobject, matrix: np.ndarray) -> Mobject:
    m = asNxN(matrix)
    n = m.shape[0]
    if n == 2:
        return mobject.copy().apply_matrix(m)
    if n == 3:
        return mobject.copy().apply_matrix(m)
    return mobject.copy().apply_matrix(m[:2, :2])


def makeTransformedMobject(mobject: Mobject, matrix: np.ndarray) -> Mobject:
    """Returns transformed copy — agent runs scene.play."""
    return applyMatrixToMobject(mobject, matrix)
