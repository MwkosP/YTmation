"""Linear algebra demos — one topic per call."""

from manim import *
import numpy as np

from Math.library.common.layout import SceneLayout, makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.linear_algebra.transformations import applyMatrixToSquare, showLinearTransform
from Math.library.math.linear_algebra.eigenvectors import showEigenDirections, showEigenvalueStretch
from Math.library.math.linear_algebra.determinant import showDeterminantArea
from Math.library.math.linear_algebra.dot_product import showDotProduct
from Math.library.math.linear_algebra.projection import showProjection
from Math.library.math.linear_algebra.span import showSpan
from Math.library.math.linear_algebra.vectors import showVectorAddition, decomposeVector
from Math.library.math.linear_algebra.systems import showGaussianElimination
from Math.library.math.linear_algebra.vector_field import showVectorField
from Math.library.math.linear_algebra.matrix_vector import showMatrixVectorProduct
from Math.library.math.linear_algebra.matrix_multiply import showMatrixMultiplyOrder
from Math.library.math.linear_algebra.rref import showRrefAnimation
from Math.library.math.linear_algebra.cross_product import showCrossProduct2d, showCrossProduct3d
from Math.library.math.linear_algebra.rotation import showRotation, showComplexEigenRotation
from Math.library.math.linear_algebra.subspaces import showColumnSpaceNullSpace
from Math.library.math.linear_algebra.gram_schmidt import showGramSchmidt
from Math.library.math.linear_algebra.norms import showNormAndAngle
from Math.library.math.linear_algebra.inverse import showMatrixInverse


def demoMatrixTransform(scene: Scene, title: str = "Matrix Transform") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    applyMatrixToSquare(scene, np.array([[1.2, 0.5], [0.3, 1.1]]))


def demoLinearTransformGrid(scene: Scene, title: str = "Linear Transform") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showLinearTransform(scene, np.array([[1.0, 0.6], [-0.4, 1.0]]), show_grid=True)


def demoMatrixVectorProduct(scene: Scene, title: str = "Matrix × Vector") -> None:
    setupScene(scene)
    layout = SceneLayout.hero()
    scene.play(Write(makeTitle(title, size=38, layout=layout)))
    showMatrixVectorProduct(scene)


def demoMatrixMultiplyOrder(scene: Scene, title: str = "AB vs BA") -> None:
    setupScene(scene)
    layout = SceneLayout.sidebar()
    scene.play(Write(makeTitle(title, size=40, layout=layout)))
    showMatrixMultiplyOrder(scene, layout=layout)


def demoRref(scene: Scene, title: str = "Row Reduction") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showRrefAnimation(scene)


def demoMatrixInverse(scene: Scene, title: str = "Inverse") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showMatrixInverse(scene)


def demoEigenvectors(scene: Scene, title: str = "Eigenvectors") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showEigenDirections(scene, np.array([[2.0, 1.0], [1.0, 2.0]]))


def demoEigenStretch(scene: Scene, title: str = "Eigenvalue Stretch") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showEigenvalueStretch(scene, np.array([[2.0, 0.0], [0.0, 0.5]]))


def demoRotation(scene: Scene, title: str = "Rotation") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showRotation(scene, angle_deg=35)


def demoComplexEigenRotation(scene: Scene, title: str = "Rotation / Complex λ") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showComplexEigenRotation(scene, angle_deg=60)


def demoDeterminant(scene: Scene, title: str = "Determinant") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showDeterminantArea(scene, np.array([[2.0, 0.5], [0.0, 1.5]]))


def demoDotProduct(scene: Scene, title: str = "Dot Product") -> None:
    setupScene(scene)
    layout = SceneLayout.sidebar()
    scene.play(Write(makeTitle(title, size=40, layout=layout)))
    showDotProduct(scene, layout=layout)


def demoProjection(scene: Scene, title: str = "Projection") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showProjection(scene)


def demoSpan(scene: Scene, title: str = "Span") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showSpan(scene)


def demoColumnNullSpace(scene: Scene, title: str = "Col / Null Space") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showColumnSpaceNullSpace(scene)


def demoGramSchmidt(scene: Scene, title: str = "Gram–Schmidt") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showGramSchmidt(scene)


def demoNormAngle(scene: Scene, title: str = "Norm & Angle") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showNormAndAngle(scene)


def demoCrossProduct2d(scene: Scene, title: str = "Cross Product (2D)") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showCrossProduct2d(scene)


def demoCrossProduct3d(scene: Scene, title: str = "Cross Product (3D)") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showCrossProduct3d(scene)


def demoVectorAddition(scene: Scene, title: str = "Vector Addition") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showVectorAddition(scene)


def demoVectorDecompose(scene: Scene, title: str = "Components") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    vg = decomposeVector(ORIGIN, np.array([2.2, 1.4, 0.0]))
    scene.play(Create(vg), run_time=1.8)


def demoGaussianElimination(scene: Scene, title: str = "Gaussian Elimination") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showGaussianElimination(scene)


def demoVectorField(scene: Scene, title: str = "Vector Field") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showVectorField(scene, lambda x, y: (-y, x))


def demoMatrixProduct3x3(scene: Scene, title: str = "3×3 Product") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    from Math.library.math.linear_algebra.nxn import showMatrixProductNxN
    A = np.array([[1.0, 0.0, 1.0], [0.0, 2.0, 0.0], [1.0, 0.0, 1.0]])
    B = np.array([[1.0, 1.0, 0.0], [0.0, 1.0, 1.0], [1.0, 0.0, 1.0]])
    showMatrixProductNxN(scene, A, B)


def demoMatrixVector3x3(scene: Scene, title: str = "3×3 · Vector") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    from Math.library.math.linear_algebra.nxn import showMatrixVectorNxN
    A = np.array([[1.0, 0.0, 0.5], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    v = np.array([1.0, 0.5, 0.8])
    showMatrixVectorNxN(scene, A, v)


def demoMatrixMultiplyOrder3x3(scene: Scene, title: str = "3×3 AB vs BA") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    from Math.library.math.linear_algebra.nxn import showMatrixMultiplyOrderNxN
    A = np.array([[1.0, 0.5, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    B = np.array([[1.0, 0.0, 0.0], [1.0, 1.0, 0.0], [0.0, 1.0, 1.0]])
    showMatrixMultiplyOrderNxN(scene, A, B)
