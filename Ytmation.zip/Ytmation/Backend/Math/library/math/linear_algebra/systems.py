"""Linear systems — augmented matrix / elimination steps."""

from manim import *

from Math.library.math.linear_algebra._core import makeMath, makeStepList, playStepReveal


def makeAugmentedMatrixTex(rows: list[list[str]]) -> Mobject:
    """rows like [['1','2','|','5'], ...] — use strings for Manim Matrix."""
    left = [[r[0], r[1]] for r in rows]
    right = [[r[3]] for r in rows]
    m_left = Matrix(left).scale(0.7)
    bar = makeMath("|").scale(0.9)
    m_right = Matrix(right).scale(0.7)
    return VGroup(m_left, bar, m_right).arrange(RIGHT, buff=0.15)


def showGaussianElimination(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    steps = steps or [
        r"\left[\begin{array}{cc|c} 1 & 2 & 5 \\ 2 & -1 & 1 \end{array}\right]",
        r"R_2 \leftarrow R_2 - 2R_1",
        r"\left[\begin{array}{cc|c} 1 & 2 & 5 \\ 0 & -5 & -9 \end{array}\right]",
        r"x=1,\ y=2",
    ]
    rows = makeStepList(steps)
    scene.play(FadeIn(rows[0]), run_time=run_time * 0.3)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.18)
    return rows
