"""Matrix inverse — A maps square back via A^{-1}."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import as2x2, inverseNxN, dimOf, makeMath
from Math.library.math.linear_algebra.matrices import makeUnitSquare, makeTransformedMobject, makeMatrixTex


def invert2x2(matrix: np.ndarray) -> np.ndarray:
    return inverseNxN(as2x2(matrix))


def showMatrixInverse(
    scene: Scene,
    matrix: np.ndarray | None = None,
    run_time: float = 2.2,
) -> VGroup:
    matrix = matrix if matrix is not None else np.array([[1.2, 0.4], [0.2, 1.0]])
    if dimOf(matrix) > 3:
        inv = inverseNxN(matrix)
        group = VGroup(makeMatrixTex(matrix), makeMath(r"A^{-1}:"), makeMatrixTex(inv)).arrange(DOWN)
        scene.play(FadeIn(group), run_time=run_time)
        return group
    sq = makeUnitSquare(side=2.0, fill_opacity=0.3)
    mid = makeTransformedMobject(sq, matrix)
    inv = invert2x2(matrix)
    back = makeTransformedMobject(mid, inv)
    mat_a = makeMatrixTex(matrix).to_corner(UL, buff=0.4)
    mat_inv = makeMatrixTex(inv).next_to(mat_a, DOWN, buff=0.2)
    scene.play(Create(sq), Write(mat_a), run_time=run_time * 0.25)
    scene.play(Transform(sq, mid), run_time=run_time * 0.35)
    scene.play(Write(mat_inv), Transform(sq, back), run_time=run_time * 0.4)
    return VGroup(sq, mat_a, mat_inv)
