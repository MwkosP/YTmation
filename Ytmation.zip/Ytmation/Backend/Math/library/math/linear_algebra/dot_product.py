"""Dot product and angle between vectors."""

from manim import *
import numpy as np

from Math.library.common import SceneLayout, placeInRegion
from Math.library.math.linear_algebra._core import makeMath
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def dot2d(a: np.ndarray, b: np.ndarray) -> float:
    return float(a[0] * b[0] + a[1] * b[1])


def makeDotProductDiagram(
    origin: np.ndarray,
    a: np.ndarray,
    b: np.ndarray,
) -> VGroup:
    """Return arrows + inline formula VGroup, no positioning."""
    va = makeVectorArrow(origin, a, label=r"\vec{a}", color=BLUE)
    vb = makeVectorArrow(origin, b, label=r"\vec{b}", color="#FF4500")
    d = dot2d(a, b)
    formula = makeMath(rf"\vec{{a}}\cdot\vec{{b}} = {d:.2f}")
    return VGroup(va, vb, formula)


def showDotProduct(
    scene: Scene,
    a: np.ndarray | None = None,
    b: np.ndarray | None = None,
    run_time: float = 2.0,
    layout: SceneLayout | None = None,
) -> VGroup:
    """
    Visualize dot product with optional SceneLayout.

    If layout is given (recommended from demos), diagram is placed in the
    'main' region and the scalar formula in the 'sidebar' or top of main.
    """
    a = a if a is not None else np.array([2.2, 0.8, 0.0])
    b = b if b is not None else np.array([1.0, 1.6, 0.0])
    diagram = makeDotProductDiagram(ORIGIN, a, b)

    # Backwards-compatible behavior: no layout -> keep simple placement
    if layout is None:
        diagram[2].to_edge(UP, buff=0.45)
        scene.play(Create(diagram[0]), Create(diagram[1]), Write(diagram[2]), run_time=run_time)
        return diagram

    # With layout: arrows in main, formula in sidebar (or top of main)
    vectors = VGroup(diagram[0], diagram[1])
    scalar = diagram[2]
    placeInRegion(vectors, "main", layout=layout, fit=True)
    if "sidebar" in layout.regions:
        placeInRegion(scalar, "sidebar", layout=layout, h_align="left", v_align="top", fit=False)
    else:
        placeInRegion(scalar, "main", layout=layout, h_align="left", v_align="top", fit=False, buff=0.2)

    scene.play(Create(vectors[0]), Create(vectors[1]), run_time=run_time * 0.6)
    scene.play(Write(scalar), run_time=run_time * 0.4)
    return VGroup(vectors, scalar)

