"""Vector arrows, sum, decomposition (pure math)."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath, as3


def makeVectorArrow(
    origin: np.ndarray,
    direction: np.ndarray,
    length_scale: float = 1.0,
    color=YELLOW,
    label: str | None = None,
    buff: float = 0,
) -> VGroup:
    origin = as3(origin)
    d = as3(direction)
    norm = np.linalg.norm(d[:2])
    if norm < 1e-9:
        d = as3(RIGHT)
        norm = 1.0
    unit = d / norm
    L = norm * length_scale
    arrow = Arrow(origin, origin + unit * L, buff=buff, color=color, stroke_width=4)
    group = VGroup(arrow)
    if label:
        group.add(MathTex(label, color=color).scale(0.7).next_to(arrow, UP, buff=0.08))
    return group


def decomposeVector(
    origin: np.ndarray,
    vector: np.ndarray,
    color_x=BLUE,
    color_y=GREEN,
    label_x: str = "x",
    label_y: str = "y",
) -> VGroup:
    vx, vy = float(vector[0]), float(vector[1])
    comp_x = makeVectorArrow(
        origin,
        RIGHT if vx >= 0 else LEFT,
        length_scale=abs(vx) * 0.35,
        color=color_x,
        label=label_x,
    )
    comp_y = makeVectorArrow(
        origin,
        UP if vy >= 0 else DOWN,
        length_scale=abs(vy) * 0.35,
        color=color_y,
        label=label_y,
    )
    dashed = DashedLine(origin, origin + vector, color=WHITE, stroke_width=2)
    return VGroup(dashed, comp_x, comp_y)


def addVectorsTipToTail(
    origin: np.ndarray,
    vectors: list[np.ndarray],
    colors: list | None = None,
) -> VGroup:
    colors = colors or [BLUE, "#FF4500", GREEN]
    arrows = VGroup()
    tip = origin
    for i, v in enumerate(vectors):
        arr = makeVectorArrow(tip, v, length_scale=1.0, color=colors[i % len(colors)])
        arrows.add(arr)
        tip = tip + v
    return arrows


def makeVectorSum(
    origin: np.ndarray,
    vectors: list[np.ndarray],
    colors: list | None = None,
) -> VGroup:
    """Tip-to-tail chain plus resultant from origin."""
    chain = addVectorsTipToTail(origin, vectors, colors)
    resultant = vectors[0]
    for v in vectors[1:]:
        resultant = resultant + v
    res = makeVectorArrow(origin, resultant, color=YELLOW, label=r"\vec{a}+\vec{b}")
    return VGroup(chain, res)


def showVectorAddition(
    scene: Scene,
    vectors: list[np.ndarray] | None = None,
    run_time: float = 2.0,
) -> VGroup:
    vectors = vectors or [np.array([2.0, 0.5, 0.0]), np.array([0.6, 1.4, 0.0])]
    diagram = makeVectorSum(ORIGIN + LEFT * 0.5, vectors)
    caption = makeMath(r"\vec{c} = \vec{a} + \vec{b}").to_edge(UP, buff=0.45)
    scene.play(Write(caption), Create(diagram[0]), run_time=run_time * 0.55)
    scene.play(Create(diagram[1]), run_time=run_time * 0.45)
    return VGroup(diagram, caption)
