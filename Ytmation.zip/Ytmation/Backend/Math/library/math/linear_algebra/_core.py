"""Shared LA helpers — pure math, no domain narrative."""

from manim import *
import numpy as np


def makeMath(tex: str, color=WHITE, scale: float = 0.85) -> MathTex:
    return MathTex(tex, color=color).scale(scale)


def makeStepList(steps: list[str], buff: float = 0.42, color=WHITE) -> VGroup:
    rows = VGroup(*[makeMath(s, color=color, scale=0.8) for s in steps])
    rows.arrange(DOWN, aligned_edge=LEFT, buff=buff)
    return rows


def playStepReveal(scene: Scene, steps: VGroup, up_to: int, run_time: float = 0.55) -> None:
    if 0 <= up_to < len(steps):
        scene.play(FadeIn(steps[up_to]), run_time=run_time)


def as3(vector) -> np.ndarray:
    """Manim points are 3D; accept (x, y) or (x, y, z)."""
    v = np.array(vector, dtype=float).flatten()
    if len(v) >= 3:
        return np.array([v[0], v[1], v[2]])
    if len(v) == 2:
        return np.array([v[0], v[1], 0.0])
    return np.array([0.0, 0.0, 0.0])


def asNxN(matrix: np.ndarray, n: int | None = None) -> np.ndarray:
    """Square slice of matrix (default: full square shape)."""
    m = np.array(matrix, dtype=float)
    if m.ndim != 2:
        raise ValueError("matrix must be 2D")
    size = min(m.shape[0], m.shape[1])
    if n is not None:
        size = min(size, n)
    return m[:size, :size]


def as2x2(matrix: np.ndarray) -> np.ndarray:
    return asNxN(matrix, 2)


def dimOf(matrix: np.ndarray) -> int:
    return asNxN(matrix).shape[0]


def multiplyNxN(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    a = asNxN(A)
    b = asNxN(B)
    if a.shape[0] != b.shape[0]:
        raise ValueError(f"shape mismatch: {a.shape} vs {b.shape}")
    return a @ b


def multiplyMatrixVectorNxN(matrix: np.ndarray, vector: np.ndarray) -> np.ndarray:
    m = asNxN(matrix)
    n = m.shape[0]
    v = np.array(vector, dtype=float).flatten()[:n]
    if v.shape[0] != n:
        raise ValueError(f"vector length {v.shape[0]} != matrix size {n}")
    return m @ v


def detNxN(matrix: np.ndarray) -> float:
    return float(np.linalg.det(asNxN(matrix)))


def det2x2(matrix: np.ndarray) -> float:
    return detNxN(as2x2(matrix))


def inverseNxN(matrix: np.ndarray) -> np.ndarray:
    return np.linalg.inv(asNxN(matrix))


def eigenNxN(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    vals, vecs = np.linalg.eig(asNxN(matrix))
    order = np.argsort(-np.real(vals))
    return np.real(vals[order]), np.real(vecs[:, order])


def eigen2x2(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return eigenNxN(as2x2(matrix))


def formatMatrixForManim(matrix: np.ndarray, precision: int = 3) -> list[list[str]]:
    m = asNxN(matrix)
    return [[f"{x:.{precision}g}" for x in row] for row in m.tolist()]
