"""Animated row reduction on augmented matrices (2×2, 3×3)."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath


def _aug_matrix_mobject(aug: np.ndarray, scale: float = 0.75) -> Matrix:
    rows = []
    for i in range(aug.shape[0]):
        rows.append([f"{aug[i, j]:.3g}" for j in range(aug.shape[1])])
    return Matrix(rows).scale(scale)


def eliminationStates(
    A: np.ndarray,
    b: np.ndarray,
) -> list[np.ndarray]:
    """Return augmented matrix [A|b] after each elimination step (2×2 or 3×3)."""
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float).reshape(-1)
    n = len(b)
    aug = np.hstack([A, b.reshape(-1, 1)])
    states = [aug.copy()]
    for col in range(min(n, A.shape[1])):
        pivot_row = col
        if abs(aug[pivot_row, col]) < 1e-9:
            for r in range(col + 1, n):
                if abs(aug[r, col]) > 1e-9:
                    aug[[pivot_row, r]] = aug[[r, pivot_row]]
                    states.append(aug.copy())
                    break
        if abs(aug[pivot_row, col]) < 1e-9:
            continue
        for r in range(n):
            if r == pivot_row:
                continue
            if abs(aug[r, col]) < 1e-12:
                continue
            factor = aug[r, col] / aug[pivot_row, col]
            aug[r] -= factor * aug[pivot_row]
            states.append(aug.copy())
    return states


def makeRrefMatrix(aug: np.ndarray) -> Matrix:
    return _aug_matrix_mobject(aug)


def showRrefAnimation(
    scene: Scene,
    A: np.ndarray | None = None,
    b: np.ndarray | None = None,
    run_time: float = 2.5,
) -> VGroup:
    A = A if A is not None else np.array([[1.0, 2.0], [2.0, -1.0]])
    b = b if b is not None else np.array([5.0, 1.0])
    states = eliminationStates(A, b)
    mats = [_aug_matrix_mobject(s) for s in states]
    current = mats[0]
    scene.play(Create(current), run_time=run_time * 0.25)
    per = (run_time * 0.65) / max(1, len(mats) - 1)
    for nxt in mats[1:]:
        scene.play(Transform(current, nxt), run_time=per)
    label = makeMath(r"\text{RREF steps}").to_edge(UP, buff=0.4)
    scene.play(Write(label), run_time=run_time * 0.1)
    return VGroup(current, label)
