"""Matrix–vector product Av — 2D arrows, 3D Arrow3D, n×n matrix display."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import asNxN, dimOf, multiplyMatrixVectorNxN, makeMath, as3
from Math.library.math.linear_algebra.vectors import makeVectorArrow
from Math.library.math.linear_algebra.matrices import makeMatrixTex


def multiplyMatrixVector(matrix: np.ndarray, vector: np.ndarray) -> np.ndarray:
    out = multiplyMatrixVectorNxN(matrix, vector)
    n = dimOf(matrix)
    if n == 2:
        return as3(out)
    if n == 3:
        return as3(out)
    return out


def makeMatrixVectorArrows(
    origin: np.ndarray,
    matrix: np.ndarray,
    vector: np.ndarray,
    in_color=BLUE,
    out_color="#FF4500",
) -> VGroup:
    n = dimOf(matrix)
    if n > 2:
        from Math.library.math.linear_algebra.nxn import makeMatrixVectorColumn
        return makeMatrixVectorColumn(matrix, vector)
    v_in = makeVectorArrow(origin, vector, color=in_color, label=r"\vec{v}")
    v_out = makeVectorArrow(
        origin,
        multiplyMatrixVector(matrix, vector),
        color=out_color,
        label=r"A\vec{v}",
    )
    mat = makeMatrixTex(matrix, scale=0.65).to_corner(UL, buff=0.4)
    return VGroup(v_in, v_out, mat)


def _showMatrixVector2d(
    scene: Scene,
    matrix: np.ndarray,
    vector: np.ndarray,
    run_time: float = 2.0,
) -> VGroup:
    diagram = makeMatrixVectorArrows(ORIGIN, matrix, vector)
    scene.play(GrowArrow(diagram[0][0]), run_time=run_time * 0.35)
    scene.play(GrowArrow(diagram[1][0]), run_time=run_time * 0.35)
    scene.play(Write(diagram[2]), run_time=run_time * 0.3)
    return diagram


def showMatrixVectorProduct(
    scene: Scene,
    matrix: np.ndarray | None = None,
    vector: np.ndarray | None = None,
    run_time: float = 2.0,
) -> VGroup:
    matrix = matrix if matrix is not None else np.array([[1.2, 0.4], [0.2, 1.1]])
    vector = vector if vector is not None else np.array([1.6, 0.9, 0.0])
    if dimOf(matrix) == 2:
        return _showMatrixVector2d(scene, matrix, vector, run_time=run_time)

    from Math.library.math.linear_algebra.nxn import showMatrixVectorNxN

    return showMatrixVectorNxN(scene, matrix, vector, run_time=run_time)
