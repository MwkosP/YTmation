"""Matrix multiplication — 2D AB vs BA; n×n matrix product display."""

from manim import *
import numpy as np

from Math.library.common import SceneLayout, placeInRegion
from Math.library.math.linear_algebra._core import as3, multiplyNxN, dimOf, makeMath
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def multiply2x2(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    return multiplyNxN(A, B)


def makeMatrixProductComparison(
    A: np.ndarray,
    B: np.ndarray,
    vector: np.ndarray,
) -> VGroup:
    """Return base + ABv + BAv arrows and labels, no scene layout."""
    v = as3(vector[:2])
    ab_v = as3(multiplyNxN(A, B) @ np.array(vector[:2], dtype=float))
    ba_v = as3(multiplyNxN(B, A) @ np.array(vector[:2], dtype=float))
    base = makeVectorArrow(ORIGIN, v, color=BLUE, label=r"\vec{v}")
    left = VGroup(
        makeMath(r"AB\vec{v}", scale=0.7),
        makeVectorArrow(ORIGIN, ab_v, color="#FF4500"),
    )
    right = VGroup(
        makeMath(r"BA\vec{v}", scale=0.7),
        makeVectorArrow(ORIGIN, ba_v, color=YELLOW),
    )
    return VGroup(base, left, right)


def showMatrixMultiplyOrder(
    scene: Scene,
    A: np.ndarray | None = None,
    B: np.ndarray | None = None,
    vector: np.ndarray | None = None,
    run_time: float = 2.2,
    layout: SceneLayout | None = None,
) -> VGroup:
    A = A if A is not None else np.array([[1.0, 0.5], [0.0, 1.0]])
    B = B if B is not None else np.array([[1.0, 0.0], [1.0, 1.0]])
    if dimOf(A) != 2 or dimOf(B) != 2:
        from Math.library.math.linear_algebra.nxn import showMatrixMultiplyOrderNxN
        return showMatrixMultiplyOrderNxN(scene, A, B, vector, run_time=run_time)
    vector = vector if vector is not None else np.array([1.0, 0.6, 0.0])
    diagram = makeMatrixProductComparison(A, B, vector)
    base_vec = diagram[0]
    left = diagram[1]
    right = diagram[2]

    caption = makeMath(r"AB \neq BA \text{ in general}")

    # Backwards-compatible fallback: original rough placement
    if layout is None:
        left[0].to_edge(UP).shift(LEFT * 3.2)
        left[1].shift(LEFT * 3.2)
        right[0].to_edge(UP).shift(RIGHT * 3.2)
        right[1].shift(RIGHT * 3.2)
        caption.to_edge(DOWN, buff=0.35)
        scene.play(GrowArrow(base_vec[0]), run_time=run_time * 0.25)
        scene.play(Create(left), Create(right), run_time=run_time * 0.55)
        scene.play(Write(caption), run_time=run_time * 0.2)
        return VGroup(diagram, caption)

    # With layout: arrows in main, text labels in sidebar or above
    pairs = VGroup(
        VGroup(left[1], left[0]),
        VGroup(right[1], right[0]),
    ).arrange(RIGHT, buff=1.5)
    main_group = VGroup(base_vec, pairs)
    placeInRegion(main_group, "main", layout=layout, fit=True)

    if "sidebar" in layout.regions:
        steps = VGroup(
            makeMath(r"\text{Order matters}", scale=0.8),
            makeMath(r"AB\vec{v} \ne BA\vec{v}", scale=0.8, color="#FF4500"),
        ).arrange(DOWN, aligned_edge=LEFT, buff=0.2)
        placeInRegion(steps, "sidebar", layout=layout, h_align="left", v_align="top", fit=True)
    else:
        steps = VGroup()

    cap_region = "caption" if "caption" in layout.regions else "formula"
    placeInRegion(caption, cap_region, layout=layout, v_align="bottom", fit=False)

    scene.play(GrowArrow(base_vec[0]), run_time=run_time * 0.2)
    scene.play(Create(pairs), run_time=run_time * 0.5)
    if len(steps) > 0:
        scene.play(FadeIn(steps), run_time=run_time * 0.15)
    scene.play(Write(caption), run_time=run_time * 0.15)
    return VGroup(main_group, steps, caption)

