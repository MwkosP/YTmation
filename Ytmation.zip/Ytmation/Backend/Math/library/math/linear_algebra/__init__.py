"""Linear algebra building blocks."""

from Math.library.math.linear_algebra.vectors import (
    makeVectorArrow,
    decomposeVector,
    addVectorsTipToTail,
    showVectorAddition,
)
from Math.library.math.linear_algebra.transformations import applyMatrixToSquare, showLinearTransform
from Math.library.math.linear_algebra.matrix_vector import showMatrixVectorProduct
from Math.library.math.linear_algebra.matrix_multiply import showMatrixMultiplyOrder
from Math.library.math.linear_algebra.inverse import showMatrixInverse
from Math.library.math.linear_algebra.rref import showRrefAnimation
from Math.library.math.linear_algebra.eigenvectors import showEigenDirections
from Math.library.math.linear_algebra.rotation import showRotation
from Math.library.math.linear_algebra.determinant import showDeterminantArea
from Math.library.math.linear_algebra.dot_product import showDotProduct
from Math.library.math.linear_algebra.projection import showProjection
from Math.library.math.linear_algebra.span import showSpan
from Math.library.math.linear_algebra.subspaces import showColumnSpaceNullSpace
from Math.library.math.linear_algebra.gram_schmidt import showGramSchmidt
from Math.library.math.linear_algebra.norms import showNormAndAngle
from Math.library.math.linear_algebra.cross_product import showCrossProduct2d
from Math.library.math.linear_algebra.vector_field import showVectorField
from Math.library.math.linear_algebra import recipes as linearAlgebraRecipes

__all__ = [
    "makeVectorArrow",
    "decomposeVector",
    "addVectorsTipToTail",
    "showVectorAddition",
    "applyMatrixToSquare",
    "showLinearTransform",
    "showMatrixVectorProduct",
    "showMatrixMultiplyOrder",
    "showMatrixInverse",
    "showRrefAnimation",
    "showEigenDirections",
    "showRotation",
    "showDeterminantArea",
    "showDotProduct",
    "showProjection",
    "showSpan",
    "showColumnSpaceNullSpace",
    "showGramSchmidt",
    "showNormAndAngle",
    "showCrossProduct2d",
    "showVectorField",
    "linearAlgebraRecipes",
]
