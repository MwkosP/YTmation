"""Span of vectors in R²."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import makeMath
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def makeSpanParallelogram(
    origin: np.ndarray,
    v1: np.ndarray,
    v2: np.ndarray,
    color=BLUE,
    fill_opacity: float = 0.2,
) -> VGroup:
    a = np.array(v1[:2], dtype=float)
    b = np.array(v2[:2], dtype=float)
    poly = Polygon(
        origin,
        origin + np.array([a[0], a[1], 0]),
        origin + np.array([a[0] + b[0], a[1] + b[1], 0]),
        origin + np.array([b[0], b[1], 0]),
        color=color,
        fill_opacity=fill_opacity,
        stroke_width=1.5,
    )
    arrows = VGroup(
        makeVectorArrow(origin, v1, color=YELLOW, label=r"\vec{v}_1"),
        makeVectorArrow(origin, v2, color="#FF4500", label=r"\vec{v}_2"),
    )
    return VGroup(poly, arrows)


def showSpan(
    scene: Scene,
    v1: np.ndarray | None = None,
    v2: np.ndarray | None = None,
    run_time: float = 2.0,
) -> VGroup:
    v1 = v1 if v1 is not None else np.array([1.8, 0.6, 0.0])
    v2 = v2 if v2 is not None else np.array([0.5, 1.4, 0.0])
    span = makeSpanParallelogram(ORIGIN, v1, v2)
    label = makeMath(r"\mathrm{span}\{\vec{v}_1,\vec{v}_2\}").to_edge(UP, buff=0.45)
    scene.play(Write(label), FadeIn(span[0]), Create(span[1]), run_time=run_time)
    return VGroup(span, label)
