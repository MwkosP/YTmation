"""N×N matrix algebra — display-first for n>3; 2D/3D geometry when possible."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import (
    asNxN,
    dimOf,
    multiplyNxN,
    multiplyMatrixVectorNxN,
    detNxN,
    inverseNxN,
    eigenNxN,
    makeMath,
    formatMatrixForManim,
)
from Math.library.math.linear_algebra.matrices import makeMatrixTex
from Math.library.math.linear_algebra.vectors import makeVectorArrow


def makeMatrixProductRow(
    A: np.ndarray,
    B: np.ndarray,
    show_result: bool = True,
    scale: float = 0.65,
) -> VGroup:
    """Displays A · B = AB as Matrix mobjects (any n×n)."""
    prod = multiplyNxN(A, B)
    row = VGroup(makeMatrixTex(A, scale=scale), makeMath(r"\cdot", scale=0.7), makeMatrixTex(B, scale=scale))
    row.arrange(RIGHT, buff=0.25)
    if show_result:
        eq = makeMath("=", scale=0.8)
        res = makeMatrixTex(prod, scale=scale)
        return VGroup(row, eq, res).arrange(RIGHT, buff=0.25)
    return row


def makeMatrixVectorColumn(
    matrix: np.ndarray,
    vector: np.ndarray,
    scale: float = 0.6,
) -> VGroup:
    """A (n×n), v (n×1), Av (n×1) as matrices — works for any n."""
    Av = multiplyMatrixVectorNxN(matrix, vector)
    a = makeMatrixTex(matrix, scale=scale)
    v = Matrix([[f"{x:.3g}"] for x in np.array(vector).flatten()[: dimOf(matrix)]]).scale(scale)
    out = Matrix([[f"{x:.3g}"] for x in Av]).scale(scale)
    return VGroup(
        a,
        makeMath(r"\cdot", scale=0.6),
        v,
        makeMath("=", scale=0.7),
        out,
    ).arrange(RIGHT, buff=0.2)


def showMatrixProductNxN(
    scene: Scene,
    A: np.ndarray,
    B: np.ndarray,
    run_time: float = 2.0,
) -> VGroup:
    diagram = makeMatrixProductRow(A, B).scale(0.9)
    n = dimOf(A)
    caption = makeMath(rf"{n}\times{n}\ \text{{multiplication}}").to_edge(UP, buff=0.4)
    scene.play(Write(caption), FadeIn(diagram), run_time=run_time)
    return VGroup(diagram, caption)


def showMatrixVectorNxN(
    scene: Scene,
    matrix: np.ndarray,
    vector: np.ndarray,
    run_time: float = 2.0,
) -> VGroup:
    n = dimOf(matrix)
    if n == 2:
        from Math.library.math.linear_algebra.matrix_vector import _showMatrixVector2d

        return _showMatrixVector2d(scene, matrix, vector, run_time=run_time)
    if n == 3:
        return _showMatrixVector3d(scene, matrix, vector, run_time)
    diagram = makeMatrixVectorColumn(matrix, vector).scale(0.85)
    caption = makeMath(rf"{n}\times{n}\ \Rightarrow\ {n}\times 1").to_edge(UP, buff=0.4)
    scene.play(Write(caption), FadeIn(diagram), run_time=run_time)
    return VGroup(diagram, caption)


def _showMatrixVector3d(
    scene: Scene,
    matrix: np.ndarray,
    vector: np.ndarray,
    run_time: float,
) -> VGroup:
    if hasattr(scene, "set_camera_orientation"):
        scene.set_camera_orientation(phi=68 * DEGREES, theta=-42 * DEGREES)
    v = np.array(vector, dtype=float).flatten()[:3]
    Av = multiplyMatrixVectorNxN(matrix, v)
    try:
        arr_in = Arrow3D(start=ORIGIN, end=v, color=BLUE)
        arr_out = Arrow3D(start=ORIGIN, end=Av, color="#FF4500")
        objs = VGroup(arr_in, arr_out)
    except Exception:
        objs = makeMatrixVectorColumn(matrix, v)
    mat = makeMatrixTex(matrix, scale=0.55).to_corner(UL, buff=0.35)
    scene.play(Write(mat), Create(objs), run_time=run_time)
    return VGroup(objs, mat)


def showMatrixMultiplyOrderNxN(
    scene: Scene,
    A: np.ndarray,
    B: np.ndarray,
    vector: np.ndarray | None = None,
    run_time: float = 2.2,
) -> VGroup:
    n = dimOf(A)
    if n == 2 and vector is not None:
        from Math.library.math.linear_algebra.matrix_multiply import showMatrixMultiplyOrder
        return showMatrixMultiplyOrder(scene, A, B, vector, run_time=run_time)
    left = makeMatrixProductRow(A, B)
    right = makeMatrixProductRow(B, A)
    left.shift(UP * 0.6)
    right.shift(DOWN * 0.8)
    note = makeMath(r"AB \neq BA").to_edge(UP, buff=0.35)
    scene.play(Write(note), FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right, note)


def showDeterminantNxN(
    scene: Scene,
    matrix: np.ndarray,
    run_time: float = 2.0,
) -> VGroup:
    n = dimOf(matrix)
    d = detNxN(matrix)
    if n == 2:
        from Math.library.math.linear_algebra.determinant import showDeterminantArea
        return showDeterminantArea(scene, matrix, run_time=run_time)
    mat = makeMatrixTex(matrix, scale=0.7)
    if n == 3:
        label = makeMath(rf"\det(A) = {d:.2f}\ \text{{(volume scale)}}")
    else:
        label = makeMath(rf"\det(A) = {d:.2g}")
    group = VGroup(mat, label).arrange(DOWN, buff=0.4)
    scene.play(FadeIn(group), run_time=run_time)
    return group


def showEigenNxN(
    scene: Scene,
    matrix: np.ndarray,
    run_time: float = 2.0,
) -> VGroup:
    n = dimOf(matrix)
    if n == 2:
        from Math.library.math.linear_algebra.eigenvectors import showEigenDirections
        return showEigenDirections(scene, matrix, run_time=run_time)
    vals, _ = eigenNxN(matrix)
    mat = makeMatrixTex(matrix, scale=0.65)
    lines = VGroup(
        *[makeMath(rf"\lambda_{{{i+1}}} \approx {vals[i]:.3g}", scale=0.75) for i in range(min(n, 4))]
    )
    if n > 4:
        lines.add(makeMath(r"\vdots", scale=0.75))
    lines.arrange(DOWN, aligned_edge=LEFT, buff=0.15).next_to(mat, RIGHT, buff=0.5)
    scene.play(FadeIn(mat), FadeIn(lines), run_time=run_time)
    return VGroup(mat, lines)
