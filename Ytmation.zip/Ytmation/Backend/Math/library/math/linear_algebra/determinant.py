"""Determinant as area scaling (2×2)."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import det2x2, detNxN, makeMath, as2x2, dimOf


def makeParallelogramFromColumns(
    matrix: np.ndarray,
    origin: np.ndarray = ORIGIN,
    color=BLUE,
    fill_opacity: float = 0.35,
) -> Polygon:
    m = as2x2(matrix)
    c1 = np.array([m[0, 0], m[1, 0], 0.0])
    c2 = np.array([m[0, 1], m[1, 1], 0.0])
    p0 = origin
    p1 = origin + c1
    p2 = origin + c1 + c2
    p3 = origin + c2
    return Polygon(p0, p1, p2, p3, color=color, fill_opacity=fill_opacity, stroke_width=2)


def makeDeterminantLabel(matrix: np.ndarray) -> MathTex:
    d = detNxN(matrix)
    return makeMath(rf"\det(A) = {d:.2f}")


def showDeterminantArea(
    scene: Scene,
    matrix: np.ndarray,
    run_time: float = 2.0,
) -> VGroup:
    if dimOf(matrix) != 2:
        from Math.library.math.linear_algebra.nxn import showDeterminantNxN
        return showDeterminantNxN(scene, matrix, run_time=run_time)
    unit = makeParallelogramFromColumns(np.eye(2), color=GREY_B, fill_opacity=0.2)
    transformed = makeParallelogramFromColumns(matrix, color=BLUE, fill_opacity=0.4)
    label = makeDeterminantLabel(matrix).to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(unit), run_time=run_time * 0.4)
    scene.play(Transform(unit, transformed), run_time=run_time * 0.6)
    return VGroup(unit, label)
