"""Backward-compatible re-export — prefer transformations.py."""

from Math.library.math.linear_algebra.transformations import applyMatrixToSquare

__all__ = ["applyMatrixToSquare"]
