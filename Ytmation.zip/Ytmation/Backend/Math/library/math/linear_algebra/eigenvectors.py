"""Eigenvalues and eigenvectors for 2×2 matrices."""

from manim import *
import numpy as np

from Math.library.math.linear_algebra._core import eigen2x2, eigenNxN, makeMath, as2x2


def makeEigenvectors(
    matrix: np.ndarray,
    axis_length: float = 2.0,
    colors: tuple = (BLUE, "#FF4500"),
) -> tuple[VGroup, VGroup]:
    """Returns (axes_group, arrows+labels) without playing."""
    m = as2x2(matrix)
    vals, vecs = eigen2x2(m)
    axes = Axes(x_range=[-3, 3, 1], y_range=[-3, 3, 1], x_length=6, y_length=6, tips=False)
    origin = axes.c2p(0, 0)
    arrows = VGroup()
    labels = VGroup()
    for i in range(min(2, vecs.shape[1])):
        v = vecs[:, i]
        n = np.linalg.norm(v)
        if n < 1e-9:
            continue
        v = v / n
        arr = Arrow(origin, origin + np.array([v[0], v[1], 0]) * axis_length, buff=0, color=colors[i % 2])
        lam = vals[i]
        lbl = makeMath(rf"\lambda_{{{i+1}}}={lam:.2f}", color=colors[i % 2], scale=0.65)
        lbl.next_to(arr, UP if i == 0 else RIGHT, buff=0.12)
        arrows.add(arr)
        labels.add(lbl)
    return VGroup(axes), VGroup(arrows, labels)


def showEigenDirections(
    scene: Scene,
    matrix: np.ndarray,
    run_time: float = 2.0,
) -> VGroup:
    from Math.library.math.linear_algebra._core import dimOf
    if dimOf(matrix) != 2:
        from Math.library.math.linear_algebra.nxn import showEigenNxN
        return showEigenNxN(scene, matrix, run_time=run_time)
    axes_g, eig = makeEigenvectors(matrix)
    scene.play(Create(axes_g), Create(eig[0]), FadeIn(eig[1]), run_time=run_time)
    return VGroup(axes_g, eig)


def showEigenvalueStretch(
    scene: Scene,
    matrix: np.ndarray,
    run_time: float = 2.2,
) -> VGroup:
    """Animate unit vector along eigen direction scaling by λ."""
    m = as2x2(matrix)
    vals, vecs = eigen2x2(m)
    axes = Axes(x_range=[-4, 4, 1], y_range=[-4, 4, 1], x_length=6.5, y_length=6.5, tips=False)
    origin = axes.c2p(0, 0)
    v = vecs[:, 0]
    v = v / np.linalg.norm(v)
    lam = float(vals[0])
    vec = Arrow(origin, origin + np.array([v[0], v[1], 0]) * 1.2, buff=0, color=BLUE)
    scaled = Arrow(origin, origin + np.array([v[0], v[1], 0]) * abs(lam) * 0.9, buff=0, color="#FF4500")
    caption = makeMath(rf"\mathbf{{Av}} = \lambda \mathbf{{v}},\ \lambda={lam:.2f}").to_edge(UP, buff=0.4)
    scene.play(Create(axes), Write(caption), GrowArrow(vec), run_time=run_time * 0.45)
    scene.play(Transform(vec, scaled), run_time=run_time * 0.55)
    return VGroup(axes, vec, caption)
