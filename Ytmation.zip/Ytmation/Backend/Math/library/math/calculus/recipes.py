"""Calculus demos — one topic per call."""

from manim import *
import numpy as np

from Math.library.common.layout import makeTitle
from Math.library.common.styling import setupScene
from Math.library.math.calculus.derivative import (
    showDerivativeTangent,
    showSecantToTangent,
    showDerivativeDefinition,
)
from Math.library.math.calculus.limit import (
    showLimitApproach,
    showLimitBothSides,
    showRemovableDiscontinuity,
)
from Math.library.math.calculus.integral import showIntegralArea, showRiemannSum
from Math.library.math.calculus.taylor import showTaylorSeries, showTaylorBuildUp
from Math.library.math.calculus.fourier import showFourierSeries, showFourierBuildUp
from Math.library.math.calculus.ode import showSlopeField, showSlopeFieldWithSolution
from Math.library.math.calculus.multivariable import showContourLines, showPartialDerivative
from Math.library.math.calculus.optimization import showCriticalPoints
from Math.library.math.calculus.fundamental_theorem import showFtcPart1, showFtcPart2
from Math.library.math.calculus.chain_rule import showChainRule, showChainRuleDiagram
from Math.library.math.calculus.product_rule import showProductRule
from Math.library.math.calculus.quotient_rule import showQuotientRule
from Math.library.math.calculus.second_derivative import showConcavity, showInflectionPoint
from Math.library.math.calculus.mvt import showMeanValueTheorem
from Math.library.math.calculus.lhopital import showLhopital
from Math.library.math.calculus.improper_integral import showImproperIntegral
from Math.library.math.calculus.volume import showDiskMethod
from Math.library.math.calculus.related_rates import showRelatedRatesLadder
from Math.library.math.calculus.series_convergence import showIntegralTest
from Math.library.math.calculus.differential import showDifferential
from Math.library.math.calculus.substitution import showUSubstitution, showUSubstitutionArea
from Math.library.math.calculus.integration_by_parts import showIntegrationByParts
from Math.library.math.calculus.parametric import showParametricVelocity
from Math.library.math.calculus.multivariable import showGradient


def demoDerivative(scene: Scene, title: str = "Derivative") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title)))
    showDerivativeTangent(scene, lambda x: 0.5 * x**2, x0=1.0)


def demoSecantToTangent(scene: Scene, title: str = "Secant → Tangent") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showSecantToTangent(scene, lambda x: 0.25 * x**2 + 0.3, x0=1.0)


def demoDerivativeDefinition(scene: Scene, title: str = "Definition") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showDerivativeDefinition(scene, lambda x: 0.4 * x**2, x0=0.8)


def demoLimit(scene: Scene, title: str = "Limit") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showLimitApproach(scene, lambda x: x**2, x_target=2.0)


def demoLimitBothSides(scene: Scene, title: str = "Two-sided Limit") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showLimitBothSides(scene, lambda x: x**2 + 0.5)


def demoRemovableDiscontinuity(scene: Scene, title: str = "Removable Hole") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showRemovableDiscontinuity(scene)


def demoIntegral(scene: Scene, title: str = "Integral") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title)))
    showIntegralArea(scene, lambda x: 0.3 * x**2 + 0.5, a=0, b=2)


def demoRiemannSum(scene: Scene, title: str = "Riemann Sum") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showRiemannSum(scene, lambda x: 0.3 * x**2 + 0.5, a=0, b=2)


def demoTaylor(scene: Scene, title: str = "Taylor Series") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showTaylorSeries(scene)


def demoTaylorBuildUp(scene: Scene, title: str = "Taylor Build-up") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showTaylorBuildUp(scene)


def demoFourier(scene: Scene, title: str = "Fourier Series") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showFourierSeries(scene, n_terms=4)


def demoFourierBuildUp(scene: Scene, title: str = "Fourier Build-up") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showFourierBuildUp(scene, max_terms=5)


def demoSlopeField(scene: Scene, title: str = "Slope Field") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showSlopeField(scene)


def demoSlopeFieldSolution(scene: Scene, title: str = "ODE Solution") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showSlopeFieldWithSolution(scene)


def demoContourLines(scene: Scene, title: str = "Contour Lines") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showContourLines(scene)


def demoPartialDerivative(scene: Scene, title: str = "Partial Derivative") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showPartialDerivative(scene)


def demoCriticalPoints(scene: Scene, title: str = "Critical Points") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showCriticalPoints(scene)


def demoFtcPart1(scene: Scene, title: str = "FTC Part 1") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showFtcPart1(scene, lambda x: 0.3 * x**2 + 0.5)


def demoFtcPart2(scene: Scene, title: str = "FTC Part 2") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showFtcPart2(scene, lambda x: 0.25 * x + 0.4)


def demoChainRule(scene: Scene, title: str = "Chain Rule") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showChainRule(scene)


def demoChainRuleDiagram(scene: Scene, title: str = "Chain Pipeline") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showChainRuleDiagram(scene)


def demoProductRule(scene: Scene, title: str = "Product Rule") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showProductRule(scene)


def demoQuotientRule(scene: Scene, title: str = "Quotient Rule") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showQuotientRule(scene)


def demoConcavity(scene: Scene, title: str = "Concavity") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showConcavity(scene)


def demoInflection(scene: Scene, title: str = "Inflection") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showInflectionPoint(scene)


def demoMeanValueTheorem(scene: Scene, title: str = "Mean Value Theorem") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showMeanValueTheorem(scene)


def demoLhopital(scene: Scene, title: str = "L'Hôpital") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showLhopital(scene)


def demoImproperIntegral(scene: Scene, title: str = "Improper Integral") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=34)))
    showImproperIntegral(scene)


def demoDiskMethod(scene: Scene, title: str = "Disk Method") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showDiskMethod(scene)


def demoRelatedRates(scene: Scene, title: str = "Related Rates") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showRelatedRatesLadder(scene)


def demoIntegralTest(scene: Scene, title: str = "Integral Test") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=36)))
    showIntegralTest(scene)


def demoDifferential(scene: Scene, title: str = "Differential") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showDifferential(scene)


def demoUSubstitution(scene: Scene, title: str = "u-Substitution") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showUSubstitution(scene)


def demoUSubstitutionArea(scene: Scene, title: str = "u-Sub Map") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showUSubstitutionArea(scene)


def demoIntegrationByParts(scene: Scene, title: str = "By Parts") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=38)))
    showIntegrationByParts(scene)


def demoParametricVelocity(scene: Scene, title: str = "Parametric") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showParametricVelocity(scene)


def demoGradient(scene: Scene, title: str = "Gradient") -> None:
    setupScene(scene)
    scene.play(Write(makeTitle(title, size=40)))
    showGradient(scene)
