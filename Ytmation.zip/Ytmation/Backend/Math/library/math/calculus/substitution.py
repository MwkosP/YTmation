"""u-substitution — change of variables."""

from manim import *
import numpy as np

from Math.library.math.calculus._core import makeMath, makeStepList, playStepReveal


def showUSubstitution(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    steps = steps or [
        r"\int 2x\cos(x^2)\,dx",
        r"u=x^2,\quad du=2x\,dx",
        r"=\int \cos(u)\,du",
        r"=\sin(u)+C=\sin(x^2)+C",
    ]
    rows = makeStepList(steps)
    cap = makeMath(r"\text{u-substitution}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), FadeIn(rows[0]), run_time=run_time * 0.3)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.18)
    return VGroup(rows, cap)


def showUSubstitutionArea(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    """Schematic: x-axis vs u-axis panels."""
    left = makeMath(r"x\text{-axis: }2x\cos(x^2)").shift(LEFT * 3)
    arrow = makeMath(r"\Rightarrow").scale(0.9)
    right = makeMath(r"u\text{-axis: }\cos(u)").shift(RIGHT * 3)
    row = VGroup(left, arrow, right).arrange(RIGHT, buff=0.4)
    cap = makeMath(r"u=x^2").to_edge(UP, buff=0.45)
    scene.play(Write(cap), FadeIn(row), run_time=run_time)
    return VGroup(row, cap)
