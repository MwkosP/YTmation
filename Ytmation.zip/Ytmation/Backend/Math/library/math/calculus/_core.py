"""Shared calculus helpers — pure math, no domain narrative."""

from manim import *
import numpy as np


def makeMath(tex: str, color=WHITE, scale: float = 0.85) -> MathTex:
    return MathTex(tex, color=color).scale(scale)


def makeStepList(steps: list[str], buff: float = 0.42, color=WHITE) -> VGroup:
    rows = VGroup(*[makeMath(s, color=color, scale=0.8) for s in steps])
    rows.arrange(DOWN, aligned_edge=LEFT, buff=buff)
    return rows


def playStepReveal(scene: Scene, steps: VGroup, up_to: int, run_time: float = 0.55) -> None:
    if 0 <= up_to < len(steps):
        scene.play(FadeIn(steps[up_to]), run_time=run_time)


def numericalDerivative(func, x: float, h: float = 1e-5) -> float:
    return (func(x + h) - func(x - h)) / (2 * h)


def riemannSum(
    func,
    a: float,
    b: float,
    n: int,
    method: str = "midpoint",
) -> float:
    if n < 1:
        return 0.0
    dx = (b - a) / n
    total = 0.0
    for i in range(n):
        if method == "left":
            x = a + i * dx
        elif method == "right":
            x = a + (i + 1) * dx
        else:
            x = a + (i + 0.5) * dx
        total += func(x) * dx
    return total


def taylorTerm(coeff: float, n: int, x0: float) -> callable:
    """Return function x ↦ coeff * (x - x0)^n (n! scaling in coeff)."""
    return lambda x, c=coeff, k=n, x0=x0: c * (x - x0) ** k
