"""ODEs: slope fields and solution curves."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes
from Math.library.math.calculus._core import makeMath


def makeSlopeField(
    dydx,
    x_range: tuple = (-3, 3, 1),
    y_range: tuple = (-3, 3, 1),
    step: float = 0.55,
    segment_length: float = 0.35,
    color=BLUE,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range, x_length=7, y_length=6)
    axes = axes_g[0]
    segments = VGroup()
    for x in np.arange(x_range[0], x_range[1] + 0.01, step):
        for y in np.arange(y_range[0], y_range[1] + 0.01, step):
            try:
                slope = dydx(x, y)
            except Exception:
                continue
            angle = np.arctan(slope)
            dx = np.cos(angle) * segment_length
            dy = np.sin(angle) * segment_length
            start = axes.c2p(x - dx / 2, y - dy / 2)
            end = axes.c2p(x + dx / 2, y + dy / 2)
            segments.add(Line(start, end, stroke_width=1.5, color=color))
    return VGroup(axes_g, segments)


def makeSolutionCurve(
    axes: Axes,
    dydx,
    x0: float,
    y0: float,
    x_end: float,
    dt: float = 0.05,
    color=YELLOW,
) -> VMobject:
    """Euler method for sketching a solution curve."""
    points = [(x0, y0)]
    x, y = x0, y0
    steps = int(abs(x_end - x0) / dt)
    direction = 1 if x_end > x0 else -1
    for _ in range(steps):
        try:
            k = dydx(x, y)
        except Exception:
            break
        x += direction * dt
        y += direction * dt * k
        points.append((x, y))
    return axes.plot_line_graph(
        [p[0] for p in points],
        [p[1] for p in points],
        add_vertex_dots=False,
        line_color=color,
        stroke_width=3,
    )


def showSlopeField(
    scene: Scene,
    dydx=None,
    run_time: float = 2.0,
) -> VGroup:
    dydx = dydx or (lambda x, y: x - y)
    field = makeSlopeField(dydx)
    label = makeMath(r"y' = x - y").to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(field[0]), Create(field[1]), run_time=run_time)
    return VGroup(field, label)


def showSlopeFieldWithSolution(
    scene: Scene,
    dydx=None,
    x0: float = -2.0,
    y0: float = 1.0,
    run_time: float = 2.5,
) -> VGroup:
    dydx = dydx or (lambda x, y: x - y)
    field = makeSlopeField(dydx)
    axes = field[0][0]
    curve = makeSolutionCurve(axes, dydx, x0, y0, x_end=2.5, color=YELLOW)
    scene.play(Create(field[0]), Create(field[1]), run_time=run_time * 0.55)
    scene.play(Create(curve), run_time=run_time * 0.45)
    return VGroup(field, curve)
