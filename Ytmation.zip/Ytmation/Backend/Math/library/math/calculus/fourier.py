"""Fourier series approximations."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath


def fourierSquarePartial(n_terms: int) -> callable:
    def f(x):
        return sum((4 / ((2 * k - 1) * PI)) * np.sin((2 * k - 1) * x) for k in range(1, n_terms + 1))

    return f


def makeFourierGraph(axes_g: VGroup, n_terms: int, x_range: tuple) -> VMobject:
    return plotOnAxes(axes_g, fourierSquarePartial(n_terms), x_range=(x_range[0], x_range[1]), color="#FF4500")


def showFourierSeries(
    scene: Scene,
    n_terms: int = 3,
    x_range: tuple = (-PI, PI, PI / 2),
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=(-1.5, 1.5, 0.5), x_label="x", y_label="S_n")
    approx = makeFourierGraph(axes_g, n_terms, x_range)
    scene.play(Create(axes_g), Create(approx), run_time=run_time)
    return VGroup(axes_g, approx)


def showFourierBuildUp(
    scene: Scene,
    max_terms: int = 5,
    run_time: float = 2.8,
) -> VGroup:
    x_range = (-PI, PI, PI / 2)
    axes_g = makeLabeledAxes(x_range=x_range, y_range=(-1.5, 1.5, 0.5), x_label="x", y_label="S_n")
    approx = makeFourierGraph(axes_g, 1, x_range)
    scene.play(Create(axes_g), Create(approx), run_time=run_time * 0.25)
    per = (run_time * 0.55) / max(1, max_terms - 1)
    for n in range(2, max_terms + 1):
        new_g = makeFourierGraph(axes_g, n, x_range)
        scene.play(Transform(approx, new_g), run_time=per)
    cap = makeMath(r"S_n \to \text{square wave}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), run_time=run_time * 0.1)
    return VGroup(axes_g, approx, cap)
