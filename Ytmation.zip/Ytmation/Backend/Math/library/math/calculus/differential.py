"""Differentials dx, dy on a tangent strip."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath, numericalDerivative
from Math.library.math.calculus.derivative import makeTangentLine


def showDifferential(
    scene: Scene,
    func=None,
    x0: float = 1.0,
    dx: float = 0.8,
    run_time: float = 2.0,
) -> VGroup:
    func = func or (lambda x: 0.3 * x**2)
    axes_g = makeLabeledAxes(x_range=(-1, 3, 1), y_range=(-1, 5, 1))
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(-1, 3), color=BLUE)
    point, tangent = makeTangentLine(axes, func, x0)
    y0 = func(x0)
    dx_line = Line(axes.c2p(x0, y0), axes.c2p(x0 + dx, y0), color=YELLOW, stroke_width=3)
    dy_line = Line(axes.c2p(x0 + dx, y0), axes.c2p(x0 + dx, func(x0 + dx)), color="#FF4500", stroke_width=3)
    dy_tan = Line(axes.c2p(x0 + dx, y0), axes.c2p(x0 + dx, y0 + numericalDerivative(func, x0) * dx), color=GREEN, stroke_width=3)
    labels = VGroup(
        makeMath("dx", color=YELLOW).next_to(dx_line, DOWN, buff=0.1),
        makeMath("dy", color="#FF4500").next_to(dy_line, RIGHT, buff=0.1),
        makeMath(r"dy\approx f'(x)\,dx", color=GREEN).scale(0.7).to_edge(UP, buff=0.45),
    )
    scene.play(Create(axes_g), Create(graph), FadeIn(point), Create(tangent), run_time=run_time * 0.45)
    scene.play(Create(dx_line), Create(dy_line), Create(dy_tan), Write(labels), run_time=run_time * 0.55)
    return VGroup(axes_g, graph, dx_line, dy_line, dy_tan, labels)
