"""Intro multivariable: contour lines, partial derivative slice."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath
from Math.library.math.calculus.derivative import makeTangentLine


def makeContourLines(
    func,
    x_range: tuple = (-2, 2, 1),
    y_range: tuple = (-2, 2, 1),
    levels: list[float] | None = None,
    color=BLUE,
) -> VGroup:
    """Plot level curves f(x,y)=c on 2D axes (slice of surface)."""
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range, x_label="x", y_label="y")
    axes = axes_g[0]
    levels = levels or [-1, 0, 1, 2]
    curves = VGroup()
    for c in levels:
        curves.add(
            ImplicitFunction(
                lambda x, y, c=c: func(x, y) - c,
                x_range=[x_range[0], x_range[1]],
                y_range=[y_range[0], y_range[1]],
                color=color,
                stroke_width=2,
            ).move_to(axes)
        )
    return VGroup(axes_g, curves)


def showContourLines(
    scene: Scene,
    func=None,
    run_time: float = 2.0,
) -> VGroup:
    func = func or (lambda x, y: x**2 + y**2)
    group = makeContourLines(func)
    label = makeMath(r"f(x,y)=c").to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(group[0]), *[Create(c) for c in group[1]], run_time=run_time)
    return VGroup(group, label)


def showPartialDerivative(
    scene: Scene,
    func_xy=None,
    y0: float = 0.5,
    x0: float = 1.0,
    run_time: float = 2.2,
) -> VGroup:
    """∂f/∂x at (x0,y0): slice f(x, y0) vs x."""
    func_xy = func_xy or (lambda x, y: x**2 + y**2)
    slice_func = lambda x: func_xy(x, y0)
    axes_g = makeLabeledAxes(x_range=(-2, 3, 1), y_range=(-1, 8, 1), x_label="x", y_label="f")
    graph = plotOnAxes(axes_g, slice_func, x_range=(-2, 2.5), color=BLUE)
    point, tangent = makeTangentLine(axes_g[0], slice_func, x0)
    cap = makeMath(rf"\partial f/\partial x \text{{ at }} y={y0}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), run_time=run_time * 0.55)
    scene.play(FadeIn(point), Create(tangent), run_time=run_time * 0.45)
    return VGroup(axes_g, graph, point, tangent, cap)


def showGradient(
    scene: Scene,
    func=None,
    x0: float = 1.0,
    y0: float = 0.5,
    run_time: float = 2.2,
) -> VGroup:
    """Gradient vector on contour plot — steepest ascent."""
    func = func or (lambda x, y: x**2 + y**2)
    group = makeContourLines(func, levels=[0.5, 1, 2, 4])
    axes = group[0][0]
    h = 1e-4
    dfx = (func(x0 + h, y0) - func(x0 - h, y0)) / (2 * h)
    dfy = (func(x0, y0 + h) - func(x0, y0 - h)) / (2 * h)
    gvec = np.array([dfx, dfy, 0])
    norm = max(np.linalg.norm(gvec), 1e-9)
    gvec = gvec / norm * 0.9
    origin = axes.c2p(x0, y0)
    arrow = Arrow(origin, origin + gvec, buff=0, color="#FF4500", stroke_width=4)
    cap = makeMath(r"\nabla f = \left(\frac{\partial f}{\partial x}, \frac{\partial f}{\partial y}\right)").scale(
        0.75
    ).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(group[0]), *[Create(c) for c in group[1]], run_time=run_time * 0.5)
    scene.play(GrowArrow(arrow), run_time=run_time * 0.5)
    return VGroup(group, arrow, cap)
