"""Series convergence — integral test sketch."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath
from Math.library.math.calculus.integral import makeIntegralArea


def showIntegralTest(
    scene: Scene,
    run_time: float = 2.2,
) -> VGroup:
    func = lambda x: 1 / x
    axes_g = makeLabeledAxes(x_range=(0, 8, 1), y_range=(0, 1.5, 0.5), x_label="n", y_label="")
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(0.8, 7.5), color=BLUE)
    area = makeIntegralArea(axes_g, graph, 1, 7, fill_color="#FF4500")
    rects = VGroup()
    for n in range(1, 8):
        h = 1 / n
        r = Rectangle(
            width=0.55,
            height=axes.c2p(0, h)[1] - axes.c2p(0, 0)[1],
            color=GREEN,
            fill_opacity=0.4,
            stroke_width=1,
        )
        r.move_to(axes.c2p(n + 0.5, 0), aligned_edge=DOWN)
        rects.add(r)
    cap = makeMath(r"\sum_{n=1}^\infty \frac1n \text{ vs } \int_1^\infty \frac1x\,dx").scale(0.7).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), FadeIn(area), run_time=run_time * 0.55)
    scene.play(Create(rects), run_time=run_time * 0.45)
    return VGroup(axes_g, graph, area, rects, cap)
