"""Integrals: area, Riemann sums."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath


def makeIntegralArea(
    axes_g: VGroup,
    graph: VMobject,
    a: float,
    b: float,
    fill_color=BLUE,
    opacity: float = 0.4,
) -> VMobject:
    return axes_g[0].get_area(graph, x_range=(a, b), color=fill_color, opacity=opacity)


def makeRiemannRectangles(
    axes: Axes,
    graph: VMobject,
    a: float,
    b: float,
    n: int,
    color=GREEN,
    opacity: float = 0.45,
) -> VGroup:
    if n < 1:
        return VGroup()
    return axes.get_riemann_rectangles(
        graph,
        x_range=[a, b],
        dx=(b - a) / n,
        color=color,
        fill_opacity=opacity,
        stroke_width=0.5,
    )


def showIntegralArea(
    scene: Scene,
    func,
    a: float = 0.0,
    b: float = 2.0,
    x_range: tuple = (-1, 3, 1),
    y_range: tuple = (-1, 5, 1),
    color=BLUE,
    fill_color=BLUE,
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    graph = plotOnAxes(axes_g, func, x_range=(x_range[0], x_range[1]), color=color)
    area = makeIntegralArea(axes_g, graph, a, b, fill_color=fill_color)
    scene.play(Create(axes_g), Create(graph), run_time=1.0)
    scene.play(FadeIn(area), run_time=run_time)
    return VGroup(axes_g, graph, area)


def showRiemannSum(
    scene: Scene,
    func,
    a: float = 0.0,
    b: float = 2.0,
    n_steps: list[int] | None = None,
    run_time: float = 2.5,
) -> VGroup:
    n_steps = n_steps or [4, 8, 16, 32]
    axes_g = makeLabeledAxes(x_range=(-0.5, 3, 1), y_range=(-0.5, 5, 1))
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(-0.5, 3), color=BLUE)
    caption = makeMath(r"\sum f(x_i)\,\Delta x").to_edge(UP, buff=0.45)
    scene.play(Write(caption), Create(axes_g), Create(graph), run_time=run_time * 0.25)
    rects = makeRiemannRectangles(axes, graph, a, b, n_steps[0])
    scene.play(Create(rects), run_time=run_time * 0.2)
    per = (run_time * 0.45) / max(1, len(n_steps) - 1)
    for n in n_steps[1:]:
        new_rects = makeRiemannRectangles(axes, graph, a, b, n)
        scene.play(Transform(rects, new_rects), run_time=per)
    area = makeIntegralArea(axes_g, graph, a, b, opacity=0.35)
    scene.play(FadeIn(area), run_time=run_time * 0.1)
    return VGroup(axes_g, graph, rects, area, caption)
