"""Related rates — ladder schematic."""

from manim import *
import numpy as np

from Math.library.math.calculus._core import makeMath


def makeLadderDiagram(
    wall_height: float = 4.0,
    base_length: float = 3.0,
) -> VGroup:
    wall = Line(ORIGIN + DOWN * 2, ORIGIN + UP * 2, color=GREY_B, stroke_width=6)
    ground = Line(ORIGIN + DOWN * 2 + LEFT * 3, ORIGIN + DOWN * 2 + RIGHT * 3, color=GREY_B)
    top = UP * 2
    base = RIGHT * base_length + DOWN * 2
    ladder = Line(top, base, color=YELLOW, stroke_width=5)
    return VGroup(wall, ground, ladder)


def showRelatedRatesLadder(
    scene: Scene,
    run_time: float = 2.5,
) -> VGroup:
    ladder = makeLadderDiagram()
    cap = makeMath(r"x^2+y^2=L^2 \Rightarrow 2x\frac{dx}{dt}+2y\frac{dy}{dt}=0").scale(0.7).to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(ladder), run_time=run_time * 0.45)
    scene.play(
        ladder[2].animate.put_start_and_end_on(UP * 2 + LEFT * 0.3, RIGHT * 3.5 + DOWN * 2),
        run_time=run_time * 0.45,
    )
    return VGroup(ladder, cap)
