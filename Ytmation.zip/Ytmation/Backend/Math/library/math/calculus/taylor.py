"""Taylor / Maclaurin polynomial approximations."""

from manim import *
import math
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath


def makeMaclaurinSin(terms: int) -> callable:
    def poly(x):
        return sum(
            ((-1) ** k / math.factorial(2 * k + 1)) * x ** (2 * k + 1)
            for k in range(terms)
        )

    return poly


def makeTaylorPolynomial(coeffs: list[float], x0: float = 0.0) -> callable:
    def poly(x):
        return sum(c * (x - x0) ** i for i, c in enumerate(coeffs))

    return poly


def showTaylorSeries(
    scene: Scene,
    base_func=None,
    coeffs: list[float] | None = None,
    x_range: tuple = (-PI, PI, PI / 2),
    run_time: float = 2.5,
) -> VGroup:
    base_func = base_func or np.sin
    taylor_func = makeMaclaurinSin(4) if coeffs is None else makeTaylorPolynomial(coeffs)
    axes_g = makeLabeledAxes(x_range=x_range, y_range=(-2, 2, 1), x_label="x", y_label="y")
    true_graph = plotOnAxes(axes_g, base_func, x_range=(x_range[0], x_range[1]), color=BLUE)
    approx = plotOnAxes(axes_g, taylor_func, x_range=(x_range[0], x_range[1]), color="#FF4500")
    label = makeMath(r"T_n(x)").to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(true_graph), run_time=run_time * 0.4)
    scene.play(Create(approx), run_time=run_time * 0.6)
    return VGroup(axes_g, true_graph, approx, label)


def showTaylorBuildUp(
    scene: Scene,
    base_func=None,
    max_terms: int = 5,
    run_time: float = 2.8,
) -> VGroup:
    base_func = base_func or np.sin
    axes_g = makeLabeledAxes(x_range=(-PI, PI, PI / 2), y_range=(-2, 2, 1))
    true_graph = plotOnAxes(axes_g, base_func, x_range=(-PI, PI), color=BLUE)
    scene.play(Create(axes_g), Create(true_graph), run_time=run_time * 0.25)
    approx = plotOnAxes(axes_g, makeMaclaurinSin(1), x_range=(-PI, PI), color="#FF4500")
    scene.play(Create(approx), run_time=run_time * 0.2)
    per = (run_time * 0.45) / max(1, max_terms - 1)
    for k in range(2, max_terms + 1):
        new_graph = plotOnAxes(axes_g, makeMaclaurinSin(k), x_range=(-PI, PI), color="#FF4500")
        scene.play(Transform(approx, new_graph), run_time=per)
    cap = makeMath(rf"n={max_terms}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), run_time=run_time * 0.1)
    return VGroup(axes_g, true_graph, approx, cap)
