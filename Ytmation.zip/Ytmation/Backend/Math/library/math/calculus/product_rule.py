"""Product rule visualization."""

from manim import *
import numpy as np

from Math.library.math.calculus._core import makeMath


def showProductRule(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    """Rectangle area model for (uv)'."""
    outer = Rectangle(width=4.2, height=2.4, color=WHITE)
    u_bar = Rectangle(width=4.2, height=0.55, color=BLUE, fill_opacity=0.35).align_to(outer, UP)
    v_bar = Rectangle(width=0.9, height=1.85, color="#FF4500", fill_opacity=0.35).align_to(outer, LEFT + DOWN)
    inner = Rectangle(width=3.3, height=1.85, color=GREEN, fill_opacity=0.35).align_to(outer, RIGHT + DOWN)
    labels = VGroup(
        makeMath(r"u", color=BLUE).next_to(u_bar, UP, buff=0.08),
        makeMath(r"v", color="#FF4500").next_to(v_bar, LEFT, buff=0.08),
        makeMath(r"u'v", color=GREEN).move_to(inner),
        makeMath(r"uv'", color=YELLOW).move_to(v_bar),
    )
    formula = makeMath(r"(uv)'=u'v+uv'").to_edge(UP, buff=0.45)
    scene.play(Write(formula), Create(outer), FadeIn(u_bar), FadeIn(v_bar), FadeIn(inner), run_time=run_time * 0.7)
    scene.play(FadeIn(labels), run_time=run_time * 0.3)
    return VGroup(outer, u_bar, v_bar, inner, labels, formula)
