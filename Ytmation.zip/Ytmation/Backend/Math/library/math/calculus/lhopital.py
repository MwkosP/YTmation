"""L'Hôpital's rule — 0/0 limits."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath


def showLhopital(
    scene: Scene,
    f=None,
    g=None,
    x_target: float = 0.0,
    run_time: float = 2.2,
) -> VGroup:
    f = f or (lambda x: np.sin(x))
    g = g or (lambda x: x if abs(x) > 1e-6 else 1e-6)
    axes_g = makeLabeledAxes(x_range=(-2, 2, 1), y_range=(-2, 2, 1))
    gf = plotOnAxes(axes_g, f, x_range=(-2, 2), color=BLUE)
    gg = plotOnAxes(axes_g, g, x_range=(-2, 2), color="#FF4500")
    cap = makeMath(r"\lim \frac{f}{g} = \lim \frac{f'}{g'}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(gf), Create(gg), run_time=run_time)
    return VGroup(axes_g, gf, gg, cap)
