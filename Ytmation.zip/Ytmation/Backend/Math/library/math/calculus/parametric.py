"""Parametric curves — velocity vector along path."""

from manim import *
import numpy as np

from Math.library.math.calculus._core import makeMath


def showParametricVelocity(
    scene: Scene,
    x_func=None,
    y_func=None,
    t_range: tuple = (0, 2 * PI, PI / 4),
    t0: float = 1.0,
    run_time: float = 2.2,
) -> VGroup:
    x_func = x_func or (lambda t: np.cos(t))
    y_func = y_func or (lambda t: np.sin(t))
    ts = np.linspace(t_range[0], t_range[1], 120)
    points = [np.array([x_func(t), y_func(t), 0]) for t in ts]
    curve = VMobject(color=BLUE, stroke_width=3).set_points_smoothly(points)
    pos = np.array([x_func(t0), y_func(t0), 0])
    dt = 0.08
    vel = np.array([(x_func(t0 + dt) - x_func(t0)) / dt, (y_func(t0 + dt) - y_func(t0)) / dt, 0])
    vel = vel / max(np.linalg.norm(vel), 1e-9) * 1.2
    dot = Dot(pos, color=YELLOW)
    arrow = Arrow(pos, pos + vel, buff=0, color="#FF4500", stroke_width=4)
    cap = makeMath(r"\vec{v}=(x'(t),y'(t))").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(curve), FadeIn(dot), GrowArrow(arrow), run_time=run_time)
    return VGroup(curve, dot, arrow, cap)
