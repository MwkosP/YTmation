"""Improper integrals — limit of proper integrals."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath
from Math.library.math.calculus.integral import makeIntegralArea


def showImproperIntegral(
    scene: Scene,
    func=None,
    a: float = 1.0,
    b_values: list[float] | None = None,
    run_time: float = 2.5,
) -> VGroup:
    func = func or (lambda x: 1 / (x**2) if x > 0.1 else 10)
    b_values = b_values or [2, 4, 8, 16]
    axes_g = makeLabeledAxes(x_range=(0, 18, 2), y_range=(0, 1.2, 0.2), x_label="x", y_label="f(x)")
    graph = plotOnAxes(axes_g, func, x_range=(0.2, 17), color=BLUE)
    cap = makeMath(r"\int_a^\infty f = \lim_{b\to\infty}\int_a^b f").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), run_time=run_time * 0.3)
    area = makeIntegralArea(axes_g, graph, a, b_values[0])
    scene.play(FadeIn(area), run_time=run_time * 0.2)
    per = (run_time * 0.4) / max(1, len(b_values) - 1)
    for b in b_values[1:]:
        new_area = makeIntegralArea(axes_g, graph, a, b)
        scene.play(Transform(area, new_area), run_time=per)
    return VGroup(axes_g, graph, area, cap)
