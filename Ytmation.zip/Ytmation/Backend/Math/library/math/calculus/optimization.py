"""Optimization: critical points on a curve."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath, numericalDerivative
from Math.library.math.calculus.derivative import makeTangentLine


def findCriticalPoints(func, x_min: float, x_max: float, n_samples: int = 200) -> list[float]:
    xs = np.linspace(x_min, x_max, n_samples)
    crit = []
    for i in range(1, len(xs) - 1):
        d_prev = numericalDerivative(func, xs[i - 1])
        d_next = numericalDerivative(func, xs[i + 1])
        if d_prev * d_next <= 0 and abs(numericalDerivative(func, xs[i])) < 0.15:
            crit.append(float(xs[i]))
    return crit[:4]


def showCriticalPoints(
    scene: Scene,
    func=None,
    x_range: tuple = (-2, 2, 1),
    run_time: float = 2.2,
) -> VGroup:
    func = func or (lambda x: x**3 - 3 * x)
    axes_g = makeLabeledAxes(x_range=x_range, y_range=(-4, 4, 1))
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(x_range[0], x_range[1]), color=BLUE)
    dots = VGroup()
    for xc in findCriticalPoints(func, x_range[0], x_range[1]):
        dots.add(Dot(axes.c2p(xc, func(xc)), color=YELLOW, radius=0.1))
    label = makeMath(r"f'(x)=0").to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(graph), run_time=run_time * 0.6)
    scene.play(*[FadeIn(d) for d in dots], run_time=run_time * 0.4)
    return VGroup(axes_g, graph, dots, label)
