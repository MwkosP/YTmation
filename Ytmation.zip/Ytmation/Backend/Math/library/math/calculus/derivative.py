"""Derivatives: tangent, secant, definition."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import numericalDerivative, makeMath


def makeGraphWithAxes(
    func,
    x_range: tuple = (-2, 3, 1),
    y_range: tuple = (-1, 5, 1),
) -> tuple[VGroup, VMobject, Axes]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    graph = plotOnAxes(axes_g, func, x_range=(x_range[0], x_range[1]), color=BLUE)
    return axes_g, graph, axes_g[0]


def makeTangentLine(
    axes: Axes,
    func,
    x0: float,
    span: float = 1.2,
    color="#FF4500",
) -> tuple[Dot, VMobject]:
    slope = numericalDerivative(func, x0)
    y0 = func(x0)
    point = Dot(axes.c2p(x0, y0), color=YELLOW, radius=0.09)
    tangent = axes.plot(
        lambda x, m=slope, y0=y0, x0=x0: m * (x - x0) + y0,
        x_range=[x0 - span, x0 + span],
        color=color,
    )
    return point, tangent


def makeSecantLine(
    axes: Axes,
    func,
    x0: float,
    x1: float,
    color=GREEN,
) -> Line:
    return Line(axes.c2p(x0, func(x0)), axes.c2p(x1, func(x1)), color=color, stroke_width=3)


def showDerivativeTangent(
    scene: Scene,
    func,
    x0: float = 1.0,
    x_range: tuple = (-2, 3, 1),
    y_range: tuple = (-1, 5, 1),
    run_time: float = 2.5,
) -> VGroup:
    axes_g, graph, axes = makeGraphWithAxes(func, x_range, y_range)
    point, tangent = makeTangentLine(axes, func, x0)
    scene.play(Create(axes_g), Create(graph), run_time=1.0)
    scene.play(FadeIn(point), Create(tangent), run_time=run_time)
    return VGroup(axes_g, graph, point, tangent)


def showSecantToTangent(
    scene: Scene,
    func,
    x0: float = 1.0,
    h_start: float = 1.2,
    run_time: float = 2.5,
) -> VGroup:
    axes_g, graph, axes = makeGraphWithAxes(func)
    x1 = x0 + h_start
    secant = makeSecantLine(axes, func, x0, x1)
    point, tangent = makeTangentLine(axes, func, x0)
    h_tracker = ValueTracker(h_start)
    dot = Dot(axes.c2p(x1, func(x1)), color="#FF4500", radius=0.08)

    def update_secant(mob):
        xb = x0 + h_tracker.get_value()
        mob.become(makeSecantLine(axes, func, x0, xb, color=GREEN))
        dot.move_to(axes.c2p(xb, func(xb)))

    secant.add_updater(update_secant)
    scene.play(Create(axes_g), Create(graph), Create(secant), FadeIn(dot), run_time=run_time * 0.4)
    scene.play(h_tracker.animate.set_value(0.08), run_time=run_time * 0.45)
    secant.clear_updaters()
    scene.play(Transform(secant, tangent), FadeIn(point), run_time=run_time * 0.15)
    return VGroup(axes_g, graph, secant, point)


def showDerivativeDefinition(
    scene: Scene,
    func,
    x0: float = 1.0,
    run_time: float = 2.0,
) -> VGroup:
    formula = makeMath(
        r"f'(x_0) = \lim_{h\to 0}\frac{f(x_0+h)-f(x_0)}{h}"
    ).to_edge(UP, buff=0.45)
    group = showSecantToTangent(scene, func, x0=x0, run_time=run_time * 0.85)
    scene.play(Write(formula), run_time=run_time * 0.15)
    return VGroup(group, formula)
