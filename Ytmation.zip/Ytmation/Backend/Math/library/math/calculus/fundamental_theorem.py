"""Fundamental Theorem of Calculus — area function and antiderivative."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath
from Math.library.math.calculus.integral import makeIntegralArea


def makeAreaFunctionGraph(
    func,
    a: float = 0.0,
    x_range: tuple = (-0.5, 3, 1),
    y_range: tuple = (-0.5, 5, 1),
) -> tuple[VGroup, VMobject, Axes]:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range, x_label="x", y_label="f(x)")
    graph = plotOnAxes(axes_g, func, x_range=(x_range[0], x_range[1]), color=BLUE)
    return axes_g, graph, axes_g[0]


def showFtcPart1(
    scene: Scene,
    func,
    a: float = 0.0,
    b: float = 2.0,
    run_time: float = 2.2,
) -> VGroup:
    """∫_a^b f = F(b)-F(a) — shaded area + formula."""
    axes_g, graph, axes = makeAreaFunctionGraph(func)
    area = makeIntegralArea(axes_g, graph, a, b)
    formula = makeMath(r"\int_a^b f(x)\,dx = F(b)-F(a)").to_edge(UP, buff=0.45)
    scene.play(Write(formula), Create(axes_g), Create(graph), run_time=run_time * 0.5)
    scene.play(FadeIn(area), run_time=run_time * 0.5)
    return VGroup(axes_g, graph, area, formula)


def showFtcPart2(
    scene: Scene,
    func,
    a: float = 0.0,
    x_end: float = 2.5,
    run_time: float = 2.5,
) -> VGroup:
    """Area from a to x grows; upper bound x is animated."""
    axes_g, graph, axes = makeAreaFunctionGraph(func, a=a)
    x_track = ValueTracker(a + 0.3)
    area = always_redraw(
        lambda: axes.get_area(
            graph,
            x_range=(a, max(a + 0.05, x_track.get_value())),
            color=GREEN,
            opacity=0.4,
        )
    )
    bound_line = always_redraw(
        lambda: DashedLine(
            axes.c2p(x_track.get_value(), axes.y_range[0]),
            axes.c2p(x_track.get_value(), axes.y_range[1]),
            color=YELLOW,
        )
    )
    cap = makeMath(r"A(x)=\int_a^x f(t)\,dt").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), run_time=run_time * 0.35)
    scene.add(area, bound_line)
    scene.play(x_track.animate.set_value(x_end), run_time=run_time * 0.55)
    return VGroup(axes_g, graph, area, bound_line, cap)
