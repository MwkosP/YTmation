"""Quotient rule."""

from manim import *

from Math.library.math.calculus._core import makeMath, makeStepList, playStepReveal


def showQuotientRule(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.0,
) -> VGroup:
    steps = steps or [
        r"\left(\frac{u}{v}\right)'",
        r"=\frac{u'v-uv'}{v^2}",
    ]
    rows = makeStepList(steps)
    cap = makeMath(r"\text{quotient rule}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), FadeIn(rows[0]), run_time=run_time * 0.45)
    playStepReveal(scene, rows, 1, run_time=run_time * 0.45)
    return VGroup(rows, cap)
