"""Solids of revolution — disk method (2D schematic)."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath


def showDiskMethod(
    scene: Scene,
    func=None,
    a: float = 0.0,
    b: float = 2.0,
    run_time: float = 2.2,
) -> VGroup:
    func = func or (lambda x: 0.4 * x + 0.5)
    axes_g = makeLabeledAxes(x_range=(0, 3, 1), y_range=(0, 3, 1), x_label="x", y_label="y")
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(0, 3), color=BLUE)
    x_slice = 1.2
    r = func(x_slice)
    disk = Circle(radius=axes.c2p(0, r)[1] - axes.c2p(0, 0)[1], color=GREEN, fill_opacity=0.35)
    disk.move_to(axes.c2p(x_slice, 0) + UP * (disk.radius))
    line = DashedLine(axes.c2p(x_slice, 0), axes.c2p(x_slice, r), color=YELLOW)
    cap = makeMath(r"V=\pi\int_a^b [f(x)]^2\,dx").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), run_time=run_time * 0.5)
    scene.play(Create(line), FadeIn(disk), run_time=run_time * 0.5)
    return VGroup(axes_g, graph, disk, line, cap)
