"""Second derivative, concavity, inflection."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import numericalDerivative, makeMath


def showConcavity(
    scene: Scene,
    func=None,
    x_range: tuple = (-2, 2, 1),
    run_time: float = 2.2,
) -> VGroup:
    func = func or (lambda x: x**3 - 3 * x)
    axes_g = makeLabeledAxes(x_range=x_range, y_range=(-4, 4, 1))
    graph = plotOnAxes(axes_g, func, x_range=(x_range[0], x_range[1]), color=BLUE)
    axes = axes_g[0]
    xs = np.linspace(x_range[0], x_range[1], 80)
    concave_up = VGroup()
    concave_down = VGroup()
    for i in range(len(xs) - 1):
        xm = (xs[i] + xs[i + 1]) / 2
        f2 = numericalDerivative(lambda x: numericalDerivative(func, x), xm)
        seg = Line(axes.c2p(xs[i], func(xs[i])), axes.c2p(xs[i + 1], func(xs[i + 1])), stroke_width=4)
        if f2 >= 0:
            seg.set_color(GREEN)
            concave_up.add(seg)
        else:
            seg.set_color("#FF4500")
            concave_down.add(seg)
    cap = makeMath(r"f''>0 \Rightarrow \text{concave up}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), run_time=run_time * 0.35)
    scene.play(Create(concave_up), Create(concave_down), run_time=run_time * 0.65)
    return VGroup(axes_g, concave_up, concave_down, cap)


def showInflectionPoint(
    scene: Scene,
    func=None,
    run_time: float = 2.0,
) -> VGroup:
    func = func or (lambda x: x**3)
    axes_g = makeLabeledAxes(x_range=(-2, 2, 1), y_range=(-4, 4, 1))
    graph = plotOnAxes(axes_g, func, x_range=(-2, 2), color=BLUE)
    dot = Dot(axes_g[0].c2p(0, 0), color=YELLOW, radius=0.1)
    cap = makeMath(r"f''=0 \Rightarrow \text{inflection}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), FadeIn(dot), run_time=run_time)
    return VGroup(axes_g, graph, dot, cap)
