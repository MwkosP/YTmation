# Calculus Library — Agent Cookbook

Pure calculus primitives for workflows; physics/ML import `graphs` + these blocks.

## API layers

| Prefix | Use when |
|--------|----------|
| `make…` | Mobjects only — you `scene.play` |
| `show…` | One beat |
| `demo…` | Full topic (`recipes.py`) |

## Module map (~90% intro single-variable + light multivar)

| File | Topics |
|------|--------|
| `derivative.py` | tangent, secant→tangent, limit definition |
| `limit.py` | one-sided, two-sided, removable hole |
| `integral.py` | shaded area, Riemann sum refinement |
| `fundamental_theorem.py` | FTC part 1 & 2 (area function) |
| `chain_rule.py` | composite graph, pipeline diagram |
| `product_rule.py` | rectangle area model |
| `quotient_rule.py` | formula steps |
| `second_derivative.py` | concavity coloring, inflection |
| `mvt.py` | mean value theorem |
| `lhopital.py` | 0/0 limit rule |
| `differential.py` | dx, dy, linear approximation |
| `substitution.py` | u-sub steps, axis map |
| `integration_by_parts.py` | IBP formula steps |
| `improper_integral.py` | limit b→∞ |
| `volume.py` | disk method schematic |
| `related_rates.py` | ladder schematic |
| `series_convergence.py` | integral test (harmonic) |
| `parametric.py` | velocity along parametric curve |
| `taylor.py` | Maclaurin sin, Taylor build-up |
| `fourier.py` | square wave partial sums |
| `ode.py` | slope field, Euler solution curve |
| `multivariable.py` | contours, ∂f/∂x slice, gradient |
| `optimization.py` | critical points f'=0 |

## Recipes (37 demos)

Core: `demoDerivative`, `demoSecantToTangent`, `demoDerivativeDefinition`, `demoLimit`, `demoLimitBothSides`, `demoRemovableDiscontinuity`, `demoIntegral`, `demoRiemannSum`, `demoTaylor`, `demoTaylorBuildUp`, `demoFourier`, `demoFourierBuildUp`, `demoSlopeField`, `demoSlopeFieldSolution`, `demoContourLines`, `demoPartialDerivative`, `demoCriticalPoints`

Extended: `demoFtcPart1`, `demoFtcPart2`, `demoChainRule`, `demoChainRuleDiagram`, `demoProductRule`, `demoQuotientRule`, `demoConcavity`, `demoInflection`, `demoMeanValueTheorem`, `demoLhopital`, `demoImproperIntegral`, `demoDiskMethod`, `demoRelatedRates`, `demoIntegralTest`, `demoDifferential`, `demoUSubstitution`, `demoUSubstitutionArea`, `demoIntegrationByParts`, `demoParametricVelocity`, `demoGradient`

## Showcase

```bash
python Workflows/channels/mathmwk/calculusShowcase.py
```

→ `Cache/math/calculus_showcase_*.mp4` → `Cache/stitched/mathmwk_calculus_showcase_<ts>.mp4`

## Compose example

```python
def scene4(scene):
    from Math.library.common.styling import setupScene
    from Math.library.math.calculus.fundamental_theorem import showFtcPart1
    from Math.library.math.calculus.chain_rule import showChainRule

    setupScene(scene)
    showFtcPart1(scene, lambda x: x**2, a=0, b=2, run_time=1.8)
    showChainRule(scene, run_time=1.8)
```

## Still optional (beyond 90%)

ε–δ formal limits, washer/shell volume, arc length, polar area, power series ratio test, Green/Stokes, PDE heat equation.

## Layout note

Titles/formulas may overlap diagrams until `common/layout.py` gets safe zones — same as other domains.
