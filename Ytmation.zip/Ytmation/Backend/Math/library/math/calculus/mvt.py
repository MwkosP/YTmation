"""Mean Value Theorem."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath, numericalDerivative
from Math.library.math.calculus.derivative import makeSecantLine, makeTangentLine


def showMeanValueTheorem(
    scene: Scene,
    func=None,
    a: float = 0.5,
    b: float = 2.5,
    run_time: float = 2.5,
) -> VGroup:
    func = func or (lambda x: 0.2 * x**2 + 0.5)
    axes_g = makeLabeledAxes(x_range=(0, 3, 1), y_range=(0, 4, 1))
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(0, 3), color=BLUE)
    secant = makeSecantLine(axes, func, a, b, color=YELLOW)
    slope = (func(b) - func(a)) / (b - a)
    c = a + (b - a) / 2
    for t in np.linspace(a, b, 40):
        if abs(numericalDerivative(func, t) - slope) < 0.2:
            c = t
            break
    point, tangent = makeTangentLine(axes, func, c, color="#FF4500")
    cap = makeMath(r"f'(c)=\frac{f(b)-f(a)}{b-a}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(axes_g), Create(graph), Create(secant), run_time=run_time * 0.45)
    scene.play(FadeIn(point), Create(tangent), run_time=run_time * 0.55)
    return VGroup(axes_g, graph, secant, tangent, cap)
