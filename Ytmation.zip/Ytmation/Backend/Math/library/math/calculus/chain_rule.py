"""Chain rule — composite functions."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath


def showChainRule(
    scene: Scene,
    inner=None,
    outer=None,
    x_range: tuple = (-2, 2, 1),
    run_time: float = 2.2,
) -> VGroup:
    inner = inner or (lambda x: x**2)
    outer = outer or (lambda u: np.sin(u))
    composed = lambda x: outer(inner(x))
    axes_g = makeLabeledAxes(x_range=x_range, y_range=(-1.5, 1.5, 0.5))
    g_inner = plotOnAxes(axes_g, inner, x_range=(x_range[0], x_range[1]), color=BLUE)
    g_comp = plotOnAxes(axes_g, composed, x_range=(x_range[0], x_range[1]), color="#FF4500")
    formula = makeMath(r"(f\circ g)'(x)=f'(g(x))\cdot g'(x)").to_edge(UP, buff=0.45)
    scene.play(Write(formula), Create(axes_g), Create(g_inner), run_time=run_time * 0.45)
    scene.play(Create(g_comp), run_time=run_time * 0.55)
    return VGroup(axes_g, g_inner, g_comp, formula)


def showChainRuleDiagram(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    """x → g(x) → f(g(x)) pipeline."""
    boxes = VGroup()
    for tex, color in [(r"x", WHITE), (r"g(x)", BLUE), (r"f(g(x))", "#FF4500")]:
        r = RoundedRectangle(width=1.6, height=0.9, corner_radius=0.12, color=color)
        t = makeMath(tex, scale=0.75).move_to(r)
        boxes.add(VGroup(r, t))
    boxes.arrange(RIGHT, buff=0.55)
    arrows = VGroup(*[Arrow(boxes[i].get_right(), boxes[i + 1].get_left(), buff=0.08) for i in range(2)])
    cap = makeMath(r"\text{chain rule}").to_edge(UP, buff=0.45)
    scene.play(Write(cap), Create(boxes), Create(arrows), run_time=run_time)
    return VGroup(boxes, arrows, cap)
