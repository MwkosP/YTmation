"""Limits: one-sided approach, both sides."""

from manim import *
import numpy as np

from Math.library.math.graphs.axes import makeLabeledAxes, plotOnAxes
from Math.library.math.calculus._core import makeMath


def makeLimitPoints(
    axes: Axes,
    func,
    x_target: float,
    side: str = "left",
) -> tuple[Dot, Dot]:
    target = Dot(axes.c2p(x_target, func(x_target)), color=YELLOW, radius=0.1)
    start_x = x_target - 1.5 if side == "left" else x_target + 1.5
    mover = Dot(axes.c2p(start_x, func(start_x)), color="#FF4500", radius=0.08)
    return target, mover


def showLimitApproach(
    scene: Scene,
    func,
    x_target: float = 2.0,
    x_range: tuple = (0, 4, 1),
    y_range: tuple = (-1, 6, 1),
    side: str = "left",
    run_time: float = 2.0,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=x_range, y_range=y_range)
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(x_range[0], x_range[1]), color=BLUE)
    target, mover = makeLimitPoints(axes, func, x_target, side)
    scene.play(Create(axes_g), Create(graph), FadeIn(target), FadeIn(mover), run_time=1.0)
    eps = 0.05
    dest_x = x_target - eps if side == "left" else x_target + eps
    scene.play(
        mover.animate.move_to(axes.c2p(dest_x, func(dest_x))),
        run_time=run_time,
        rate_func=smooth,
    )
    return VGroup(axes_g, graph, target, mover)


def showLimitBothSides(
    scene: Scene,
    func,
    x_target: float = 0.0,
    run_time: float = 2.2,
) -> VGroup:
    axes_g = makeLabeledAxes(x_range=(-2, 2, 1), y_range=(-1, 5, 1))
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(-2, 2), color=BLUE)
    target = Dot(axes.c2p(x_target, func(x_target)), color=YELLOW, radius=0.1)
    left, mover_l = makeLimitPoints(axes, func, x_target, "left")
    right, mover_r = makeLimitPoints(axes, func, x_target, "right")
    caption = makeMath(r"\lim_{x\to x_0} f(x)").to_edge(UP, buff=0.45)
    scene.play(Write(caption), Create(axes_g), Create(graph), FadeIn(target), run_time=run_time * 0.35)
    scene.play(FadeIn(mover_l), FadeIn(mover_r), run_time=run_time * 0.15)
    scene.play(
        mover_l.animate.move_to(axes.c2p(x_target - 0.05, func(x_target))),
        mover_r.animate.move_to(axes.c2p(x_target + 0.05, func(x_target))),
        run_time=run_time * 0.5,
    )
    return VGroup(axes_g, graph, target, mover_l, mover_r, caption)


def showRemovableDiscontinuity(
    scene: Scene,
    run_time: float = 2.0,
) -> VGroup:
    """(x^2-1)/(x-1) with hole at x=1."""
    func = lambda x: x + 1 if abs(x - 1) > 1e-6 else 1.999
    axes_g = makeLabeledAxes(x_range=(-1, 3, 1), y_range=(0, 4, 1))
    axes = axes_g[0]
    graph = plotOnAxes(axes_g, func, x_range=(-1, 2.9), color=BLUE)
    hole = Circle(radius=0.08, color=BLACK, fill_opacity=1).move_to(axes.c2p(1, 2))
    open_dot = Circle(radius=0.08, color=YELLOW).move_to(axes.c2p(1, 2))
    label = makeMath(r"\text{hole at } x=1").to_edge(UP, buff=0.45)
    scene.play(Write(label), Create(axes_g), Create(graph), FadeIn(open_dot), run_time=run_time)
    return VGroup(axes_g, graph, open_dot, label)
