"""Integration by parts."""

from manim import *

from Math.library.math.calculus._core import makeMath, makeStepList, playStepReveal


def showIntegrationByParts(
    scene: Scene,
    steps: list[str] | None = None,
    run_time: float = 2.2,
) -> VGroup:
    steps = steps or [
        r"\int u\,dv = uv - \int v\,du",
        r"\text{choose } u,\ dv",
        r"\text{find } du,\ v",
        r"\text{evaluate}",
    ]
    rows = makeStepList(steps)
    banner = makeMath(r"\int u\,dv = uv - \int v\,du").scale(0.9).to_edge(UP, buff=0.45)
    scene.play(Write(banner), FadeIn(rows[0]), run_time=run_time * 0.35)
    for i in range(1, len(rows)):
        playStepReveal(scene, rows, i, run_time=run_time * 0.16)
    return VGroup(rows, banner)
