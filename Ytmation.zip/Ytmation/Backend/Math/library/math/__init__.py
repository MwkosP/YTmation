"""Pure math building blocks."""

from Math.library.math.graphs import makeLabeledAxes, plotOnAxes, animateDotOnPath, makeNumberLine
from Math.library.math.linear_algebra.vectors import makeVectorArrow, decomposeVector, addVectorsTipToTail
from Math.library.math.recipes import (
    demoDerivative,
    demoIntegral,
    demoQuadratic,
    demoPythagorean,
    demoSineCos,
    demoMatrixTransform,
    demoNormalDist,
    demoPrimeSieve,
)

__all__ = [
    "makeLabeledAxes",
    "plotOnAxes",
    "animateDotOnPath",
    "makeNumberLine",
    "makeVectorArrow",
    "decomposeVector",
    "addVectorsTipToTail",
    "demoDerivative",
    "demoIntegral",
    "demoQuadratic",
    "demoPythagorean",
    "demoSineCos",
    "demoMatrixTransform",
    "demoNormalDist",
    "demoPrimeSieve",
]
