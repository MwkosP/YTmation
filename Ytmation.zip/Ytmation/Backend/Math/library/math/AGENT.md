# Math Library — Agent Cookbook

## Role: shared base layer

`library/math/` is **pure math** — no physics, ML, or economics story. Other domains **import and compose** it:

```text
library/math/          ← graphs, algebra, calculus, … (this package)
library/physics/       ← wraps math (e.g. kinematics → makeLabeledAxes)
library/ml/            ← loss curves, gradients (future; uses math.graphs)
library/economics/     ← supply/demand axes (future)
```

**Design rules for every `math/` function:**

1. **Specific enough** to do one job well (`plotOnAxes`, `decomposeVector`).
2. **Generic enough** that physics/ML/economics can call it without physics-only params.
3. **No domain narrative** in names or defaults (no “projectile”, “loss”, “GDP” in `math/`).
4. **Prefer `make…` returning mobjects** so callers control `scene.play` and combine with their own titles.
5. **Domain modules thin-wrap** when they need different labels/units (`makeMotionAxes` → `makeLabeledAxes` with `t`, `x`).

Domain-specific **demos** live in `physics/recipes.py`, `ml/recipes.py`, etc. — not in `math/recipes.py` unless the topic is pure math.

## Easiest: recipes

```python
from Math.library.common.styling import setupScene
from Math.library.math.recipes import demoDerivative

setupScene(scene)
demoDerivative(scene)
```

| Recipe | Topic |
|--------|--------|
| `demoDerivative` | Tangent line |
| `demoIntegral` | Area under curve |
| `demoQuadratic` | Parabola + roots |
| `demoPythagorean` | a²+b²=c² |
| `demoSineCos` | sin & cos on same axes |
| `demoMatrixTransform` | 2×2 matrix on square |
| `demoNormalDist` | Bell curve (see `statistics/AGENT.md` for full stats library) |
| `demoPrimeSieve` | Eratosthenes grid |

## Core primitives

| Module | Functions |
|--------|-----------|
| `graphs.*` | axes, plots, scatter, shade, asymptotes, polar — see `graphs/AGENT.md` |
| `linear_algebra.*` | vectors, transforms, det, dot, proj, span, eigen — see `linear_algebra/AGENT.md` |
| `trigonometry.sine` | `plotSine`, `animateSinePhase`, `plotSuperposition` |
| `calculus.*` | derivatives, limits, Riemann sums, Taylor, Fourier, slope fields — see `calculus/AGENT.md` |
| `algebra.*` | `makeLinearGraph`, `showFactorTrinomial`, `showSystemIntersection`, … — see `algebra/AGENT.md` |
| `geometry.*` | triangles, circles, area, solids, coordinate, rigid motions — see `geometry/AGENT.md` |
| `statistics.*` | descriptive stats, charts, distributions, inference — see `statistics/AGENT.md` |

## API layers (agents: read this)

| Prefix | Plays on `scene`? | Use when |
|--------|-------------------|----------|
| `make…`, `build…`, `plot…` (no `scene` arg) | **No** — returns mobjects only | Agent controls timing; combine many in **one** `sceneX(scene)` |
| `show…`, `animate…` | **One beat** — may `scene.play` once | Agent chains 2+ beats in the same scene |
| `demo…` (`recipes.py`) | **Full fixed recipe** | Quick single-topic clip or showcase; not for stuffing unrelated topics |

**Default for agents:** import **primitives** (`make…` / `show…` / `animate…`), not only `demo…`.  
A workflow scene often needs title + graph A + graph B + caption — that is **one** `scene()` calling several blocks, not three `demo` calls unless each demo is the whole segment.

**Do not** add library APIs that render an entire segment with no composability (e.g. “render whole algebra lesson” wrappers). Keep full stories in `Workflows/…/sceneX`, built from blocks.

## Rules

- Use for **math videos** and as base layer for `physics/`, `economics/`, etc.
- Not rendered scene strings — import inside `scene(scene)` functions.
- Manim CE only: `from manim import *`
