# Economics Library — Agent Cookbook

## Where things live

| Layer | Path | Use for |
|------|------|---------|
| Shared layout | `Math/library/common/` | `SceneLayout`, titles, captions |
| Economics domain | `Math/library/economics/` | make/show/demo econ blocks |
| Channel showcase | `Workflows/channels/mathmwk/economicsShowcase.py` | Render + stitch catalog |

## API layers

| Prefix | Plays on scene? | Use when |
|------|-------------------|---------|
| `make*` | No | Axes, curve helpers |
| `show*` | Yes (one beat) | Compose inside scenes |
| `demo*` | Yes (mini lesson) | Showcase segments |

## Available demos

- `demoSupplyDemand`, `demoEquilibrium`, `demoDemandShift`, `demoSupplyShift`
- `demoElasticity`, `demoSurplus`, `demoOpportunityCost`
- `demoGDP`, `demoInflation`, `demoUnemployment`
- `demoFiscalPolicy`, `demoMonetaryPolicy`, `demoPhillipsCurve`, `demoBusinessCycle`
- `demoComparativeAdvantage`, `demoMarketStructures`

## Quick usage

```python
from Math.library.common.styling import setupScene
from Math.library.economics.recipes import demoSupplyDemand

setupScene(scene)
demoSupplyDemand(scene)
```

## Render full catalog

```bash
python Workflows/channels/mathmwk/economicsShowcase.py
```
