"""Layout-aware economics show* beats."""

from manim import *

from Math.library.common.layout import SceneLayout, placeInRegion
from Math.library.common.pacing import beatDuration, splitRunTime
from Math.library.economics._core import (
    makePriceQuantityAxes,
    demandCurve,
    supplyCurve,
    equilibrium,
    consumerSurplusPolygon,
    producerSurplusPolygon,
    D_INTERCEPT,
    D_SLOPE,
    S_INTERCEPT,
    S_SLOPE,
    ECON_DEMAND,
    ECON_SUPPLY,
    ECON_ACCENT,
    ECON_ALERT,
)


def _marketCurves(axes: Axes):
    d_int, d_sl = D_INTERCEPT, D_SLOPE
    s_int, s_sl = S_INTERCEPT, S_SLOPE
    return demandCurve(axes, d_int, d_sl), supplyCurve(axes, s_int, s_sl), equilibrium(d_int, d_sl, s_int, s_sl)


def showSupplyDemand(scene: Scene, layout: SceneLayout | None = None, run_time: float | None = None) -> VGroup:
    layout = layout or SceneLayout("standard")
    rt = beatDuration(run_time)
    t1, t2 = splitRunTime(rt, 0.55, 0.45)
    axes = makePriceQuantityAxes()
    d = demandCurve(axes)
    s = supplyCurve(axes)
    labels = VGroup(Text("D", font_size=24, color=ECON_DEMAND), Text("S", font_size=24, color=ECON_SUPPLY)).arrange(DOWN, buff=0.15).next_to(axes, RIGHT, buff=0.2)
    g = VGroup(axes, d, s, labels)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(d), Create(s), run_time=t1)
    scene.play(FadeIn(labels), run_time=t2)
    return g


def showEquilibrium(scene: Scene, layout: SceneLayout | None = None, run_time: float | None = None) -> VGroup:
    layout = layout or SceneLayout("standard")
    rt = beatDuration(run_time)
    t1, t2 = splitRunTime(rt, 0.55, 0.45)
    axes = makePriceQuantityAxes()
    d, s, (q_star, p_star) = _marketCurves(axes)
    dot = Dot(axes.c2p(q_star, p_star), color=ECON_ACCENT, radius=0.08)
    lines = VGroup(
        DashedLine(axes.c2p(0, p_star), dot.get_center(), color=GREY_B),
        DashedLine(dot.get_center(), axes.c2p(q_star, 0), color=GREY_B),
    )
    g = VGroup(axes, d, s, lines, dot)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(d), Create(s), run_time=t1)
    scene.play(Create(lines), FadeIn(dot), run_time=t2)
    return g


def showDemandShift(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = makePriceQuantityAxes()
    d1 = demandCurve(axes, intercept=9)
    d2 = demandCurve(axes, intercept=11)
    arrow = Arrow(axes.c2p(4, 5), axes.c2p(5.5, 6.2), color=ECON_ACCENT, buff=0.08)
    g = VGroup(axes, d1, d2, arrow)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(d1), run_time=run_time * 0.45)
    scene.play(Create(d2), GrowArrow(arrow), run_time=run_time * 0.55)
    return g


def showSupplyShift(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = makePriceQuantityAxes()
    s1 = supplyCurve(axes, intercept=1)
    s2 = supplyCurve(axes, intercept=3)
    g = VGroup(axes, s1, s2)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(s1), run_time=run_time * 0.45)
    scene.play(Create(s2), run_time=run_time * 0.55)
    return g


def showElasticity(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.2) -> VGroup:
    layout = layout or SceneLayout("split")

    def _panel(intercept: float, slope: float, title: str, color) -> VGroup:
        ax = Axes(
            x_range=[0, 6, 2],
            y_range=[0, 10, 2],
            x_length=4.8,
            y_length=3.2,
            axis_config={"include_tip": True, "color": GREY_B},
        )
        curve = ax.plot(lambda q: intercept - slope * q, x_range=[0, intercept / slope - 0.15], color=color)
        lbl = Text(title, font_size=22, color=color).next_to(ax, DOWN, buff=0.15)
        return VGroup(ax, curve, lbl)

    inelastic = _panel(9, 1.6, "Inelastic (steep)", ECON_DEMAND)
    elastic = _panel(9, 0.35, "Elastic (flat)", GREEN_B)
    placeInRegion(inelastic, "left", layout=layout, fit=True)
    placeInRegion(elastic, "right", layout=layout, fit=True)
    scene.play(
        Create(inelastic[0]), Create(inelastic[1]), FadeIn(inelastic[2]),
        Create(elastic[0]), Create(elastic[1]), FadeIn(elastic[2]),
        run_time=run_time,
    )
    return VGroup(inelastic, elastic)


def showSurplus(scene: Scene, layout: SceneLayout | None = None, run_time: float | None = None) -> VGroup:
    layout = layout or SceneLayout("standard")
    rt = beatDuration(run_time)
    t1, t2 = splitRunTime(rt, 0.5, 0.5)
    axes = makePriceQuantityAxes()
    d, s, (q_star, p_star) = _marketCurves(axes)
    cs = consumerSurplusPolygon(axes, q_star, p_star)
    ps = producerSurplusPolygon(axes, q_star, p_star)
    eq_dot = Dot(axes.c2p(q_star, p_star), color=ECON_ACCENT, radius=0.06)
    g = VGroup(axes, d, s, cs, ps, eq_dot)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(d), Create(s), run_time=t1)
    scene.play(FadeIn(cs), FadeIn(ps), FadeIn(eq_dot), run_time=t2)
    return g


def showOpportunityCost(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    ppc = Axes(x_range=[0, 10, 2], y_range=[0, 10, 2], x_length=5.5, y_length=3.5)
    curve = ppc.plot(lambda x: 9 - 0.7 * x, color=ECON_ACCENT)
    label = Text("Trade-off on PPC", font_size=24, color=YELLOW)
    placeInRegion(VGroup(ppc, curve, label), "left", layout=layout, fit=True)
    note = Text("Opportunity cost\nof more X is less Y", font_size=26, color=GREEN_B)
    placeInRegion(note, "right", layout=layout, fit=True)
    scene.play(Create(ppc), Create(curve), FadeIn(label), FadeIn(note), run_time=run_time)
    return VGroup(ppc, curve, label, note)


def showGDP(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    formula = MathTex(r"\mathrm{Y = C + I + G + (X - M)}", color=ECON_ACCENT).scale(1.1)
    placeInRegion(formula, "main", layout=layout, fit=True)
    scene.play(Write(formula), run_time=run_time)
    return VGroup(formula)


def showInflation(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 8, 2], y_range=[0, 8, 2], x_length=6.5, y_length=3.5)
    line = axes.plot(lambda x: 1.5 + 0.5 * x, color=ECON_ALERT)
    label = Text("Price level rising", font_size=24, color=ECON_ALERT)
    g = VGroup(axes, line, label)
    label.next_to(line, UP, buff=0.2)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(line), FadeIn(label), run_time=run_time)
    return g


def showUnemployment(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    left = Text("Unemployment rate", font_size=28, color=ECON_ALERT)
    right = Text("Labor not fully utilized", font_size=26, color=YELLOW)
    placeInRegion(left, "left", layout=layout, fit=True)
    placeInRegion(right, "right", layout=layout, fit=True)
    scene.play(FadeIn(left), FadeIn(right), run_time=run_time)
    return VGroup(left, right)


def showFiscalPolicy(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    spend = Text("Government spending (G) ↑", font_size=26, color=GREEN_B)
    tax = Text("Taxes (T) ↓ or ↑", font_size=26, color=BLUE_B)
    placeInRegion(spend, "left", layout=layout, fit=True)
    placeInRegion(tax, "right", layout=layout, fit=True)
    scene.play(FadeIn(spend), FadeIn(tax), run_time=run_time)
    return VGroup(spend, tax)


def showMonetaryPolicy(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("formula_focus")
    eq = MathTex(r"\mathrm{Interest\ rate \downarrow \Rightarrow Investment \uparrow}", color=ECON_ACCENT)
    placeInRegion(eq, "main", layout=layout, fit=True)
    scene.play(Write(eq), run_time=run_time)
    return VGroup(eq)


def showPhillipsCurve(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 10, 2], y_range=[0, 10, 2], x_length=6.5, y_length=3.5)
    curve = axes.plot(lambda u: 10 - 0.7 * u, color=PURPLE_B)
    xlab = Text("Unemployment", font_size=22).next_to(axes, DOWN)
    ylab = Text("Inflation", font_size=22).next_to(axes, LEFT).rotate(PI / 2)
    g = VGroup(axes, curve, xlab, ylab)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(curve), FadeIn(xlab), FadeIn(ylab), run_time=run_time)
    return g


def showBusinessCycle(scene: Scene, layout: SceneLayout | None = None, run_time: float = 2.0) -> VGroup:
    layout = layout or SceneLayout("standard")
    axes = Axes(x_range=[0, 12, 2], y_range=[0, 6, 1], x_length=7, y_length=3.5)
    cycle = axes.plot(lambda x: 3 + np.sin(x), color=ECON_ACCENT)
    labels = VGroup(Text("boom", font_size=22), Text("recession", font_size=22, color=ECON_ALERT)).arrange(DOWN, buff=0.15).next_to(axes, RIGHT, buff=0.2)
    g = VGroup(axes, cycle, labels)
    placeInRegion(g, "main", layout=layout, fit=True)
    scene.play(Create(axes), Create(cycle), FadeIn(labels), run_time=run_time)
    return g


def showComparativeAdvantage(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    a = Text("Country A: lower opp. cost in cloth", font_size=24, color=BLUE_B)
    b = Text("Country B: lower opp. cost in food", font_size=24, color=GREEN_B)
    placeInRegion(a, "left", layout=layout, fit=True)
    placeInRegion(b, "right", layout=layout, fit=True)
    scene.play(FadeIn(a), FadeIn(b), run_time=run_time)
    return VGroup(a, b)


def showMarketStructures(scene: Scene, layout: SceneLayout | None = None, run_time: float = 1.8) -> VGroup:
    layout = layout or SceneLayout("split")
    comp = Text("Perfect competition\nmany firms, price takers", font_size=24, color=GREEN_B)
    mono = Text("Monopoly\none firm, market power", font_size=24, color=ECON_ALERT)
    placeInRegion(comp, "left", layout=layout, fit=True)
    placeInRegion(mono, "right", layout=layout, fit=True)
    scene.play(FadeIn(comp), FadeIn(mono), run_time=run_time)
    return VGroup(comp, mono)
