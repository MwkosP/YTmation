"""Shared constants + helpers for economics scenes."""

from manim import *

ECON_BG = "#0a0a0a"
ECON_DEMAND = BLUE_B
ECON_SUPPLY = GREEN_B
ECON_ACCENT = YELLOW
ECON_ALERT = RED_B

# Default linear market: P = D_INTERCEPT - D_SLOPE * Q  and  P = S_INTERCEPT + S_SLOPE * Q
D_INTERCEPT = 9.0
D_SLOPE = 0.8
S_INTERCEPT = 1.0
S_SLOPE = 0.7


def equilibrium(
    d_intercept: float = D_INTERCEPT,
    d_slope: float = D_SLOPE,
    s_intercept: float = S_INTERCEPT,
    s_slope: float = S_SLOPE,
) -> tuple[float, float]:
    """Quantity and price where linear supply meets linear demand."""
    q = (d_intercept - s_intercept) / (d_slope + s_slope)
    p = s_intercept + s_slope * q
    return q, p


def makePriceQuantityAxes(x_max: float = 10, y_max: float = 10) -> Axes:
    return Axes(
        x_range=[0, x_max, 2],
        y_range=[0, y_max, 2],
        x_length=6.5,
        y_length=4.0,
        axis_config={"include_tip": True, "color": GREY_B},
    )


def demandCurve(
    axes: Axes,
    intercept: float = D_INTERCEPT,
    slope: float = D_SLOPE,
):
    q_max = (intercept - 0.5) / slope
    return axes.plot(lambda q: intercept - slope * q, x_range=[0, q_max], color=ECON_DEMAND)


def supplyCurve(
    axes: Axes,
    intercept: float = S_INTERCEPT,
    slope: float = S_SLOPE,
):
    return axes.plot(lambda q: intercept + slope * q, x_range=[0, 8.5], color=ECON_SUPPLY)


def consumerSurplusPolygon(
    axes: Axes,
    q_star: float,
    p_star: float,
    d_intercept: float = D_INTERCEPT,
) -> Polygon:
    """Triangle under demand and above equilibrium price (linear demand)."""
    return Polygon(
        axes.c2p(0, d_intercept),
        axes.c2p(q_star, p_star),
        axes.c2p(0, p_star),
        color=ECON_DEMAND,
        fill_opacity=0.28,
        stroke_width=0,
    )


def producerSurplusPolygon(
    axes: Axes,
    q_star: float,
    p_star: float,
    s_intercept: float = S_INTERCEPT,
) -> Polygon:
    """Triangle above supply and below equilibrium price (linear supply)."""
    return Polygon(
        axes.c2p(0, s_intercept),
        axes.c2p(q_star, p_star),
        axes.c2p(0, p_star),
        color=ECON_SUPPLY,
        fill_opacity=0.28,
        stroke_width=0,
    )
