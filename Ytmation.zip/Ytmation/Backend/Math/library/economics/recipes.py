"""Economics recipes — one topic per call."""

from manim import *

from Math.library.common.layout import SceneLayout, makeTitle, makeCaption
from Math.library.common.styling import setupScene
from Math.library.common.pacing import PacingProfile, getPacing, runDemoLesson
from Math.library.economics.shows import (
    showSupplyDemand,
    showEquilibrium,
    showDemandShift,
    showSupplyShift,
    showElasticity,
    showSurplus,
    showOpportunityCost,
    showGDP,
    showInflation,
    showUnemployment,
    showFiscalPolicy,
    showMonetaryPolicy,
    showPhillipsCurve,
    showBusinessCycle,
    showComparativeAdvantage,
    showMarketStructures,
)


def _demo(
    scene: Scene,
    title_text: str,
    layout_preset: str,
    show_fn,
    *,
    caption: str | None = None,
    pacing: PacingProfile | None = None,
) -> None:
    p = pacing or getPacing()
    setupScene(scene)
    layout = SceneLayout(layout_preset)
    cap = makeCaption(caption, layout=layout) if caption else None
    runDemoLesson(
        scene,
        makeTitle(title_text, size=40 if layout_preset != "formula_focus" else 38, layout=layout),
        show_fn,
        layout=layout,
        caption_mob=cap,
        pacing=p,
    )


def demoSupplyDemand(scene: Scene, title_text: str = "Supply and Demand", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "standard", showSupplyDemand, pacing=pacing)


def demoEquilibrium(scene: Scene, title_text: str = "Market Equilibrium", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "standard", showEquilibrium, pacing=pacing)


def demoDemandShift(scene: Scene, title_text: str = "Demand Shift", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "standard", showDemandShift, pacing=pacing)


def demoSupplyShift(scene: Scene, title_text: str = "Supply Shift", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "standard", showSupplyShift, pacing=pacing)


def demoElasticity(scene: Scene, title_text: str = "Price Elasticity", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "split", showElasticity, pacing=pacing)


def demoSurplus(scene: Scene, title_text: str = "Consumer & Producer Surplus", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "standard", showSurplus, pacing=pacing)


def demoOpportunityCost(scene: Scene, title_text: str = "Opportunity Cost", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "split", showOpportunityCost, pacing=pacing)


def demoGDP(scene: Scene, title_text: str = "GDP Components", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "formula_focus", showGDP, pacing=pacing)


def demoInflation(scene: Scene, title_text: str = "Inflation", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "standard", showInflation, pacing=pacing)


def demoUnemployment(scene: Scene, title_text: str = "Unemployment", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "split", showUnemployment, pacing=pacing)


def demoFiscalPolicy(scene: Scene, title_text: str = "Fiscal Policy", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "split", showFiscalPolicy, pacing=pacing)


def demoMonetaryPolicy(scene: Scene, title_text: str = "Monetary Policy", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "formula_focus", showMonetaryPolicy, pacing=pacing)


def demoPhillipsCurve(scene: Scene, title_text: str = "Phillips Curve", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "standard", showPhillipsCurve, pacing=pacing)


def demoBusinessCycle(scene: Scene, title_text: str = "Business Cycle", pacing: PacingProfile | None = None) -> None:
    _demo(
        scene,
        title_text,
        "standard",
        showBusinessCycle,
        caption="Output fluctuates over time",
        pacing=pacing,
    )


def demoComparativeAdvantage(scene: Scene, title_text: str = "Comparative Advantage", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "split", showComparativeAdvantage, pacing=pacing)


def demoMarketStructures(scene: Scene, title_text: str = "Market Structures", pacing: PacingProfile | None = None) -> None:
    _demo(scene, title_text, "split", showMarketStructures, pacing=pacing)
