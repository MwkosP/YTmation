"""Reusable domain blocks for math workflows."""
