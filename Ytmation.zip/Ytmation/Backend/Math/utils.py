import subprocess
import sys
import tempfile
import shutil
from pathlib import Path


def _manimCommand() -> list[str]:
    """Resolve a runnable Manim command across common environments."""
    project_root = Path(__file__).resolve().parent.parent
    # Do not resolve sys.executable — venv pythons are often symlinks to /usr/bin.
    for candidate in (
        project_root / ".venv" / "bin" / "manim",
        Path(sys.executable).parent / "manim",
        Path(sys.prefix) / "bin" / "manim",
    ):
        if candidate.is_file():
            return [str(candidate)]
    found = shutil.which("manim")
    if found:
        return [found]
    # Final fallback when entrypoint script is not installed on PATH.
    return [sys.executable, "-m", "manim"]

QUALITY_FLAGS = {
    "low":    ["-ql"],   # 480p 15fps — fast preview
    "medium": ["-qm"],   # 720p 30fps
    "high":   ["-qh"],   # 1080p 60fps — final render
    "4k":     ["-qk"],   # 4K
}


def _renderManim(
    source: str,
    scene_name: str,
    output: Path,
    quality: str = "medium",
) -> Path:
    flags = QUALITY_FLAGS.get(quality, ["-qm"])
    math_dir = Path(__file__).resolve().parent
    community_dir = math_dir / "community"

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        scene_file = tmp_path / "scene.py"

        path_injection = (
            "import sys\n"
            f"sys.path.insert(0, '{math_dir.parent}')\n"
            f"sys.path.insert(0, '{math_dir}')\n"
            f"sys.path.insert(0, '{community_dir}')\n"
        )
        scene_file.write_text(path_injection + source)

        print(f"   manim {quality} render starting...", flush=True)
        result = subprocess.run([
            *_manimCommand(),
            *flags,
            str(scene_file),
            scene_name,
            "--media_dir", str(tmp_path / "media"),
            "--disable_caching",
        ])

        if result.returncode != 0:
            raise RuntimeError(f"Manim render failed (exit {result.returncode})")

        rendered = list((tmp_path / "media").rglob("*.mp4"))
        if not rendered:
            raise FileNotFoundError("Manim produced no mp4 output")

        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(rendered[0]), str(output))

    print(f"   Done: {output}")
    return output