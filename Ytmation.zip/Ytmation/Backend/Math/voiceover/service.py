"""
SpeechService adapters that use the project's Voice module.
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

from manim_voiceover.helper import remove_bookmarks
from manim_voiceover.services.base import SpeechService

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


class YtmationVoiceService(SpeechService):
    """Generate mp3 during render via Voice.generateVoice()."""

    def __init__(self, lang: str = "en", slow: bool = False, **kwargs):
        kwargs.setdefault("transcription_model", None)
        super().__init__(**kwargs)
        self.lang = lang
        self.slow = slow

    def generate_from_text(
        self,
        text: str,
        cache_dir: str = None,
        path: str = None,
        **kwargs,
    ) -> dict:
        from Voice.voice import generateVoice

        if cache_dir is None:
            cache_dir = self.cache_dir

        input_text = remove_bookmarks(text)
        input_data = {"input_text": input_text, "service": "ytmation_voice"}

        cached = self.get_cached_result(input_data, cache_dir)
        if cached is not None:
            return cached

        audio_name = path or (self.get_audio_basename(input_data) + ".mp3")
        dest = Path(cache_dir) / audio_name
        generateVoice(input_text, lang=self.lang, slow=self.slow, output=dest)

        return {
            "input_text": text,
            "input_data": input_data,
            "original_audio": audio_name,
        }


class YtmationFileVoiceService(SpeechService):
    """Reuse an already-generated mp3 file."""

    def __init__(
        self,
        audio_file: str | Path,
        transcription_model: str | None = None,
        **kwargs,
    ):
        kwargs.setdefault("transcription_model", transcription_model)
        super().__init__(**kwargs)
        self.audio_file = Path(audio_file).resolve()
        if not self.audio_file.is_file():
            raise FileNotFoundError(f"Voice file not found: {self.audio_file}")

    def generate_from_text(
        self,
        text: str,
        cache_dir: str = None,
        path: str = None,
        **kwargs,
    ) -> dict:
        if cache_dir is None:
            cache_dir = self.cache_dir

        input_text = remove_bookmarks(text)
        input_data = {
            "input_text": input_text,
            "service": "ytmation_file",
            "source": str(self.audio_file),
        }

        cached = self.get_cached_result(input_data, cache_dir)
        if cached is not None:
            return cached

        audio_name = path or (self.get_audio_basename(input_data) + self.audio_file.suffix)
        dest = Path(cache_dir) / audio_name
        shutil.copy2(self.audio_file, dest)

        return {
            "input_text": text,
            "input_data": input_data,
            "original_audio": audio_name,
        }
