"""Build inline Manim source for voice-synced custom scenes."""

from __future__ import annotations

import textwrap
from pathlib import Path


def _escapeTriple(text: str) -> str:
    return text.replace("\\", "\\\\").replace('"""', '\\"\\"\\"')


def pregenerateVoice(text: str, output: Path | None = None, **kwargs) -> Path:
    from Voice.voice import generateVoice

    return generateVoice(text, output=output, **kwargs)


def pregenerateOrpheusVoice(text: str, output: Path | None = None, **kwargs) -> Path:
    from Voice.orpheus import generateOrpheusVoice

    if output is None:
        from Voice.voice import OUTPUT_DIR
        from datetime import datetime

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OUTPUT_DIR / f"orpheus_{stamp}.mp3"
    # Use a conservative default max_new_tokens unless caller overrides,
    # so we stay friendly to free ZeroGPU quota.
    kwargs.setdefault("max_new_tokens", 400)
    return generateOrpheusVoice(text, output=output, **kwargs)


def buildVoiceoverScene(
    animation_body: str,
    narration: str,
    voice_path: Path | str | None = None,
    bg_color: str = "#0a0a0a",
    lang: str = "en",
    transcription_model: str | None = None,
    three_d: bool = False,
) -> str:
    narration_safe = _escapeTriple(narration.strip())
    body = textwrap.indent(animation_body.strip(), "            ")
    tm = "None" if transcription_model is None else f'"{transcription_model}"'

    if voice_path is not None:
        service = f"""
        self.set_speech_service(YtmationFileVoiceService(
            audio_file=r"{Path(voice_path).resolve()}",
            transcription_model={tm},
        ))"""
    else:
        service = f"""
        self.set_speech_service(YtmationVoiceService(
            lang="{lang}",
            transcription_model={tm},
        ))"""

    bases = "ThreeDScene, VoiceoverScene" if three_d else "VoiceoverScene"
    return f"""
from manim import *
from manim_voiceover import VoiceoverScene
from Math.voiceover.service import YtmationVoiceService, YtmationFileVoiceService

class CustomScene({bases}):
    def construct(self):
        self.camera.background_color = "{bg_color}"
{service}
        with self.voiceover(text=\"\"\"{narration_safe}\"\"\") as tracker:
{body}
"""
