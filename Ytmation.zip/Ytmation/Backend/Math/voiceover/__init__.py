"""Voiceover helpers and speech service adapters for Math renders."""
