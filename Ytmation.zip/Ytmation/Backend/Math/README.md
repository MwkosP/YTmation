# Math Module

Reusable animation engine for the project.

## Scope

- Keep render/runtime APIs in `Math/math.py`
- Keep Manim subprocess plumbing in `Math/utils.py`
- Keep voiceover adapters in `Math/voiceover/`
- Build reusable domain blocks in `Math/library/`

`Workflows/` files should orchestrate videos, while `Math/` should provide reusable building blocks and render primitives.

## Planned library categories

- `Math/library/math/calculus`
- `Math/library/math/algebra`
- `Math/library/math/linear_algebra`
- `Math/library/math/geometry`
- `Math/library/math/statistics`
- `Math/library/math/number_theory`
- `Math/library/ml`
- `Math/library/physics`
- `Math/library/chemistry`
- `Math/library/economics`
- `Math/library/space`
- `Math/library/text`

## Voiceover note

Use `renderCustomVoiceoverScene(...)` with `tracker.duration`-scaled timing.
If Whisper transcription is unavailable, set `transcription_model=None` and use duration-based sync.
Project-wide TTS entry point: `Voice.generateSpeech(text, model=...)` — see `Voice/SKILL.md`.

Math pre-generation helpers in `Math/voiceover/helpers.py`:
- `pregenerateVoice(...)` for gTTS
- `pregenerateOrpheusVoice(...)` for Orpheus via HF Spaces (subject to token/quota)
