from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
from datetime import datetime

ROOT       = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "Cache" / "images" / "reddit"

BG             = (26, 26, 27)
CARD_BG        = (30, 30, 31)
BORDER         = (52, 53, 54)
TEXT_PRIMARY   = (215, 218, 220)
TEXT_SECONDARY = (129, 131, 132)
UPVOTE_COLOR   = (255, 85, 0)
BTN_BG         = (42, 42, 43)


def _loadFont(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf" if bold else "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ]
    for path in paths:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _wrapText(text: str, font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    words = text.split()
    lines = []
    current = ""
    for word in words:
        test = f"{current} {word}".strip()
        bbox = font.getbbox(test)
        if bbox[2] - bbox[0] <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def _drawUpvoteIcon(draw, cx, cy, size, color):
    """Draw realistic Reddit upvote arrow icon."""
    hw = size // 2
    # arrow head
    draw.polygon([
        (cx, cy),
        (cx - hw, cy + int(size * 0.55)),
        (cx - int(hw * 0.35), cy + int(size * 0.55)),
        (cx - int(hw * 0.35), cy + size),
        (cx + int(hw * 0.35), cy + size),
        (cx + int(hw * 0.35), cy + int(size * 0.55)),
        (cx + hw, cy + int(size * 0.55)),
    ], fill=color)


def _drawDownvoteIcon(draw, cx, cy, size, color):
    """Draw realistic Reddit downvote arrow icon (flipped)."""
    hw = size // 2
    draw.polygon([
        (cx, cy + size),
        (cx - hw, cy + int(size * 0.45)),
        (cx - int(hw * 0.35), cy + int(size * 0.45)),
        (cx - int(hw * 0.35), cy),
        (cx + int(hw * 0.35), cy),
        (cx + int(hw * 0.35), cy + int(size * 0.45)),
        (cx + hw, cy + int(size * 0.45)),
    ], fill=color)


def _drawCommentIcon(draw, cx, cy, size, color):
    """Draw speech bubble comment icon."""
    # bubble body
    draw.ellipse([cx, cy, cx + size, cy + int(size * 0.85)], fill=color)
    # tail
    draw.polygon([
        (cx + int(size * 0.2), cy + int(size * 0.75)),
        (cx + int(size * 0.1), cy + size),
        (cx + int(size * 0.45), cy + int(size * 0.75)),
    ], fill=color)
    # inner white cutout
    pad = int(size * 0.12)
    draw.ellipse(
        [cx + pad, cy + pad, cx + size - pad, cy + int(size * 0.85) - pad],
        fill=CARD_BG
    )


def _drawShareIcon(draw, cx, cy, size, color):
    """Draw share/upload arrow icon."""
    hw = size // 2
    sw = int(size * 0.18)
    # arrow up
    draw.polygon([
        (cx + hw, cy),
        (cx + hw - int(size * 0.3), cy + int(size * 0.38)),
        (cx + hw - sw, cy + int(size * 0.38)),
        (cx + hw - sw, cy + int(size * 0.72)),
        (cx + hw + sw, cy + int(size * 0.72)),
        (cx + hw + sw, cy + int(size * 0.38)),
        (cx + hw + int(size * 0.3), cy + int(size * 0.38)),
    ], fill=color)
    # base platform
    draw.rectangle(
        [cx, cy + int(size * 0.72), cx + size, cy + size],
        fill=color
    )
    draw.rectangle(
        [cx + sw, cy + int(size * 0.72) - sw, cx + size - sw, cy + int(size * 0.72)],
        fill=color
    )


def _drawPillButton(draw, x, y, icon_fn, icon_size, text, font, text_color=TEXT_SECONDARY, bg=BTN_BG) -> int:
    bbox   = font.getbbox(text)
    tw     = bbox[2] - bbox[0]
    th     = bbox[3] - bbox[1]
    pad_x  = 18
    pad_y  = 10
    gap    = 10
    bw     = pad_x + icon_size + gap + tw + pad_x
    bh     = max(icon_size, th) + pad_y * 2

    draw.rounded_rectangle([x, y, x + bw, y + bh], radius=bh // 2, fill=bg)

    icon_x = x + pad_x
    icon_y = y + (bh - icon_size) // 2
    icon_fn(draw, icon_x, icon_y, icon_size, text_color)

    draw.text((icon_x + icon_size + gap, y + pad_y - bbox[1]), text, font=font, fill=text_color)
    return bw


def _drawVotePill(draw, x, y, upvotes, font_count) -> int:
    icon_size = 28
    pad_x     = 14
    pad_y     = 10
    gap       = 8
    divider   = 2

    count_bbox = font_count.getbbox(upvotes)
    count_w    = count_bbox[2] - count_bbox[0]
    count_h    = count_bbox[3] - count_bbox[1]

    bh = max(icon_size, count_h) + pad_y * 2
    bw = pad_x + icon_size + gap + count_w + gap + divider + gap + icon_size + pad_x

    # pill bg
    draw.rounded_rectangle([x, y, x + bw, y + bh], radius=bh // 2, fill=(60, 35, 20))

    # upvote icon
    up_x = x + pad_x
    up_y = y + (bh - icon_size) // 2
    _drawUpvoteIcon(draw, up_x + icon_size // 2, up_y, icon_size, UPVOTE_COLOR)

    # upvote count
    draw.text((up_x + icon_size + gap, y + pad_y - count_bbox[1]), upvotes, font=font_count, fill=UPVOTE_COLOR)

    # divider
    div_x = up_x + icon_size + gap + count_w + gap
    draw.rectangle([div_x, y + 10, div_x + divider, y + bh - 10], fill=(90, 50, 20))

    # downvote icon
    dv_x = div_x + divider + gap
    dv_y = y + (bh - icon_size) // 2
    _drawDownvoteIcon(draw, dv_x + icon_size // 2, dv_y, icon_size, TEXT_SECONDARY)

    return bw


def generateRedditCard(
    title: str,
    subreddit: str = "r/psychology",
    username: str = "u/throwaway_28492",
    upvotes: str = "12.4k",
    comments: str = "847",
    time_posted: str = "6 hours ago",
    output: str | Path = None,
    width: int = 1080,
) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if output is None:
        stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
        output = OUTPUT_DIR / f"reddit_card_{stamp}.png"

    font_title  = _loadFont(38, bold=True)
    font_meta   = _loadFont(24)
    font_sub    = _loadFont(26, bold=True)
    font_btn    = _loadFont(24, bold=True)
    font_count  = _loadFont(26, bold=True)

    padding      = 40
    card_width   = width - padding * 2
    inner_width  = card_width - 40
    title_lines  = _wrapText(title, font_title, inner_width)
    title_height = len(title_lines) * 50
    card_height  = 30 + 44 + 20 + title_height + 24 + 70 + 30
    img_height   = card_height + padding * 2

    img  = Image.new("RGBA", (width, img_height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    cx, cy = padding, padding
    draw.rounded_rectangle(
        [cx, cy, cx + card_width, cy + card_height],
        radius=12,
        fill=CARD_BG,
        outline=BORDER,
        width=1
    )

    content_x = cx + 28

    # ─── META ROW ────────────────────────────────────────
    meta_y = cy + 30
    draw.text((content_x, meta_y), subreddit, font=font_sub, fill=TEXT_PRIMARY)
    sub_bbox = font_sub.getbbox(subreddit)
    sub_w    = sub_bbox[2] - sub_bbox[0]
    draw.text(
        (content_x + sub_w + 12, meta_y + 2),
        f"• {username}  •  {time_posted}",
        font=font_meta,
        fill=TEXT_SECONDARY
    )

    # ─── TITLE ───────────────────────────────────────────
    title_y = meta_y + 44
    for i, line in enumerate(title_lines):
        draw.text((content_x, title_y + i * 50), line, font=font_title, fill=TEXT_PRIMARY)

    # ─── BOTTOM ACTION ROW ───────────────────────────────
    icon_size = 26
    btn_y     = title_y + title_height + 28
    btn_x     = content_x

    # vote pill
    vw   = _drawVotePill(draw, btn_x, btn_y, upvotes, font_count)
    btn_x += vw + 10

    # comments button
    cw = _drawPillButton(draw, btn_x, btn_y, _drawCommentIcon, icon_size, f"{comments} Comments", font_btn)
    btn_x += cw + 10

    # share button
    _drawPillButton(draw, btn_x, btn_y, _drawShareIcon, icon_size, "Share", font_btn)

    img.save(str(output), "PNG")
    print(f"Reddit card saved: {output}")
    return Path(output)


if __name__ == "__main__":
    generateRedditCard(
        title="Yo mama fat bro.",
        subreddit="r/psychology",
        username="u/throwaway_28492",
        upvotes="12.4k",
        comments="847",
        time_posted="6 hours ago",
    )