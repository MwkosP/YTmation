#!/usr/bin/env python3
"""Footage module — pick, trim, inspect video clips."""

import random
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from utils import _getVideos, _runFfmpeg

ROOT       = Path(__file__).resolve().parent.parent
OUTPUT_DIR = ROOT / "Cache" / "footage"


def pickClip(folder: str | Path) -> Path:
    """Pick a random video clip from a folder."""
    return random.choice(_getVideos(Path(folder)))


def getClipDuration(path: str | Path) -> float:
    """Get duration of a video file in seconds."""
    result = subprocess.check_output([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(path)
    ])
    return float(result.decode().strip())


def trimClip(
    source: str | Path,
    duration: float,
    start: float = None,
    output: str | Path = None,
) -> Path:
    """
    Trim a video clip to duration seconds.
    If start is None picks a random start point.
    """
    source        = Path(source)
    clip_duration = getClipDuration(source)

    if start is None:
        max_start = max(0, clip_duration - duration)
        start     = random.uniform(0, max_start)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    if output is None:
        output = OUTPUT_DIR / f"{source.stem}_{int(start)}s_{int(duration)}s.mp4"

    _runFfmpeg([
        "-ss", str(start),
        "-i", str(source),
        "-t", str(duration),
        "-c:v", "libx264", "-preset", "veryfast",
        "-c:a", "aac",
        str(output)
    ])

    return Path(output)


def listClips(folder: str | Path) -> list[Path]:
    """List all video clips in a folder."""
    return _getVideos(Path(folder))