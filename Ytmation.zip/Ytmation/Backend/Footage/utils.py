#!/usr/bin/env python3
"""Internal helpers for Footage module."""

import subprocess
from pathlib import Path

EXTENSIONS = [".mp4", ".mov", ".mkv", ".webm", ".avi"]


def _getVideos(folder: Path) -> list[Path]:
    if not folder.exists():
        raise FileNotFoundError(f"Footage folder not found: {folder}")
    videos = [f for f in folder.iterdir() if f.suffix.lower() in EXTENSIONS]
    if not videos:
        raise FileNotFoundError(f"No video files found in {folder}")
    return videos


def _runFfmpeg(args: list[str]) -> None:
    subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *args],
        check=True
    )