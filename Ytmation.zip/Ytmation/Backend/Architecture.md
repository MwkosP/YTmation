# YT Project Architecture — Skill Directory


```
YT/
├── AGENT.md                    ← master agent instructions
├── STRUCTURE.md                ← this file
│
├── Image/                      ← generate & edit images
│   ├── SKILL.md
│   └── image.py
│
├── Motions/                    ← animate images to video
│   ├── SKILL.md
│   └── animate.py
│
├── Video/                      ← cut, trim, merge, effects
│   ├── SKILL.md
│   └── editutils.py
│
├── Blender/                    ← 3D renders & physics
│   ├── SKILL.md
│   ├── main.py
│   ├── scripts/
│   │   ├── render_balls.py
│   │   ├── render_cloth.py
│   │   ├── render_chain.py
│   │   ├── render_cradle.py
│   │   ├── render_dice.py
│   │   ├── render_dominoes.py
│   │   ├── render_wrecking.py
│   │   ├── render_fluid.py
│   │   └── render_glass.py
│   ├── blendymwk/
│   │   ├── __init__.py
│   │   ├── scene.py
│   │   ├── lights.py
│   │   ├── materials.py
│   │   ├── objects.py
│   │   ├── animation.py
│   │   ├── physics.py
│   │   └── render.py
│   └── outputs/
│
├── Voice/                      ← text to speech narration
│   ├── SKILL.md
│   ├── speech.py               ← generateSpeech router
│   ├── voice.py
│   └── orpheus.py
│
├── Characters/                 ← mascot pose timelines on video
│   ├── SKILL.md
│   ├── characters.py
│   └── poses.py
│
├── SFX/                        ← sound effects placement
│   ├── SKILL.md
│   ├── sfx.py
│   └── library/
│
├── Music/                      ← background music
│   ├── SKILL.md
│   ├── music.py
│   └── library/
│
├── Game/                       ← game content creation
│   ├── SKILL.md
│   └── game.py
│
├── Stitching/                  ← final video assembly
│   ├── SKILL.md
│   └── stitch.py
│
├── Thumbnail/                  ← YouTube thumbnail generation
│   ├── SKILL.md
│   └── thumbnail.py
│
├── Captions/                   ← subtitles & transcription
│   ├── SKILL.md
│   └── captions.py
│
├── Upload/                     ← YouTube API uploader
│   ├── SKILL.md
│   └── upload.py
│
├── Script/                     ← AI script & narration writer
│   ├── SKILL.md
│   └── script.py
│
├── Insights/                   ← analytics & trend research
│   ├── SKILL.md
│   └── insights.py
│
├── Translation/                ← multi-language captions
│   ├── SKILL.md
│   └── translate.py
│
├── Branding/                   ← intros, outros, watermarks
│   ├── SKILL.md
│   ├── branding.py
│   └── assets/
│
├── Storage/                    ← file & asset management
│   ├── SKILL.md
│   └── storage.py
│
├── Scheduler/                  ← upload timing & queue
│   ├── SKILL.md
│   └── scheduler.py
│
├── Hooks/                      ← opening 3 second optimizer
│   ├── SKILL.md
│   └── hooks.py
│
├── Templates/                  ← reusable video formats
│   ├── SKILL.md
│   ├── templates.py
│   └── formats/
│       ├── neon_physics.json
│       ├── soundscape_1hr.json
│       └── manhwa_recap.json
│
├── QA/                         ← quality check before upload
│   ├── SKILL.md
│   └── qa.py
│
├── Trends/                     ← real time trend monitoring
│   ├── SKILL.md
│   └── trends.py
│
├── Transitions/               ← effects between clips
│   ├── SKILL.md
│   └── transitions.py
│
│
└── Cache/                      ← reusable asset storage
    ├── SKILL.md
    ├── cache.py
    └── store/
        ├── renders/
        ├── audio/
        ├── images/
        └── scripts/
```

## Image/
Generates, edits, and manipulates images. Handles background removal, upscaling, and AI image generation from prompts.

## Motions/
Animates still images,text or any format into short video clips using local AI models. Takes a PNG/JPG and outputs animated video with optional movement prompts.

## Video/
Cuts, trims, merges, and applies effects to video clips. Handles color grading, filters, speed changes, and text overlays.

## Blender/
Renders 3D physics simulations and animations using Blender. Uses the blendymwk library and render scripts to output video files.

## Voice/
Converts text into voiceover audio. **Primary API:** `generateSpeech(text, model=...)` routes to gTTS, Orpheus, or future backends (ElevenLabs stub). Also provides Whisper transcription and duration via `getAudioDuration` / `transcribeAudio`. See `Voice/SKILL.md`.

## Characters/
Renders timed pose overlays from transparent PNGs (`Templates/characters/`) using pygame + ffmpeg. Supports solid or photo backgrounds via `renderCharacterTimeline`. Spoken intro helpers (`renderCharacterIntro`, `renderSpokenCharacterTimeline`) will compose TTS through `generateSpeech` and mux with `Stitching.overlayAudio`. See `Characters/SKILL.md`.

## SFX/
Fetches and places sound effects at specific timestamps in the video. Handles whoosh, impact, bounce, ASMR, and other audio cues.

## Music/
Manages background music selection and placement. Fetches royalty-free tracks, loops them to video length, and handles fade in/out.

## Game/
Creates game-related video content and assets. Handles gameplay capture, game-style animations, and interactive simulations.

## Transitions/
Creates Transitiosn between clips/images etc.

## Stitching/
Assembles all clips, audio tracks, music, SFX, and captions into one final video file. The last step before publishing.

## Thumbnail/
Auto-generates YouTube thumbnails optimized for CTR. Extracts best frame from video, adds bold text and visual overlays.

## Captions/
Generates subtitles using Whisper transcription. Outputs .srt files for YouTube or burns captions directly into video frames.

## Upload/
Posts finished videos to YouTube via API. Sets title, description, tags, thumbnail, and schedules optimal upload time.

## Script/
Writes video scripts, narration, and hooks using Claude. Structures content with strong opening, engaging body, and clear CTA.

## Insights/
Reads YouTube analytics and external trends to decide what content to make next. Identifies what performed well and recommends next topics.

## Translation/
Translates scripts and captions into multiple languages automatically. Multiplies reach across Spanish, Portuguese, Hindi, and other audiences.

## Branding/
Enforces visual consistency across all videos. Adds intros, outros, watermarks, and color grading presets to every output.

## Storage/
Manages and organizes all generated assets and files. Tracks where every render, clip, audio, and final video lives across jobs.

## Scheduler/
Decides optimal timing and spacing of video uploads. Prevents posting similar content back to back and maintains algorithm momentum.

## Hooks/
Generates and optimizes the first 3 seconds of each video. Tests multiple opening options to maximize viewer retention from the start.

## Templates/
Stores reusable video format definitions. Agent fills in variables to produce consistent daily content without rebuilding from scratch each time.

## QA/
Checks final video quality before uploading. Verifies audio levels, resolution, caption sync, and thumbnail before approving for upload.

## Trends/
Monitors what is trending right now on YouTube, TikTok, and Reddit. Feeds real-time hot topics to the agent for immediate content opportunities.

## Cache/
Stores previously generated assets to avoid redundant regeneration. Reuses renders, voices, and music across multiple videos to save time and compute.